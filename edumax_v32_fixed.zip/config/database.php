<?php
declare(strict_types=1);

/*
 * Database configuration
 *
 * Priority:
 * 1) config/database.local.php
 * 2) EDUMAX_DB_* environment variables
 * 3) Local XAMPP defaults
 */

$config = [
    'host'    => getenv('EDUMAX_DB_HOST') ?: 'localhost',
    'name'    => getenv('EDUMAX_DB_NAME') ?: 'dawaghor_edumax_admission',
    'user'    => getenv('EDUMAX_DB_USER') ?: 'dawaghor_dawaghor_edumax',
    // The real password lives ONLY in config/database.local.php (or the
    // EDUMAX_DB_PASS environment variable). Never hard-code it here.
    'pass'    => getenv('EDUMAX_DB_PASS') ?: '',
    'charset' => getenv('EDUMAX_DB_CHARSET') ?: 'utf8mb4',
];

$localConfigFile = __DIR__ . '/database.local.php';

if (is_file($localConfigFile)) {
    $localConfig = require $localConfigFile;

    if (is_array($localConfig)) {
        $config = array_replace(
            $config,
            array_intersect_key($localConfig, $config)
        );
    }
}

$dsn = sprintf(
    'mysql:host=%s;dbname=%s;charset=%s',
    $config['host'],
    $config['name'],
    $config['charset']
);

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
];

try {
    $pdo = new PDO(
        $dsn,
        $config['user'],
        $config['pass'],
        $options
    );
} catch (PDOException $e) {
    http_response_code(500);

    $isProduction =
        (getenv('EDUMAX_ENV') ?: 'development') === 'production';

    if ($isProduction) {
        exit('Database connection failed. Please contact the administrator.');
    }

    exit(
        'Database connection failed. Check config/database.local.php, environment variables, and MySQL.'
    );
}
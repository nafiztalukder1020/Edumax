<?php
/*
 * Copy this file to: config/database.local.php
 * Then enter the hosting database credentials locally/on the server.
 * Do NOT share or commit the real password.
 */
return [
    'host'    => 'localhost',
    'name'    => 'dawaghor_edumax_admission',
    'user'    => 'dawaghor_dawaghor_edumax',
    'pass'    => 'YOUR_DATABASE_PASSWORD',
    'charset' => 'utf8mb4',
];

<?php

declare(strict_types=1);

/*
 * Session bootstrap
 * Keep the session cookie stable across every page/form in the application.
 * This is especially important for CSRF-protected forms and for localhost/XAMPP.
 */
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    session_name('EDUMAXSESSID');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => '/',
        'secure' => $secure,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

require_once __DIR__ . '/database.php';

/**
 * HTML-escape any scalar value. Accepts int/float/bool as well as strings so
 * that values fetched from PDO (native int types) never trigger a TypeError.
 */
function e(mixed $value): string {
    if ($value === null || is_array($value) || (is_object($value) && !method_exists($value, '__toString'))) {
        return '';
    }
    if (is_bool($value)) {
        $value = $value ? '1' : '0';
    }
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

/**
 * Ensure archive columns exist for older deployments. This is idempotent and
 * only runs the lightweight INFORMATION_SCHEMA check on pages that need it.
 */
function ensure_archive_columns(): void {
    global $pdo;
    static $done = false;
    if ($done) return;

    $checks = [
        ['batches', 'is_archived', "ALTER TABLE batches ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0 AFTER status"],
        ['students', 'is_archived', "ALTER TABLE students ADD COLUMN is_archived TINYINT(1) NOT NULL DEFAULT 0 AFTER photo_path"],
        ['students', 'archived_batch_id', "ALTER TABLE students ADD COLUMN archived_batch_id INT UNSIGNED NULL AFTER is_archived"],
        ['students', 'archived_at', "ALTER TABLE students ADD COLUMN archived_at DATETIME NULL AFTER archived_batch_id"],
    ];

    foreach ($checks as [$table, $column, $alter]) {
        $q = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?");
        $q->execute([$table, $column]);
        if ((int)$q->fetchColumn() === 0) {
            $pdo->exec($alter);
        }
    }

    $done = true;
}

/** Ensure batch recurring-schedule metadata exists. */
function ensure_batch_schedule_columns(): void {
    global $pdo;
    static $done = false;
    if ($done) return;
    $checks = [
        ['batches', 'class_days', "ALTER TABLE batches ADD COLUMN class_days TEXT NULL AFTER time_slots"],
        ['batches', 'schedule_months', "ALTER TABLE batches ADD COLUMN schedule_months TINYINT UNSIGNED NOT NULL DEFAULT 3 AFTER class_days"],
    ];
    foreach ($checks as [$table, $column, $alter]) {
        $q = $pdo->prepare("SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?");
        $q->execute([$table, $column]);
        if ((int)$q->fetchColumn() === 0) {
            $pdo->exec($alter);
        }
    }
    $done = true;
}

/** Infer weekday numbers from legacy batch names such as "sat-wed" or "Sunday-Thursday". */
function infer_batch_days(string $name): array {
    $text = strtolower($name);
    $map = [
        'sunday'=>0,'sun'=>0,
        'monday'=>1,'mon'=>1,
        'tuesday'=>2,'tue'=>2,'tues'=>2,
        'wednesday'=>3,'wed'=>3,
        'thursday'=>4,'thu'=>4,'thur'=>4,'thurs'=>4,
        'friday'=>5,'fri'=>5,
        'saturday'=>6,'sat'=>6,
    ];
    $days = [];
    foreach ($map as $needle => $day) {
        if (strpos($text, $needle) !== false && !in_array($day, $days, true)) {
            $days[] = $day;
        }
    }
    sort($days);
    return $days;
}

/**
 * Generate recurring class placeholders for a batch. Existing class rows are
 * never overwritten, so teacher/topic/routine edits remain safe.
 */
function generate_batch_schedule(int $batchId): int {
    global $pdo;
    ensure_batch_schedule_columns();
    $q = $pdo->prepare("SELECT id,name,start_date,time_slots,class_days,schedule_months,status,is_archived FROM batches WHERE id=? LIMIT 1");
    $q->execute([$batchId]);
    $batch = $q->fetch();
    if (!$batch || (int)($batch['is_archived'] ?? 0) === 1 || empty($batch['start_date'])) return 0;

    $slots = json_decode((string)($batch['time_slots'] ?? ''), true);
    $slots = is_array($slots) ? array_values(array_unique(array_filter(array_map('trim', $slots)))) : [];
    if (!$slots) return 0;

    $days = json_decode((string)($batch['class_days'] ?? ''), true);
    $days = is_array($days) ? array_values(array_unique(array_map('intval', $days))) : [];
    $days = array_values(array_filter($days, static fn($d) => $d >= 0 && $d <= 6));
    if (!$days) {
        $days = infer_batch_days((string)$batch['name']);
        if ($days) {
            $pdo->prepare("UPDATE batches SET class_days=? WHERE id=?")
                ->execute([json_encode($days, JSON_UNESCAPED_UNICODE), $batchId]);
        }
    }
    if (!$days) return 0;

    $months = max(1, min(12, (int)($batch['schedule_months'] ?? 3)));
    $start = new DateTime($batch['start_date']);
    $end = (clone $start)->modify('+' . $months . ' months')->modify('-1 day');

    $exists = $pdo->prepare("SELECT id FROM class_schedules WHERE batch_id=? AND class_date=? AND time_slot=? LIMIT 1");
    $insert = $pdo->prepare("INSERT IGNORE INTO class_schedules (batch_id,class_date,time_slot,teacher_name,room,topic,class_type,status,notes,created_by) VALUES (?,?,?,?,?,?,?,?,?,?)");
    $createdBy = (int)($_SESSION['user_id'] ?? 0);
    $count = 0;

    for ($d = clone $start; $d <= $end; $d->modify('+1 day')) {
        $weekday = (int)$d->format('w');
        if (!in_array($weekday, $days, true)) continue;
        $date = $d->format('Y-m-d');
        foreach ($slots as $slot) {
            $exists->execute([$batchId, $date, $slot]);
            if ($exists->fetch()) continue;
            // INSERT IGNORE + the uq_class_schedule_slot unique key prevent
            // duplicate classes when two requests generate at the same time.
            $insert->execute([$batchId,$date,$slot,null,'Classroom 1',null,'Regular Class','Scheduled',null,$createdBy ?: null]);
            $count += $insert->rowCount();
        }
    }
    return $count;
}

/**
 * Normalize a Bangladesh mobile number to the 11-digit local format
 * (01XXXXXXXXX). Handles +880/880 prefixes and numbers whose leading 0 was
 * stripped by Excel (e.g. 1712345678). Other values are returned digits-only.
 */
function normalize_bd_mobile(?string $mobile): string {
    $digits = preg_replace('/\D+/', '', (string)$mobile) ?? '';
    if (strlen($digits) === 13 && str_starts_with($digits, '880')) {
        $digits = substr($digits, 2);
    } elseif (strlen($digits) === 12 && str_starts_with($digits, '88')) {
        $digits = substr($digits, 2);
    }
    if (strlen($digits) === 10 && $digits[0] === '1') {
        $digits = '0' . $digits;
    }
    return $digits;
}

/**
 * One-time flash messages (stored in the session, shown on the next page).
 * flash('success'|'error', 'text') stores; flash_messages() returns and clears.
 */
if (!function_exists('flash')) {
    function flash(string $type, string $message): void {
        $_SESSION['_flash'][] = ['type' => $type === 'success' ? 'success' : 'error', 'message' => $message];
    }
}

function flash_messages(): array {
    $messages = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return is_array($messages) ? $messages : [];
}

/*
 * CSRF protection
 * Tokens are session-bound and intentionally do not expire while the session
 * is active. A small token history also keeps forms opened in multiple tabs
 * working after another form generates a token.
 */
function csrf_token(): string {
    if (!isset($_SESSION['_csrf_tokens']) || !is_array($_SESSION['_csrf_tokens'])) {
        $_SESSION['_csrf_tokens'] = [];
    }

    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(32));
    }

    if (!in_array($_SESSION['_csrf'], $_SESSION['_csrf_tokens'], true)) {
        $_SESSION['_csrf_tokens'][] = $_SESSION['_csrf'];
    }

    // Keep a small history for multi-tab/back-button compatibility.
    if (count($_SESSION['_csrf_tokens']) > 8) {
        $_SESSION['_csrf_tokens'] = array_slice($_SESSION['_csrf_tokens'], -8);
    }

    return $_SESSION['_csrf'];
}

function csrf_input(): string {
    return '<input type="hidden" name="_csrf" value="'.e(csrf_token()).'">';
}

function csrf_validate(?string $token): bool {
    if (!is_string($token) || $token === '') {
        return false;
    }

    $tokens = $_SESSION['_csrf_tokens'] ?? [];
    if (!is_array($tokens)) {
        $tokens = [];
    }

    // Also accept the current token for compatibility with older sessions.
    if (!empty($_SESSION['_csrf']) && !in_array($_SESSION['_csrf'], $tokens, true)) {
        $tokens[] = $_SESSION['_csrf'];
    }

    foreach ($tokens as $validToken) {
        if (is_string($validToken) && hash_equals($validToken, $token)) {
            return true;
        }
    }

    return false;
}

function require_valid_csrf(): void {
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && !csrf_validate($_POST['_csrf'] ?? null)) {
        http_response_code(419);
        exit('Invalid or expired form token. Please refresh the page and submit the form again.');
    }
}

/*
 * Backward-compatible aliases used by several pages (materials, student
 * profile, mock test, batch transfer). These were previously undefined and
 * caused fatal errors.
 */
if (!function_exists('csrf_field')) {
    function csrf_field(): void {
        echo csrf_input();
    }
}

if (!function_exists('verify_csrf')) {
    function verify_csrf(): void {
        require_valid_csrf();
    }
}

/*
 * Login throttling: blocks an IP/username pair after too many failed attempts.
 * Uses the login_attempts table (created by the v32 migration). If the table
 * is missing, throttling is silently skipped so login keeps working.
 */
const LOGIN_MAX_ATTEMPTS = 5;
const LOGIN_LOCK_MINUTES = 15;

function login_client_ip(): string {
    return substr((string)($_SERVER['REMOTE_ADDR'] ?? 'unknown'), 0, 45);
}

function login_is_locked(string $scope, string $username): bool {
    global $pdo;
    try {
        // Lock the same username from the same IP after LOGIN_MAX_ATTEMPTS
        // failures. A whole IP is only locked after many more failures, so
        // staff sharing one office connection do not lock each other out.
        $q = $pdo->prepare("SELECT
                SUM(username = ?) AS user_failures,
                COUNT(*) AS ip_failures
            FROM login_attempts
            WHERE scope=? AND ip_address=? AND success=0
              AND attempted_at > (NOW() - INTERVAL " . (int)LOGIN_LOCK_MINUTES . " MINUTE)");
        $q->execute([mb_strtolower($username), $scope, login_client_ip()]);
        $row = $q->fetch() ?: [];
        return (int)($row['user_failures'] ?? 0) >= LOGIN_MAX_ATTEMPTS
            || (int)($row['ip_failures'] ?? 0) >= LOGIN_MAX_ATTEMPTS * 6;
    } catch (Throwable $e) {
        return false;
    }
}

function login_record_attempt(string $scope, string $username, bool $success): void {
    global $pdo;
    try {
        if ($success) {
            $pdo->prepare("DELETE FROM login_attempts WHERE scope=? AND ip_address=? AND username=? AND success=0")
                ->execute([$scope, login_client_ip(), mb_strtolower($username)]);
            return;
        }
        $pdo->prepare("INSERT INTO login_attempts (scope, username, ip_address, success) VALUES (?,?,?,0)")
            ->execute([$scope, mb_strtolower(mb_substr($username, 0, 100)), login_client_ip()]);
        // Keep the table small.
        if (random_int(1, 50) === 1) {
            $pdo->exec("DELETE FROM login_attempts WHERE attempted_at < (NOW() - INTERVAL 7 DAY)");
        }
    } catch (Throwable $e) {
        // Throttling must never block a valid login.
    }
}

/*
 * One-time schema compatibility checks (receipt_sequences table and
 * admissions.due_date). These used to run on EVERY request; they now run
 * once per session, which removes several information_schema queries from
 * each page load while keeping older installations working.
 */
if (empty($_SESSION['_schema_boot_v32'])) {
    $schemaBootOk = true;
    /*
     * Receipt sequence table must exist BEFORE any payment transaction starts.
     * MySQL DDL (CREATE TABLE) can implicitly commit a transaction, so this
     * must never be executed from inside next_receipt_number().
     */
    try {
        $pdo->exec("CREATE TABLE IF NOT EXISTS receipt_sequences (
            receipt_year SMALLINT UNSIGNED PRIMARY KEY,
            next_number INT UNSIGNED NOT NULL
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    } catch (Throwable $e) {
        // Leave the connection error to surface when a receipt is actually needed.
        $schemaBootOk = false;
    }

    /*
     * Due-date compatibility: older databases may not have admissions.due_date.
     * Create the nullable column automatically so existing installations keep working.
     */
    try {
        $dueDateColumn = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='admissions' AND COLUMN_NAME='due_date'")->fetchColumn();
        if (!(int)$dueDateColumn) {
            $pdo->exec("ALTER TABLE admissions ADD COLUMN due_date DATE NULL AFTER admission_date");
        }
        $dueDateIndex = $pdo->query("SELECT COUNT(*) FROM information_schema.STATISTICS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='admissions' AND INDEX_NAME='idx_admissions_due_date'")->fetchColumn();
        if (!(int)$dueDateIndex) {
            $pdo->exec("CREATE INDEX idx_admissions_due_date ON admissions (due_date)");
        }
    } catch (Throwable $e) {
        // Existing functionality should continue even if this compatibility check fails.
        $schemaBootOk = false;
    }
    if ($schemaBootOk) {
        $_SESSION['_schema_boot_v32'] = 1;
    }
}

function next_receipt_number(): string {
    global $pdo;

    $year = (int)date('Y');

    // All current callers invoke this inside a transaction. Keep the helper
    // safe if it is ever called outside one as well.
    $ownsTransaction = false;
    if (!$pdo->inTransaction()) {
        $pdo->beginTransaction();
        $ownsTransaction = true;
    }

    try {
        // INSERT IGNORE lets concurrent transactions converge on the same
        // yearly sequence row; SELECT ... FOR UPDATE then serializes allocation.
        $ins = $pdo->prepare(
            'INSERT IGNORE INTO receipt_sequences (receipt_year, next_number) VALUES (?, 1)'
        );
        $ins->execute([$year]);

        $q = $pdo->prepare(
            'SELECT next_number FROM receipt_sequences WHERE receipt_year=? FOR UPDATE'
        );
        $q->execute([$year]);
        $next = $q->fetchColumn();

        if ($next === false) {
            throw new RuntimeException('Unable to initialize receipt sequence.');
        }

        $prefix = 'EDU-RC-' . $year . '-';

        // Find the largest receipt number already stored for this year.
        // SUBSTRING_INDEX extracts the 5-digit sequence portion safely.
        $maxStmt = $pdo->prepare(
            "SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(receipt_no, '-', -1) AS UNSIGNED)), 0)
             FROM payments
             WHERE receipt_no LIKE ?"
        );
        $maxStmt->execute([$prefix . '%']);
        $maxExisting = (int)$maxStmt->fetchColumn();

        $seq = max((int)$next, $maxExisting + 1);

        $update = $pdo->prepare(
            'UPDATE receipt_sequences SET next_number=? WHERE receipt_year=?'
        );
        $update->execute([$seq + 1, $year]);

        $receipt = $prefix . str_pad((string)$seq, 5, '0', STR_PAD_LEFT);

        if ($ownsTransaction) {
            $pdo->commit();
        }

        return $receipt;
    } catch (Throwable $e) {
        if ($ownsTransaction && $pdo->inTransaction()) {
            $pdo->rollBack();
        }
        throw $e;
    }
}

function is_admin(): bool {
    return isset($_SESSION['user_id']);
}

function require_admin(): void {
    if (!is_admin()) {
        header('Location: login.php');
        exit;
    }
}

function has_role(array $roles): bool {
    return is_admin() && in_array($_SESSION['role'] ?? '', $roles, true);
}

function require_role(string ...$roles): void {
    require_admin();
    if (!has_role($roles)) {
        http_response_code(403);
        exit('Access denied.');
    }
}

function ensure_user_permissions_table(): void {
    global $pdo;
    static $done = false;
    if ($done) return;
    $pdo->exec("CREATE TABLE IF NOT EXISTS user_permissions (
        id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        user_id INT UNSIGNED NOT NULL,
        permission_key VARCHAR(80) NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_user_permission (user_id, permission_key),
        FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
    // Give users with no permissions yet a safe starting set based on their role, but never overwrite custom access.
    // Only users that have zero permission rows are touched (single query instead of one query per user).
    $users = $pdo->query('SELECT u.id, u.role FROM users u WHERE NOT EXISTS (SELECT 1 FROM user_permissions p WHERE p.user_id=u.id)')->fetchAll();
    $defaults = [
        'Super Admin' => array_keys(permission_catalog()),
        'Admission Admin' => ['dashboard','new_admission','admissions','students','student_performance','attendance','batch','classes','teachers'],
        'Accounts' => ['dashboard','payments','receipts','reports','students'],
        'Reception' => ['dashboard','new_admission','students','admissions'],
        'Teacher' => ['dashboard','students','attendance','student_performance'],
    ];
    $countStmt = $pdo->prepare('SELECT COUNT(*) FROM user_permissions WHERE user_id=?');
    $ins = $pdo->prepare('INSERT IGNORE INTO user_permissions (user_id, permission_key) VALUES (?,?)');
    foreach ($users as $u) {
        $countStmt->execute([(int)$u['id']]);
        if ((int)$countStmt->fetchColumn() === 0) {
            foreach (($defaults[$u['role']] ?? ['dashboard']) as $perm) $ins->execute([(int)$u['id'], $perm]);
        }
    }
    $done = true;
}

function permission_catalog(): array {
    return [
        'dashboard' => 'Dashboard',
        'new_admission' => 'New Admission',
        'admissions' => 'Admissions & Processing',
        'batch' => 'Batch Management',
        'classes' => 'Class Management',
        'teachers' => 'Teachers & Rooms',
        'attendance' => 'Attendance',
        'students' => 'Students',
        'student_performance' => 'Student Performance',
        'payments' => 'Payments & Due Payment',
        'receipts' => 'Receipts',
        'reports' => 'Reports & Monthly Audit',
        'system_check' => 'System Check',
        'admin_users' => 'Admin Users',
        'consultancy_dashboard' => 'Consultancy Dashboard',
        'consultancy_enquiries' => 'Consultancy Enquiries',
    ];
}

function is_super_admin(): bool {
    return is_admin() && (($_SESSION['role'] ?? '') === 'Super Admin');
}

function user_has_permission(string $permission): bool {
    if (!is_admin()) return false;
    if (is_super_admin()) return true;
    ensure_user_permissions_table();
    global $pdo;
    $stmt = $pdo->prepare('SELECT 1 FROM user_permissions WHERE user_id=? AND permission_key=? LIMIT 1');
    $stmt->execute([(int)$_SESSION['user_id'], $permission]);
    return (bool)$stmt->fetchColumn();
}

function require_access(string $permission): void {
    require_admin();
    if (!user_has_permission($permission)) {
        http_response_code(403);
        exit('Access denied. You do not have permission to access this section.');
    }
}


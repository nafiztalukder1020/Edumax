<?php
/*
 * Private database credentials for THIS server only.
 * config/.htaccess blocks web access to this folder.
 *
 * IMPORTANT: the old password was exposed (it was hard-coded in database.php
 * and shared in a ZIP). Change the MySQL user's password in cPanel ->
 * MySQL Databases, then put the NEW password below. Do not share this file.
 */
return [
    'host'    => 'localhost',
    'name'    => 'dawaghor_edumax_admission',
    'user'    => 'dawaghor_dawaghor_edumax',
    'pass'    => 'nafiz1020@',
    'charset' => 'utf8mb4',
];

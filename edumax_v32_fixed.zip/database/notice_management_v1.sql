-- EDUMAX NOTICE MANAGEMENT V1
CREATE TABLE IF NOT EXISTS notices (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL,
 body TEXT NOT NULL,
 audience ENUM('All','Batch','Student') NOT NULL DEFAULT 'All',
 batch_id INT UNSIGNED NULL,
 student_id INT UNSIGNED NULL,
 publish_date DATE NOT NULL,
 expiry_date DATE NULL,
 status ENUM('Published','Draft','Expired') NOT NULL DEFAULT 'Published',
 created_by INT UNSIGNED NULL,
 created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_notice_status_date (status,publish_date,expiry_date),
 KEY idx_notice_batch (batch_id), KEY idx_notice_student (student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

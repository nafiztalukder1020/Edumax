-- Guardian Performance Module V2
-- No destructive schema changes. Existing V1 tables are sufficient.
-- Run once. The index improves monthly history/report queries.
SET @idx_exists := (
  SELECT COUNT(*) FROM information_schema.statistics
  WHERE table_schema = DATABASE()
    AND table_name = 'performance_evaluations'
    AND index_name = 'idx_perf_student_month'
);
SET @sql := IF(@idx_exists = 0,
  'ALTER TABLE performance_evaluations ADD INDEX idx_perf_student_month (student_id, evaluation_month)',
  'SELECT 1');
PREPARE stmt FROM @sql;
EXECUTE stmt;
DEALLOCATE PREPARE stmt;

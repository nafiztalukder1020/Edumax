-- Edumax Course & Fee Management V1
-- Run once in the Edumax database.

SET @db := DATABASE();

SET @sql := IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='courses' AND COLUMN_NAME='regular_fee')=0,
  'ALTER TABLE courses ADD COLUMN regular_fee DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER status',
  'SELECT 1'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

SET @sql := IF(
  (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='courses' AND COLUMN_NAME='default_discount_percent')=0,
  'ALTER TABLE courses ADD COLUMN default_discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER regular_fee',
  'SELECT 1'
);
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

-- Safe defaults for the current Edumax courses. Change them from the Course & Fees page later.
UPDATE courses SET regular_fee=20000, default_discount_percent=40 WHERE name='IELTS' AND regular_fee=0;
UPDATE courses SET regular_fee=12000, default_discount_percent=50 WHERE name='Spoken English' AND regular_fee=0;

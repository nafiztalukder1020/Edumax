-- Edumax Refund Management V1
-- Run once after taking a database backup.

CREATE TABLE IF NOT EXISTS refunds (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    refund_no VARCHAR(50) NOT NULL UNIQUE,
    student_id INT UNSIGNED NOT NULL,
    admission_id INT UNSIGNED NOT NULL,
    payment_id INT UNSIGNED NULL,
    amount DECIMAL(12,2) NOT NULL,
    method ENUM('Cash','bKash','Nagad','Bank','Other') NOT NULL DEFAULT 'Cash',
    reason VARCHAR(255) NULL,
    note TEXT NULL,
    processed_by INT UNSIGNED NOT NULL,
    status ENUM('Valid','Void') NOT NULL DEFAULT 'Valid',
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT chk_refunds_amount_positive CHECK (amount > 0),
    CONSTRAINT fk_refunds_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE RESTRICT,
    CONSTRAINT fk_refunds_admission FOREIGN KEY (admission_id) REFERENCES admissions(id) ON DELETE RESTRICT,
    CONSTRAINT fk_refunds_payment FOREIGN KEY (payment_id) REFERENCES payments(id) ON DELETE RESTRICT,
    CONSTRAINT fk_refunds_user FOREIGN KEY (processed_by) REFERENCES users(id) ON DELETE RESTRICT,
    INDEX idx_refunds_admission_status (admission_id,status),
    INDEX idx_refunds_student_status (student_id,status),
    INDEX idx_refunds_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Edumax Admission Management System
-- Mock Test admission module
-- Run once against the LIVE Edumax database.
--
-- Mock Test schedule: Monday & Wednesday, 10:00 AM - 01:00 PM
-- Packages: 1 Mock = 500, 2 Mocks = 900, 3 Mocks = 1,200

ALTER TABLE applications
    ADD COLUMN mock_package VARCHAR(30) NULL AFTER course_interest,
    ADD COLUMN mock_day VARCHAR(20) NULL AFTER mock_package;

ALTER TABLE admissions
    ADD COLUMN mock_package VARCHAR(30) NULL AFTER status,
    ADD COLUMN mock_day VARCHAR(20) NULL AFTER mock_package;

INSERT INTO courses (name, status)
SELECT 'Mock Test', 'Active'
WHERE NOT EXISTS (
    SELECT 1 FROM courses WHERE name='Mock Test'
);

INSERT INTO batches (course_id, name, start_date, status, time_slots, class_days, schedule_months, is_archived)
SELECT c.id, 'Mock Test', NULL, 'Active', '["10:00 AM - 01:00 PM"]', '["Monday","Wednesday"]', 1, 0
FROM courses c
WHERE c.name='Mock Test'
  AND NOT EXISTS (
      SELECT 1 FROM batches b WHERE b.course_id=c.id AND b.name='Mock Test'
  );

-- Verify after running:
-- SELECT id,name,status FROM courses WHERE name='Mock Test';
-- SELECT id,course_id,name,status,time_slots,class_days FROM batches WHERE name='Mock Test';

-- Run this once on an existing database if needed.
ALTER TABLE batches ADD COLUMN time_slots TEXT NULL AFTER status;
CREATE TABLE IF NOT EXISTS receipt_sequences (
  receipt_year SMALLINT UNSIGNED PRIMARY KEY,
  next_number INT UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

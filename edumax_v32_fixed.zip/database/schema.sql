CREATE DATABASE IF NOT EXISTS edumax_admission
  CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE edumax_admission;

CREATE TABLE users (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    username VARCHAR(80) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('Super Admin','Admission Admin','Accounts','Reception','Teacher') NOT NULL DEFAULT 'Admission Admin',
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE courses (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(120) NOT NULL UNIQUE,
    status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE batches (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    course_id INT UNSIGNED NOT NULL,
    name VARCHAR(120) NOT NULL,
    start_date DATE NULL,
    status ENUM('Active','Upcoming','Closed') NOT NULL DEFAULT 'Upcoming',
    time_slots TEXT NULL,
    class_days TEXT NULL,
    schedule_months TINYINT UNSIGNED NOT NULL DEFAULT 3,
    is_archived TINYINT(1) NOT NULL DEFAULT 0,
    FOREIGN KEY (course_id) REFERENCES courses(id)
);

CREATE TABLE students (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id VARCHAR(40) NOT NULL UNIQUE,
    full_name VARCHAR(160) NOT NULL,
    mobile VARCHAR(30) NOT NULL,
    guardian_name VARCHAR(160) NULL,
    guardian_mobile VARCHAR(30) NULL,
    date_of_birth DATE NULL,
    gender ENUM('Male','Female','Other') NULL,
    email VARCHAR(160) NULL,
    blood_group VARCHAR(10) NULL,
    present_address TEXT NULL,
    passport_number VARCHAR(80) NULL,
    photo_path VARCHAR(255) NULL,
    is_archived TINYINT(1) NOT NULL DEFAULT 0,
    archived_batch_id INT UNSIGNED NULL,
    archived_at DATETIME NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE academic_records (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    degree VARCHAR(60) NOT NULL,
    subject VARCHAR(160) NULL,
    result VARCHAR(60) NULL,
    passing_year VARCHAR(10) NULL,
    institution VARCHAR(180) NULL,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE applications (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    status ENUM('Pending','Approved','Active','Cancelled') NOT NULL DEFAULT 'Pending',
    course_interest VARCHAR(50) NULL,
    lead_source VARCHAR(80) NULL,
    ielts_reading DECIMAL(3,1) NULL,
    ielts_writing DECIMAL(3,1) NULL,
    ielts_listening DECIMAL(3,1) NULL,
    ielts_speaking DECIMAL(3,1) NULL,
    ielts_overall DECIMAL(3,1) NULL,
    other_tests VARCHAR(255) NULL,
    country_1 VARCHAR(120) NULL,
    country_2 VARCHAR(120) NULL,
    country_3 VARCHAR(120) NULL,
    university_1 VARCHAR(180) NULL,
    university_2 VARCHAR(180) NULL,
    university_3 VARCHAR(180) NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE
);

CREATE TABLE admissions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    course_id INT UNSIGNED NOT NULL,
    batch_id INT UNSIGNED NOT NULL,
    time_slot VARCHAR(100) NULL,
    admission_date DATE NOT NULL,
    counsellor VARCHAR(120) NULL,
    regular_fee DECIMAL(12,2) NOT NULL DEFAULT 0,
    discount DECIMAL(12,2) NOT NULL DEFAULT 0,
    do_discount DECIMAL(12,2) NOT NULL DEFAULT 0,
    final_dealing_price DECIMAL(12,2) NOT NULL DEFAULT 0,
    reference VARCHAR(180) NULL,
    status ENUM('Pending','Approved','Active','Cancelled') NOT NULL DEFAULT 'Pending',
    admin_note TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (course_id) REFERENCES courses(id),
    FOREIGN KEY (batch_id) REFERENCES batches(id)
);

CREATE TABLE payments (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    admission_id INT UNSIGNED NOT NULL,
    receipt_no VARCHAR(50) NULL UNIQUE,
    amount DECIMAL(12,2) NOT NULL,
    method ENUM('Cash','bKash','Nagad','Bank','Other') NOT NULL,
    note VARCHAR(255) NULL,
    received_by INT UNSIGNED NULL,
    status ENUM('Valid','Void') NOT NULL DEFAULT 'Valid',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(id),
    FOREIGN KEY (admission_id) REFERENCES admissions(id),
    FOREIGN KEY (received_by) REFERENCES users(id)
);

CREATE TABLE audit_logs (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NULL,
    action VARCHAR(160) NOT NULL,
    student_id INT UNSIGNED NULL,
    details TEXT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (student_id) REFERENCES students(id)
);

INSERT INTO users (name, username, password_hash, role)
VALUES ('Admin', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llCqHkQfTtXfRzXQm1a', 'Super Admin');

INSERT INTO courses (name) VALUES ('IELTS'), ('PTE'), ('Spoken English');
INSERT INTO batches (course_id, name, start_date, status)
SELECT id, 'August 2026', '2026-08-15', 'Active' FROM courses WHERE name='IELTS';
INSERT INTO batches (course_id, name, start_date, status)
SELECT id, 'September 2026', '2026-09-15', 'Upcoming' FROM courses WHERE name='IELTS';

-- Per-user access control. Super Admin bypasses this table and has full access.
CREATE TABLE IF NOT EXISTS user_permissions (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    user_id INT UNSIGNED NOT NULL,
    permission_key VARCHAR(80) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY uq_user_permission (user_id, permission_key),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


CREATE TABLE receipt_sequences (
    receipt_year SMALLINT UNSIGNED PRIMARY KEY,
    next_number INT UNSIGNED NOT NULL
);

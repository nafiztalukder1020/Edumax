-- EDUMAX V31 - recurring batch class schedule
-- Safe additive migration for deployments created from older schemas.
-- The application also runs these checks automatically.

ALTER TABLE batches ADD COLUMN class_days TEXT NULL AFTER time_slots;
ALTER TABLE batches ADD COLUMN schedule_months TINYINT UNSIGNED NOT NULL DEFAULT 3 AFTER class_days;

-- class_days stores JSON weekday numbers: 0=Sun ... 6=Sat.
-- schedule_months controls the automatic recurring period (default 3).

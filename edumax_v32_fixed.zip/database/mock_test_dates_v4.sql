-- Mock Test Date Selection V4
-- Allows the admission form to capture 1, 2 or 3 separate Mock Test dates.
-- Only Monday/Wednesday dates are accepted by the PHP validation.

ALTER TABLE applications
    ADD COLUMN mock_dates TEXT NULL AFTER mock_day;

ALTER TABLE admissions
    ADD COLUMN mock_dates TEXT NULL AFTER mock_day;

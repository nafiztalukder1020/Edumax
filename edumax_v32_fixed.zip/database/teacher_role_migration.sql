-- Edumax: add Teacher role to Admin Users
-- Run once on an existing database.
ALTER TABLE users
  MODIFY COLUMN role ENUM('Super Admin','Admission Admin','Accounts','Reception','Teacher')
  NOT NULL DEFAULT 'Admission Admin';

-- No existing user's permissions are changed by this migration.
-- New Teacher accounts receive these defaults from config/app.php + admin-users.php:
-- dashboard, students, attendance, student_performance

-- =====================================================================
-- EDUMAX v32 FIX MIGRATION
-- Run ONCE in phpMyAdmin -> dawaghor_edumax_admission -> SQL tab.
-- Take a backup (Export) first. Safe to run again: every step checks
-- before changing anything.
-- =====================================================================

SET NAMES utf8mb4;

-- ---------------------------------------------------------------------
-- 1) Login throttling table (used by login.php / counselor login)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `login_attempts` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `scope` VARCHAR(20) NOT NULL,
  `username` VARCHAR(100) NOT NULL,
  `ip_address` VARCHAR(45) NOT NULL,
  `success` TINYINT(1) NOT NULL DEFAULT 0,
  `attempted_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_login_attempts_ip` (`scope`, `ip_address`, `attempted_at`),
  KEY `idx_login_attempts_user` (`scope`, `username`, `attempted_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 2) Alumni table (alumni-list.php / alumni-profile.php crashed without it)
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `alumni_registrations` (
  `id` INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `registration_no` VARCHAR(40) DEFAULT NULL,
  `registration_date` DATE DEFAULT NULL,
  `photo` VARCHAR(255) DEFAULT NULL,
  `alumni_name` VARCHAR(160) NOT NULL,
  `batch` VARCHAR(80) DEFAULT NULL,
  `mobile_no` VARCHAR(30) DEFAULT NULL,
  `alumni_contact_no` VARCHAR(30) DEFAULT NULL,
  `blood_group` VARCHAR(10) DEFAULT NULL,
  `date_of_birth` DATE DEFAULT NULL,
  `email` VARCHAR(160) DEFAULT NULL,
  `residential_address` TEXT DEFAULT NULL,
  `father_name` VARCHAR(160) DEFAULT NULL,
  `father_occupation` VARCHAR(120) DEFAULT NULL,
  `father_mobile` VARCHAR(30) DEFAULT NULL,
  `mother_name` VARCHAR(160) DEFAULT NULL,
  `mother_occupation` VARCHAR(120) DEFAULT NULL,
  `mother_mobile` VARCHAR(30) DEFAULT NULL,
  `present_status` VARCHAR(80) DEFAULT NULL,
  `study_level` VARCHAR(120) DEFAULT NULL,
  `profession` VARCHAR(120) DEFAULT NULL,
  `organization_name` VARCHAR(160) DEFAULT NULL,
  `key_skills` TEXT DEFAULT NULL,
  `status` ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
  `created_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_alumni_registration_no` (`registration_no`),
  KEY `idx_alumni_batch` (`batch`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- 3) Mobile numbers: restore the leading 0 that Excel removed
--    (1712345678 -> 01712345678, 8801712345678 -> 01712345678)
-- ---------------------------------------------------------------------
UPDATE `students`
   SET `mobile` = CONCAT('0', `mobile`)
 WHERE `mobile` REGEXP '^1[3-9][0-9]{8}$';

UPDATE `students`
   SET `mobile` = SUBSTRING(`mobile`, 3)
 WHERE `mobile` REGEXP '^8801[3-9][0-9]{8}$';

UPDATE `students`
   SET `guardian_mobile` = CONCAT('0', `guardian_mobile`)
 WHERE `guardian_mobile` REGEXP '^1[3-9][0-9]{8}$';

UPDATE `students`
   SET `guardian_mobile` = SUBSTRING(`guardian_mobile`, 3)
 WHERE `guardian_mobile` REGEXP '^8801[3-9][0-9]{8}$';

-- ---------------------------------------------------------------------
-- 4) Payments that were saved without a receipt number get the next
--    numbers from the receipt sequence (current year).
-- ---------------------------------------------------------------------
SET @rc_year := YEAR(CURDATE());
INSERT IGNORE INTO `receipt_sequences` (`receipt_year`, `next_number`) VALUES (@rc_year, 1);
SET @rc_next := GREATEST(
  (SELECT `next_number` FROM `receipt_sequences` WHERE `receipt_year` = @rc_year),
  (SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(`receipt_no`, '-', -1) AS UNSIGNED)), 0) + 1
     FROM `payments` WHERE `receipt_no` LIKE CONCAT('EDU-RC-', @rc_year, '-%'))
);
SET @rc_n := @rc_next - 1;
UPDATE `payments`
   SET `receipt_no` = CONCAT('EDU-RC-', @rc_year, '-', LPAD((@rc_n := @rc_n + 1), 5, '0'))
 WHERE `receipt_no` IS NULL
 ORDER BY `id`;
UPDATE `receipt_sequences`
   SET `next_number` = GREATEST(`next_number`, @rc_n + 1)
 WHERE `receipt_year` = @rc_year;

-- ---------------------------------------------------------------------
-- 5) Guardian report links without expiry: expire 90 days after creation
--    (same rule the app uses for new links).
-- ---------------------------------------------------------------------
UPDATE `guardian_report_links`
   SET `expires_at` = DATE_ADD(`created_at`, INTERVAL 90 DAY)
 WHERE `expires_at` IS NULL;

-- ---------------------------------------------------------------------
-- 6) Prevent duplicate class rows for the same batch/date/slot
-- ---------------------------------------------------------------------
SET @has_idx := (SELECT COUNT(*) FROM information_schema.STATISTICS
                  WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'class_schedules'
                    AND INDEX_NAME = 'uq_class_schedule_slot');
SET @sql := IF(@has_idx = 0,
  'ALTER TABLE `class_schedules` ADD UNIQUE KEY `uq_class_schedule_slot` (`batch_id`, `class_date`, `time_slot`)',
  'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

-- ---------------------------------------------------------------------
-- 7) One collation for every table (avoids "Illegal mix of collations")
-- ---------------------------------------------------------------------
SET FOREIGN_KEY_CHECKS = 0;
ALTER TABLE `guardian_report_links`    CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `performance_evaluations`  CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `receipt_sequences`        CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `refund_sequences`         CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `refunds`                  CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `student_batch_transfers`  CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `student_material_history` CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `student_materials`        CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
ALTER TABLE `user_permissions`         CONVERT TO CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
SET FOREIGN_KEY_CHECKS = 1;

-- ---------------------------------------------------------------------
-- 7b) Notices table: the live table had an older layout (message,
--     notice_date, expires_at ...) but notice-management.php uses
--     body/publish_date/expiry_date. Convert it, keeping existing notices.
-- ---------------------------------------------------------------------
SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notices' AND COLUMN_NAME='message');
SET @sql := IF(@c=1, 'ALTER TABLE `notices` CHANGE `message` `body` TEXT NOT NULL', 'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notices' AND COLUMN_NAME='notice_date');
SET @sql := IF(@c=1, 'ALTER TABLE `notices` CHANGE `notice_date` `publish_date` DATE NOT NULL', 'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notices' AND COLUMN_NAME='expires_at');
SET @sql := IF(@c=1, 'ALTER TABLE `notices` CHANGE `expires_at` `expiry_date` DATE NULL', 'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

-- audience / status: widen enum, map old values, then narrow to what the app uses
ALTER TABLE `notices` MODIFY `audience` ENUM('All','All Students','Batch','Student') NOT NULL DEFAULT 'All';
UPDATE `notices` SET `audience`='All' WHERE `audience`='All Students';
ALTER TABLE `notices` MODIFY `audience` ENUM('All','Batch','Student') NOT NULL DEFAULT 'All';

ALTER TABLE `notices` MODIFY `status` ENUM('Published','Draft','Expired','Active','Archived') NOT NULL DEFAULT 'Published';
UPDATE `notices` SET `status`='Published' WHERE `status`='Active';
UPDATE `notices` SET `status`='Expired'   WHERE `status`='Archived';
ALTER TABLE `notices` MODIFY `status` ENUM('Published','Draft','Expired') NOT NULL DEFAULT 'Published';

ALTER TABLE `notices` MODIFY `title` VARCHAR(200) NOT NULL;

SET @c := (SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME='notices' AND COLUMN_NAME='updated_at');
SET @sql := IF(@c=0, 'ALTER TABLE `notices` ADD COLUMN `updated_at` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP AFTER `created_at`', 'SELECT 1');
PREPARE st FROM @sql; EXECUTE st; DEALLOCATE PREPARE st;

-- ---------------------------------------------------------------------
-- 8) Audit trail
-- ---------------------------------------------------------------------
INSERT INTO `audit_logs` (`user_id`, `action`, `details`)
SELECT `id`, 'System Migration', 'v32 fix migration applied (mobile normalisation, missing receipt numbers, guardian link expiry, schedule unique key, collation)'
  FROM `users` WHERE `role` = 'Super Admin' ORDER BY `id` LIMIT 1;

-- =====================================================================
-- REVIEW QUERIES (read-only) - run these and check the results by hand.
-- =====================================================================

-- A) Admission/payment with a future date (looks like a typo, e.g. 2028)
SELECT a.id AS admission_id, s.student_id, a.admission_date, a.status
  FROM admissions a JOIN students s ON s.id = a.student_id
 WHERE a.admission_date > CURDATE();
SELECT id AS payment_id, admission_id, receipt_no, amount, created_at
  FROM payments WHERE created_at > NOW();

-- B) Cancelled admissions that promise a refund but have no VALID refund record
SELECT a.id AS admission_id, s.student_id, a.refund_amount,
       COALESCE((SELECT SUM(r.amount) FROM refunds r WHERE r.admission_id = a.id AND r.status = 'Valid'), 0) AS refunded
  FROM admissions a JOIN students s ON s.id = a.student_id
 WHERE a.status = 'Cancelled' AND COALESCE(a.refund_amount, 0) > 0
HAVING refunded < a.refund_amount;

-- C) Same mobile number used by more than one student (possible duplicates)
SELECT mobile, GROUP_CONCAT(student_id ORDER BY id) AS students, COUNT(*) AS total
  FROM students GROUP BY mobile HAVING COUNT(*) > 1;

-- D) Mobile numbers that are still not valid 11-digit BD numbers
SELECT id, student_id, mobile FROM students WHERE mobile NOT REGEXP '^01[3-9][0-9]{8}$';

-- E) Admission time slot not in its batch's slot list
SELECT a.id AS admission_id, a.batch_id, a.time_slot, b.time_slots
  FROM admissions a JOIN batches b ON b.id = a.batch_id
 WHERE a.status <> 'Cancelled' AND a.time_slot IS NOT NULL AND JSON_VALID(b.time_slots)
   AND NOT JSON_CONTAINS(b.time_slots, JSON_QUOTE(a.time_slot));

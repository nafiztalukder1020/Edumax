-- Mock Test Usage & Schedule V2
CREATE TABLE IF NOT EXISTS mock_test_usage (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    admission_id INT UNSIGNED NOT NULL,
    student_id INT UNSIGNED NOT NULL,
    mock_no INT UNSIGNED NOT NULL,
    mock_date DATE NOT NULL,
    mock_day VARCHAR(20) NOT NULL,
    time_slot VARCHAR(100) NOT NULL DEFAULT '10:00 AM - 01:00 PM',
    status ENUM('Scheduled','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
    note VARCHAR(255) NULL,
    marked_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_mock_usage_no (admission_id, mock_no),
    KEY idx_mock_usage_date (mock_date),
    KEY idx_mock_usage_student (student_id),
    CONSTRAINT fk_mock_usage_admission FOREIGN KEY (admission_id) REFERENCES admissions(id) ON DELETE CASCADE,
    CONSTRAINT fk_mock_usage_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_mock_usage_user FOREIGN KEY (marked_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

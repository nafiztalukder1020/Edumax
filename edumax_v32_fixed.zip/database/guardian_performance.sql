-- Student Performance & Guardian Report module
-- Run once in phpMyAdmin on database: edumax_admission

CREATE TABLE IF NOT EXISTS performance_evaluations (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    evaluation_month DATE NOT NULL,
    participation ENUM('Excellent','Very Good','Good','Average','Needs Improvement') NOT NULL DEFAULT 'Good',
    homework_assigned INT UNSIGNED NOT NULL DEFAULT 0,
    homework_completed INT UNSIGNED NOT NULL DEFAULT 0,
    speaking ENUM('Excellent','Very Good','Good','Average','Needs Improvement') NOT NULL DEFAULT 'Good',
    listening ENUM('Excellent','Very Good','Good','Average','Needs Improvement') NOT NULL DEFAULT 'Good',
    reading ENUM('Excellent','Very Good','Good','Average','Needs Improvement') NOT NULL DEFAULT 'Good',
    writing ENUM('Excellent','Very Good','Good','Average','Needs Improvement') NOT NULL DEFAULT 'Good',
    grammar ENUM('Excellent','Very Good','Good','Average','Needs Improvement') NOT NULL DEFAULT 'Good',
    vocabulary ENUM('Excellent','Very Good','Good','Average','Needs Improvement') NOT NULL DEFAULT 'Good',
    strengths TEXT NULL,
    improvement_areas TEXT NULL,
    teacher_comment TEXT NULL,
    evaluated_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    UNIQUE KEY uq_student_evaluation_month (student_id, evaluation_month),
    KEY idx_performance_month (evaluation_month),
    CONSTRAINT fk_performance_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_performance_user FOREIGN KEY (evaluated_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS guardian_report_links (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    evaluation_id INT UNSIGNED NOT NULL,
    token CHAR(64) NOT NULL UNIQUE,
    status ENUM('Active','Revoked') NOT NULL DEFAULT 'Active',
    expires_at DATETIME NULL,
    created_by INT UNSIGNED NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    KEY idx_guardian_student (student_id),
    KEY idx_guardian_evaluation (evaluation_id),
    CONSTRAINT fk_guardian_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    CONSTRAINT fk_guardian_evaluation FOREIGN KEY (evaluation_id) REFERENCES performance_evaluations(id) ON DELETE CASCADE,
    CONSTRAINT fk_guardian_user FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Give the new Student Performance page to current Super Admin / Admission Admin users.
-- Existing custom permissions are not overwritten.
INSERT IGNORE INTO user_permissions (user_id, permission_key)
SELECT id, 'student_performance' FROM users WHERE role IN ('Super Admin','Admission Admin');

-- Edumax Financial Hardening V1
-- Run once after backup. Safe/idempotent for the added columns/table.

SET @db := DATABASE();

SET @sql := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='admissions' AND COLUMN_NAME='regular_discount_percent')=0,
'ALTER TABLE admissions ADD COLUMN regular_discount_percent DECIMAL(5,2) NULL AFTER regular_fee', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='admissions' AND COLUMN_NAME='regular_discount_amount')=0,
'ALTER TABLE admissions ADD COLUMN regular_discount_amount DECIMAL(12,2) NULL AFTER regular_discount_percent', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='admissions' AND COLUMN_NAME='special_discount_percent')=0,
'ALTER TABLE admissions ADD COLUMN special_discount_percent DECIMAL(5,2) NULL AFTER regular_discount_amount', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;
SET @sql := IF((SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA=@db AND TABLE_NAME='admissions' AND COLUMN_NAME='special_discount_amount')=0,
'ALTER TABLE admissions ADD COLUMN special_discount_amount DECIMAL(12,2) NULL AFTER special_discount_percent', 'SELECT 1');
PREPARE s FROM @sql; EXECUTE s; DEALLOCATE PREPARE s;

CREATE TABLE IF NOT EXISTS refund_sequences (
    year SMALLINT UNSIGNED NOT NULL PRIMARY KEY,
    last_number INT UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Backfill percentage snapshots where the old amount fields are available.
UPDATE admissions
SET regular_discount_percent = CASE WHEN regular_fee > 0 THEN ROUND((discount / regular_fee) * 100,2) ELSE 0 END,
    regular_discount_amount = discount,
    special_discount_percent = CASE WHEN (regular_fee-discount) > 0 THEN ROUND((do_discount / (regular_fee-discount)) * 100,2) ELSE 0 END,
    special_discount_amount = do_discount
WHERE regular_discount_percent IS NULL;

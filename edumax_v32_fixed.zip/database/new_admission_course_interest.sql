ALTER TABLE applications
ADD COLUMN IF NOT EXISTS course_interest VARCHAR(50) NULL AFTER status;

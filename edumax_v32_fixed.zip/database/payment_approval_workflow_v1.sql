-- Edumax Admission Management System
-- Payment / approval workflow migration
-- Run once against dawaghor_edumax_admission after taking a database backup.
--
-- Purpose:
-- 1) Allow a valid pre-approval payment to exist without a receipt number.
--    The receipt is generated only when the admission is finally approved.
-- 2) Prevent zero/negative payment amounts at database level.
--
-- Existing receipt numbers are preserved.

ALTER TABLE payments
    MODIFY COLUMN receipt_no VARCHAR(50) NULL;

ALTER TABLE payments
    ADD CONSTRAINT chk_payments_amount_positive CHECK (amount > 0);

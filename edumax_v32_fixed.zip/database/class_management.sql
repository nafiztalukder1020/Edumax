-- EDUMAX CLASS MANAGEMENT
-- Safe additive migration: does not drop/reset existing data.

CREATE TABLE IF NOT EXISTS class_schedules (
    id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
    batch_id INT UNSIGNED NOT NULL,
    class_date DATE NOT NULL,
    time_slot VARCHAR(100) NOT NULL,
    teacher_name VARCHAR(160) DEFAULT NULL,
    room VARCHAR(100) DEFAULT NULL,
    topic VARCHAR(255) DEFAULT NULL,
    class_type ENUM('Regular Class','Mock Test','Special Class','Seminar','Other') NOT NULL DEFAULT 'Regular Class',
    status ENUM('Scheduled','Completed','Cancelled','Rescheduled') NOT NULL DEFAULT 'Scheduled',
    notes TEXT DEFAULT NULL,
    created_by INT UNSIGNED DEFAULT NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    KEY idx_class_date (class_date),
    KEY idx_class_batch_date (batch_id, class_date),
    CONSTRAINT fk_class_schedule_batch
        FOREIGN KEY (batch_id) REFERENCES batches(id) ON DELETE CASCADE,
    CONSTRAINT fk_class_schedule_user
        FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

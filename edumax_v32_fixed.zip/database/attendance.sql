-- Attendance module
-- Run once in phpMyAdmin on database: edumax_admission
-- This creates a new table only; existing data is not changed.

CREATE TABLE IF NOT EXISTS attendance (
    id INT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    batch_id INT UNSIGNED NOT NULL,
    attendance_date DATE NOT NULL,
    status ENUM('Present','Absent') NOT NULL DEFAULT 'Absent',
    marked_by INT UNSIGNED NULL,
    created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

    UNIQUE KEY uq_attendance_student_batch_date (
        student_id,
        batch_id,
        attendance_date
    ),

    KEY idx_attendance_batch_date (
        batch_id,
        attendance_date
    ),

    CONSTRAINT fk_attendance_student
        FOREIGN KEY (student_id) REFERENCES students(id)
        ON DELETE CASCADE,

    CONSTRAINT fk_attendance_batch
        FOREIGN KEY (batch_id) REFERENCES batches(id)
        ON DELETE CASCADE
);

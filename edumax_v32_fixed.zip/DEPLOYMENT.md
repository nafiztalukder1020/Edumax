# Edumax Admission Management System — Deployment

## Recommended cPanel layout

The domain/subdomain document root should point to the `public` directory, for example:

`/home/USERNAME/admission.dawaghor.com/public`

Keep `config/` and `database/` one level above the public document root.

## Database configuration

The project no longer requires hosting credentials to be stored in the distributable `database.php`.

1. Copy `config/database.local.example.php` to `config/database.local.php` on the server.
2. Set the cPanel database host, database name, database user, and password in that local file.
3. Do not upload/share the real password in chat, source control, or public folders.

Environment variables are also supported:

- `EDUMAX_DB_HOST`
- `EDUMAX_DB_NAME`
- `EDUMAX_DB_USER`
- `EDUMAX_DB_PASS`
- `EDUMAX_DB_CHARSET`
- `EDUMAX_ENV=production`

Local XAMPP defaults remain `127.0.0.1 / edumax_admission / root / blank password` when no override is present.

## Database schema

For an existing installation, keep the current database and run only missing migrations from `database/`.
For a brand-new installation, import `database/schema.sql` and then the additive module SQL files as needed:

- `attendance.sql`
- `class_management.sql`
- `teacher_room_management.sql`
- `guardian_performance.sql`
- `user_permissions.sql`
- `teacher_role_migration.sql` (only for older user-role schemas)

## Hosting checks

- PHP 8.1+ recommended.
- PDO MySQL extension enabled.
- Domain document root points to `/public`.
- HTTPS/AutoSSL enabled.
- `config/database.local.php` is outside the public document root.
- `public/.htaccess` disables directory listing and uses `index.php` as the default entry point.

## Updated project checks

- Responsive login page for mobile/tablet/desktop.
- Global responsive layer for authenticated pages.
- Receipt remains A4-safe for printing but is readable on phones.
- Logout now boots the app/session correctly and cannot fail just because audit logging fails.
- Footer markup is valid and mobile sidebar closes on navigation/Escape.
- Student Performance CSS typo fixed.

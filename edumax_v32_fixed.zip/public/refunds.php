<?php
require_once __DIR__ . '/../config/app.php';
require_access('payments');

$q = trim($_GET['q'] ?? '');
$status = $_GET['status'] ?? 'All';
$where = ['r.status IN (\'Valid\',\'Void\')'];
$params = [];
if ($q !== '') {
    $where[] = '(r.refund_no LIKE ? OR s.student_id LIKE ? OR s.full_name LIKE ? OR s.mobile LIKE ?)';
    $like = '%' . $q . '%';
    array_push($params, $like, $like, $like, $like);
}
if (in_array($status, ['Valid','Void'], true)) { $where[] = 'r.status=?'; $params[] = $status; }

$st = $pdo->prepare("SELECT r.*, s.student_id AS code, s.full_name, c.name course_name, p.receipt_no payment_receipt FROM refunds r JOIN students s ON s.id=r.student_id JOIN admissions a ON a.id=r.admission_id JOIN courses c ON c.id=a.course_id LEFT JOIN payments p ON p.id=r.payment_id WHERE " . implode(' AND ', $where) . " ORDER BY r.id DESC LIMIT 300");
$st->execute($params);
$rows = $st->fetchAll();
$total = 0;
foreach ($rows as $r) if ($r['status'] === 'Valid') $total += (float)$r['amount'];

require '_header.php';
?>
<div class="section-title"><div><h1>Refunds</h1><p>Valid refunds reduce the student's net paid amount. Refunds are never hard-deleted; they can be voided.</p></div><a class="btn btn-primary" href="refund-create.php">+ New Refund</a></div>
<div class="card" style="margin-bottom:18px"><form method="get" class="form-grid"><div><label>Search</label><input name="q" value="<?=e($q)?>" placeholder="Refund, Student ID, name or mobile"></div><div><label>Status</label><select name="status"><option value="All" <?=$status==='All'?'selected':''?>>All</option><option value="Valid" <?=$status==='Valid'?'selected':''?>>Valid</option><option value="Void" <?=$status==='Void'?'selected':''?>>Void</option></select></div><div style="align-self:end"><button class="btn btn-primary">Filter</button> <a class="btn btn-light" href="refunds.php">Reset</a></div></form></div>
<div class="card" style="margin-bottom:18px"><div class="form-grid"><div><small>Records</small><strong><?=number_format(count($rows))?></strong></div><div><small>Valid Refund Total</small><strong>৳ <?=number_format($total,2)?></strong></div></div></div>
<div class="card table-wrap"><table class="table"><tr><th>Refund</th><th>Student</th><th>Course</th><th>Amount</th><th>Method</th><th>Reason</th><th>Date</th><th>Status</th><th>Action</th></tr><?php foreach($rows as $r): ?><tr><td><strong><?=e($r['refund_no'])?></strong><?php if($r['payment_receipt']): ?><br><small>Payment: <?=e($r['payment_receipt'])?></small><?php endif;?></td><td><?=e($r['full_name'])?><br><small><?=e($r['code'])?></small></td><td><?=e($r['course_name'])?></td><td>৳<?=number_format((float)$r['amount'],2)?></td><td><?=e($r['method'])?></td><td><?=e($r['reason'] ?? '')?></td><td><?=e($r['created_at'])?></td><td><span class="status-pill <?=strtolower($r['status'])?>"><?=e($r['status'])?></span></td><td>
<?php if(!empty($r['id'])): ?>
<a class="btn btn-light" href="refund-receipt.php?id=<?=urlencode($r['id'])?>" target="_blank" rel="noopener">View Receipt</a>
<?php endif; ?>
<?php if($r['status']==='Valid'): ?>
<a class="btn btn-light" href="refund-void.php?id=<?=urlencode($r['id'])?>">Void</a>
<?php endif; ?>
</td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="9">No refunds found.</td></tr><?php endif;?></table></div>
<?php require '_footer.php'; ?>

<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_access('consultancy_dashboard');
$_SESSION['workspace'] = 'consultancy';

$error = '';
$fileId = (int)($_GET['file'] ?? 0);
$qText = trim((string)($_GET['q'] ?? ''));
$status = trim((string)($_GET['status'] ?? 'All'));

if (!in_array($status, ['All','Valid','Void'], true)) $status = 'All';

try {
    $pdo->query('SELECT 1 FROM consultancy_payments LIMIT 1');
    $pdo->query('SELECT 1 FROM consultancy_files LIMIT 1');
} catch (Throwable $e) {
    $error = 'Consultancy payment tables are not available.';
}

$receipts = [];
if ($error === '') {
    $where = [];
    $params = [];

    if ($fileId > 0) {
        $where[] = 'p.file_id=?';
        $params[] = $fileId;
    }

    if ($status !== 'All') {
        $where[] = 'p.status=?';
        $params[] = $status;
    }

    if ($qText !== '') {
        $where[] = '(p.payment_no LIKE ? OR f.file_no LIKE ? OR e.enquiry_no LIKE ? OR e.full_name LIKE ? OR e.mobile LIKE ?)';
        $like = '%'.$qText.'%';
        array_push($params, $like, $like, $like, $like, $like);
    }

    $sql = "SELECT
                p.id,p.payment_no,p.amount,p.method,p.reference_no,p.note,p.status,p.created_at,
                f.id AS file_id,f.file_no,f.service_fee,f.file_status,
                e.enquiry_no,e.full_name,e.mobile,
                co.country_name,c.counselor_name,
                u.name AS receiver_name
            FROM consultancy_payments p
            INNER JOIN consultancy_files f ON f.id=p.file_id
            INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
            LEFT JOIN consultancy_countries co ON co.id=f.country_id
            LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id
            LEFT JOIN users u ON u.id=p.received_by";

    if ($where) $sql .= ' WHERE '.implode(' AND ', $where);
    $sql .= ' ORDER BY p.id DESC LIMIT 500';

    try {
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $receipts = $st->fetchAll();
    } catch (Throwable $e) {
        $error = 'Unable to load consultancy receipts.';
    }
}
?>
<?php require_once __DIR__ . '/_header.php'; ?>
<style>
.cr-wrap{max-width:1240px;margin:28px auto;padding:0 18px}
.cr-head{display:flex;justify-content:space-between;gap:15px;align-items:flex-end;margin-bottom:20px}
.cr-head h1{margin:0 0 5px;font-size:28px}.cr-head p{margin:0;color:#747a83}
.cr-btn{display:inline-block;text-decoration:none;border:0;border-radius:10px;background:#c91f2e;color:#fff;padding:11px 16px;font-weight:800}
.cr-card{background:#fff;border:1px solid #e5e8ec;border-radius:16px;box-shadow:0 7px 24px rgba(25,30,38,.05);overflow:hidden}
.cr-filter{padding:16px;border-bottom:1px solid #eceef1;display:grid;grid-template-columns:1.5fr 180px auto;gap:10px}
.cr-filter input,.cr-filter select{border:1px solid #dfe2e6;border-radius:10px;padding:11px 12px;font:inherit}
.cr-filter button{border:0;border-radius:10px;background:#333;color:#fff;padding:10px 16px;font-weight:800}
.cr-table-wrap{overflow:auto}.cr-table{width:100%;border-collapse:collapse;min-width:1000px}
.cr-table th,.cr-table td{padding:13px 11px;border-bottom:1px solid #eef0f2;text-align:left;vertical-align:top;font-size:12px}
.cr-table th{font-size:10px;color:#747b84;text-transform:uppercase;white-space:nowrap}
.cr-name{font-weight:800}.cr-sub{font-size:10px;color:#818892;margin-top:3px}
.cr-badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:800}
.valid{background:#eaf8ef;color:#176b39}.void{background:#fff0f1;color:#a71928}
.cr-link{display:inline-block;padding:7px 9px;border:1px solid #dfe2e6;border-radius:8px;color:#333;text-decoration:none;font-size:10px;font-weight:750;background:#fff}
.cr-empty{text-align:center;padding:45px;color:#858b93}
@media(max-width:700px){.cr-head{display:block}.cr-head .cr-btn{margin-top:12px}.cr-filter{grid-template-columns:1fr}}
</style>
<div class="cr-wrap">
  <div class="cr-head">
    <div>
      <h1>Consultancy Receipts</h1>
      <p>View, re-open and print consultancy payment receipts at any time.</p>
    </div>
    <a class="cr-btn" href="consultancy-payments.php">← Consultancy Payments</a>
  </div>

  <?php if($error!==''): ?>
    <div style="padding:12px 14px;border-radius:10px;background:#fff1f2;color:#a71928;border:1px solid #f3c6cb;margin-bottom:18px"><?=e($error)?></div>
  <?php endif; ?>

  <section class="cr-card">
    <form class="cr-filter" method="get">
      <input type="text" name="q" value="<?=e($qText)?>" placeholder="Search receipt / file / student / mobile">
      <select name="status">
        <?php foreach(['All','Valid','Void'] as $s): ?>
          <option value="<?=e($s)?>" <?=$status===$s?'selected':''?>><?=e($s)?> Receipts</option>
        <?php endforeach; ?>
      </select>
      <button type="submit">Search</button>
    </form>

    <div class="cr-table-wrap">
      <?php if(!$receipts): ?>
        <div class="cr-empty">No consultancy receipts found.</div>
      <?php else: ?>
        <table class="cr-table">
          <thead>
            <tr>
              <th>Receipt No.</th><th>Student</th><th>File</th><th>Amount</th>
              <th>Method</th><th>Date</th><th>Received By</th><th>Status</th><th>Action</th>
            </tr>
          </thead>
          <tbody>
          <?php foreach($receipts as $r): ?>
            <tr>
              <td><div class="cr-name"><?=e($r['payment_no'])?></div></td>
              <td><div class="cr-name"><?=e($r['full_name'])?></div><div class="cr-sub"><?=e($r['mobile'])?></div></td>
              <td><div class="cr-name"><?=e($r['file_no'])?></div><div class="cr-sub"><?=e($r['enquiry_no'])?></div></td>
              <td>৳<?=number_format((float)$r['amount'],2)?></td>
              <td><?=e($r['method'])?></td>
              <td><?=e(date('d M Y, h:i A',strtotime($r['created_at'])))?></td>
              <td><?=e($r['receiver_name']??'-')?></td>
              <td><span class="cr-badge <?=$r['status']==='Valid'?'valid':'void'?>"><?=e($r['status'])?></span></td>
              <td>
                <div style="display:flex;gap:6px;flex-wrap:wrap">
                  <a class="cr-link" href="consultancy-payment-receipt.php?id=<?=e((string)$r['id'])?>">View</a>
                  <a class="cr-link" href="consultancy-payment-receipt.php?id=<?=e((string)$r['id'])?>&print=1">Print</a>
                </div>
              </td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      <?php endif; ?>
    </div>
  </section>
</div>
</main></div></body></html>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
require_access('reports');
$month = $_GET['month'] ?? date('Y-m');
if (!preg_match('/^\d{4}-\d{2}$/', $month)) $month = date('Y-m');
$monthStart = $month . '-01';
$monthEnd = date('Y-m-t', strtotime($monthStart));

$from = $_GET['from'] ?? $monthStart;
$to   = $_GET['to'] ?? $monthEnd;
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = $monthStart;
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) $to = $monthEnd;
if ($from > $to) { [$from,$to] = [$to,$from]; }

function money(float $v): string { return '৳'.number_format($v, 2); }

// Admission counts for selected period.
$mockReportRows=[];
try {
    $mq=$pdo->prepare("SELECT a.admission_date,s.student_id,s.full_name,a.mock_package,a.mock_day,a.final_dealing_price,
        GREATEST(
            COALESCE((SELECT SUM(amount) FROM payments p WHERE p.admission_id=a.id AND p.status='Valid'),0)
            -
            COALESCE((SELECT SUM(amount) FROM refunds r WHERE r.admission_id=a.id AND r.status='Valid'),0),
            0
        ) AS paid,
        COALESCE((SELECT COUNT(*) FROM mock_test_usage mu WHERE mu.admission_id=a.id AND mu.status='Completed'),0) AS used_mocks
        FROM admissions a INNER JOIN students s ON s.id=a.student_id INNER JOIN courses c ON c.id=a.course_id
        WHERE LOWER(c.name)='mock test' AND a.admission_date BETWEEN ? AND ? ORDER BY a.admission_date DESC,a.id DESC");
    $mq->execute([$from,$to]); $mockReportRows=$mq->fetchAll();
} catch(Throwable $e) {}

$stmt = $pdo->prepare("SELECT COUNT(*) FROM admissions WHERE admission_date BETWEEN ? AND ? AND status <> 'Cancelled'");
$stmt->execute([$from,$to]);
$admissions = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM students WHERE DATE(created_at) BETWEEN ? AND ?");
$stmt->execute([$from,$to]);
$newStudents = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM admissions WHERE status='Active' AND admission_date BETWEEN ? AND ?");
$stmt->execute([$from,$to]);
$active = (int)$stmt->fetchColumn();

$stmt = $pdo->prepare("SELECT COUNT(*) FROM admissions WHERE status='Approved' AND admission_date BETWEEN ? AND ?");
$stmt->execute([$from,$to]);
$approved = (int)$stmt->fetchColumn();

// Payment collection is based on actual transaction date, not admission date.
$stmt = $pdo->prepare("
    SELECT GREATEST(
        COALESCE((
            SELECT SUM(p.amount)
            FROM payments p
            WHERE p.status='Valid'
              AND DATE(p.created_at) BETWEEN ? AND ?
        ),0)
        -
        COALESCE((
            SELECT SUM(r.amount)
            FROM refunds r
            WHERE r.status='Valid'
              AND DATE(r.created_at) BETWEEN ? AND ?
        ),0),
        0
    )
");
$stmt->execute([$from,$to,$from,$to]);
$collection = (float)$stmt->fetchColumn();

// Deal value for admissions in selected period.
$stmt = $pdo->prepare("SELECT COALESCE(SUM(final_dealing_price),0) FROM admissions WHERE status <> 'Cancelled' AND admission_date BETWEEN ? AND ?");
$stmt->execute([$from,$to]);
$dealValue = (float)$stmt->fetchColumn();

// Current outstanding due across all non-cancelled admissions.
$dueSql = "SELECT COALESCE(SUM(
               GREATEST(
                   a.final_dealing_price
                   -
                   GREATEST(
                       COALESCE(p.paid,0) - COALESCE(r.refunded,0),
                       0
                   ),
                   0
               )
           ),0)
           FROM admissions a
           LEFT JOIN (
               SELECT admission_id, SUM(amount) paid
               FROM payments
               WHERE status='Valid'
               GROUP BY admission_id
           ) p ON p.admission_id=a.id
           LEFT JOIN (
               SELECT admission_id, SUM(amount) refunded
               FROM refunds
               WHERE status='Valid'
               GROUP BY admission_id
           ) r ON r.admission_id=a.id
           WHERE a.status <> 'Cancelled'";
$currentDue = (float)$pdo->query($dueSql)->fetchColumn();

// Attendance in selected period.
$stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE attendance_date BETWEEN ? AND ?");
$stmt->execute([$from,$to]);
$attendanceMarked = (int)$stmt->fetchColumn();
$stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE attendance_date BETWEEN ? AND ? AND status='Present'");
$stmt->execute([$from,$to]);
$present = (int)$stmt->fetchColumn();
$stmt = $pdo->prepare("SELECT COUNT(*) FROM attendance WHERE attendance_date BETWEEN ? AND ? AND status='Absent'");
$stmt->execute([$from,$to]);
$absent = (int)$stmt->fetchColumn();
$attendanceRate = $attendanceMarked > 0 ? ($present / $attendanceMarked) * 100 : 0;

// Payment method breakdown.
$stmt = $pdo->prepare("SELECT method, COUNT(*) transactions, COALESCE(SUM(amount),0) amount
                       FROM payments WHERE status='Valid' AND DATE(created_at) BETWEEN ? AND ?
                       GROUP BY method ORDER BY amount DESC");
$stmt->execute([$from,$to]);
$methods = $stmt->fetchAll();

// Course-wise admission/deal report.
$stmt = $pdo->prepare("SELECT c.name, COUNT(a.id) admissions, COALESCE(SUM(a.final_dealing_price),0) deal
                       FROM admissions a INNER JOIN courses c ON c.id=a.course_id
                       WHERE a.status <> 'Cancelled' AND a.admission_date BETWEEN ? AND ?
                       GROUP BY c.id,c.name ORDER BY admissions DESC,c.name");
$stmt->execute([$from,$to]);
$courses = $stmt->fetchAll();

// Batch-wise attendance.
$stmt = $pdo->prepare("SELECT b.name batch_name, c.name course_name,
                              COUNT(at.id) marked,
                              SUM(at.status='Present') present,
                              SUM(at.status='Absent') absent
                       FROM attendance at
                       INNER JOIN batches b ON b.id=at.batch_id
                       INNER JOIN courses c ON c.id=b.course_id
                       WHERE at.attendance_date BETWEEN ? AND ?
                       GROUP BY b.id,b.name,c.name
                       ORDER BY c.name,b.name");
$stmt->execute([$from,$to]);
$attendanceBatches = $stmt->fetchAll();

// Admission audit rows.
$stmt = $pdo->prepare("SELECT a.id,a.admission_date,s.student_id,s.full_name,
                              s.mobile,s.guardian_name,s.guardian_mobile,
                              c.name course_name,b.name batch_name,a.time_slot,a.final_dealing_price,
                              GREATEST(
                                  COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.admission_id=a.id AND p.status='Valid'),0)
                                  -
                                  COALESCE((SELECT SUM(r.amount) FROM refunds r WHERE r.admission_id=a.id AND r.status='Valid'),0),
                                  0
                              ) paid,
                              a.status
                       FROM admissions a
                       INNER JOIN students s ON s.id=a.student_id
                       INNER JOIN courses c ON c.id=a.course_id
                       LEFT JOIN batches b ON b.id=a.batch_id
                       WHERE a.admission_date BETWEEN ? AND ?
                       ORDER BY a.admission_date DESC,a.id DESC");
$stmt->execute([$from,$to]);
$rows = $stmt->fetchAll();

// Current due students, regardless of their original admission date.
$dueRows = $pdo->query("SELECT a.id,s.student_id,s.full_name,s.mobile,c.name course_name,b.name batch_name,
                               a.final_dealing_price,
                               GREATEST(COALESCE(p.paid,0)-COALESCE(r.refunded,0),0) paid,
                               GREATEST(
                                   a.final_dealing_price -
                                   GREATEST(COALESCE(p.paid,0)-COALESCE(r.refunded,0),0),
                                   0
                               ) due,
                               a.status
                        FROM admissions a
                        INNER JOIN students s ON s.id=a.student_id
                        INNER JOIN courses c ON c.id=a.course_id
                        LEFT JOIN batches b ON b.id=a.batch_id
                        LEFT JOIN (
                            SELECT admission_id,SUM(amount) paid
                            FROM payments
                            WHERE status='Valid'
                            GROUP BY admission_id
                        ) p ON p.admission_id=a.id
                        LEFT JOIN (
                            SELECT admission_id,SUM(amount) refunded
                            FROM refunds
                            WHERE status='Valid'
                            GROUP BY admission_id
                        ) r ON r.admission_id=a.id
                        WHERE a.status <> 'Cancelled'
                          AND GREATEST(
                              a.final_dealing_price -
                              GREATEST(COALESCE(p.paid,0)-COALESCE(r.refunded,0),0),
                              0
                          ) > 0
                        ORDER BY due DESC,s.full_name")->fetchAll();

// CSV exports.
// overall   = one student per row
// finance   = payment/refund transaction list
// materials = material issue/history entries
$export = $_GET['export'] ?? '';

if (in_array($export, ['csv', 'overall'], true)) {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename=edumax-overall-'.$from.'-to-'.$to.'.csv');

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");

    fputcsv($out, [
        'Admission Date','Student ID','Student Name','Mobile',
        'Guardian Name','Guardian Mobile','Course','Batch','Time Slot',
        'Final Deal','Paid','Due','Status'
    ]);

    // Group selected-period admissions by student so one student = one row.
    $studentRows = [];

    foreach ($rows as $r) {
        $sid = (string)$r['student_id'];

        if (!isset($studentRows[$sid])) {
            $studentRows[$sid] = [
                'admission_date'  => $r['admission_date'],
                'student_id'      => $r['student_id'],
                'full_name'       => $r['full_name'],
                'mobile'          => $r['mobile'] ?? '',
                'guardian_name'   => $r['guardian_name'] ?? '',
                'guardian_mobile' => $r['guardian_mobile'] ?? '',
                'courses'         => [],
                'batches'         => [],
                'time_slots'      => [],
                'final_deal'      => 0,
                'paid'            => 0,
                'status'          => []
            ];
        }

        if (!empty($r['course_name'])) $studentRows[$sid]['courses'][] = $r['course_name'];
        if (!empty($r['batch_name'])) $studentRows[$sid]['batches'][] = $r['batch_name'];
        if (!empty($r['time_slot'])) $studentRows[$sid]['time_slots'][] = $r['time_slot'];

        $studentRows[$sid]['final_deal'] += (float)$r['final_dealing_price'];
        $studentRows[$sid]['paid'] += (float)$r['paid'];

        if (!empty($r['status'])) $studentRows[$sid]['status'][] = $r['status'];
    }

    foreach ($studentRows as $r) {
        $finalDeal = (float)$r['final_deal'];
        $paid = (float)$r['paid'];
        $due = max(0, $finalDeal - $paid);

        fputcsv($out, [
            $r['admission_date'],
            $r['student_id'],
            $r['full_name'],
            $r['mobile'],
            $r['guardian_name'],
            $r['guardian_mobile'],
            implode(' | ', array_unique($r['courses'])),
            implode(' | ', array_unique($r['batches'])),
            implode(' | ', array_unique($r['time_slots'])),
            number_format($finalDeal, 2, '.', ''),
            number_format($paid, 2, '.', ''),
            number_format($due, 2, '.', ''),
            implode(' | ', array_unique($r['status']))
        ]);
    }

    fclose($out);
    exit;
}

if ($export === 'finance') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename=edumax-finance-'.$from.'-to-'.$to.'.csv');

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");

    fputcsv($out, [
        'Date','Transaction Type','Student ID','Student Name',
        'Course','Receipt / Refund No.','Payment Method','Amount','Status'
    ]);

    // Payments: actual transaction date controls the selected period.
    $financeStmt = $pdo->prepare("
        SELECT DATE(p.created_at) transaction_date,
               'Payment' transaction_type,
               s.student_id,
               s.full_name,
               c.name course_name,
               p.receipt_no transaction_no,
               p.method payment_method,
               p.amount,
               p.status
        FROM payments p
        INNER JOIN admissions a ON a.id=p.admission_id
        INNER JOIN students s ON s.id=p.student_id
        INNER JOIN courses c ON c.id=a.course_id
        WHERE DATE(p.created_at) BETWEEN ? AND ?
        ORDER BY p.created_at ASC, p.id ASC
    ");
    $financeStmt->execute([$from, $to]);

    while ($r = $financeStmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($out, [
            $r['transaction_date'],
            $r['transaction_type'],
            $r['student_id'],
            $r['full_name'],
            $r['course_name'],
            $r['transaction_no'] ?? '',
            $r['payment_method'] ?? '',
            number_format((float)$r['amount'], 2, '.', ''),
            $r['status']
        ]);
    }

    // Refunds are exported as separate negative financial transactions.
    try {
        $refundStmt = $pdo->prepare("
            SELECT DATE(r.created_at) transaction_date,
                   'Refund' transaction_type,
                   s.student_id,
                   s.full_name,
                   c.name course_name,
                   r.refund_no transaction_no,
                   '' payment_method,
                   r.amount,
                   r.status
            FROM refunds r
            INNER JOIN admissions a ON a.id=r.admission_id
            INNER JOIN students s ON s.id=a.student_id
            INNER JOIN courses c ON c.id=a.course_id
            WHERE DATE(r.created_at) BETWEEN ? AND ?
            ORDER BY r.created_at ASC, r.id ASC
        ");
        $refundStmt->execute([$from, $to]);

        while ($r = $refundStmt->fetch(PDO::FETCH_ASSOC)) {
            fputcsv($out, [
                $r['transaction_date'],
                $r['transaction_type'],
                $r['student_id'],
                $r['full_name'],
                $r['course_name'],
                $r['transaction_no'] ?? '',
                '',
                '-'.number_format((float)$r['amount'], 2, '.', ''),
                $r['status']
            ]);
        }
    } catch (Throwable $e) {
        // Keep finance export working even if refund table is unavailable.
    }

    fclose($out);
    exit;
}

if ($export === 'materials') {
    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename=edumax-material-history-'.$from.'-to-'.$to.'.csv');

    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");

    fputcsv($out, [
        'Date & Time','Student ID','Student Name','Mobile',
        'Material','Old Status','New Status','Reason / Note','Changed By'
    ]);

    $materialStmt = $pdo->prepare("
        SELECT h.changed_at,
               s.student_id,
               s.full_name,
               s.mobile,
               h.material_type,
               h.old_status,
               h.new_status,
               h.note,
               COALESCE(u.name, CONCAT('User #', h.changed_by)) changed_by_name
        FROM student_material_history h
        INNER JOIN students s ON s.id=h.student_id
        LEFT JOIN users u ON u.id=h.changed_by
        WHERE DATE(h.changed_at) BETWEEN ? AND ?
        ORDER BY h.changed_at ASC, h.id ASC
    ");
    $materialStmt->execute([$from, $to]);

    while ($r = $materialStmt->fetch(PDO::FETCH_ASSOC)) {
        fputcsv($out, [
            $r['changed_at'],
            $r['student_id'],
            $r['full_name'],
            $r['mobile'],
            $r['material_type'],
            $r['old_status'] ?: 'New',
            $r['new_status'],
            $r['note'] ?? '',
            $r['changed_by_name']
        ]);
    }

    fclose($out);
    exit;
}

require '_header.php';
?>
<style>
.report-actions{display:flex;gap:8px;flex-wrap:wrap}
.report-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:18px}
.report-kpi{background:#fff;border:1px solid var(--border);border-radius:16px;padding:18px;box-shadow:var(--shadow)}
.report-kpi small{display:block;color:var(--muted);font-size:12px;margin-bottom:7px}
.report-kpi strong{font-size:25px;color:var(--ink)}
.report-section{margin-bottom:18px}
.report-section h2{margin:0 0 14px;font-size:18px}
.report-mini{display:flex;gap:18px;flex-wrap:wrap;color:var(--muted);font-size:13px;margin-top:8px}
.status-pill{display:inline-block;padding:5px 9px;border-radius:999px;background:var(--brand-soft);color:var(--brand);font-weight:700;font-size:12px}
@media(max-width:900px){.report-kpis{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:560px){.report-kpis{grid-template-columns:1fr}}
@media print{
 .sidebar,.topbar,.sidebar-overlay,.report-actions,.report-filter,.nav-label,.sidebar-footer{display:none!important}
 .layout,.content{margin:0!important;padding:0!important;width:100%!important}
 .card,.report-kpi{box-shadow:none!important}
 body{background:#fff!important}
}
</style>

<div class="section-title">
  <div><h1>Reports & Monthly Audit</h1><p>Admissions, collections, due and attendance from live system data.</p></div>
  <div class="report-actions">
    <button type="button" class="btn btn-light" onclick="window.print()">Print Report</button>
    <a class="btn btn-primary" href="reports.php?from=<?=e($from)?>&to=<?=e($to)?>&export=overall">Overall CSV</a>
    <a class="btn btn-primary" href="reports.php?from=<?=e($from)?>&to=<?=e($to)?>&export=finance">Finance CSV</a>
    <a class="btn btn-primary" href="reports.php?from=<?=e($from)?>&to=<?=e($to)?>&export=materials">Issue / Entry CSV</a>
</div>
</div>

<form method="GET" class="card report-filter" style="margin-bottom:18px">
  <div class="form-grid">
    <div class="field"><label>Monthly Audit</label><input type="month" name="month" value="<?=e($month)?>" onchange="this.form.from.value=this.value+'-01'; this.form.to.value=new Date(this.value+'-02').toISOString().slice(0,7)+'-'+new Date(this.value+'-01').getDate()"></div>
    <div class="field"><label>From</label><input type="date" name="from" value="<?=e($from)?>"></div>
    <div class="field"><label>To</label><input type="date" name="to" value="<?=e($to)?>"></div>
    <div class="field" style="display:flex;align-items:end"><button class="btn btn-primary">Generate Report</button></div>
  </div>
</form>

<div class="report-kpis">
  <div class="report-kpi"><small>Admissions</small><strong><?=$admissions?></strong><div class="report-mini"><span>Active <?=$active?></span><span>Approved <?=$approved?></span></div></div>
  <div class="report-kpi"><small>New Students</small><strong><?=$newStudents?></strong></div>
  <div class="report-kpi"><small>Collection</small><strong><?=money($collection)?></strong></div>
  <div class="report-kpi"><small>Current Total Due</small><strong><?=money($currentDue)?></strong></div>
  <div class="report-kpi"><small>Deal Value</small><strong><?=money($dealValue)?></strong></div>
  <div class="report-kpi"><small>Attendance Marked</small><strong><?=$attendanceMarked?></strong></div>
  <div class="report-kpi"><small>Present</small><strong><?=$present?></strong></div>
  <div class="report-kpi"><small>Attendance Rate</small><strong><?=number_format($attendanceRate,1)?>%</strong></div>
</div>

<div class="grid report-section">
  <div class="card"><h2>Payment Method Breakdown</h2><div style="overflow-x:auto"><table class="table"><tr><th>Method</th><th>Transactions</th><th>Amount</th></tr><?php foreach($methods as $m): ?><tr><td><?=e($m['method'])?></td><td><?=$m['transactions']?></td><td><?=money((float)$m['amount'])?></td></tr><?php endforeach; if(!$methods): ?><tr><td colspan="3">No payments in this period.</td></tr><?php endif; ?></table></div></div>
  <div class="card"><h2>Course-wise Admissions</h2><div style="overflow-x:auto"><table class="table"><tr><th>Course</th><th>Admissions</th><th>Deal Value</th></tr><?php foreach($courses as $c): ?><tr><td><?=e($c['name'])?></td><td><?=$c['admissions']?></td><td><?=money((float)$c['deal'])?></td></tr><?php endforeach; if(!$courses): ?><tr><td colspan="3">No admissions in this period.</td></tr><?php endif; ?></table></div></div>
</div>

<div class="card report-section"><h2>Mock Test Report</h2><div style="overflow-x:auto"><table class="table"><tr><th>Date</th><th>Student</th><th>Package</th><th>Preferred Day</th><th>Purchased</th><th>Used</th><th>Remaining</th><th>Paid</th></tr><?php foreach($mockReportRows as $r): $pc=['1 Mock'=>1,'2 Mocks'=>2,'3 Mocks'=>3]; $purchased=(int)($pc[$r['mock_package']]??0); $used=(int)$r['used_mocks']; ?><tr><td><?=e($r['admission_date'])?></td><td><strong><?=e($r['full_name'])?></strong><br><small><?=e($r['student_id'])?></small></td><td><?=e($r['mock_package'])?></td><td><?=e($r['mock_day'])?></td><td><?=$purchased?></td><td><?=$used?></td><td><?=max(0,$purchased-$used)?></td><td><?=money((float)$r['paid'])?></td></tr><?php endforeach; if(!$mockReportRows): ?><tr><td colspan="8">No Mock Test admissions in this period.</td></tr><?php endif; ?></table></div></div>
<div class="card report-section"><h2>Attendance by Batch</h2><div style="overflow-x:auto"><table class="table"><tr><th>Course</th><th>Batch</th><th>Marked</th><th>Present</th><th>Absent</th><th>Rate</th></tr><?php foreach($attendanceBatches as $a): $rate=((int)$a['marked']>0?((int)$a['present']/(int)$a['marked']*100):0); ?><tr><td><?=e($a['course_name'])?></td><td><?=e($a['batch_name'])?></td><td><?=$a['marked']?></td><td><?=$a['present']?></td><td><?=$a['absent']?></td><td><?=number_format($rate,1)?>%</td></tr><?php endforeach; if(!$attendanceBatches): ?><tr><td colspan="6">No attendance records in this period.</td></tr><?php endif; ?></table></div></div>

<div class="card report-section"><h2>Due Report</h2><div style="overflow-x:auto"><table class="table"><tr><th>Student ID</th><th>Student</th><th>Course</th><th>Batch</th><th>Final Deal</th><th>Paid</th><th>Due</th><th>Status</th></tr><?php foreach($dueRows as $r): ?><tr><td><?=e($r['student_id'])?></td><td><strong><?=e($r['full_name'])?></strong><br><small><?=e($r['mobile'])?></small></td><td><?=e($r['course_name'])?></td><td><?=e($r['batch_name'] ?? '')?></td><td><?=money((float)$r['final_dealing_price'])?></td><td><?=money((float)$r['paid'])?></td><td><strong><?=money((float)$r['due'])?></strong></td><td><span class="status-pill">Approved / Due</span></td></tr><?php endforeach; if(!$dueRows): ?><tr><td colspan="8">No outstanding due found.</td></tr><?php endif; ?></table></div></div>

<div class="card report-section"><h2>Admission Audit List</h2><div style="overflow-x:auto"><table class="table" style="min-width:1100px"><tr><th>Date</th><th>Student</th><th>Course</th><th>Batch</th><th>Time Slot</th><th>Final Deal</th><th>Paid</th><th>Due</th><th>Status</th></tr><?php foreach($rows as $r): $rowDue=max(0,(float)$r['final_dealing_price']-(float)$r['paid']); $displayStatus=$rowDue<=0?'Active':($r['status']==='Cancelled'?'Cancelled':'Approved'); ?><tr><td><?=e($r['admission_date'])?></td><td><strong><?=e($r['full_name'])?></strong><br><small><?=e($r['student_id'])?></small></td><td><?=e($r['course_name'])?></td><td><?=e($r['batch_name'] ?? '')?></td><td><?=e($r['time_slot'] ?? '')?></td><td><?=money((float)$r['final_dealing_price'])?></td><td><?=money((float)$r['paid'])?></td><td><?=money($rowDue)?></td><td><span class="status-pill"><?=e($displayStatus)?></span></td></tr><?php endforeach; if(!$rows): ?><tr><td colspan="9">No admissions in this period.</td></tr><?php endif; ?></table></div></div>

<?php require '_footer.php'; ?>

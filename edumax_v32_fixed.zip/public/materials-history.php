<?php
require_once __DIR__ . '/../config/app.php';
require_access('students');
$pdo = $pdo ?? db();

$pdo->exec("CREATE TABLE IF NOT EXISTS student_material_history (
    id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
    student_id INT UNSIGNED NOT NULL,
    material_type VARCHAR(30) NOT NULL,
    old_status VARCHAR(20) NULL,
    new_status VARCHAR(20) NOT NULL,
    note VARCHAR(255) NULL,
    changed_by INT UNSIGNED NULL,
    changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
    KEY idx_material_history_student (student_id),
    KEY idx_material_history_material (material_type),
    KEY idx_material_history_date (changed_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

$studentId=(int)($_GET['student_id']??0);
if($studentId<=0){ header('Location: materials.php'); exit; }
$st=$pdo->prepare("SELECT id,student_id,full_name,mobile FROM students WHERE id=? LIMIT 1");
$st->execute([$studentId]);
$student=$st->fetch(PDO::FETCH_ASSOC);
if(!$student){ header('Location: materials.php'); exit; }
$st=$pdo->prepare("SELECT h.*,u.name AS changed_by_name FROM student_material_history h LEFT JOIN users u ON u.id=h.changed_by WHERE h.student_id=? ORDER BY h.changed_at DESC,h.id DESC");
$st->execute([$studentId]); $history=$st->fetchAll(PDO::FETCH_ASSOC);
?>
<!doctype html><html lang="en"><head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Material History</title>
<link rel="stylesheet" href="assets/edumax-modern.css"><link rel="stylesheet" href="assets/style.css"><link rel="stylesheet" href="assets/responsive.css">
<style>.history-wrap{padding:28px}.history-head{display:flex;justify-content:space-between;align-items:center;gap:15px;margin-bottom:20px}.history-list-wrap{background:#fff;border:1px solid #e8e9ed;border-radius:16px;overflow-x:auto;overflow-y:visible}.history-list{min-width:760px}.history-row,.history-head-row{display:grid;grid-template-columns:170px 150px 190px minmax(220px,1fr) 150px;align-items:start}.history-head-row{padding:14px;border-bottom:1px solid #eee;font-weight:700}.history-row{padding:14px;border-bottom:1px solid #eee;min-height:58px}.history-row:last-child{border-bottom:0}.history-cell{min-width:0;display:block}.history-empty{padding:24px;text-align:center;color:#737982}@media(max-width:900px){.history-list{min-width:760px}}@media(max-width:600px){.history-wrap{padding:16px}.history-head{display:block}.history-head .btn{margin-top:10px}}</style>
</head><body><?php require __DIR__.'/_header.php'; ?>
<main class="main-content"><div class="history-wrap">
<div class="history-head"><div><h1>📋 Material History</h1><div style="color:#737982;margin-top:5px"><?=e($student['full_name'])?> · <?=e($student['student_id'])?> · <?=e($student['mobile'])?></div></div><a class="btn btn-light" href="materials.php">← Back to Materials</a></div>
<div class="history-list-wrap"><div class="history-list">
<div class="history-head-row"><div>Date & Time</div><div>Material</div><div>Change</div><div>Reason / Note</div><div>Changed By</div></div>
<?php if(!$history): ?><div class="history-empty">No material history yet.</div><?php endif; ?>
<?php foreach($history as $h): ?><div class="history-row"><div class="history-cell"><?=e(date('d M Y, h:i A',strtotime($h['changed_at'])))?></div><div class="history-cell"><strong><?=e($h['material_type'])?></strong></div><div class="history-cell"><?=e($h['old_status']?:'New')?> → <strong><?=e($h['new_status'])?></strong></div><div class="history-cell"><?=e($h['note']?:'—')?></div><div class="history-cell"><?=e($h['changed_by_name']?:('User #'.(int)$h['changed_by']))?></div></div><?php endforeach; ?>
</div></div></div></main><?php require __DIR__.'/_footer.php'; ?></body></html>

<?php
require_once __DIR__ . '/../config/app.php';
require_access('system_check');
$checks = [];

function add_check(&$checks, $name, $ok, $details = '') {
    $checks[] = [
        'name' => $name,
        'ok' => (bool)$ok,
        'details' => $details
    ];
}

add_check($checks, 'Database Connection', isset($pdo) && $pdo instanceof PDO, 'PDO connection');

$requiredTables = [
    'users','students','courses','batches','admissions',
    'payments','refunds','audit_logs','attendance'
];

foreach ($requiredTables as $table) {
    try {
        $stmt = $pdo->query("SHOW TABLES LIKE " . $pdo->quote($table));
        add_check(
            $checks,
            'Table: ' . $table,
            (bool)$stmt->fetchColumn(),
            $table
        );
    } catch (Throwable $e) {
        add_check($checks, 'Table: ' . $table, false, $e->getMessage());
    }
}

$columns = [
    'batches' => ['time_slots'],
    'admissions' => ['time_slot'],
    'payments' => ['receipt_no','method','status'],
    'refunds' => ['refund_no','admission_id','amount','status']
];

foreach ($columns as $table => $cols) {
    foreach ($cols as $column) {
        try {
            $stmt = $pdo->query(
                "SHOW COLUMNS FROM `$table` LIKE " . $pdo->quote($column)
            );
            add_check(
                $checks,
                "Column: $table.$column",
                (bool)$stmt->fetch(),
                "$table.$column"
            );
        } catch (Throwable $e) {
            add_check($checks, "Column: $table.$column", false, $e->getMessage());
        }
    }
}

/* Financial data integrity checks */
try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM payments p
        LEFT JOIN admissions a ON a.id=p.admission_id
        WHERE a.id IS NULL
    ")->fetchColumn();
    add_check(
        $checks,
        'Payments → Admission Mapping',
        $count === 0,
        $count === 0 ? 'No orphan payment records' : "$count orphan payment record(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Payments → Admission Mapping', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM payments p
        LEFT JOIN students s ON s.id=p.student_id
        WHERE s.id IS NULL
    ")->fetchColumn();
    add_check(
        $checks,
        'Payments → Student Mapping',
        $count === 0,
        $count === 0 ? 'No orphan payment records' : "$count orphan payment record(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Payments → Student Mapping', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM refunds r
        LEFT JOIN admissions a ON a.id=r.admission_id
        WHERE a.id IS NULL
    ")->fetchColumn();
    add_check(
        $checks,
        'Refunds → Admission Mapping',
        $count === 0,
        $count === 0 ? 'No orphan refund records' : "$count orphan refund record(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Refunds → Admission Mapping', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM refunds r
        LEFT JOIN students s ON s.id=r.student_id
        WHERE s.id IS NULL
    ")->fetchColumn();
    add_check(
        $checks,
        'Refunds → Student Mapping',
        $count === 0,
        $count === 0 ? 'No orphan refund records' : "$count orphan refund record(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Refunds → Student Mapping', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM payments
        WHERE amount <= 0
    ")->fetchColumn();
    add_check(
        $checks,
        'Payment Amount Integrity',
        $count === 0,
        $count === 0 ? 'No invalid payment amount' : "$count invalid payment record(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Payment Amount Integrity', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM refunds
        WHERE amount <= 0
    ")->fetchColumn();
    add_check(
        $checks,
        'Refund Amount Integrity',
        $count === 0,
        $count === 0 ? 'No invalid refund amount' : "$count invalid refund record(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Refund Amount Integrity', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM payments p
        INNER JOIN admissions a ON a.id=p.admission_id
        WHERE p.student_id <> a.student_id
    ")->fetchColumn();
    add_check(
        $checks,
        'Payment Student/Admission Match',
        $count === 0,
        $count === 0 ? 'All payment mappings match' : "$count mismatch(es)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Payment Student/Admission Match', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM refunds r
        INNER JOIN admissions a ON a.id=r.admission_id
        WHERE r.student_id <> a.student_id
    ")->fetchColumn();
    add_check(
        $checks,
        'Refund Student/Admission Match',
        $count === 0,
        $count === 0 ? 'All refund mappings match' : "$count mismatch(es)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Refund Student/Admission Match', false, $e->getMessage());
}

/* Duplicate transaction identifiers */
try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM (
            SELECT receipt_no
            FROM payments
            WHERE receipt_no IS NOT NULL AND receipt_no <> ''
            GROUP BY receipt_no
            HAVING COUNT(*) > 1
        ) d
    ")->fetchColumn();
    add_check(
        $checks,
        'Duplicate Payment Receipt No.',
        $count === 0,
        $count === 0 ? 'No duplicate receipt numbers' : "$count duplicate receipt number group(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Duplicate Payment Receipt No.', false, $e->getMessage());
}

try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM (
            SELECT refund_no
            FROM refunds
            WHERE refund_no IS NOT NULL AND refund_no <> ''
            GROUP BY refund_no
            HAVING COUNT(*) > 1
        ) d
    ")->fetchColumn();
    add_check(
        $checks,
        'Duplicate Refund No.',
        $count === 0,
        $count === 0 ? 'No duplicate refund numbers' : "$count duplicate refund number group(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Duplicate Refund No.', false, $e->getMessage());
}

/* Cancelled admissions must not have a positive outstanding due in financial data */
try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM admissions a
        WHERE a.status='Cancelled'
          AND GREATEST(
              a.final_dealing_price
              -
              GREATEST(
                  COALESCE((
                      SELECT SUM(p.amount)
                      FROM payments p
                      WHERE p.admission_id=a.id AND p.status='Valid'
                  ),0)
                  -
                  COALESCE((
                      SELECT SUM(r.amount)
                      FROM refunds r
                      WHERE r.admission_id=a.id AND r.status='Valid'
                  ),0),
                  0
              ),
              0
          ) > 0
    ")->fetchColumn();
    add_check(
        $checks,
        'Cancelled Admission Due',
        $count === 0,
        $count === 0 ? 'No cancelled admission has outstanding due' : "$count cancelled admission(s) show positive due"
    );
} catch (Throwable $e) {
    add_check($checks, 'Cancelled Admission Due', false, $e->getMessage());
}

/* Valid refund should never exceed valid paid amount for the same admission */
try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM admissions a
        INNER JOIN (
            SELECT admission_id, SUM(amount) AS refunded
            FROM refunds
            WHERE status='Valid'
            GROUP BY admission_id
        ) r ON r.admission_id=a.id
        LEFT JOIN (
            SELECT admission_id, SUM(amount) AS paid
            FROM payments
            WHERE status='Valid'
            GROUP BY admission_id
        ) p ON p.admission_id=a.id
        WHERE r.refunded > COALESCE(p.paid,0)
    ")->fetchColumn();
    add_check(
        $checks,
        'Refund ≤ Valid Paid',
        $count === 0,
        $count === 0 ? 'No admission is over-refunded' : "$count admission(s) have refund greater than valid paid"
    );
} catch (Throwable $e) {
    add_check($checks, 'Refund ≤ Valid Paid', false, $e->getMessage());
}

/* Audit log table existence plus basic orphan-user check. */
try {
    $count = (int)$pdo->query("
        SELECT COUNT(*)
        FROM audit_logs al
        LEFT JOIN users u ON u.id=al.user_id
        WHERE al.user_id IS NOT NULL AND u.id IS NULL
    ")->fetchColumn();
    add_check(
        $checks,
        'Audit Log → User Mapping',
        $count === 0,
        $count === 0 ? 'No orphan audit log user references' : "$count orphan audit log record(s)"
    );
} catch (Throwable $e) {
    add_check($checks, 'Audit Log → User Mapping', false, $e->getMessage());
}

$allGood = true;
foreach ($checks as $c) {
    if (!$c['ok']) $allGood = false;
}

require '_header.php';
?>
<div class="section-title">
    <div>
        <h1>System Check</h1>
        <p>Quick deployment, database and financial integrity health check.</p>
    </div>
</div>

<div class="card">
    <div style="padding:16px;border-radius:12px;margin-bottom:16px;background:<?= $allGood ? '#effaf4' : '#fff3f4' ?>;">
        <strong><?= $allGood ? '✓ System check passed' : '⚠ Some items need attention' ?></strong>
    </div>

    <div class="table-wrap">
        <table class="table">
            <thead>
                <tr>
                    <th>Check</th>
                    <th>Status</th>
                    <th>Details</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($checks as $check): ?>
                <tr>
                    <td><?= e($check['name']) ?></td>
                    <td>
                        <strong style="color:<?= $check['ok'] ? '#16834e' : '#c91f2e' ?>">
                            <?= $check['ok'] ? 'PASS' : 'FAIL' ?>
                        </strong>
                    </td>
                    <td><?= e($check['details']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require '_footer.php'; ?>

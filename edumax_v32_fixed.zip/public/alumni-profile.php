<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
if (function_exists('require_access')) require_access('alumni');
elseif (function_exists('is_admin') && !is_admin()) { http_response_code(403); exit('Access denied.'); }

$db=$GLOBALS['pdo'] ?? ($pdo ?? null);
if(!$db instanceof PDO) exit('Database connection is not available.');
function h($v): string{return htmlspecialchars((string)$v,ENT_QUOTES,'UTF-8');}
$id=(int)($_GET['id']??0);
if($id<1) exit('Invalid alumni record.');

try {
    $s=$db->prepare("SELECT * FROM alumni_registrations WHERE id=? LIMIT 1");
    $s->execute([$id]); $a=$s->fetch(PDO::FETCH_ASSOC);
} catch (Throwable $e) { $a=false; }
if(!$a) exit('Alumni record not found.');

if(file_exists(__DIR__.'/_header.php')) require __DIR__.'/_header.php';
?>
<style>
.ap-wrap{max-width:1000px;margin:auto;padding:20px}.ap-card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;box-shadow:0 8px 25px rgba(15,23,42,.06);overflow:hidden}
.ap-head{padding:22px 24px;display:flex;justify-content:space-between;gap:15px;border-bottom:1px solid #eee}.ap-head h2{margin:0}.ap-head p{margin:5px 0;color:#6b7280;font-size:13px}.ap-actions{display:flex;gap:8px;flex-wrap:wrap}.ap-btn{padding:10px 14px;border-radius:8px;text-decoration:none;border:0;font-weight:700;cursor:pointer}.ap-primary{background:#c91f2e;color:#fff}.ap-light{background:#f3f4f6;color:#374151}
.ap-body{padding:24px}.ap-top{display:flex;gap:18px;align-items:center;padding-bottom:20px;border-bottom:1px solid #eee}.ap-photo{width:92px;height:110px;border-radius:8px;object-fit:cover;border:1px solid #ddd;background:#f4f4f4}.ap-title h3{margin:0 0 6px}.ap-reg{color:#c91f2e;font-weight:800}.ap-section{margin-top:22px;font-size:14px;font-weight:800;color:#c91f2e;border-bottom:2px solid #f1f1f1;padding-bottom:8px}.ap-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:0}.ap-item{padding:12px 10px;border-bottom:1px solid #edf0f2}.ap-label{font-size:11px;color:#7b8188;text-transform:uppercase;font-weight:700}.ap-value{margin-top:4px;font-size:14px;font-weight:600;color:#252a30;white-space:pre-wrap}
@media(max-width:650px){.ap-head{flex-direction:column}.ap-grid{grid-template-columns:1fr}.ap-body{padding:16px}}
@media print{.ap-actions,.no-print{display:none!important}.ap-wrap{padding:0}.ap-card{box-shadow:none;border:0}.ap-head{padding:0 0 15px}.ap-body{padding:15px 0}}
</style>
<div class="ap-wrap"><div class="ap-card">
<div class="ap-head"><div><h2>🎓 Alumni Profile</h2><p>Registered Alumni Information</p></div>
<div class="ap-actions"><a class="ap-btn ap-light" href="alumni-list.php">← Back</a><button class="ap-btn ap-primary" onclick="window.print()">Print</button></div></div>
<div class="ap-body">
<div class="ap-top">
<?php if($a['photo']):?><img class="ap-photo" src="<?=h('../'.$a['photo'])?>" alt="Alumni Photo"><?php else:?><div class="ap-photo"></div><?php endif;?>
<div class="ap-title"><h3><?=h($a['alumni_name'])?></h3><div class="ap-reg"><?=h($a['registration_no'])?></div><div><?=h($a['batch'] ?: 'Batch not provided')?> · <?=h($a['status'])?></div></div>
</div>
<div class="ap-section">Personal Information</div><div class="ap-grid">
<?php foreach([
'Mobile No.'=>'mobile_no','Alumni Contact No.'=>'alumni_contact_no','Blood Group'=>'blood_group','Date of Birth'=>'date_of_birth','Email'=>'email','Residential Address'=>'residential_address'
] as $label=>$key):?><div class="ap-item"><div class="ap-label"><?=h($label)?></div><div class="ap-value"><?=h($a[$key] ?: '—')?></div></div><?php endforeach;?>
</div>
<div class="ap-section">Family Information</div><div class="ap-grid">
<?php foreach(["Father's Name"=>'father_name',"Father's Occupation"=>'father_occupation',"Father's Mobile"=>'father_mobile',"Mother's Name"=>'mother_name',"Mother's Occupation"=>'mother_occupation',"Mother's Mobile"=>'mother_mobile'] as $label=>$key):?><div class="ap-item"><div class="ap-label"><?=h($label)?></div><div class="ap-value"><?=h($a[$key] ?: '—')?></div></div><?php endforeach;?>
</div>
<div class="ap-section">Presently Working / Studying</div><div class="ap-grid">
<?php foreach(['Current Status'=>'present_status','Level Presently Enrolled'=>'study_level','Profession'=>'profession','Organization Name'=>'organization_name','Key Skills'=>'key_skills'] as $label=>$key):?><div class="ap-item"><div class="ap-label"><?=h($label)?></div><div class="ap-value"><?=h($a[$key] ?: '—')?></div></div><?php endforeach;?>
</div>
</div></div></div>
<?php if(file_exists(__DIR__.'/_footer.php')) require __DIR__.'/_footer.php'; ?>

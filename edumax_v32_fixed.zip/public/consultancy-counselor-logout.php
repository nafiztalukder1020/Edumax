<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
$logoutToken = $_POST['_csrf'] ?? $_GET['_csrf'] ?? null;
if (!empty($_SESSION['counselor_id']) && !csrf_validate(is_string($logoutToken) ? $logoutToken : null)) {
    header('Location: consultancy-counselor-dashboard.php');
    exit;
}
unset($_SESSION['counselor_id'], $_SESSION['counselor_name'], $_SESSION['counselor_username']);
header('Location: consultancy-counselor-login.php');
exit;

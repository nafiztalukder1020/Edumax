<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';

if (is_admin()) {
    header('Location: workspace-switch.php?to=auto');
    exit;
}

$error = '';
require_valid_csrf();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    $locked = login_is_locked('admin', $username);
    $user = false;
    if (!$locked) {
        $stmt = $pdo->prepare("SELECT * FROM users WHERE username=? AND status='Active' LIMIT 1");
        $stmt->execute([$username]);
        $user = $stmt->fetch();
    }

    if (!$locked && $user && password_verify($password, $user['password_hash'])) {
        login_record_attempt('admin', $username, true);
        session_regenerate_id(true);
        $_SESSION['user_id'] = (int)$user['id'];
        $_SESSION['user_name'] = $user['name'];
        $_SESSION['role'] = $user['role'];

        // Record the latest successful login and login count.
        // Activity metrics must never block a valid login.
        try {
            $pdo->prepare("UPDATE users SET last_login=NOW(), login_count=COALESCE(login_count,0)+1 WHERE id=?")
                ->execute([(int)$user['id']]);
        } catch (Throwable $e) {
            // Keep login working even if activity columns are unavailable.
        }

        try {
            $audit = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'Login', ?)");
            $audit->execute([(int)$user['id'], 'Successful login']);
        } catch (Throwable $e) {
            // A temporary audit-log issue should not block a valid login.
        }

        header('Location: workspace-switch.php?to=auto');
        exit;
    }

    if ($locked) {
        $error = 'Too many failed login attempts. Please wait ' . LOGIN_LOCK_MINUTES . ' minutes and try again.';
    } else {
        login_record_attempt('admin', $username, false);
        $error = 'Invalid username or password.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#c91f2e">
<title>Edumax Login</title>
<link rel="stylesheet" href="assets/style.css">
<style>
html,body{min-height:100%}
body.login{
    min-height:100vh;min-height:100dvh;width:100%;margin:0;padding:24px;
    display:flex;align-items:center;justify-content:center;overflow-x:hidden;
    background:
        radial-gradient(circle at 90% 10%,rgba(201,31,46,.10),transparent 30%),
        radial-gradient(circle at 10% 90%,rgba(95,95,99,.07),transparent 28%),
        #f6f7f9!important
}
body.login .login-box{
    width:100%;max-width:440px;margin:0 auto;padding:34px 32px;
    background:#fff;border:1px solid #e7e8ec;border-radius:18px;
    box-shadow:0 18px 50px rgba(32,36,43,.10)
}
body.login .login-logo{width:100%;margin:0 0 20px;text-align:center}
body.login .login-logo img{
    display:block;width:auto;max-width:210px;max-height:75px;height:auto;
    margin:0 auto;object-fit:contain
}
body.login h1{
    margin:0 0 25px;text-align:center;color:#20242b;font-size:22px;
    line-height:1.3;font-weight:800;letter-spacing:-.02em
}
body.login form{width:100%;margin:0}
body.login .field{width:100%;margin:0 0 16px}
body.login .field label{
    display:block;margin:0 0 7px;color:#444951;font-size:13px;font-weight:700
}
body.login .field input{
    display:block;width:100%!important;min-width:0;min-height:48px;margin:0;
    padding:12px 14px!important;border:1px solid #dfe2e7!important;
    border-radius:10px!important;background:#fff!important;color:#20242b;
    font-size:15px;outline:none;box-sizing:border-box
}
body.login .field input:focus{
    border-color:#c91f2e!important;
    box-shadow:0 0 0 3px rgba(201,31,46,.09)!important
}
body.login .password-wrap{position:relative}
body.login .password-wrap input{padding-right:48px!important}
body.login .toggle-password{
    position:absolute;right:10px;top:50%;transform:translateY(-50%);
    width:34px;height:34px;border:0;background:transparent;color:#70757d;
    cursor:pointer;border-radius:8px;display:flex;align-items:center;
    justify-content:center;padding:0
}
body.login .toggle-password:hover{background:#f2f3f5;color:#c91f2e}
body.login .toggle-password svg{width:19px;height:19px;display:block}
body.login .login-options{
    display:flex;align-items:center;justify-content:space-between;
    gap:12px;margin:-2px 0 16px
}
body.login .remember{
    display:flex;align-items:center;gap:7px;color:#626871;font-size:12px;
    cursor:pointer;user-select:none
}
body.login .remember input{
    width:15px;height:15px;margin:0;accent-color:#c91f2e;cursor:pointer
}
body.login .btn-primary{
    display:flex;align-items:center;justify-content:center;width:100%!important;
    min-height:50px!important;margin-top:4px;padding:12px 18px!important;
    border:0!important;border-radius:11px!important;
    background:linear-gradient(135deg,#cf2032 0%,#b8182a 100%)!important;
    color:#fff!important;font-size:14px;font-weight:800;letter-spacing:.04em;
    box-shadow:0 7px 18px rgba(201,31,46,.18);cursor:pointer
}
body.login .btn-primary:disabled{opacity:.75;cursor:wait}
body.login .login-help{
    margin:16px 0 0;text-align:center;color:#7a8088;font-size:12px
}
body.login .alert{
    margin:0 0 16px;padding:10px 12px;border-radius:9px;
    font-size:13px;line-height:1.45
}
@media(max-width:640px){
    body.login{padding:18px}
    body.login .login-box{max-width:420px;padding:30px 24px;border-radius:16px}
    body.login h1{font-size:20px}
}
@media(max-width:480px){
    body.login{padding:12px;align-items:center}
    body.login .login-box{max-width:100%;padding:25px 18px;border-radius:14px}
    body.login .login-logo{margin-bottom:15px}
    body.login .login-logo img{max-width:170px!important;max-height:62px}
    body.login h1{font-size:18px;margin-bottom:21px}
    body.login .field{margin-bottom:14px}
    body.login .field input{font-size:16px;min-height:48px}
    body.login .btn-primary{min-height:49px!important}
}
@media(max-width:360px){
    body.login{padding:9px}
    body.login .login-box{padding:22px 14px;border-radius:12px}
    body.login .login-logo img{max-width:150px!important}
    body.login h1{font-size:17px}
}
@media(max-height:600px) and (max-width:480px){
    body.login{align-items:flex-start}
    .login-box{margin:0 auto!important}
}
</style>
</head>
<body class="login">
<div class="login-box">
    <div class="login-logo">
        <img src="assets/edumax-logo.png" alt="Edumax IELTS Center">
    </div>

    <h1>Admission Management System</h1>

    <?php if ($error): ?>
        <div class="alert"><?=e($error)?></div>
    <?php endif; ?>

    <form method="post" autocomplete="on" id="loginForm">
        <?=csrf_input()?>

        <div class="field">
            <label for="username">Username</label>
            <input
                id="username"
                type="text"
                name="username"
                autocomplete="username"
                autocapitalize="none"
                spellcheck="false"
                required
            >
        </div>

        <div class="field">
            <label for="password">Password</label>
            <div class="password-wrap">
                <input
                    id="password"
                    type="password"
                    name="password"
                    autocomplete="current-password"
                    required
                >
                <button type="button" class="toggle-password" id="togglePassword"
                        aria-label="Show password" title="Show password">
                    <svg id="eyeIcon" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                         stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"
                         aria-hidden="true">
                        <path d="M2.5 12s3.5-6 9.5-6 9.5 6 9.5 6-3.5 6-9.5 6-9.5-6-9.5-6z"/>
                        <circle cx="12" cy="12" r="2.5"/>
                    </svg>
                </button>
            </div>
        </div>

        <div class="login-options">
            <label class="remember">
                <input type="checkbox" name="remember" value="1" id="remember">
                <span>Remember me</span>
            </label>
        </div>

        <button type="submit" class="btn btn-primary" id="loginButton">LOGIN</button>
    </form>

    <p class="login-help">Edumax authorized staff access only.</p>
</div>

<script>
(function(){
    const password = document.getElementById('password');
    const toggle = document.getElementById('togglePassword');
    const loginForm = document.getElementById('loginForm');
    const loginButton = document.getElementById('loginButton');

    toggle.addEventListener('click', function(){
        const showing = password.type === 'text';
        password.type = showing ? 'password' : 'text';
        toggle.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
        toggle.setAttribute('title', showing ? 'Show password' : 'Hide password');
    });

    loginForm.addEventListener('submit', function(){
        loginButton.disabled = true;
        loginButton.textContent = 'SIGNING IN...';
    });
})();
</script>
</body>
</html>

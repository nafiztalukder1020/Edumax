<?php
require_once __DIR__ . '/../config/app.php';
require_access('students');

$studentCode = trim($_GET['id'] ?? '');
if ($studentCode === '') {
    http_response_code(400);
    exit('Student ID is required.');
}

$studentStmt = $pdo->prepare("SELECT s.* FROM students s WHERE s.student_id = ? LIMIT 1");
$studentStmt->execute([$studentCode]);
$student = $studentStmt->fetch();
if (!$student) {
    http_response_code(404);
    exit('Student not found.');
}
$studentDbId = (int)$student['id'];
$profileIsIelts = false;

// Batch transfer history. This keeps an audit trail while the latest admission
// always represents the student's current batch/time slot.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS student_batch_transfers (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        student_id INT UNSIGNED NOT NULL,
        admission_id INT UNSIGNED NOT NULL,
        from_batch_id INT UNSIGNED NULL,
        from_time_slot VARCHAR(100) NULL,
        to_batch_id INT UNSIGNED NOT NULL,
        to_time_slot VARCHAR(100) NULL,
        reason VARCHAR(255) NULL,
        transferred_by INT UNSIGNED NULL,
        transferred_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        KEY idx_transfer_student (student_id),
        KEY idx_transfer_admission (admission_id),
        CONSTRAINT fk_transfer_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        CONSTRAINT fk_transfer_admission FOREIGN KEY (admission_id) REFERENCES admissions(id) ON DELETE CASCADE,
        CONSTRAINT fk_transfer_from_batch FOREIGN KEY (from_batch_id) REFERENCES batches(id) ON DELETE SET NULL,
        CONSTRAINT fk_transfer_to_batch FOREIGN KEY (to_batch_id) REFERENCES batches(id) ON DELETE RESTRICT,
        CONSTRAINT fk_transfer_user FOREIGN KEY (transferred_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {
    // Transfer history is optional; the profile remains usable if setup is unavailable.
}

// Student materials tracking. ID Card is for every student; IELTS Book is only for IELTS students.
try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS student_materials (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        student_id INT UNSIGNED NOT NULL,
        material_type VARCHAR(30) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'Pending',
        given_at DATETIME NULL,
        given_by INT UNSIGNED NULL,
        note VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_student_material (student_id, material_type),
        KEY idx_material_type_status (material_type,status),
        KEY idx_student_material_student (student_id),
        CONSTRAINT fk_student_material_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
        CONSTRAINT fk_student_material_user FOREIGN KEY (given_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch (Throwable $e) {
    // Keep the profile page usable if the materials table cannot be created yet.
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['materials_action'] ?? '') === 'give') {
    verify_csrf();
    $materialType = trim((string)($_POST['material_type'] ?? ''));
    if (in_array($materialType, ['ID Card', 'IELTS Book'], true)) {
        $isIelts = false;
        if (!empty($latestAdmissionId ?? 0)) {
            // Latest admission is not available yet at this point, so check directly.
        }
        try {
            $courseCheck = $pdo->prepare("SELECT 1
                FROM admissions a
                INNER JOIN courses c ON c.id = a.course_id
                WHERE a.student_id = ? AND a.status <> 'Cancelled'
                ORDER BY a.id DESC LIMIT 1");
            $courseCheck->execute([$studentDbId]);
            $latestCourseIsIelts = (bool)$courseCheck->fetchColumn();
            if ($latestCourseIsIelts) {
                $courseNameCheck = $pdo->prepare("SELECT c.name
                    FROM admissions a
                    INNER JOIN courses c ON c.id = a.course_id
                    WHERE a.student_id = ? AND a.status <> 'Cancelled'
                    ORDER BY a.id DESC LIMIT 1");
                $courseNameCheck->execute([$studentDbId]);
                $isIelts = stripos((string)$courseNameCheck->fetchColumn(), 'ielts') !== false;
            } else {
                $appCourseCheck = $pdo->prepare("SELECT course_interest FROM applications WHERE student_id=? ORDER BY id DESC LIMIT 1");
                $appCourseCheck->execute([$studentDbId]);
                $isIelts = stripos((string)$appCourseCheck->fetchColumn(), 'ielts') !== false;
            }
        } catch (Throwable $e) {
            $isIelts = false;
        }

        if ($materialType === 'IELTS Book' && !$isIelts) {
            flash('error', 'IELTS Book is only for IELTS students.');
        } else {
            try {
                $matStmt = $pdo->prepare("INSERT INTO student_materials
                    (student_id, material_type, status, given_at, given_by)
                    VALUES (?, ?, 'Given', NOW(), ?)
                    ON DUPLICATE KEY UPDATE
                        status='Given', given_at=NOW(), given_by=VALUES(given_by)");
                $matStmt->execute([$studentDbId, $materialType, (int)$_SESSION['user_id']]);
                flash('success', $materialType . ' marked as Given.');
            } catch (Throwable $e) {
                flash('error', 'Could not update material status. Please check the student_materials table.');
            }
        }
    }
    header('Location: student-profile.php?id=' . urlencode($student['student_id']));
    exit;
}

// Latest application / IELTS target / lead source.
$appStmt = $pdo->prepare("SELECT * FROM applications WHERE student_id = ? ORDER BY id DESC LIMIT 1");
$appStmt->execute([$studentDbId]);
$application = $appStmt->fetch() ?: [];
if (!$profileIsIelts) {
    $profileIsIelts = stripos((string)($application['course_interest'] ?? ''), 'ielts') !== false;
}

// Academic excellence records.
$academicStmt = $pdo->prepare("SELECT * FROM academic_records WHERE student_id = ? ORDER BY FIELD(degree,'Masters','Honors','Diploma','HSC/Equivalent','SSC/Equivalent'), id DESC");
$academicStmt->execute([$studentDbId]);
$academics = $academicStmt->fetchAll();

// Detect the optional time_slot column so older databases do not break the page.
$hasTimeSlot = false;
try {
    $columnStmt = $pdo->query("SHOW COLUMNS FROM admissions LIKE 'time_slot'");
    $hasTimeSlot = (bool)$columnStmt->fetch();
} catch (Throwable $e) {
    $hasTimeSlot = false;
}
$timeSlotSelect = $hasTimeSlot ? ', a.time_slot' : ", NULL AS time_slot";

// Mock Test package / usage summary.
$mockTestAdmissions = [];
try {
    $mq = $pdo->prepare("SELECT a.id, a.mock_package, a.mock_day, a.status,
        COALESCE((SELECT COUNT(*) FROM mock_test_usage mu WHERE mu.admission_id=a.id AND mu.status='Completed'),0) AS used_mocks
        FROM admissions a INNER JOIN courses c ON c.id=a.course_id
        WHERE a.student_id=? AND LOWER(c.name)='mock test' AND a.status<>'Cancelled' ORDER BY a.id DESC");
    $mq->execute([$studentDbId]);
    $mockTestAdmissions = $mq->fetchAll();
} catch (Throwable $e) { $mockTestAdmissions=[]; }

// Full admission history, newest first.
$admissionStmt = $pdo->prepare("SELECT a.id, a.student_id, a.course_id, a.batch_id, a.admission_date,
    a.regular_fee, a.discount, a.do_discount, a.final_dealing_price,
    a.reference, a.status, a.admin_note, a.created_at{$timeSlotSelect},
    c.name AS course_name, b.name AS batch_name, b.start_date AS batch_start_date
    FROM admissions a
    LEFT JOIN courses c ON c.id = a.course_id
    LEFT JOIN batches b ON b.id = a.batch_id
    WHERE a.student_id = ?
    ORDER BY a.id DESC");
$admissionStmt->execute([$studentDbId]);
$admissions = $admissionStmt->fetchAll();
$latestAdmission = $admissions[0] ?? [];

// IELTS Book is available only for IELTS students.
// Prefer the latest admission course; fall back to the application course.
$profileIsIelts = !empty($latestAdmission['course_name'])
    && stripos((string)$latestAdmission['course_name'], 'ielts') !== false;
if (!$profileIsIelts) {
    $profileIsIelts = stripos((string)($application['course_interest'] ?? ''), 'ielts') !== false;
}

 // Current material status for this student.
$materialStatus = ['ID Card' => null, 'IELTS Book' => null];
try {
    $materialStmt = $pdo->prepare("SELECT material_type, status, given_at, given_by, note
        FROM student_materials WHERE student_id = ?");
    $materialStmt->execute([$studentDbId]);
    foreach ($materialStmt->fetchAll(PDO::FETCH_ASSOC) as $mr) {
        if (isset($materialStatus[$mr['material_type']])) $materialStatus[$mr['material_type']] = $mr;
    }
} catch (Throwable $e) {
    // Optional until the materials table is installed.
}
// All payments for this student. Valid payments count toward totals; void ones remain visible in history.
$paymentStmt = $pdo->prepare("SELECT p.*, u.name AS received_by_name,
    c.name AS course_name, b.name AS batch_name
    FROM payments p
    LEFT JOIN users u ON u.id = p.received_by
    LEFT JOIN admissions a ON a.id = p.admission_id
    LEFT JOIN courses c ON c.id = a.course_id
    LEFT JOIN batches b ON b.id = a.batch_id
    WHERE p.student_id = ?
    ORDER BY p.id DESC");
$paymentStmt->execute([$studentDbId]);
$payments = $paymentStmt->fetchAll();

$totalFinal = 0.0;
$hasNonCancelledAdmission = false;
foreach ($admissions as $adm) {
    if (($adm['status'] ?? '') !== 'Cancelled') {
        $totalFinal += (float)($adm['final_dealing_price'] ?? 0);
        $hasNonCancelledAdmission = true;
    }
}

// If the latest/only admission was cancelled, keep its original final dealing
// price visible in the profile instead of showing ৳0.00.
if (!$hasNonCancelledAdmission && !empty($latestAdmission['final_dealing_price'])) {
    $totalFinal = (float)$latestAdmission['final_dealing_price'];
}

$totalPaid = 0.0;
foreach ($payments as $payment) {
    if (($payment['status'] ?? '') === 'Valid') {
        $totalPaid += (float)$payment['amount'];
    }
}
try {
    $refundTotalStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE student_id=? AND status='Valid'");
    $refundTotalStmt->execute([$studentDbId]);
    $totalPaid = max(0, $totalPaid - (float)$refundTotalStmt->fetchColumn());
} catch (Throwable $e) {
    // Refund module may not be installed yet.
}
// A cancelled admission has no collectible due. The original paid amount
// remains visible, while any valid refund is already deducted from net paid.
$totalDue = (($latestAdmission['status'] ?? '') === 'Cancelled')
    ? 0.0
    : max(0, $totalFinal - $totalPaid);

// The current admission status must always follow the latest admission's actual payment state.
// This prevents an old/stale 'Active' flag from showing while money is still due.
$latestPaid = 0.0;
$latestDue = 0.0;
if (!empty($latestAdmission['id'])) {
    $latestPaidStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE admission_id=? AND status='Valid'");
    $latestPaidStmt->execute([(int)$latestAdmission['id']]);
    $latestGrossPaid = (float)$latestPaidStmt->fetchColumn();
    $latestRefundStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE admission_id=? AND status='Valid'");
    $latestRefundStmt->execute([(int)$latestAdmission['id']]);
    $latestRefunded = (float)$latestRefundStmt->fetchColumn();
    $latestPaid = max(0, $latestGrossPaid - $latestRefunded);
    $latestFinal = (float)($latestAdmission['final_dealing_price'] ?? 0);
    $latestDue = (($latestAdmission['status'] ?? '') === 'Cancelled')
        ? 0.0
        : max(0, $latestFinal - $latestPaid);
}

// Attendance is optional for installations that have not yet imported attendance.sql.
$attendanceRows = [];
$attendanceTotal = 0;
$attendancePresent = 0;
$attendanceAbsent = 0;
$attendancePercent = 0.0;
$hasAttendanceTable = false;
try {
    $checkAttendance = $pdo->query("SHOW TABLES LIKE 'attendance'");
    $hasAttendanceTable = (bool)$checkAttendance->fetch();
    if ($hasAttendanceTable) {
        $attStmt = $pdo->prepare("SELECT at.attendance_date, at.status, at.batch_id,
            b.name AS batch_name, u.name AS marked_by_name
            FROM attendance at
            LEFT JOIN batches b ON b.id = at.batch_id
            LEFT JOIN users u ON u.id = at.marked_by
            WHERE at.student_id = ?
            ORDER BY at.attendance_date DESC, at.id DESC");
        $attStmt->execute([$studentDbId]);
        $attendanceRows = $attStmt->fetchAll();
        $attendanceTotal = count($attendanceRows);
        foreach ($attendanceRows as $row) {
            if (($row['status'] ?? '') === 'Present') $attendancePresent++;
            if (($row['status'] ?? '') === 'Absent') $attendanceAbsent++;
        }
        $attendancePercent = $attendanceTotal > 0 ? round(($attendancePresent / $attendanceTotal) * 100, 1) : 0.0;
    }
} catch (Throwable $e) {
    $hasAttendanceTable = false;
}

// Performance summary is optional; safely skip it if the performance module table is not installed.
$performanceEvaluation = null;
$performanceHistory = [];
$hasPerformanceTable = false;
try {
    $checkPerformance = $pdo->query("SHOW TABLES LIKE 'performance_evaluations'");
    $hasPerformanceTable = (bool)$checkPerformance->fetch();

    if ($hasPerformanceTable) {
        // Latest evaluation for this student.
        $perfStmt = $pdo->prepare("
            SELECT e.*, u.name AS evaluator_name
            FROM performance_evaluations e
            LEFT JOIN users u ON u.id = e.evaluated_by
            WHERE e.student_id = ?
            ORDER BY e.evaluation_month DESC, e.id DESC
            LIMIT 1
        ");
        $perfStmt->execute([$studentDbId]);
        $performanceEvaluation = $perfStmt->fetch() ?: null;

        // Recent evaluation history for the profile.
        $perfHistoryStmt = $pdo->prepare("
            SELECT evaluation_month, participation, homework_assigned,
                   homework_completed, speaking, listening, reading,
                   writing, grammar, vocabulary, updated_at
            FROM performance_evaluations
            WHERE student_id = ?
            ORDER BY evaluation_month DESC, id DESC
            LIMIT 6
        ");
        $perfHistoryStmt->execute([$studentDbId]);
        $performanceHistory = $perfHistoryStmt->fetchAll();
    }
} catch (Throwable $e) {
    $hasPerformanceTable = false;
    $performanceEvaluation = null;
    $performanceHistory = [];
}

function performance_rating_class($value): string {
    $value = strtolower(trim((string)$value));
    if ($value === 'excellent') return 'excellent';
    if ($value === 'very good') return 'very-good';
    if ($value === 'good') return 'good';
    if ($value === 'average') return 'average';
    if ($value === 'needs improvement') return 'needs-improvement';
    return '';
}

function performance_rating_score($value): int {
    switch (strtolower(trim((string)$value))) {
        case 'excellent': return 5;
        case 'very good': return 4;
        case 'good': return 3;
        case 'average': return 2;
        case 'needs improvement': return 1;
        default: return 0;
    }
}

$performanceAverage = 0;
$performanceSkillCount = 0;
$performanceWeakAreas = [];
$performanceStrongAreas = [];

if ($performanceEvaluation) {
    $performanceFields = [
        'speaking' => 'Speaking',
        'listening' => 'Listening',
        'reading' => 'Reading',
        'writing' => 'Writing',
        'grammar' => 'Grammar',
        'vocabulary' => 'Vocabulary'
    ];

    $performanceScoreTotal = 0;
    foreach ($performanceFields as $field => $label) {
        $score = performance_rating_score($performanceEvaluation[$field] ?? '');
        if ($score > 0) {
            $performanceScoreTotal += $score;
            $performanceSkillCount++;
            if ($score <= 2) $performanceWeakAreas[] = $label;
            if ($score >= 4) $performanceStrongAreas[] = $label;
        }
    }

    if ($performanceSkillCount > 0) {
        $performanceAverage = round($performanceScoreTotal / $performanceSkillCount, 1);
    }
}

$performanceHomeworkPercent = 0;
if ($performanceEvaluation && (int)($performanceEvaluation['homework_assigned'] ?? 0) > 0) {
    $performanceHomeworkPercent = round(
        ((int)$performanceEvaluation['homework_completed'] / (int)$performanceEvaluation['homework_assigned']) * 100,
        1
    );
}

function profile_value($value): string {
    if ($value === null || $value === '') return '-';
    return e((string)$value);
}

$currentStatus = $latestAdmission['status'] ?? ($application['status'] ?? 'Pending');
if (!empty($latestAdmission['id']) && ($latestAdmission['status'] ?? '') !== 'Cancelled') {
    // Never promote a Pending admission merely because a payment exists.
    // Approval is an explicit administrative action.
    if (($latestAdmission['status'] ?? '') === 'Pending') {
        $currentStatus = 'Pending';
    } else {
        $currentStatus = ($latestDue <= 0) ? 'Active' : 'Approved';
    }
    if (($latestAdmission['status'] ?? '') !== $currentStatus) {
        $sync = $pdo->prepare("UPDATE admissions SET status=? WHERE id=? AND status <> 'Cancelled'");
        $sync->execute([$currentStatus, (int)$latestAdmission['id']]);
        if (!empty($application['id'])) {
            $appSync = $pdo->prepare("UPDATE applications SET status=? WHERE id=?");
            $appSync->execute([$currentStatus, (int)$application['id']]);
        }
    }
}
$latestAdmissionId = isset($latestAdmission['id']) ? (int)$latestAdmission['id'] : 0;

require '_header.php';
?>
<?php foreach (flash_messages() as $flashMsg): ?>
<div class="alert <?= $flashMsg['type'] === 'success' ? 'alert-success' : 'alert-error' ?>"><?=e($flashMsg['message'])?></div>
<?php endforeach; ?>
<?php if ($mockTestAdmissions): ?>
<div class="card edmx-card" style="margin-bottom:18px"><h2>Mock Test</h2>
<?php foreach($mockTestAdmissions as $mi=>$m): $pkgCounts=['1 Mock'=>1,'2 Mocks'=>2,'3 Mocks'=>3]; $mc=(int)($pkgCounts[$m['mock_package']]??0); $mu=(int)$m['used_mocks']; $mr=max(0,$mc-$mu); ?>
<div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap;padding:12px 0;border-bottom:<?= $mi<count($mockTestAdmissions)-1?'1px solid #eee':'0' ?>"><div><strong><?=e($m['mock_package'])?></strong><br><small><?=e($m['mock_day'])?> · 10:00 AM – 1:00 PM · Used <?=$mu?> / <?=$mc?> · Remaining <?=$mr?></small></div><a class="btn btn-primary" href="mock-test.php?admission_id=<?=urlencode($m['id'])?>">Manage Mock</a></div>
<?php endforeach; ?></div>
<?php endif; ?>


<style>
.profile-hero{background:linear-gradient(135deg,#22262d 0%,#3c3f46 60%,#c91f2e 150%);color:#fff;border-radius:20px;padding:24px;box-shadow:0 18px 45px rgba(32,36,43,.14);margin-bottom:18px;position:relative;overflow:hidden}.profile-hero:after{content:"";position:absolute;width:220px;height:220px;border-radius:50%;background:rgba(201,31,46,.18);right:-80px;top:-90px}.profile-hero h1{margin:0 0 5px;font-size:28px}.profile-hero p{margin:0;color:rgba(255,255,255,.78)}.profile-hero .actions{position:relative;z-index:2;display:flex;flex-wrap:wrap;gap:9px}.profile-hero-top{display:flex;justify-content:space-between;align-items:flex-start;gap:18px}.profile-id-badge{display:inline-flex;margin-top:12px;padding:6px 11px;border-radius:999px;background:rgba(255,255,255,.11);font-size:13px;font-weight:700}.profile-kpis{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin-bottom:18px}.profile-kpi{padding:18px;border:1px solid #ececf0;border-radius:17px;background:linear-gradient(180deg,#fff,#fbfbfc);box-shadow:0 8px 25px rgba(30,34,40,.045)}.profile-kpi small{display:block;color:#7a7f87;font-weight:700;font-size:11px;letter-spacing:.55px;margin-bottom:8px}.profile-kpi strong{font-size:23px;color:#252930}.profile-kpi.due strong{color:#c91f2e}.profile-card{margin-bottom:18px}.profile-card h2{margin-bottom:4px}.profile-sub{color:#7a7f87;font-size:13px;margin:0 0 16px}.info-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:13px}.info-cell{background:#fafafb;border:1px solid #ededf0;border-radius:13px;padding:12px}.info-cell.wide{grid-column:1/-1}.info-cell small{display:block;color:#7b8088;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;margin-bottom:5px}.info-cell strong{display:block;color:#24282f;line-height:1.45;word-break:break-word}.section-head{display:flex;justify-content:space-between;gap:12px;align-items:center;margin-bottom:12px}.status-pill{display:inline-flex;padding:5px 9px;border-radius:999px;background:#f3f4f6;color:#4b5058;font-size:12px;font-weight:700}.status-pill.present,.status-pill.active,.status-pill.approved,.status-pill.valid{background:#eaf7ef;color:#237a46}.status-pill.absent,.status-pill.cancelled,.status-pill.void{background:#fff0f1;color:#b31e2c}.attendance-meter{height:10px;background:#eceef1;border-radius:999px;overflow:hidden;margin-top:8px}.attendance-meter span{display:block;height:100%;background:linear-gradient(90deg,#c91f2e,#e75b67);border-radius:999px}.table.compact td,.table.compact th{padding:10px 11px}
.performance-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:14px}
.performance-stat{padding:15px;border:1px solid #eceef2;border-radius:13px;background:#fafbfc}
.performance-stat small{display:block;color:#7b8088;font-size:10px;font-weight:800;text-transform:uppercase;letter-spacing:.45px;margin-bottom:6px}
.performance-stat strong{display:block;font-size:20px;color:#252930}
.performance-skills{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px}
.performance-skill{display:flex;align-items:center;justify-content:space-between;gap:10px;padding:11px 12px;border:1px solid #eceef2;border-radius:11px;background:#fff}
.performance-skill span:first-child{font-weight:700;color:#30343b;font-size:12px}
.performance-rating{padding:4px 8px;border-radius:999px;font-size:10px;font-weight:800;white-space:nowrap}
.performance-rating.excellent,.performance-rating.very-good{background:#eaf7ef;color:#237a46}
.performance-rating.good{background:#eef4ff;color:#315d9b}
.performance-rating.average{background:#fff7e6;color:#9a6900}
.performance-rating.needs-improvement{background:#fff0f1;color:#b31e2c}
.performance-bar-wrap{display:flex;align-items:center;gap:8px;min-width:150px}
.performance-bar{height:7px;flex:1;min-width:80px;background:#eceef1;border-radius:999px;overflow:hidden}
.performance-bar span{display:block;height:100%;border-radius:999px;background:linear-gradient(90deg,#c91f2e,#e75b67)}
.performance-score{font-size:10px;font-weight:800;color:#666b73;min-width:26px;text-align:right}
.performance-note{padding:12px 14px;border-radius:12px;background:#fafbfc;border:1px solid #eceef2;margin-top:12px;color:#555b64;font-size:12px;line-height:1.6}
.performance-history td{white-space:nowrap}
@media(max-width:1050px){.performance-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.performance-skills{grid-template-columns:repeat(2,minmax(0,1fr))}}
@media(max-width:680px){.performance-grid,.performance-skills{grid-template-columns:1fr}.performance-skill{flex-wrap:wrap}.performance-bar-wrap{flex:1;min-width:130px}}
.materials-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.material-item{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:15px;border:1px solid #eceef2;border-radius:13px;background:#fafbfc}.material-item strong{display:block;color:#252930}.material-meta{font-size:11px;color:#7b8088;margin-top:4px}.material-actions{display:flex;align-items:center;gap:8px;flex-wrap:wrap}.material-given{background:#eaf7ef;color:#237a46}.material-pending{background:#fff4df;color:#a15b00}.material-link{font-size:12px;font-weight:700}.material-actions form{margin:0!important;display:inline-flex!important;align-items:center!important}.material-give-btn{display:inline-flex!important;align-items:center!important;justify-content:center!important;padding:8px 12px!important;border:0!important;border-radius:9px!important;cursor:pointer!important;font-weight:700!important;font-size:12px!important;background:#c91f2e!important;color:#fff!important;visibility:visible!important;opacity:1!important}@media(max-width:680px){.materials-grid{grid-template-columns:1fr}}.print-only{display:none}@media(max-width:1050px){.profile-kpis,.info-grid{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:680px){.profile-hero-top{display:block}.profile-hero .actions{margin-top:16px}.profile-kpis,.info-grid{grid-template-columns:1fr}.info-cell.wide{grid-column:auto}}@media print{.topbar,.sidebar,.sidebar-overlay,.profile-hero .actions,.no-print,.edmx-top-accent{display:none!important}.content{margin:0!important;padding:0!important;max-width:none!important}.profile-hero{background:#fff!important;color:#111!important;box-shadow:none;border:1px solid #ddd}.profile-hero p{color:#555!important}.profile-id-badge{background:#f1f1f1!important;color:#222}.profile-kpis{grid-template-columns:repeat(4,1fr)}.profile-card,.profile-kpi{box-shadow:none!important;break-inside:avoid}.print-only{display:block}.table{font-size:11px}}
</style>

<div class="profile-hero">
    <div class="profile-hero-top">
        <div>
            <h1><?= profile_value($student['full_name'] ?? '') ?></h1>
            <p><?= profile_value($student['mobile'] ?? '') ?><?php if (!empty($student['email'])): ?> · <?= e($student['email']) ?><?php endif; ?></p>
            <span class="profile-id-badge">Student ID: <?= e($student['student_id']) ?></span>
        </div>
        <div class="actions">
            <button class="btn btn-light" type="button" onclick="window.print()">Print Profile</button>
            <?php if ($latestAdmissionId && $latestDue > 0 && $currentStatus === 'Approved' && has_role(['Super Admin','Admission Admin','Accounts','Reception'])): ?>
                <a class="btn btn-primary" href="due-payment.php?id=<?= urlencode($student['student_id']) ?>">+ Due Payment</a>
            <?php endif; ?>
            <a class="btn btn-light" href="students.php">Back</a>
        </div>
    </div>
</div>

<div class="profile-kpis">
    <div class="profile-kpi"><small>CURRENT STATUS</small><strong style="font-size:19px"><?= profile_value($currentStatus) ?></strong></div>
    <div class="profile-kpi"><small>TOTAL DEALING PRICE</small><strong>৳<?= number_format($totalFinal, 2) ?></strong></div>
    <div class="profile-kpi"><small>TOTAL PAID</small><strong>৳<?= number_format($totalPaid, 2) ?></strong></div>
    <div class="profile-kpi due"><small>CURRENT DUE</small><strong>৳<?= number_format($totalDue, 2) ?></strong></div>
</div>

<?php if (!empty($latestAdmission)): ?>
<div class="card profile-card">
    <div class="section-head">
        <div>
            <h2>Current Course & Batch</h2>
            <p class="profile-sub">Latest active admission details</p>
        </div>
        <div style="display:flex;align-items:center;gap:9px;flex-wrap:wrap">
            <?php if ($latestAdmissionId && $currentStatus !== 'Cancelled' && has_role(['Super Admin','Admission Admin','Reception'])): ?>
                <a class="btn btn-primary no-print" href="student-batch-transfer.php?id=<?= urlencode($student['student_id']) ?>">Transfer Batch</a>
            <?php endif; ?>
            <span class="status-pill <?= e(strtolower((string)$currentStatus)) ?>"><?= profile_value($currentStatus) ?></span>
        </div>
    </div>
    <div class="info-grid">
        <div class="info-cell">
            <small>Course</small>
            <strong><?= profile_value($latestAdmission['course_name'] ?? '') ?></strong>
        </div>
        <div class="info-cell">
            <small>Batch</small>
            <strong><?= profile_value($latestAdmission['batch_name'] ?? '') ?></strong>
        </div>
        <div class="info-cell">
            <small>Class Time</small>
            <strong><?= profile_value($latestAdmission['time_slot'] ?? '') ?></strong>
        </div>
        <div class="info-cell">
            <small>Admission Date</small>
            <strong><?= profile_value($latestAdmission['admission_date'] ?? '') ?></strong>
        </div>
        <div class="info-cell">
            <small>Batch Start Date</small>
            <strong><?= profile_value($latestAdmission['batch_start_date'] ?? '') ?></strong>
        </div>
        <div class="info-cell">
            <small>Final Dealing Price</small>
            <strong>৳<?= number_format((float)($latestAdmission['final_dealing_price'] ?? 0), 2) ?></strong>
        </div>
        <div class="info-cell">
            <small>Paid</small>
            <strong>৳<?= number_format($latestPaid, 2) ?></strong>
        </div>
        <div class="info-cell">
            <small>Current Due</small>
            <strong style="color:#c91f2e">৳<?= number_format($latestDue, 2) ?></strong>
        </div>
    </div>
</div>
<?php endif; ?>

<?php
$transferHistory = [];
if ($latestAdmissionId) {
    try {
        $transferHistoryStmt = $pdo->prepare("
            SELECT t.transferred_at, t.from_time_slot, t.to_time_slot, t.reason,
                   fb.name AS from_batch_name, tb.name AS to_batch_name,
                   u.name AS transferred_by_name
            FROM student_batch_transfers t
            LEFT JOIN batches fb ON fb.id = t.from_batch_id
            LEFT JOIN batches tb ON tb.id = t.to_batch_id
            LEFT JOIN users u ON u.id = t.transferred_by
            WHERE t.student_id = ?
            ORDER BY t.id DESC
            LIMIT 10
        ");
        $transferHistoryStmt->execute([$studentDbId]);
        $transferHistory = $transferHistoryStmt->fetchAll();
    } catch (Throwable $e) {
        $transferHistory = [];
    }
}
?>

<?php if ($transferHistory): ?>
<div class="card profile-card table-wrap">
    <div class="section-head">
        <div>
            <h2>Batch Transfer History</h2>
            <p class="profile-sub">Recent batch changes for this student</p>
        </div>
    </div>
    <table class="table compact">
        <thead><tr><th>Date</th><th>From</th><th>Time</th><th>To</th><th>Time</th><th>Transferred By</th><th>Reason</th></tr></thead>
        <tbody>
        <?php foreach ($transferHistory as $tr): ?>
            <tr>
                <td><?= profile_value($tr['transferred_at'] ?? '') ?></td>
                <td><?= profile_value($tr['from_batch_name'] ?? '') ?></td>
                <td><?= profile_value($tr['from_time_slot'] ?? '') ?></td>
                <td><strong><?= profile_value($tr['to_batch_name'] ?? '') ?></strong></td>
                <td><?= profile_value($tr['to_time_slot'] ?? '') ?></td>
                <td><?= profile_value($tr['transferred_by_name'] ?? '') ?></td>
                <td><?= profile_value($tr['reason'] ?? '') ?></td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>
</div>
<?php endif; ?>

<div class="card profile-card">
    <div class="section-head">
        <div><h2>Materials</h2><p class="profile-sub">Track ID Card for every student and IELTS Book for IELTS students.</p></div>
        <a class="material-link" href="materials.php?q=<?= urlencode($student['student_id']) ?>">Open Materials →</a>
    </div>
    <div class="materials-grid">
        <div class="material-item">
            <div>
                <strong>🎫 ID Card</strong>
                <?php if (($materialStatus['ID Card']['status'] ?? '') === 'Given'): ?>
                    <div class="material-meta">Given <?= profile_value($materialStatus['ID Card']['given_at'] ?? '') ?></div>
                <?php else: ?>
                    <div class="material-meta">Not given yet</div>
                <?php endif; ?>
            </div>
            <div class="material-actions">
                <?php if (($materialStatus['ID Card']['status'] ?? '') === 'Given'): ?>
                    <span class="status-pill material-given">✓ Given</span>
                <?php else: ?>
                    <span class="status-pill material-pending">Pending</span>
                    <form method="post">
                        <?php csrf_field(); ?>
                        <input type="hidden" name="materials_action" value="give">
                        <input type="hidden" name="material_type" value="ID Card">
                        <button type="submit" style="display:inline-flex!important;visibility:visible!important;opacity:1!important;background:#c91f2e!important;color:#fff!important;border:0!important;padding:9px 14px!important;border-radius:9px!important;font-weight:700!important;font-size:12px!important;cursor:pointer!important;">Give ID Card</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>

        <?php $showIeltsBook = (!empty($latestAdmission['course_name']) && stripos((string)$latestAdmission['course_name'], 'ielts') !== false) || stripos((string)($application['course_interest'] ?? ''), 'ielts') !== false; ?>
        <?php if ($showIeltsBook): ?>
        <div class="material-item">
            <div>
                <strong>📘 IELTS Book</strong>
                <?php if (($materialStatus['IELTS Book']['status'] ?? '') === 'Given'): ?>
                    <div class="material-meta">Given <?= profile_value($materialStatus['IELTS Book']['given_at'] ?? '') ?></div>
                <?php else: ?>
                    <div class="material-meta">Not given yet</div>
                <?php endif; ?>
            </div>
            <div class="material-actions">
                <?php if (($materialStatus['IELTS Book']['status'] ?? '') === 'Given'): ?>
                    <span class="status-pill material-given">✓ Given</span>
                <?php else: ?>
                    <span class="status-pill material-pending">Pending</span>
                    <form method="post">
                        <?php csrf_field(); ?>
                        <input type="hidden" name="materials_action" value="give">
                        <input type="hidden" name="material_type" value="IELTS Book">
                        <button type="submit" style="display:inline-flex!important;visibility:visible!important;opacity:1!important;background:#c91f2e!important;color:#fff!important;border:0!important;padding:9px 14px!important;border-radius:9px!important;font-weight:700!important;font-size:12px!important;cursor:pointer!important;">Give Book</button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
        <?php endif; ?>
    </div>
</div>

<div class="card profile-card">
    <div class="section-head"><div><h2>Personal Information</h2><p class="profile-sub">Student and guardian details</p></div></div>
    <div class="info-grid">
        <div class="info-cell"><small>Student Name</small><strong><?= profile_value($student['full_name'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Mobile</small><strong><?= profile_value($student['mobile'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Guardian Name</small><strong><?= profile_value($student['guardian_name'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Guardian Mobile</small><strong><?= profile_value($student['guardian_mobile'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Date of Birth</small><strong><?= profile_value($student['date_of_birth'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Gender</small><strong><?= profile_value($student['gender'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Email</small><strong><?= profile_value($student['email'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Blood Group</small><strong><?= profile_value($student['blood_group'] ?? '') ?></strong></div>
        <div class="info-cell wide"><small>Present Address</small><strong><?= profile_value($student['present_address'] ?? '') ?></strong></div>
    </div>
</div>

<div class="card profile-card table-wrap">
    <div class="section-head"><div><h2>Academic Excellence</h2><p class="profile-sub">Education history submitted during application</p></div></div>
    <table class="table compact">
        <thead><tr><th>Level</th><th>Subject / Group</th><th>Result</th><th>Passing Year</th><th>Institution</th></tr></thead>
        <tbody>
        <?php if (!$academics): ?>
            <tr><td colspan="5">No academic record found.</td></tr>
        <?php else: foreach ($academics as $row): ?>
            <tr><td><strong><?= profile_value($row['degree'] ?? '') ?></strong></td><td><?= profile_value($row['subject'] ?? '') ?></td><td><?= profile_value($row['result'] ?? '') ?></td><td><?= profile_value($row['passing_year'] ?? '') ?></td><td><?= profile_value($row['institution'] ?? '') ?></td></tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<div class="card profile-card">
    <div class="section-head"><div><h2>IELTS Target & Lead Source</h2><p class="profile-sub">Application preferences</p></div></div>
    <div class="info-grid">
        <div class="info-cell"><small>Reading</small><strong><?= profile_value($application['ielts_reading'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Writing</small><strong><?= profile_value($application['ielts_writing'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Listening</small><strong><?= profile_value($application['ielts_listening'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Speaking</small><strong><?= profile_value($application['ielts_speaking'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Overall</small><strong><?= profile_value($application['ielts_overall'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Lead Source</small><strong><?= profile_value($application['lead_source'] ?? '') ?></strong></div>
        <div class="info-cell"><small>Application Status</small><strong><?= profile_value($application['status'] ?? 'Pending') ?></strong></div>
    </div>
</div>

<div class="card profile-card table-wrap">
    <div class="section-head"><div><h2>Admission History</h2><p class="profile-sub"><?= count($admissions) ?> admission record(s)</p></div></div>
    <table class="table compact">
        <thead><tr><th>Date</th><th>Course</th><th>Batch</th><th>Time Slot</th><th>Regular Fee</th><th>Discount</th><th>Special</th><th>Final Price</th><th>Status</th></tr></thead>
        <tbody>
        <?php if (!$admissions): ?>
            <tr><td colspan="9">No processed admission found yet.</td></tr>
        <?php else: foreach ($admissions as $adm): ?>
            <tr>
                <td><?= profile_value($adm['admission_date'] ?? '') ?></td>
                <td><?= profile_value($adm['course_name'] ?? '') ?></td>
                <td><?= profile_value($adm['batch_name'] ?? '') ?></td>
                <td><?= profile_value($adm['time_slot'] ?? '') ?></td>
                <td>৳<?= number_format((float)($adm['regular_fee'] ?? 0), 2) ?></td>
                <td>৳<?= number_format((float)($adm['discount'] ?? 0), 2) ?></td>
                <td>৳<?= number_format((float)($adm['do_discount'] ?? 0), 2) ?></td>
                <td><strong>৳<?= number_format((float)($adm['final_dealing_price'] ?? 0), 2) ?></strong></td>
                <td><span class="status-pill <?= e(strtolower((string)($adm['status'] ?? ''))) ?>"><?= profile_value($adm['status'] ?? '') ?></span></td>
            </tr>
            <?php if (!empty($adm['reference'])): ?>
            <tr><td colspan="9" style="background:#fafafb;color:#656a72"><strong>Reference:</strong> <?= profile_value($adm['reference'] ?? '') ?></td></tr>
            <?php endif; ?>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<div class="card profile-card">
    <div class="section-head">
        <div>
            <h2>Payment Summary</h2>
            <p class="profile-sub">Overall financial summary for this student</p>
        </div>
    </div>
    <div class="info-grid">
        <div class="info-cell">
            <small>Total Dealing Price</small>
            <strong>৳<?= number_format($totalFinal, 2) ?></strong>
        </div>
        <div class="info-cell">
            <small>Total Paid</small>
            <strong style="color:#237a46">৳<?= number_format($totalPaid, 2) ?></strong>
        </div>
        <div class="info-cell">
            <small>Total Due</small>
            <strong style="color:#c91f2e">৳<?= number_format($totalDue, 2) ?></strong>
        </div>
        <div class="info-cell">
            <small>Payment Transactions</small>
            <strong><?= count($payments) ?></strong>
        </div>
    </div>
</div>

<div class="card profile-card table-wrap">
    <div class="section-head"><div><h2>Payment History</h2><p class="profile-sub"><?= count($payments) ?> transaction(s) · Valid paid: ৳<?= number_format($totalPaid, 2) ?></p></div></div>
    <table class="table compact">
        <thead><tr><th>Receipt</th><th>Date</th><th>Course / Batch</th><th>Amount</th><th>Method</th><th>Received By</th><th>Status</th><th class="no-print">Action</th></tr></thead>
        <tbody>
        <?php if (!$payments): ?>
            <tr><td colspan="8">No payment found.</td></tr>
        <?php else: foreach ($payments as $p): ?>
            <tr>
                <td><?php if(!empty($p['receipt_no'])): ?><a href="receipt.php?receipt=<?=urlencode((string)$p['receipt_no'])?>" target="_blank"><?=e((string)$p['receipt_no'])?></a><?php else: ?><span class="badge pending">Pending Approval</span><?php endif; ?></td>
                <td><?= profile_value($p['created_at'] ?? '') ?></td>
                <td><?= profile_value($p['course_name'] ?? '') ?> / <?= profile_value($p['batch_name'] ?? '') ?></td>
                <td><strong>৳<?= number_format((float)($p['amount'] ?? 0), 2) ?></strong></td>
                <td><?= profile_value($p['method'] ?? '') ?></td>
                <td><?= profile_value($p['received_by_name'] ?? '') ?></td>
                <td><span class="status-pill <?= e(strtolower((string)($p['status'] ?? ''))) ?>"><?= profile_value($p['status'] ?? '') ?></span></td>
                <td class="no-print"><?php if(!empty($p['receipt_no'])): ?><a href="receipt.php?receipt=<?= urlencode((string)$p['receipt_no']) ?>" target="_blank">Receipt →</a><?php else: ?><span class="muted">Available after approval</span><?php endif; ?></td>
            </tr>
        <?php endforeach; endif; ?>
        </tbody>
    </table>
</div>

<div class="card profile-card">
    <div class="section-head">
        <div>
            <h2>Performance Summary</h2>
            <p class="profile-sub">Latest teacher evaluation and learning progress</p>
        </div>
        <?php if ($performanceEvaluation): ?>
            <span class="status-pill <?= e(performance_rating_class($performanceEvaluation['participation'] ?? '')) ?>">
                <?= profile_value($performanceEvaluation['participation'] ?? '') ?>
            </span>
        <?php endif; ?>
    </div>

    <?php if (!$hasPerformanceTable): ?>
        <p>Performance module database table is not installed yet.</p>
    <?php elseif (!$performanceEvaluation): ?>
        <div class="performance-note">No performance evaluation has been recorded for this student yet.</div>
    <?php else: ?>
        <div class="performance-grid">
            <div class="performance-stat">
                <small>Evaluation Month</small>
                <strong style="font-size:16px"><?= profile_value(date('F Y', strtotime($performanceEvaluation['evaluation_month'] ?? ''))) ?></strong>
            </div>
            <div class="performance-stat">
                <small>Skill Average</small>
                <strong><?= number_format($performanceAverage, 1) ?> / 5</strong>
            </div>
            <div class="performance-stat">
                <small>Homework</small>
                <strong><?= number_format($performanceHomeworkPercent, 1) ?>%</strong>
            </div>
            <div class="performance-stat">
                <small>Participation</small>
                <strong style="font-size:16px"><?= profile_value($performanceEvaluation['participation'] ?? '') ?></strong>
            </div>
        </div>

        <div class="performance-skills">
            <?php
            $performanceFields = [
                'speaking' => 'Speaking',
                'listening' => 'Listening',
                'reading' => 'Reading',
                'writing' => 'Writing',
                'grammar' => 'Grammar',
                'vocabulary' => 'Vocabulary'
            ];
            foreach ($performanceFields as $field => $label):
                $rating = $performanceEvaluation[$field] ?? '';
            ?>
                <div class="performance-skill">
                    <span><?= e($label) ?></span>
                    <div class="performance-bar-wrap">
                        <div class="performance-bar" title="<?= profile_value($rating) ?>">
                            <span style="width:<?= performance_rating_score($rating) * 20 ?>%"></span>
                        </div>
                        <span class="performance-score"><?= performance_rating_score($rating) ?>/5</span>
                    </div>
                    <span class="performance-rating <?= e(performance_rating_class($rating)) ?>">
                        <?= profile_value($rating) ?>
                    </span>
                </div>
            <?php endforeach; ?>
        </div>

        <?php if ($performanceStrongAreas || $performanceWeakAreas): ?>
            <div class="performance-note">
                <?php if ($performanceStrongAreas): ?>
                    <strong>Strong areas:</strong> <?= e(implode(', ', $performanceStrongAreas)) ?>.
                <?php endif; ?>
                <?php if ($performanceWeakAreas): ?>
                    <?php if ($performanceStrongAreas): ?> &nbsp;·&nbsp; <?php endif; ?>
                    <strong>Needs attention:</strong> <?= e(implode(', ', $performanceWeakAreas)) ?>.
                <?php endif; ?>
            </div>
        <?php endif; ?>

        <?php if (!empty($performanceEvaluation['strengths'])): ?>
            <div class="performance-note"><strong>Strengths:</strong> <?= nl2br(e($performanceEvaluation['strengths'])) ?></div>
        <?php endif; ?>

        <?php if (!empty($performanceEvaluation['improvement_areas'])): ?>
            <div class="performance-note"><strong>Areas to Improve:</strong> <?= nl2br(e($performanceEvaluation['improvement_areas'])) ?></div>
        <?php endif; ?>

        <?php if (!empty($performanceEvaluation['teacher_comment'])): ?>
            <div class="performance-note"><strong>Teacher's Comment:</strong> <?= nl2br(e($performanceEvaluation['teacher_comment'])) ?></div>
        <?php endif; ?>

        <?php if ($performanceHistory): ?>
            <div class="table-wrap" style="margin-top:14px">
                <table class="table compact performance-history">
                    <thead>
                        <tr>
                            <th>Month</th>
                            <th>Participation</th>
                            <th>Speaking</th>
                            <th>Listening</th>
                            <th>Reading</th>
                            <th>Writing</th>
                            <th>Homework</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($performanceHistory as $ph): ?>
                        <tr>
                            <td><?= profile_value(date('M Y', strtotime($ph['evaluation_month'] ?? ''))) ?></td>
                            <td><?= profile_value($ph['participation'] ?? '') ?></td>
                            <td><?= profile_value($ph['speaking'] ?? '') ?></td>
                            <td><?= profile_value($ph['listening'] ?? '') ?></td>
                            <td><?= profile_value($ph['reading'] ?? '') ?></td>
                            <td><?= profile_value($ph['writing'] ?? '') ?></td>
                            <td><?= number_format((int)($ph['homework_completed'] ?? 0)) ?> / <?= number_format((int)($ph['homework_assigned'] ?? 0)) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    <?php endif; ?>
</div>

<div class="card profile-card">
    <div class="section-head"><div><h2>Attendance Summary</h2><p class="profile-sub">Batch attendance history</p></div></div>
    <?php if (!$hasAttendanceTable): ?>
        <p>Attendance module database table is not installed yet.</p>
    <?php else: ?>
        <div class="info-grid" style="margin-bottom:14px">
            <div class="info-cell"><small>Total Classes</small><strong><?= $attendanceTotal ?></strong></div>
            <div class="info-cell"><small>Present</small><strong><?= $attendancePresent ?></strong></div>
            <div class="info-cell"><small>Absent</small><strong><?= $attendanceAbsent ?></strong></div>
            <div class="info-cell"><small>Attendance Rate</small><strong><?= number_format($attendancePercent, 1) ?>%</strong><div class="attendance-meter"><span style="width:<?= max(0, min(100, $attendancePercent)) ?>%"></span></div></div>
        </div>
        <div class="table-wrap">
            <table class="table compact">
                <thead><tr><th>Date</th><th>Batch</th><th>Status</th><th>Marked By</th></tr></thead>
                <tbody>
                <?php if (!$attendanceRows): ?>
                    <tr><td colspan="4">No attendance record found.</td></tr>
                <?php else: foreach ($attendanceRows as $att): ?>
                    <tr><td><?= profile_value($att['attendance_date'] ?? '') ?></td><td><?= profile_value($att['batch_name'] ?? '') ?></td><td><span class="status-pill <?= e(strtolower((string)($att['status'] ?? ''))) ?>"><?= profile_value($att['status'] ?? '') ?></span></td><td><?= profile_value($att['marked_by_name'] ?? '') ?></td></tr>
                <?php endforeach; endif; ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>

<div class="print-only" style="margin-top:20px;font-size:11px;color:#666">Printed from Edumax Admission Management System</div>

<?php require '_footer.php'; ?>

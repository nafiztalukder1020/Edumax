<?php
require_once __DIR__ . '/../config/app.php';
require_access('student_performance');

function perf_rating_options(): array {
    return ['Excellent','Very Good','Good','Average','Needs Improvement'];
}

$selectedStudent = (int)($_GET['student_id'] ?? $_POST['student_id'] ?? 0);
$selectedMonth = trim($_GET['month'] ?? $_POST['evaluation_month'] ?? date('Y-m-01'));
if (!preg_match('/^\d{4}-\d{2}-01$/', $selectedMonth)) $selectedMonth = date('Y-m-01');

$notice = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $action = $_POST['action'] ?? '';

    if ($action === 'save_evaluation') {
        $studentId = (int)($_POST['student_id'] ?? 0);
        $month = trim($_POST['evaluation_month'] ?? '');
        if (!preg_match('/^\d{4}-\d{2}-01$/', $month)) $month = date('Y-m-01');
        $allowed = perf_rating_options();

        $fields = ['participation','speaking','listening','reading','writing','grammar','vocabulary'];
        $data = [];
        foreach ($fields as $field) {
            $value = trim($_POST[$field] ?? 'Good');
            $data[$field] = in_array($value, $allowed, true) ? $value : 'Good';
        }
        $assigned = max(0, (int)($_POST['homework_assigned'] ?? 0));
        $completed = max(0, (int)($_POST['homework_completed'] ?? 0));
        if ($completed > $assigned) $completed = $assigned;

        $studentCheck = $pdo->prepare('SELECT id FROM students WHERE id=? LIMIT 1');
        $studentCheck->execute([$studentId]);
        if (!$studentCheck->fetchColumn()) {
            $error = 'Student not found.';
        } else {
            $sql = "INSERT INTO performance_evaluations
                    (student_id,evaluation_month,participation,homework_assigned,homework_completed,speaking,listening,reading,writing,grammar,vocabulary,strengths,improvement_areas,teacher_comment,evaluated_by)
                    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                    ON DUPLICATE KEY UPDATE
                    participation=VALUES(participation), homework_assigned=VALUES(homework_assigned), homework_completed=VALUES(homework_completed),
                    speaking=VALUES(speaking), listening=VALUES(listening), reading=VALUES(reading), writing=VALUES(writing), grammar=VALUES(grammar), vocabulary=VALUES(vocabulary),
                    strengths=VALUES(strengths), improvement_areas=VALUES(improvement_areas), teacher_comment=VALUES(teacher_comment), evaluated_by=VALUES(evaluated_by)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                $studentId, $month, $data['participation'], $assigned, $completed,
                $data['speaking'],$data['listening'],$data['reading'],$data['writing'],$data['grammar'],$data['vocabulary'],
                trim($_POST['strengths'] ?? ''), trim($_POST['improvement_areas'] ?? ''), trim($_POST['teacher_comment'] ?? ''),
                (int)$_SESSION['user_id']
            ]);
            $selectedStudent = $studentId;
            $selectedMonth = $month;
            $notice = 'Performance evaluation saved successfully.';
        }
    }

    if ($action === 'revoke_link') {
        $linkId = (int)($_POST['link_id'] ?? 0);
        $selectedForRevoke = (int)($_POST['student_id'] ?? 0);
        if ($linkId <= 0) {
            $error = 'Invalid guardian report link.';
        } else {
            $rev = $pdo->prepare("UPDATE guardian_report_links SET status='Revoked' WHERE id=? AND status='Active'");
            $rev->execute([$linkId]);
            $notice = $rev->rowCount() > 0 ? 'Guardian report link revoked successfully.' : 'The guardian report link is already inactive.';
            if ($selectedForRevoke > 0) $selectedStudent = $selectedForRevoke;
        }
    }

    if ($action === 'generate_link') {
        $evaluationId = (int)($_POST['evaluation_id'] ?? 0);
        $stmt = $pdo->prepare('SELECT id, student_id FROM performance_evaluations WHERE id=? LIMIT 1');
        $stmt->execute([$evaluationId]);
        $evaluation = $stmt->fetch();
        if (!$evaluation) {
            $error = 'Please save the evaluation before generating a guardian report.';
        } else {
            $pdo->prepare("UPDATE guardian_report_links SET status='Revoked' WHERE evaluation_id=? AND status='Active'")->execute([$evaluationId]);
            $token = bin2hex(random_bytes(32));
            $ins = $pdo->prepare("INSERT INTO guardian_report_links (student_id,evaluation_id,token,created_by,expires_at) VALUES (?,?,?,?,DATE_ADD(NOW(), INTERVAL 90 DAY))");
            $ins->execute([(int)$evaluation['student_id'], $evaluationId, $token, (int)$_SESSION['user_id']]);
            $notice = 'Guardian report link generated. It will remain active for 90 days unless revoked.';
            $selectedStudent = (int)$evaluation['student_id'];
        }
    }
}

$search = trim($_GET['q'] ?? '');
$batchFilter = (int)($_GET['batch_id'] ?? 0);
$where = "s.id IS NOT NULL AND COALESCE(s.is_archived,0)=0 AND (b.is_archived IS NULL OR b.is_archived=0)";
$params = [];
if ($search !== '') {
    $where .= " AND (s.full_name LIKE ? OR s.student_id LIKE ? OR s.mobile LIKE ? OR s.guardian_mobile LIKE ?)";
    $like = "%{$search}%";
    $params = [$like,$like,$like,$like];
}
if ($batchFilter > 0) {
    $where .= " AND la.batch_id = ?";
    $params[] = $batchFilter;
}

$batchOptionsStmt = $pdo->query("SELECT b.id,b.name,b.start_date,b.status,c.name course_name
    FROM batches b
    LEFT JOIN courses c ON c.id=b.course_id
    WHERE COALESCE(b.is_archived,0)=0
    ORDER BY b.start_date DESC,b.name ASC");
$batchOptions = $batchOptionsStmt->fetchAll();

$studentsStmt = $pdo->prepare("SELECT s.id,s.student_id,s.full_name,s.mobile,s.guardian_name,s.guardian_mobile,
        la.id admission_id, c.name course_name, b.name batch_name, la.time_slot, la.status admission_status
        FROM students s
        LEFT JOIN (SELECT a1.* FROM admissions a1 INNER JOIN (SELECT student_id,MAX(id) max_id FROM admissions GROUP BY student_id) x ON x.student_id=a1.student_id AND x.max_id=a1.id) la ON la.student_id=s.id
        LEFT JOIN courses c ON c.id=la.course_id
        LEFT JOIN batches b ON b.id=la.batch_id
        WHERE $where
        ORDER BY s.full_name ASC, s.id DESC");
$studentsStmt->execute($params);
$students = $studentsStmt->fetchAll();

$evaluation = null;
$attendance = ['total'=>0,'present'=>0,'absent'=>0,'rate'=>0];
$history = [];
$shareUrl = '';
$guardianLinks = [];
$selectedStudentData = null;
$performanceSummary = [
    'score' => null,
    'rating' => 'Not evaluated',
    'attendance' => null,
    'homework' => null,
    'skill_average' => null,
    'comment' => 'Save a monthly teacher evaluation to generate an overall performance summary.'
];

if ($selectedStudent > 0) {
    $st = $pdo->prepare("SELECT s.*, la.id admission_id, la.time_slot, c.name course_name, b.name batch_name
        FROM students s
        LEFT JOIN (SELECT a1.* FROM admissions a1 INNER JOIN (SELECT student_id,MAX(id) max_id FROM admissions GROUP BY student_id) x ON x.student_id=a1.student_id AND x.max_id=a1.id) la ON la.student_id=s.id
        LEFT JOIN courses c ON c.id=la.course_id LEFT JOIN batches b ON b.id=la.batch_id WHERE s.id=? LIMIT 1");
    $st->execute([$selectedStudent]);
    $selectedStudentData = $st->fetch();

    if ($selectedStudentData) {
        $ev = $pdo->prepare('SELECT e.*, u.name evaluator_name FROM performance_evaluations e LEFT JOIN users u ON u.id=e.evaluated_by WHERE e.student_id=? AND e.evaluation_month=? LIMIT 1');
        $ev->execute([$selectedStudent, $selectedMonth]);
        $evaluation = $ev->fetch();

        $att = $pdo->prepare("SELECT COUNT(*) total, SUM(status='Present') present, SUM(status='Absent') absent FROM attendance WHERE student_id=? AND attendance_date BETWEEN ? AND LAST_DAY(?)");
        $att->execute([$selectedStudent, $selectedMonth, $selectedMonth]);
        $a = $att->fetch() ?: [];
        $attendance['total'] = (int)($a['total'] ?? 0);
        $attendance['present'] = (int)($a['present'] ?? 0);
        $attendance['absent'] = (int)($a['absent'] ?? 0);
        $attendance['rate'] = $attendance['total'] ? round($attendance['present']/$attendance['total']*100,1) : 0;

        $hist = $pdo->prepare('SELECT evaluation_month, participation, homework_assigned, homework_completed, updated_at FROM performance_evaluations WHERE student_id=? ORDER BY evaluation_month DESC LIMIT 6');
        $hist->execute([$selectedStudent]);
        $history = $hist->fetchAll();

        // Automatic alerts for the selected month.
        $alerts = [];
        if ($attendance['total'] > 0 && $attendance['rate'] < 70) {
            $alerts[] = ['level'=>'High','title'=>'Low Attendance','text'=>'Attendance is below 70% for this month.'];
        }
        if ($attendance['absent'] >= 3) {
            $alerts[] = ['level'=>'Medium','title'=>'Repeated Absence','text'=>'Student has been absent 3 or more times this month.'];
        }
        if ($evaluation) {
            $evalFields = ['participation','speaking','listening','reading','writing','grammar','vocabulary'];
            $needsImprovement = [];
            foreach ($evalFields as $ef) {
                if (($evaluation[$ef] ?? '') === 'Needs Improvement') {
                    $needsImprovement[] = ucwords(str_replace('_',' ', $ef));
                }
            }
            $hwAssigned = (int)($evaluation['homework_assigned'] ?? 0);
            $hwCompleted = (int)($evaluation['homework_completed'] ?? 0);
            if ($hwAssigned >= 3 && (($hwCompleted / $hwAssigned) * 100) < 70) {
                $alerts[] = ['level'=>'Medium','title'=>'Homework Needs Attention','text'=>'Assigned work completion is below 70%.'];
            }
            if ($needsImprovement) {
                $alerts[] = ['level'=>'Medium','title'=>'Performance Needs Attention','text'=>'Needs improvement: '.implode(', ', $needsImprovement).'.'];
            }
        } else {
            $alerts[] = ['level'=>'Low','title'=>'Evaluation Pending','text'=>'No performance evaluation has been saved for this month.'];
        }

        /*
         * Automatic monthly performance summary.
         * This is calculated from existing attendance + evaluation data;
         * no database change is required.
         */
        if ($evaluation) {
            $ratingPoints = [
                'Excellent' => 5,
                'Very Good' => 4,
                'Good' => 3,
                'Average' => 2,
                'Needs Improvement' => 1
            ];

            $skillFields = ['speaking','listening','reading','writing','grammar','vocabulary','participation'];
            $skillTotal = 0;
            $skillCount = 0;
            foreach ($skillFields as $sf) {
                $rv = $evaluation[$sf] ?? '';
                if (isset($ratingPoints[$rv])) {
                    $skillTotal += $ratingPoints[$rv];
                    $skillCount++;
                }
            }

            $skillAvg = $skillCount ? ($skillTotal / $skillCount) : null;
            $hwAssigned = (int)($evaluation['homework_assigned'] ?? 0);
            $hwCompleted = (int)($evaluation['homework_completed'] ?? 0);
            $hwRate = $hwAssigned > 0 ? min(100, round(($hwCompleted / $hwAssigned) * 100, 1)) : null;
            $attRate = $attendance['total'] > 0 ? (float)$attendance['rate'] : null;

            $weighted = 0;
            $weight = 0;
            if ($attRate !== null) {
                $weighted += $attRate * 0.30;
                $weight += 0.30;
            }
            if ($hwRate !== null) {
                $weighted += $hwRate * 0.20;
                $weight += 0.20;
            }
            if ($skillAvg !== null) {
                $skillPercent = (($skillAvg - 1) / 4) * 100;
                $weighted += $skillPercent * 0.50;
                $weight += 0.50;
            }

            $overallScore = $weight > 0 ? round($weighted / $weight, 1) : null;

            if ($overallScore === null) {
                $overallRating = 'Not enough data';
                $overallComment = 'Add attendance or evaluation data to generate the monthly summary.';
            } elseif ($overallScore >= 90) {
                $overallRating = 'Excellent';
                $overallComment = 'The student is performing exceptionally well this month.';
            } elseif ($overallScore >= 80) {
                $overallRating = 'Very Good';
                $overallComment = 'The student is making very good progress this month.';
            } elseif ($overallScore >= 70) {
                $overallRating = 'Good';
                $overallComment = 'The student is progressing well, with some areas to strengthen.';
            } elseif ($overallScore >= 60) {
                $overallRating = 'Average';
                $overallComment = 'The student should focus on the identified improvement areas.';
            } else {
                $overallRating = 'Needs Improvement';
                $overallComment = 'The student needs focused support and consistent practice.';
            }

            $performanceSummary = [
                'score' => $overallScore,
                'rating' => $overallRating,
                'attendance' => $attRate,
                'homework' => $hwRate,
                'skill_average' => $skillAvg,
                'comment' => $overallComment
            ];
        }

        if ($evaluation) {
            $lk = $pdo->prepare("SELECT token FROM guardian_report_links WHERE evaluation_id=? AND status='Active' AND (expires_at IS NULL OR expires_at>NOW()) ORDER BY id DESC LIMIT 1");
            $lk->execute([(int)$evaluation['id']]);
            $token = $lk->fetchColumn();
            if ($token) {
                $shareUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http').'://'.($_SERVER['HTTP_HOST'] ?? 'localhost').rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/').'/guardian-report.php?token='.urlencode($token);
            }
        }
        if ($evaluation) {
            $linkHistoryStmt = $pdo->prepare("SELECT id,token,status,expires_at,created_at FROM guardian_report_links WHERE evaluation_id=? ORDER BY id DESC LIMIT 8");
            $linkHistoryStmt->execute([(int)$evaluation['id']]);
            $guardianLinks = $linkHistoryStmt->fetchAll();
        }
    }
}

require '_header.php';
?>
<style>
.perf-head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px}.perf-head h1{margin:0;font-size:26px}.perf-head p{margin:6px 0 0;color:#737982}.perf-layout{display:grid;grid-template-columns:330px minmax(0,1fr);gap:18px}.perf-panel,.perf-card{background:#fff;border:1px solid #e8e9ed;border-radius:16px;box-shadow:0 8px 30px rgba(25,31,40,.05)}.perf-panel{padding:16px;height:max-content}.perf-search{display:flex;gap:8px;margin-bottom:12px}.perf-search input{width:100%;height:40px;border:1px solid #e1e3e7;border-radius:10px;padding:0 11px}.teacher-quick{margin-bottom:10px}.teacher-quick label{display:block;font-size:11px;font-weight:800;color:#666;margin-bottom:5px}.teacher-quick select{width:100%;height:42px;border:1px solid #e1e3e7;border-radius:10px;padding:0 10px;background:#fff}.student-list{max-height:610px;overflow:auto}.student-item{display:block;padding:12px;border:1px solid #eee;border-radius:11px;margin-bottom:8px;text-decoration:none;color:#252930}.student-item.active{border-color:#c91f2e;background:#fff5f6}.student-item strong{display:block}.student-item small{display:block;color:#777;margin-top:3px}.perf-card{padding:20px;margin-bottom:16px}.student-hero{display:flex;justify-content:space-between;gap:16px;align-items:flex-start}.student-hero h2{margin:0 0 5px}.student-meta{color:#737982;font-size:13px;line-height:1.7}.month-form{display:flex;gap:8px;align-items:end}.month-form label{font-size:11px;font-weight:700;color:#666;display:block;margin-bottom:5px}.month-form input{height:40px;border:1px solid #e1e3e7;border-radius:10px;padding:0 10px}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}.stat{border:1px solid #ececf0;border-radius:12px;padding:14px}.stat small{color:#777}.stat strong{display:block;font-size:24px;margin-top:4px}.section-label{font-size:13px;font-weight:800;margin:0 0 12px}.eval-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.field label{display:block;font-size:12px;font-weight:700;color:#5f636b;margin-bottom:6px}.field select,.field input,.field textarea{width:100%;border:1px solid #e1e3e7;border-radius:10px;padding:10px;background:#fff;box-sizing:border-box}.field textarea{min-height:88px;resize:vertical}.full{grid-column:1/-1}.share-box{background:#fff7f8;border:1px dashed #d66a75;border-radius:12px;padding:14px}.share-row{display:flex;gap:8px}.share-row input{flex:1;border:1px solid #e1e3e7;border-radius:9px;padding:10px;background:#fff}.btn{border-radius:10px!important}.alert-grid{display:grid;gap:10px}.alert-item{display:flex;align-items:flex-start;gap:12px;padding:12px 14px;border:1px solid #eee;border-radius:11px;background:#fff}.alert-dot{width:9px;height:9px;border-radius:50%;margin-top:6px;background:#c91f2e;flex:none}.alert-item.medium .alert-dot{background:#d88920}.alert-item.low .alert-dot{background:#777}.alert-item strong{display:block;margin-bottom:3px}.alert-item small{color:#6f737b}.empty-alert{padding:13px;border:1px dashed #cfd2d7;border-radius:11px;color:#555;background:#fafafa}
.summary-box{display:flex;gap:18px;align-items:center;border:1px solid #ececf0;border-radius:13px;padding:16px;background:#fafafa}
.summary-score{width:108px;height:108px;min-width:108px;border-radius:50%;border:8px solid #f0d8db;display:flex;flex-direction:column;align-items:center;justify-content:center;background:#fff}
.summary-score-number{font-size:21px;font-weight:900;color:#c91f2e;line-height:1}
.summary-score-label{font-size:9px;color:#777;margin-top:5px}
.summary-main{min-width:0;flex:1}
.summary-rating{font-size:18px;font-weight:900;color:#20242b}
.summary-main p{margin:5px 0 10px;color:#6f737b;line-height:1.5}
.summary-metrics{display:flex;gap:8px;flex-wrap:wrap}
.summary-metrics span{font-size:11px;padding:6px 9px;border:1px solid #e4e6ea;border-radius:8px;background:#fff;color:#686e77}
@media(max-width:650px){.summary-box{align-items:flex-start}.summary-score{width:88px;height:88px;min-width:88px;border-width:6px}.summary-score-number{font-size:17px}.summary-rating{font-size:16px}}
.history-table{width:100%;border-collapse:collapse}.history-table th,.history-table td{padding:10px;border-bottom:1px solid #eee;text-align:left;font-size:13px}.history-table th{font-size:11px;color:#737982;text-transform:uppercase}@media(max-width:1050px){.perf-layout{grid-template-columns:1fr}.student-list{max-height:280px}.eval-grid{grid-template-columns:repeat(2,1fr)}}@media(max-width:650px){.perf-head,.student-hero{flex-direction:column;align-items:flex-start}.stats,.eval-grid{grid-template-columns:1fr}.month-form{width:100%}.month-form input{flex:1}.share-row{flex-direction:column}}
</style>

<div class="perf-head">
    <div><h1>Student Performance</h1><p>Evaluate class performance, track attendance and prepare guardian-ready reports.</p></div>
</div>

<?php if($notice): ?><div class="alert alert-success"><?=e($notice)?></div><?php endif; ?>
<?php if($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>

<div class="perf-layout">
    <aside class="perf-panel">
        <form class="teacher-quick" method="get">
            <div>
                <label>Batch</label>
                <select name="batch_id" onchange="this.form.submit()">
                    <option value="0">All Current Batches</option>
                    <?php foreach($batchOptions as $bo): ?>
                        <option value="<?=$bo['id']?>" <?=$batchFilter===(int)$bo['id']?'selected':''?>>
                            <?=e(($bo['course_name'] ? $bo['course_name'].' �� ' : '').$bo['name'])?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <input type="hidden" name="month" value="<?=e($selectedMonth)?>">
        </form>
        <form class="perf-search" method="get">
            <input type="hidden" name="batch_id" value="<?=$batchFilter?>"><input name="q" value="<?=e($search)?>" placeholder="Search student / ID / mobile">
            <button class="btn btn-primary" type="submit">Search</button>
        </form>
        <div style="font-size:12px;font-weight:800;color:#5f636b;margin:8px 0 10px">
            <?=count($students)?> student<?=count($students)===1?'':'s'?><?= $batchFilter>0 ? ' in selected batch' : '' ?>
        </div>
        <div class="student-list">
        <?php foreach($students as $s): ?>
            <a class="student-item <?=$selectedStudent===(int)$s['id']?'active':''?>" href="student-performance.php?student_id=<?=$s['id']?>&month=<?=e($selectedMonth)?>&q=<?=urlencode($search)?>&batch_id=<?=$batchFilter?>">
                <strong><?=e($s['full_name'])?></strong>
                <small><?=e($s['student_id'])?>  •  <?=e($s['course_name'] ?: 'No course')?></small>
            </a>
        <?php endforeach; if(!$students): ?><div class="muted" style="padding:20px;text-align:center">No students found.</div><?php endif; ?>
        </div>
    </aside>

    <section>
    <?php if(!$selectedStudentData): ?>
        <div class="perf-card" style="text-align:center;padding:60px 20px"><h2>Select a student</h2><p class="muted">Choose a student from the left to evaluate performance and create a guardian report.</p></div>
    <?php else: ?>
        <div class="perf-card">
            <div class="student-hero">
                <div><h2><?=e($selectedStudentData['full_name'])?></h2><div class="student-meta"><strong><?=e($selectedStudentData['student_id'])?></strong>  •  <?=e($selectedStudentData['course_name'] ?: '-')?><br><?=e($selectedStudentData['batch_name'] ?: '-')?><?=!empty($selectedStudentData['time_slot'])?'  •  '.e($selectedStudentData['time_slot']):''?><br>Guardian: <?=e($selectedStudentData['guardian_name'] ?: '-')?><?=!empty($selectedStudentData['guardian_mobile'])?'  •  '.e($selectedStudentData['guardian_mobile']):''?></div></div>
                <form class="month-form" method="get"><input type="hidden" name="student_id" value="<?=$selectedStudent?>"><input type="hidden" name="batch_id" value="<?=$batchFilter?>"><input type="hidden" name="q" value="<?=e($search)?>"><div><label>Evaluation Month</label><input type="month" name="month" value="<?=e(substr($selectedMonth,0,7))?>" onchange="this.form.submit()"></div></form>
            </div>
        </div>

        <div class="perf-card"><p class="section-label">Student Alerts</p>
            <?php if (empty($alerts)): ?>
                <div class="empty-alert">No attention required for this month.</div>
            <?php else: ?>
                <div class="alert-grid">
                    <?php foreach ($alerts as $al): ?>
                        <div class="alert-item <?=e(strtolower($al['level']))?>"><span class="alert-dot"></span><div><strong><?=e($al['title'])?></strong><small><?=e($al['text'])?></small></div></div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>

        <div class="perf-card"><p class="section-label">Monthly Overview</p><div class="stats"><div class="stat"><small>Attendance</small><strong><?=e((string)$attendance['rate'])?>%</strong><span class="muted"><?=number_format($attendance['present'])?> / <?=number_format($attendance['total'])?> present</span></div><div class="stat"><small>Participation</small><strong style="font-size:17px"><?=e($evaluation['participation'] ?? 'Not evaluated')?></strong></div><div class="stat"><small>Homework</small><strong style="font-size:17px"><?php $hwPct=(!empty($evaluation) && (int)$evaluation['homework_assigned']>0)?round((int)$evaluation['homework_completed']/(int)$evaluation['homework_assigned']*100):0; echo $evaluation ? $hwPct.'%' : 'Not set'; ?></strong></div><div class="stat"><small>Guardian</small><strong style="font-size:17px"><?=!empty($shareUrl)?'Shared':'Not shared'?></strong></div></div></div>

        <div class="perf-card">
            <p class="section-label">Overall Performance Summary</p>
            <div class="summary-box">
                <div class="summary-score">
                    <span class="summary-score-number"><?= $performanceSummary['score'] !== null ? e((string)$performanceSummary['score']).'%' : '—' ?></span>
                    <span class="summary-score-label">Monthly Score</span>
                </div>
                <div class="summary-main">
                    <div class="summary-rating"><?=e($performanceSummary['rating'])?></div>
                    <p><?=e($performanceSummary['comment'])?></p>
                    <div class="summary-metrics">
                        <span>Attendance: <b><?= $performanceSummary['attendance'] !== null ? e((string)$performanceSummary['attendance']).'%' : '—' ?></b></span>
                        <span>Homework: <b><?= $performanceSummary['homework'] !== null ? e((string)$performanceSummary['homework']).'%' : '—' ?></b></span>
                        <span>Skill Rating: <b><?= $performanceSummary['skill_average'] !== null ? e(number_format($performanceSummary['skill_average'], 1)).' / 5' : '—' ?></b></span>
                    </div>
                </div>
            </div>
        </div>

        <form method="post" class="perf-card">
            <?=csrf_input()?>
            <input type="hidden" name="action" value="save_evaluation"><input type="hidden" name="student_id" value="<?=$selectedStudent?>"><input type="hidden" name="evaluation_month" value="<?=e($selectedMonth)?>">
            <p class="section-label">Teacher Evaluation</p>
            <div class="eval-grid">
            <?php foreach(['participation'=>'Class Participation','speaking'=>'Speaking','listening'=>'Listening','reading'=>'Reading','writing'=>'Writing','grammar'=>'Grammar','vocabulary'=>'Vocabulary'] as $field=>$label): ?><div class="field"><label><?=e($label)?></label><select name="<?=e($field)?>"><?php foreach(perf_rating_options() as $opt): ?><option value="<?=e($opt)?>" <?=($evaluation[$field] ?? 'Good')===$opt?'selected':''?>><?=e($opt)?></option><?php endforeach; ?></select></div><?php endforeach; ?>
                <div class="field"><label>Homework / Assigned Work</label><input type="number" min="0" name="homework_assigned" value="<?=e((string)($evaluation['homework_assigned'] ?? 0))?>" placeholder="Assigned"></div>
                <div class="field"><label>Completed</label><input type="number" min="0" name="homework_completed" value="<?=e((string)($evaluation['homework_completed'] ?? 0))?>" placeholder="Completed"></div>
                <div class="field full"><label>Strengths</label><textarea name="strengths" placeholder="What is the student doing well?"><?=e($evaluation['strengths'] ?? '')?></textarea></div>
                <div class="field full"><label>Areas to Improve</label><textarea name="improvement_areas" placeholder="What should the student focus on next?"><?=e($evaluation['improvement_areas'] ?? '')?></textarea></div>
                <div class="field full"><label>Teacher's Overall Comment</label><textarea name="teacher_comment" placeholder="Short guardian-friendly comment..."><?=e($evaluation['teacher_comment'] ?? '')?></textarea></div>
            </div>
            <div style="margin-top:14px;display:flex;justify-content:flex-end"><button class="btn btn-primary" type="submit">Save Evaluation</button></div>
        </form>

        <?php if($evaluation): ?>
        <div class="perf-card guardian-manager">
            <p class="section-label">Guardian Report</p>
            <p class="muted">Generate a secure read-only link, share it with the guardian, or revoke an existing link.</p>
            <form method="post" style="margin-bottom:12px">
                <?=csrf_input()?>
                <input type="hidden" name="action" value="generate_link">
                <input type="hidden" name="evaluation_id" value="<?=$evaluation['id']?>">
                <button class="btn btn-primary" type="submit">Generate New Guardian Link</button>
            </form>
            <?php if($shareUrl): ?>
                <div class="share-box">
                    <div style="font-weight:800;margin-bottom:8px">Active Share Link</div>
                    <div class="share-row">
                        <input id="shareUrl" readonly value="<?=e($shareUrl)?>">
                        <button type="button" class="btn btn-secondary" onclick="copyGuardianLink()">Copy Link</button>
                        <button type="button" class="btn btn-secondary" onclick="shareGuardianWhatsApp()">WhatsApp</button>
                        <a class="btn btn-secondary" target="_blank" href="<?=e($shareUrl)?>">View / PDF</a>
                    </div>
                    <div class="guardian-link-note">Active for up to 90 days unless revoked.</div>
                </div>
            <?php endif; ?>
            <?php if(!empty($guardianLinks)): ?>
                <div class="guardian-link-history">
                    <div class="guardian-history-title">Link History</div>
                    <?php foreach($guardianLinks as $gl):
                        $isActive = $gl['status']==='Active' && (empty($gl['expires_at']) || strtotime($gl['expires_at']) > time());
                        $glUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http').'://'.($_SERVER['HTTP_HOST'] ?? 'localhost').rtrim(str_replace('\\','/',dirname($_SERVER['SCRIPT_NAME'] ?? '/')), '/').'/guardian-report.php?token='.urlencode($gl['token']);
                    ?>
                        <div class="guardian-link-row">
                            <div>
                                <strong><?=e($isActive ? 'Active' : $gl['status'])?></strong>
                                <small>Created <?=e(date('d M Y, h:i A',strtotime($gl['created_at'])))?><?=!empty($gl['expires_at'])?' � Expires '.e(date('d M Y',strtotime($gl['expires_at']))):''?></small>
                            </div>
                            <div class="guardian-link-actions">
                                <?php if($isActive): ?>
                                    <button type="button" class="btn btn-secondary btn-sm" onclick='copyText(<?=json_encode($glUrl)?>,this)'>Copy</button>
                                    <a class="btn btn-secondary btn-sm" target="_blank" href="<?=e($glUrl)?>">View</a>
                                    <form method="post" onsubmit="return confirm('Revoke this guardian report link?');">
                                        <?=csrf_input()?>
                                        <input type="hidden" name="action" value="revoke_link">
                                        <input type="hidden" name="link_id" value="<?=$gl['id']?>">
                                        <input type="hidden" name="student_id" value="<?=$selectedStudent?>">
                                        <button class="btn btn-danger btn-sm" type="submit">Revoke</button>
                                    </form>
                                <?php else: ?>
                                    <span class="link-status-muted"><?=e($gl['status'])?></span>
                                <?php endif; ?>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <?php if($history): ?><div class="perf-card"><p class="section-label">Recent Evaluations</p><div style="overflow:auto"><table class="history-table"><thead><tr><th>Month</th><th>Participation</th><th>Homework</th><th>Updated</th></tr></thead><tbody><?php foreach($history as $h): ?><tr><td><?=e(date('F Y',strtotime($h['evaluation_month'])))?></td><td><?=e($h['participation'])?></td><td><?=number_format((int)$h['homework_completed'])?> / <?=number_format((int)$h['homework_assigned'])?></td><td><?=e(date('d M Y',strtotime($h['updated_at'])))?></td></tr><?php endforeach; ?></tbody></table></div></div><?php endif; ?>
    <?php endif; ?>
    </section>
</div>

<style>
.guardian-manager .share-row{display:flex;gap:8px;align-items:center;flex-wrap:wrap}
.guardian-manager .share-row input{flex:1;min-width:240px}
.guardian-link-note{font-size:11px;color:#777;margin-top:8px}
.guardian-link-history{margin-top:18px;border-top:1px solid #eee;padding-top:15px}
.guardian-history-title{font-size:12px;font-weight:800;margin-bottom:10px}
.guardian-link-row{display:flex;justify-content:space-between;align-items:center;gap:12px;padding:11px 0;border-bottom:1px solid #eee}
.guardian-link-row small{display:block;color:#777;margin-top:3px;font-size:10px}
.guardian-link-actions{display:flex;align-items:center;gap:6px;flex-wrap:wrap}
.btn-sm{padding:7px 10px!important;font-size:11px!important}
.btn-danger{background:#fff0f1!important;color:#b21f2d!important;border:1px solid #f0c7cc!important}
.link-status-muted{font-size:11px;color:#888}
@media(max-width:650px){.guardian-link-row{align-items:flex-start;flex-direction:column}.guardian-link-actions{width:100%}.guardian-link-actions .btn,.guardian-link-actions form{flex:1}.guardian-link-actions form .btn{width:100%}}
</style>
<script>
function copyText(value,button){
    navigator.clipboard.writeText(value).then(function(){
        var old=button.textContent; button.textContent='Copied!';
        setTimeout(function(){button.textContent=old;},1200);
    }).catch(function(){prompt('Copy this link:',value);});
}
function copyGuardianLink(){
    var el=document.getElementById('shareUrl');
    if(el) copyText(el.value, document.querySelector('.guardian-manager .share-row .btn-secondary'));
}
function shareGuardianWhatsApp(){
    var el=document.getElementById('shareUrl');
    if(!el) return;
    window.open('https://wa.me/?text='+encodeURIComponent('Edumax Student Performance & Guardian Report\n'+el.value),'_blank','noopener');
}
</script>

<?php require '_footer.php'; ?>

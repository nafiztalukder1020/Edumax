<?php
require_once __DIR__ . '/../config/app.php';
require_access('students');

$pdo = $pdo ?? db();

try {
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS student_materials (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        student_id INT UNSIGNED NOT NULL,
        material_type VARCHAR(30) NOT NULL,
        status VARCHAR(20) NOT NULL DEFAULT 'Pending',
        given_at DATETIME NULL,
        given_by INT UNSIGNED NULL,
        note VARCHAR(255) NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
        UNIQUE KEY uq_student_material (student_id, material_type),
        KEY idx_material_type_status (material_type,status),
        KEY idx_student_material_student (student_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
} catch (Throwable $e) {
    http_response_code(500);
    exit('Materials database setup failed. Please import database/student_materials.sql from the Materials V46 package.');
}

try {
    $pdo->exec("
    CREATE TABLE IF NOT EXISTS student_material_history (
        id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
        student_id INT UNSIGNED NOT NULL,
        material_type VARCHAR(30) NOT NULL,
        old_status VARCHAR(20) NULL,
        new_status VARCHAR(20) NOT NULL,
        note VARCHAR(255) NULL,
        changed_by INT UNSIGNED NULL,
        changed_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        KEY idx_material_history_student (student_id),
        KEY idx_material_history_material (material_type),
        KEY idx_material_history_date (changed_at)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ");
} catch (Throwable $e) {
    http_response_code(500);
    exit('Material history database setup failed.');
}

function is_ielts_student(PDO $pdo, int $studentId): bool {
    $st=$pdo->prepare("
        SELECT 1 FROM admissions a
        JOIN courses c ON c.id=a.course_id
        WHERE a.student_id=? AND LOWER(c.name) LIKE '%ielts%'
        LIMIT 1
    ");
    $st->execute([$studentId]);
    if ($st->fetchColumn()) return true;
    $st=$pdo->prepare("SELECT course_interest FROM applications WHERE student_id=? ORDER BY id DESC LIMIT 1");
    $st->execute([$studentId]);
    return stripos((string)$st->fetchColumn(), 'ielts') !== false;
}

$message = '';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    require_valid_csrf();

    $studentId=(int)($_POST['student_id']??0);
    $type=$_POST['material_type']??'';
    $action=$_POST['action']??'';
    $note=trim($_POST['note']??'');

    if ($studentId>0 && in_array($type,['ID Card','IELTS Book'],true)
        && in_array($action,['give','pending'],true)) {

        // A material can only be tracked for a student who has a current/non-cancelled admission.
        $st=$pdo->prepare("
            SELECT 1
            FROM admissions a
            WHERE a.student_id=? AND a.status<>'Cancelled'
            LIMIT 1
        ");
        $st->execute([$studentId]);
        $hasActiveAdmission=(bool)$st->fetchColumn();

        if (!$hasActiveAdmission) {
            $message = 'Material cannot be updated because the student has no active admission.';
        } elseif ($type==='IELTS Book' && !is_ielts_student($pdo,$studentId)) {
            $message = 'IELTS Book is only for IELTS students.';
        } elseif ($action==='pending' && $note==='') {
            $message = 'Please select a pending reason.';
        } else {
            $oldSt=$pdo->prepare("
                SELECT status,note FROM student_materials
                WHERE student_id=? AND material_type=? LIMIT 1
            ");
            $oldSt->execute([$studentId,$type]);
            $old=$oldSt->fetch(PDO::FETCH_ASSOC);
            $oldStatus=$old['status']??'Pending';

            if ($action==='give') {
                $newStatus='Given';
                $newNote=$note!==''?$note:null;
                $givenAt=date('Y-m-d H:i:s');
                $givenBy=(int)$_SESSION['user_id'];
            } else {
                $newStatus='Pending';
                $newNote=$note;
                $givenAt=null;
                $givenBy=null;
            }

            $st=$pdo->prepare("INSERT INTO student_materials
                (student_id,material_type,status,given_at,given_by,note)
                VALUES (?,?,?,?,?,?)
                ON DUPLICATE KEY UPDATE
                    status=VALUES(status),
                    given_at=VALUES(given_at),
                    given_by=VALUES(given_by),
                    note=VALUES(note)");
            $st->execute([$studentId,$type,$newStatus,$givenAt,$givenBy,$newNote]);

            // Keep a history row whenever the tracked state/reason changes.
            $historyChanged = ($oldStatus !== $newStatus) || (($old['note']??'') !== ($newNote??''));
            if ($historyChanged) {
                $hst=$pdo->prepare("
                    INSERT INTO student_material_history
                    (student_id,material_type,old_status,new_status,note,changed_by,changed_at)
                    VALUES (?,?,?,?,?,?,?)
                ");
                $hst->execute([
                    $studentId,$type,$oldStatus,$newStatus,$newNote,
                    (int)$_SESSION['user_id'],date('Y-m-d H:i:s')
                ]);
            }

            $message = $type . ($action==='give' ? ' marked as Given.' : ' kept as Pending.');
        }
    } else {
        $message = 'Invalid material action.';
    }

    $redirect = 'materials.php';
    $params = [];
    if (!empty($_POST['q'])) $params['q'] = $_POST['q'];
    if (!empty($_POST['course'])) $params['course'] = $_POST['course'];
    if (!empty($_POST['type'])) $params['type'] = $_POST['type'];
    if (!empty($_POST['status'])) $params['status'] = $_POST['status'];
    if (!empty($message)) $params['msg'] = $message;
    if ($params) $redirect .= '?' . http_build_query($params);
    header('Location: ' . $redirect);
    exit;
}

$q=trim($_GET['q']??'');
$course=trim($_GET['course']??'');
$status=strtolower(trim($_GET['status']??''));
$type=trim($_GET['type']??'');

/*
 * Fetch the complete active-student material dataset first.
 * All dashboard filters are applied in PHP so the quick boxes and the
 * result list always use exactly the same status logic.
 */
$studentsStmt=$pdo->query("
SELECT
       s.id,
       s.student_id,
       s.full_name,
       s.mobile,
       c.name AS course_name,
       im.status AS id_status,
       im.given_at AS id_given_at,
       im.given_by AS id_given_by,
       im.note AS id_note,
       bm.status AS book_status,
       bm.given_at AS book_given_at,
       bm.given_by AS book_given_by,
       bm.note AS book_note
FROM students s
INNER JOIN admissions a
    ON a.student_id=s.id
   AND a.status<>'Cancelled'
INNER JOIN courses c
    ON c.id=a.course_id
LEFT JOIN student_materials im
    ON im.student_id=s.id
   AND im.material_type='ID Card'
LEFT JOIN student_materials bm
    ON bm.student_id=s.id
   AND bm.material_type='IELTS Book'
WHERE a.id=(
    SELECT MAX(a2.id)
    FROM admissions a2
    WHERE a2.student_id=s.id
      AND a2.status<>'Cancelled'
)
ORDER BY s.id DESC
");
$allStudentRows=$studentsStmt->fetchAll(PDO::FETCH_ASSOC);

/* Apply search/course/material/status filters to the exact same rows. */
$rows=[];
foreach($allStudentRows as $r){
    $studentName=(string)($r['full_name']??'');
    $studentMobile=(string)($r['mobile']??'');
    $studentId=(string)($r['student_id']??'');
    $courseName=(string)($r['course_name']??'');

    if($q!==''){
        $hay=strtolower($studentName.' '.$studentMobile.' '.$studentId);
        if(strpos($hay,strtolower($q))===false) continue;
    }

    if($course!=='' && strcasecmp(trim($courseName),trim($course))!==0){
        continue;
    }

    $idIsGiven=(strtolower(trim((string)($r['id_status']??'')))==='given');
    $isIelts=(stripos($courseName,'ielts')!==false);
    $bookIsGiven=(strtolower(trim((string)($r['book_status']??'')))==='given');

    if($type==='ID Card'){
        if($status==='given' && !$idIsGiven) continue;
        if($status==='pending' && $idIsGiven) continue;
    } elseif($type==='IELTS Book'){
        if(!$isIelts) continue;
        if($status==='given' && !$bookIsGiven) continue;
        if($status==='pending' && $bookIsGiven) continue;
    } elseif($status!==''){
        if($status==='given'){
            if(!($idIsGiven || ($isIelts && $bookIsGiven))) continue;
        } elseif($status==='pending'){
            if(!(!$idIsGiven || ($isIelts && !$bookIsGiven))) continue;
        }
    }

    $rows[]=$r;
}

/*
 * Dashboard summary ALWAYS uses the complete active-student dataset.
 * Clicking a box changes only $rows (the list below).
 */
$summaryRows=$allStudentRows;

$totalStudents=count($summaryRows);
$idGiven=$idPending=$bookGiven=$bookPending=$ieltsStudents=0;

foreach($summaryRows as $r){
    if(strtolower(trim((string)($r['id_status']??'')))==='given') $idGiven++;
    else $idPending++;

    if(stripos((string)($r['course_name']??''),'ielts')!==false){
        $ieltsStudents++;
        if(strtolower(trim((string)($r['book_status']??'')))==='given') $bookGiven++;
        else $bookPending++;
    }
}

$resultCount=count($rows);
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Materials Tracking</title>
<link rel="stylesheet" href="assets/edumax-modern.css">
<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="assets/responsive.css">
<style>
.material-wrap{padding:28px}
.material-head{display:flex;justify-content:space-between;gap:16px;align-items:center;margin-bottom:20px}
.material-head h1{margin:0}
.material-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.mcard{background:#fff;border:1px solid #e8e9ed;border-radius:16px;padding:18px}
.mcard small{color:#737982}
.mcard strong{display:block;font-size:26px;margin-top:5px}

.quick-filters{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:10px;margin:0 0 16px}
.quick-filter{display:flex;justify-content:space-between;align-items:center;gap:8px;padding:12px 14px;background:#fff;border:1px solid #e8e9ed;border-radius:12px;text-decoration:none;color:#172033;transition:.15s}
.quick-filter:hover{border-color:#c91f2e;transform:translateY(-1px)}
.quick-filter.active{border-color:#c91f2e;box-shadow:0 0 0 1px #c91f2e inset;background:#fff5f6}
.quick-filter span{font-size:12px;font-weight:600}
.quick-filter strong{font-size:18px;color:#c91f2e}

.filters{background:#fff;border:1px solid #e8e9ed;border-radius:16px;padding:16px;margin-bottom:16px;display:flex;gap:10px;flex-wrap:wrap}
.filters input,.filters select{min-height:42px;border:1px solid #ddd;border-radius:10px;padding:8px 12px;background:#fff}
.filters input{min-width:220px;flex:1}

.result-heading{display:flex;justify-content:space-between;align-items:center;padding:0 2px 10px}
.result-heading strong{font-size:15px}
.result-heading span{font-size:12px;color:#737982;margin-left:8px}
.summary-note{font-size:12px;color:#737982;margin:-8px 0 10px 2px}

/* Real table: every matching student gets its own visible row. */
.materials-result-wrap{
    width:100%;
    background:#fff;
    border:1px solid #e8e9ed;
    border-radius:16px;
    overflow-x:auto;
    overflow-y:visible;
}
.materials-result-table{
    width:100%;
    min-width:950px;
    border-collapse:collapse;
    border-spacing:0;
}
.materials-result-table thead{display:table-header-group}
.materials-result-table tbody{display:table-row-group}
.materials-result-table tr{display:table-row!important;visibility:visible!important;opacity:1!important}
.materials-result-table th,
.materials-result-table td{
    display:table-cell!important;
    padding:14px;
    text-align:left;
    vertical-align:top;
    border-bottom:1px solid #eee;
}
.materials-result-table th{
    background:#fafafa;
    font-size:12px;
    font-weight:700;
    color:#4d535b;
    white-space:nowrap;
}
.materials-result-table tbody tr:last-child td{border-bottom:0}
.materials-result-table tbody tr:hover{background:#fcfcfd}
.student-name{font-size:13px;font-weight:700;color:#172033}
.student-meta{display:block;margin-top:5px;font-size:11px;color:#737982;line-height:1.4}
.course-name{font-size:13px;color:#30343b}
.material-meta{display:block;margin-top:5px;font-size:11px;color:#737982;line-height:1.35}
.badge-given{display:inline-block;color:#16794c;background:#e9f8f0;padding:5px 9px;border-radius:999px;font-size:12px;font-weight:700;white-space:nowrap}
.badge-pending{display:inline-block;color:#a15b00;background:#fff4df;padding:5px 9px;border-radius:999px;font-size:12px;font-weight:700;white-space:nowrap}
.material-actions{display:flex;flex-wrap:wrap;gap:6px;align-items:center;min-width:210px}
.material-actions form{margin:0;padding:0}
.history-link{display:inline-block;font-size:12px;font-weight:700;text-decoration:none;padding:7px 8px}
.empty-row{text-align:center!important;padding:40px!important;color:#737982!important}

@media(max-width:1050px){
    .quick-filters{grid-template-columns:repeat(3,1fr)}
}
@media(max-width:900px){
    .material-grid{grid-template-columns:repeat(2,1fr)}
}
@media(max-width:700px){
    .material-wrap{padding:16px}
    .material-grid{grid-template-columns:1fr 1fr}
    .quick-filters{grid-template-columns:1fr 1fr}
    .material-head{display:block}
}
@media(max-width:500px){
    .material-grid{grid-template-columns:1fr}
    .quick-filters{grid-template-columns:1fr}
}
</style>
</head>
<body>
<?php require __DIR__.'/_header.php'; ?>

<main class="main-content">
<div class="material-wrap">

    <div class="material-head">
        <div>
            <h1>📦 Materials Tracking</h1>
            <div style="color:#737982;margin-top:5px">
                Track ID Cards for all students and IELTS Books for IELTS students.
            </div>
        </div>
    </div>

    <?php if (!empty($_GET['msg'])): ?>
        <div style="margin-bottom:16px;padding:12px 14px;border:1px solid #e8e9ed;border-radius:12px;background:#fff;">
            <?=e($_GET['msg'])?>
        </div>
    <?php endif; ?>

    <!-- SUMMARY -->
    <div class="material-grid">
        <div class="mcard">
            <small>Total Students</small>
            <strong><?=number_format($totalStudents)?></strong>
        </div>

        <div class="mcard">
            <small>ID Card — Given / Pending</small>
            <strong><?=number_format($idGiven)?> / <?=number_format($idPending)?></strong>
        </div>

        <div class="mcard">
            <small>IELTS Book — Given / Pending</small>
            <strong><?=number_format($bookGiven)?> / <?=number_format($bookPending)?></strong>
        </div>

        <div class="mcard">
            <small>IELTS Students</small>
            <strong><?=number_format($ieltsStudents)?></strong>
        </div>
    </div>

    <div class="summary-note">
        Click any box to show only those students in the list below.
    </div>

    <!-- QUICK FILTERS -->
    <div class="quick-filters">
        <a href="materials.php"
           class="quick-filter <?=($type==='' && $status==='' && $course==='' && $q==='')?'active':''?>">
            <span>All Students</span>
            <strong><?=number_format($totalStudents)?></strong>
        </a>

        <a href="materials.php?type=<?=rawurlencode('ID Card')?>&status=given"
           class="quick-filter <?=($type==='ID Card' && $status==='given')?'active':''?>">
            <span>ID Card Given</span>
            <strong><?=number_format($idGiven)?></strong>
        </a>

        <a href="materials.php?type=<?=rawurlencode('ID Card')?>&status=pending"
           class="quick-filter <?=($type==='ID Card' && $status==='pending')?'active':''?>">
            <span>ID Card Pending</span>
            <strong><?=number_format($idPending)?></strong>
        </a>

        <a href="materials.php?type=<?=rawurlencode('IELTS Book')?>&status=given"
           class="quick-filter <?=($type==='IELTS Book' && $status==='given')?'active':''?>">
            <span>Book Given</span>
            <strong><?=number_format($bookGiven)?></strong>
        </a>

        <a href="materials.php?type=<?=rawurlencode('IELTS Book')?>&status=pending"
           class="quick-filter <?=($type==='IELTS Book' && $status==='pending')?'active':''?>">
            <span>Book Pending</span>
            <strong><?=number_format($bookPending)?></strong>
        </a>
    </div>

    <!-- MANUAL FILTER -->
    <form class="filters" method="get" action="materials.php">
        <input
            name="q"
            value="<?=e($q)?>"
            placeholder="Search name, mobile or Student ID"
        >

        <select name="course">
            <option value="">All Courses</option>
            <?php foreach($pdo->query("SELECT name FROM courses ORDER BY name")->fetchAll(PDO::FETCH_COLUMN) as $cn): ?>
                <option value="<?=e($cn)?>" <?=$course===$cn?'selected':''?>>
                    <?=e($cn)?>
                </option>
            <?php endforeach; ?>
        </select>

        <select name="type">
            <option value="">All Materials</option>
            <option value="ID Card" <?=$type==='ID Card'?'selected':''?>>ID Card</option>
            <option value="IELTS Book" <?=$type==='IELTS Book'?'selected':''?>>IELTS Book</option>
        </select>

        <select name="status">
            <option value="">All Status</option>
            <option value="pending" <?=$status==='pending'?'selected':''?>>Pending</option>
            <option value="given" <?=$status==='given'?'selected':''?>>Given</option>
        </select>

        <button class="btn btn-primary" type="submit">Filter</button>
        <a class="btn btn-light" href="materials.php">Reset</a>
    </form>

    <!-- RESULT COUNT -->
    <div class="result-heading">
        <div>
            <strong>
                <?=number_format($resultCount)?> student<?=($resultCount==1?'':'s')?> shown
            </strong>
            <span>
                <?php if($type!=='' || $status!=='' || $course!=='' || $q!==''): ?>
                    Filtered result
                <?php else: ?>
                    Latest active admissions
                <?php endif; ?>
            </span>
        </div>
    </div>

    <!-- STUDENT LIST -->
    <div class="materials-result-wrap">
        <table class="materials-result-table">
            <thead>
                <tr>
                    <th style="width:25%">Student</th>
                    <th style="width:15%">Course</th>
                    <th style="width:18%">ID Card</th>
                    <th style="width:18%">IELTS Book</th>
                    <th style="width:24%">Action</th>
                </tr>
            </thead>

            <tbody>
            <?php if(!$rows): ?>
                <tr>
                    <td colspan="5" class="empty-row">
                        No students found for this filter.
                    </td>
                </tr>
            <?php else: ?>

                <?php foreach($rows as $r): ?>
                    <?php
                        $ielts = !empty($r['course_name'])
                            && stripos((string)$r['course_name'],'ielts')!==false;

                        $idGivenStatus =
                            strtolower(trim((string)($r['id_status']??''))) === 'given';

                        $bookGivenStatus =
                            strtolower(trim((string)($r['book_status']??''))) === 'given';
                    ?>

                    <tr>
                        <!-- STUDENT -->
                        <td>
                            <div class="student-name">
                                <?=e($r['full_name'])?>
                            </div>

                            <span class="student-meta">
                                <?=e($r['student_id'])?>
                                <?php if(!empty($r['mobile'])): ?>
                                    · <?=e($r['mobile'])?>
                                <?php endif; ?>
                            </span>
                        </td>

                        <!-- COURSE -->
                        <td>
                            <span class="course-name">
                                <?=e($r['course_name'] ?: '—')?>
                            </span>
                        </td>

                        <!-- ID CARD -->
                        <td>
                            <?php if($idGivenStatus): ?>
                                <span class="badge-given">✓ Given</span>

                                <?php if(!empty($r['id_given_at'])): ?>
                                    <span class="material-meta">
                                        Given:
                                        <?=e(date('d M Y, h:i A',strtotime($r['id_given_at'])))?>
                                    </span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge-pending">Pending</span>

                                <?php if(!empty($r['id_note'])): ?>
                                    <span class="material-meta">
                                        <?=e($r['id_note'])?>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>

                        <!-- IELTS BOOK -->
                        <td>
                            <?php if(!$ielts): ?>
                                <span style="color:#999">—</span>
                            <?php elseif($bookGivenStatus): ?>
                                <span class="badge-given">✓ Given</span>

                                <?php if(!empty($r['book_given_at'])): ?>
                                    <span class="material-meta">
                                        Given:
                                        <?=e(date('d M Y, h:i A',strtotime($r['book_given_at'])))?>
                                    </span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="badge-pending">Pending</span>

                                <?php if(!empty($r['book_note'])): ?>
                                    <span class="material-meta">
                                        <?=e($r['book_note'])?>
                                    </span>
                                <?php endif; ?>
                            <?php endif; ?>
                        </td>

                        <!-- ACTION -->
                        <td>
                            <div class="material-actions">

                                <?php if(!$idGivenStatus): ?>
                                    <form method="post" action="materials.php">
                                        <?php csrf_field(); ?>

                                        <input type="hidden" name="student_id" value="<?=e($r['id'])?>">
                                        <input type="hidden" name="material_type" value="ID Card">
                                        <input type="hidden" name="action" value="give">
                                        <input type="hidden" name="q" value="<?=e($q)?>">
                                        <input type="hidden" name="course" value="<?=e($course)?>">
                                        <input type="hidden" name="type" value="<?=e($type)?>">
                                        <input type="hidden" name="status" value="<?=e($status)?>">

                                        <button class="btn btn-sm btn-primary" type="submit">
                                            Give ID Card
                                        </button>
                                    </form>
                                <?php endif; ?>

                                <?php if($ielts && !$bookGivenStatus): ?>
                                    <form method="post" action="materials.php">
                                        <?php csrf_field(); ?>

                                        <input type="hidden" name="student_id" value="<?=e($r['id'])?>">
                                        <input type="hidden" name="material_type" value="IELTS Book">
                                        <input type="hidden" name="action" value="give">
                                        <input type="hidden" name="q" value="<?=e($q)?>">
                                        <input type="hidden" name="course" value="<?=e($course)?>">
                                        <input type="hidden" name="type" value="<?=e($type)?>">
                                        <input type="hidden" name="status" value="<?=e($status)?>">

                                        <button class="btn btn-sm btn-primary" type="submit">
                                            Give Book
                                        </button>
                                    </form>
                                <?php endif; ?>

                                <a
                                    class="history-link"
                                    href="materials-history.php?student_id=<?=e($r['id'])?>"
                                >
                                    History
                                </a>

                            </div>
                        </td>
                    </tr>

                <?php endforeach; ?>

            <?php endif; ?>
            </tbody>
        </table>
    </div>

</div>
</main>

<?php require __DIR__.'/_footer.php'; ?>
</body>
</html>

<?php
require_once __DIR__ . '/../config/app.php';
require_access('teachers');

$message = '';
$error = '';
$editTeacher = null;
$editRoom = null;

/*
 * Teacher + Room Management
 * Teachers and rooms stay as directories; scheduling is handled by
 * Class Management. Rooms are intentionally name-based in class_schedules
 * so this remains compatible with the current database.
 */
$pdo->exec("
    CREATE TABLE IF NOT EXISTS teachers (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(160) NOT NULL,
        mobile VARCHAR(40) DEFAULT NULL,
        email VARCHAR(160) DEFAULT NULL,
        subject VARCHAR(160) DEFAULT NULL,
        status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
        notes TEXT DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_teacher_status (status),
        KEY idx_teacher_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

$pdo->exec("
    CREATE TABLE IF NOT EXISTS rooms (
        id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(100) NOT NULL,
        capacity INT UNSIGNED DEFAULT NULL,
        status ENUM('Active','Inactive') NOT NULL DEFAULT 'Active',
        notes TEXT DEFAULT NULL,
        created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
            ON UPDATE CURRENT_TIMESTAMP,
        KEY idx_room_status (status),
        KEY idx_room_name (name)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci
");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    try {
        $action = $_POST['action'] ?? '';

        if ($action === 'save_teacher') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $mobile = trim($_POST['mobile'] ?? '');
            $email = trim($_POST['email'] ?? '');
            $subject = trim($_POST['subject'] ?? '');
            $status = $_POST['status'] ?? 'Active';
            $notes = trim($_POST['notes'] ?? '');

            if ($name === '') throw new RuntimeException('Teacher name is required.');
            if (mb_strlen($name) > 160) throw new RuntimeException('Teacher name is too long.');
            if (!in_array($status, ['Active','Inactive'], true)) $status = 'Active';

            if ($id > 0) {
                $stmt = $pdo->prepare(
                    "UPDATE teachers SET name=?,mobile=?,email=?,subject=?,status=?,notes=? WHERE id=?"
                );
                $stmt->execute([$name,$mobile?:null,$email?:null,$subject?:null,$status,$notes?:null,$id]);
                $message = 'Teacher updated successfully.';
            } else {
                $stmt = $pdo->prepare(
                    "INSERT INTO teachers (name,mobile,email,subject,status,notes) VALUES (?,?,?,?,?,?)"
                );
                $stmt->execute([$name,$mobile?:null,$email?:null,$subject?:null,$status,$notes?:null]);
                $message = 'Teacher added successfully.';
            }
        } elseif ($action === 'delete_teacher') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Invalid teacher.');
            $used = $pdo->prepare("SELECT COUNT(*) FROM class_schedules WHERE teacher_name=(SELECT name FROM teachers WHERE id=?)");
            $used->execute([$id]);
            if ((int)$used->fetchColumn() > 0) {
                throw new RuntimeException('This teacher has class history. Set the teacher to Inactive instead of deleting.');
            }
            $pdo->prepare("DELETE FROM teachers WHERE id=?")->execute([$id]);
            $message = 'Teacher removed successfully.';
        } elseif ($action === 'save_room') {
            $id = (int)($_POST['room_id'] ?? 0);
            $name = trim($_POST['room_name'] ?? '');
            $capacity = trim($_POST['room_capacity'] ?? '');
            $status = $_POST['room_status'] ?? 'Active';
            $notes = trim($_POST['room_notes'] ?? '');

            if ($name === '') throw new RuntimeException('Room name is required.');
            if (mb_strlen($name) > 100) throw new RuntimeException('Room name is too long.');
            if (!in_array($status, ['Active','Inactive'], true)) $status = 'Active';

            $cap = ($capacity === '') ? null : (int)$capacity;
            if ($cap !== null && $cap < 1) throw new RuntimeException('Room capacity must be at least 1.');

            $dup = $pdo->prepare("SELECT id FROM rooms WHERE LOWER(name)=LOWER(?) AND id<>? LIMIT 1");
            $dup->execute([$name,$id]);
            if ($dup->fetch()) throw new RuntimeException('A room with this name already exists.');

            if ($id > 0) {
                $old = $pdo->prepare("SELECT name FROM rooms WHERE id=? LIMIT 1");
                $old->execute([$id]);
                $oldName = $old->fetchColumn();
                if (!$oldName) throw new RuntimeException('Room not found.');

                $stmt = $pdo->prepare("UPDATE rooms SET name=?,capacity=?,status=?,notes=? WHERE id=?");
                $stmt->execute([$name,$cap,$status,$notes?:null,$id]);

                // Keep existing schedule history compatible if a room is renamed.
                if ((string)$oldName !== $name) {
                    $up = $pdo->prepare("UPDATE class_schedules SET room=? WHERE room=?");
                    $up->execute([$name,$oldName]);
                }
                $message = 'Room updated successfully.';
            } else {
                $stmt = $pdo->prepare("INSERT INTO rooms (name,capacity,status,notes) VALUES (?,?,?,?)");
                $stmt->execute([$name,$cap,$status,$notes?:null]);
                $message = 'Room added successfully.';
            }
        } elseif ($action === 'delete_room') {
            $id = (int)($_POST['room_id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Invalid room.');

            $st = $pdo->prepare("SELECT name FROM rooms WHERE id=? LIMIT 1");
            $st->execute([$id]);
            $roomName = $st->fetchColumn();
            if (!$roomName) throw new RuntimeException('Room not found.');

            $used = $pdo->prepare("SELECT COUNT(*) FROM class_schedules WHERE room=?");
            $used->execute([$roomName]);
            if ((int)$used->fetchColumn() > 0) {
                throw new RuntimeException('This room has class history. Set the room to Inactive instead of deleting.');
            }

            $pdo->prepare("DELETE FROM rooms WHERE id=?")->execute([$id]);
            $message = 'Room removed successfully.';
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

$teachers = $pdo->query(
    "SELECT id,name,mobile,email,subject,status,notes FROM teachers ORDER BY name ASC,id ASC"
)->fetchAll();

$rooms = $pdo->query(
    "SELECT id,name,capacity,status,notes FROM rooms ORDER BY name ASC,id ASC"
)->fetchAll();

if (isset($_GET['edit_teacher'])) {
    $editId = (int)$_GET['edit_teacher'];
    if ($editId > 0) {
        $stmt = $pdo->prepare("SELECT * FROM teachers WHERE id=? LIMIT 1");
        $stmt->execute([$editId]);
        $editTeacher = $stmt->fetch() ?: null;
    }
}

if (isset($_GET['edit_room'])) {
    $editId = (int)$_GET['edit_room'];
    if ($editId > 0) {
        $stmt = $pdo->prepare("SELECT * FROM rooms WHERE id=? LIMIT 1");
        $stmt->execute([$editId]);
        $editRoom = $stmt->fetch() ?: null;
    }
}

$tab = ($_GET['tab'] ?? 'teachers') === 'rooms' ? 'rooms' : 'teachers';

require '_header.php';
?>
<div class="section-title">
  <div><h1>Teacher & Room Management</h1><p>Manage teachers and rooms used by the class calendar.</p></div>
</div>

<?php if($message): ?><div class="alert success"><?=e($message)?></div><?php endif; ?>
<?php if($error): ?><div class="alert danger"><?=e($error)?></div><?php endif; ?>

<div class="trm-tabs">
  <a href="?tab=teachers" class="<?=$tab==='teachers'?'active':''?>">Teachers <span><?=count($teachers)?></span></a>
  <a href="?tab=rooms" class="<?=$tab==='rooms'?'active':''?>">Rooms <span><?=count($rooms)?></span></a>
</div>

<?php if($tab==='teachers'): ?>
<div class="trm-grid">
  <div class="card">
    <div class="card-head"><h3><?= $editTeacher?'Edit Teacher':'Add Teacher' ?></h3></div>
    <form method="post" class="form-grid">
      <?=csrf_input()?>
      <input type="hidden" name="action" value="save_teacher">
      <input type="hidden" name="id" value="<?=e((string)($editTeacher['id']??0))?>">
      <div><label>Teacher Name *</label><input name="name" required value="<?=e($editTeacher['name']??'')?>"></div>
      <div><label>Mobile</label><input name="mobile" value="<?=e($editTeacher['mobile']??'')?>"></div>
      <div><label>Email</label><input type="email" name="email" value="<?=e($editTeacher['email']??'')?>"></div>
      <div><label>Subject / Module</label><input name="subject" placeholder="e.g. IELTS Speaking" value="<?=e($editTeacher['subject']??'')?>"></div>
      <div><label>Status</label><select name="status"><option <?=($editTeacher['status']??'Active')==='Active'?'selected':''?>>Active</option><option <?=($editTeacher['status']??'')==='Inactive'?'selected':''?>>Inactive</option></select></div>
      <div style="grid-column:1/-1"><label>Notes</label><textarea name="notes" rows="3"><?=e($editTeacher['notes']??'')?></textarea></div>
      <div style="grid-column:1/-1;display:flex;gap:8px">
        <button class="btn btn-primary">Save Teacher</button>
        <?php if($editTeacher): ?><a class="btn btn-secondary" href="?tab=teachers">Cancel</a><?php endif; ?>
      </div>
    </form>
  </div>

  <div class="card">
    <div class="card-head"><h3>Teacher Directory</h3></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Name</th><th>Subject</th><th>Contact</th><th>Status</th><th>Action</th></tr></thead><tbody>
    <?php if(!$teachers): ?><tr><td colspan="5" class="empty-cell">No teachers added yet.</td></tr><?php endif; ?>
    <?php foreach($teachers as $t): ?><tr>
      <td><strong><?=e($t['name'])?></strong></td>
      <td><?=e($t['subject']?:'-')?></td>
      <td><?=e($t['mobile']?:$t['email']?:'-')?></td>
      <td><span class="status-pill <?=strtolower($t['status'])?>"><?=e($t['status'])?></span></td>
      <td>
        <a class="btn btn-secondary btn-sm" href="?tab=teachers&edit_teacher=<?=$t['id']?>">Edit</a>
        <form method="post" style="display:inline" onsubmit="return confirm('Remove this teacher?')">
          <?=csrf_input()?><input type="hidden" name="action" value="delete_teacher"><input type="hidden" name="id" value="<?=$t['id']?>">
          <button class="btn btn-secondary btn-sm">Delete</button>
        </form>
      </td>
    </tr><?php endforeach; ?>
    </tbody></table></div>
  </div>
</div>
<?php else: ?>
<div class="trm-grid">
  <div class="card">
    <div class="card-head"><h3><?= $editRoom?'Edit Room':'Add Room' ?></h3></div>
    <form method="post" class="form-grid">
      <?=csrf_input()?>
      <input type="hidden" name="action" value="save_room">
      <input type="hidden" name="room_id" value="<?=e((string)($editRoom['id']??0))?>">
      <div><label>Room Name *</label><input name="room_name" required value="<?=e($editRoom['name']??'')?>" placeholder="e.g. Classroom 1"></div>
      <div><label>Capacity (optional)</label><input type="number" min="1" name="room_capacity" value="<?=e($editRoom['capacity']??'')?>" placeholder="e.g. 40"></div>
      <div><label>Status</label><select name="room_status"><option <?=($editRoom['status']??'Active')==='Active'?'selected':''?>>Active</option><option <?=($editRoom['status']??'')==='Inactive'?'selected':''?>>Inactive</option></select></div>
      <div style="grid-column:1/-1"><label>Notes</label><textarea name="room_notes" rows="3"><?=e($editRoom['notes']??'')?></textarea></div>
      <div style="grid-column:1/-1;display:flex;gap:8px">
        <button class="btn btn-primary">Save Room</button>
        <?php if($editRoom): ?><a class="btn btn-secondary" href="?tab=rooms">Cancel</a><?php endif; ?>
      </div>
    </form>
  </div>

  <div class="card">
    <div class="card-head"><h3>Room Directory</h3></div>
    <div class="table-wrap"><table class="table"><thead><tr><th>Room</th><th>Capacity</th><th>Status</th><th>Notes</th><th>Action</th></tr></thead><tbody>
    <?php if(!$rooms): ?><tr><td colspan="5" class="empty-cell">No rooms added yet.</td></tr><?php endif; ?>
    <?php foreach($rooms as $r): ?><tr>
      <td><strong><?=e($r['name'])?></strong></td>
      <td><?=e($r['capacity']!==null?(string)$r['capacity']:'—')?></td>
      <td><span class="status-pill <?=strtolower($r['status'])?>"><?=e($r['status'])?></span></td>
      <td><?=e($r['notes']?:'-')?></td>
      <td>
        <a class="btn btn-secondary btn-sm" href="?tab=rooms&edit_room=<?=$r['id']?>">Edit</a>
        <form method="post" style="display:inline" onsubmit="return confirm('Remove this room?')">
          <?=csrf_input()?><input type="hidden" name="action" value="delete_room"><input type="hidden" name="room_id" value="<?=$r['id']?>">
          <button class="btn btn-secondary btn-sm">Delete</button>
        </form>
      </td>
    </tr><?php endforeach; ?>
    </tbody></table></div>
  </div>
</div>
<?php endif; ?>

<style>
.trm-tabs{display:flex;gap:8px;margin:0 0 18px}.trm-tabs a{padding:11px 16px;border:1px solid var(--border);border-radius:12px;background:#fff;color:var(--ink);font-weight:800;text-decoration:none}.trm-tabs a.active{background:var(--brand);border-color:var(--brand);color:#fff}.trm-tabs span{display:inline-flex;min-width:22px;height:22px;padding:0 6px;border-radius:99px;align-items:center;justify-content:center;background:rgba(0,0,0,.08);font-size:11px;margin-left:5px}.trm-tabs a.active span{background:rgba(255,255,255,.2)}.trm-grid{display:grid;grid-template-columns:minmax(320px,.85fr) minmax(480px,1.5fr);gap:18px}.card-head{padding:18px 20px;border-bottom:1px solid var(--border)}.card-head h3{margin:0}.trm-grid .card>form{padding:20px}.status-pill{display:inline-flex;padding:5px 9px;border-radius:99px;font-size:11px;font-weight:800}.status-pill.active{background:#eaf7ee}.status-pill.inactive{background:#f1f2f4;color:var(--muted)}.btn-sm{padding:7px 10px;font-size:12px}.empty-cell{text-align:center;padding:30px;color:var(--muted)}@media(max-width:900px){.trm-grid{grid-template-columns:1fr}.table-wrap{overflow-x:auto}}
</style>
<?php require '_footer.php'; ?>

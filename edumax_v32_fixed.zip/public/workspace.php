<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_admin();

header('Location: workspace-switch.php?to=auto');
exit;

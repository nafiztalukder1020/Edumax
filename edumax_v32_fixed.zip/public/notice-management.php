<?php
require_once __DIR__ . '/../config/app.php';
require_valid_csrf();
require_access('students');

$pdo->exec("CREATE TABLE IF NOT EXISTS notices (
 id INT UNSIGNED NOT NULL AUTO_INCREMENT PRIMARY KEY,
 title VARCHAR(200) NOT NULL, body TEXT NOT NULL,
 audience ENUM('All','Batch','Student') NOT NULL DEFAULT 'All',
 batch_id INT UNSIGNED NULL, student_id INT UNSIGNED NULL,
 publish_date DATE NOT NULL, expiry_date DATE NULL,
 status ENUM('Published','Draft','Expired') NOT NULL DEFAULT 'Published',
 created_by INT UNSIGNED NULL, created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 KEY idx_notice_status_date (status,publish_date,expiry_date), KEY idx_notice_batch(batch_id), KEY idx_notice_student(student_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci");

$message=''; $error='';
if($_SERVER['REQUEST_METHOD']==='POST'){
 try{
  $action=$_POST['action']??''; $id=(int)($_POST['id']??0);
  if($action==='save'){
   $title=trim($_POST['title']??''); $body=trim($_POST['body']??'');
   $aud=$_POST['audience']??'All'; $batch=(int)($_POST['batch_id']??0); $student=(int)($_POST['student_id']??0);
   $pub=$_POST['publish_date']??date('Y-m-d'); $exp=trim($_POST['expiry_date']??''); $status=$_POST['status']??'Published';
   if($title===''||$body==='') throw new RuntimeException('Title and notice details are required.');
   if(!in_array($aud,['All','Batch','Student'],true)) $aud='All';
   if($aud==='Batch' && $batch<=0) throw new RuntimeException('Please select a batch.');
   if($aud==='Student' && $student<=0) throw new RuntimeException('Please select a student.');
   if(!in_array($status,['Published','Draft','Expired'],true)) $status='Published';
   $batchVal=$aud==='Batch'?$batch:null; $studentVal=$aud==='Student'?$student:null; $expVal=$exp!==''?$exp:null;
   if($id>0){$q=$pdo->prepare('UPDATE notices SET title=?,body=?,audience=?,batch_id=?,student_id=?,publish_date=?,expiry_date=?,status=? WHERE id=?');$q->execute([$title,$body,$aud,$batchVal,$studentVal,$pub,$expVal,$status,$id]);$message='Notice updated successfully.';}
   else{$q=$pdo->prepare('INSERT INTO notices(title,body,audience,batch_id,student_id,publish_date,expiry_date,status,created_by) VALUES(?,?,?,?,?,?,?,?,?)');$q->execute([$title,$body,$aud,$batchVal,$studentVal,$pub,$expVal,$status,(int)($_SESSION['user_id']??0)?:null]);$message='Notice created successfully.';}
  }elseif($action==='delete'){$q=$pdo->prepare('DELETE FROM notices WHERE id=?');$q->execute([$id]);$message='Notice deleted successfully.';}
 }catch(Throwable $e){$error=$e->getMessage();}
}
$batches=$pdo->query("SELECT id,name FROM batches WHERE is_archived=0 ORDER BY name")->fetchAll();
$students=$pdo->query("SELECT id,student_id,full_name AS name,mobile FROM students WHERE is_archived=0 ORDER BY full_name LIMIT 1000")->fetchAll();
$notices=$pdo->query("SELECT n.*,b.name batch_name,s.student_id student_code,s.full_name student_name FROM notices n LEFT JOIN batches b ON b.id=n.batch_id LEFT JOIN students s ON s.id=n.student_id ORDER BY n.publish_date DESC,n.id DESC")->fetchAll();
$edit=null;if(isset($_GET['edit'])){$q=$pdo->prepare('SELECT * FROM notices WHERE id=?');$q->execute([(int)$_GET['edit']]);$edit=$q->fetch()?:null;}
require '_header.php';
?>
<div class="section-title"><div><h1>Notice Management</h1><p>Create announcements for all students, a batch, or one student.</p></div></div>
<?php if($message):?><div class="alert success"><?=e($message)?></div><?php endif;?><?php if($error):?><div class="alert danger"><?=e($error)?></div><?php endif;?>
<div class="notice-grid"><div class="card"><div class="card-head"><h3><?= $edit?'Edit Notice':'Create Notice' ?></h3></div><form method="post" class="form-grid"><?=csrf_input()?><input type="hidden" name="action" value="save"><input type="hidden" name="id" value="<?=e((string)($edit['id']??0))?>">
<div style="grid-column:1/-1"><label>Title *</label><input name="title" required value="<?=e($edit['title']??'')?>"></div>
<div style="grid-column:1/-1"><label>Notice Details *</label><textarea name="body" rows="6" required><?=e($edit['body']??'')?></textarea></div>
<div><label>Audience</label><select name="audience" id="noticeAudience" onchange="toggleAudience()"><option>All</option><option <?=($edit['audience']??'')==='Batch'?'selected':''?>>Batch</option><option <?=($edit['audience']??'')==='Student'?'selected':''?>>Student</option></select></div>
<div id="batchBox"><label>Batch</label><select name="batch_id"><option value="0">Select batch</option><?php foreach($batches as $b):?><option value="<?=$b['id']?>" <?=((int)($edit['batch_id']??0)===(int)$b['id'])?'selected':''?>><?=e($b['name'])?></option><?php endforeach;?></select></div>
<div id="studentBox"><label>Student</label><select name="student_id"><option value="0">Select student</option><?php foreach($students as $s):?><option value="<?=$s['id']?>" <?=((int)($edit['student_id']??0)===(int)$s['id'])?'selected':''?>><?=e($s['name'].' — '.$s['student_id'])?></option><?php endforeach;?></select></div>
<div><label>Publish Date</label><input type="date" name="publish_date" value="<?=e($edit['publish_date']??date('Y-m-d'))?>"></div><div><label>Expiry Date</label><input type="date" name="expiry_date" value="<?=e($edit['expiry_date']??'')?>"></div><div><label>Status</label><select name="status"><option <?=($edit['status']??'Published')==='Published'?'selected':''?>>Published</option><option <?=($edit['status']??'')==='Draft'?'selected':''?>>Draft</option><option <?=($edit['status']??'')==='Expired'?'selected':''?>>Expired</option></select></div>
<div style="grid-column:1/-1;display:flex;gap:8px"><button class="btn btn-primary">Save Notice</button><?php if($edit):?><a class="btn btn-secondary" href="notice-management.php">Cancel</a><?php endif;?></div></form></div>
<div class="card"><div class="card-head"><h3>Notice List</h3></div><div class="table-wrap"><table class="table"><thead><tr><th>Title</th><th>Audience</th><th>Publish</th><th>Expiry</th><th>Status</th><th>Action</th></tr></thead><tbody><?php if(!$notices):?><tr><td colspan="6" class="empty-cell">No notices found.</td></tr><?php endif;?><?php foreach($notices as $n):?><tr><td><strong><?=e($n['title'])?></strong><div style="font-size:12px;color:#777;margin-top:4px"><?=e(mb_strimwidth($n['body'],0,90,'…'))?></div></td><td><?=e($n['audience'])?><?php if($n['audience']==='Batch'):?> · <?=e($n['batch_name']??'-')?><?php elseif($n['audience']==='Student'):?> · <?=e($n['student_name']??'-')?><?php endif;?></td><td><?=e($n['publish_date'])?></td><td><?=e($n['expiry_date']??'-')?></td><td><span class="status-pill <?=strtolower($n['status'])?>"><?=e($n['status'])?></span></td><td><a class="btn btn-secondary btn-sm" href="?edit=<?=$n['id']?>">Edit</a> <form method="post" style="display:inline" onsubmit="return confirm('Delete this notice?')"><?=csrf_input()?><input type="hidden" name="action" value="delete"><input type="hidden" name="id" value="<?=$n['id']?>"><button class="btn btn-secondary btn-sm">Delete</button></form></td></tr><?php endforeach;?></tbody></table></div></div></div>
<script>function toggleAudience(){const a=document.getElementById('noticeAudience').value;document.getElementById('batchBox').style.display=a==='Batch'?'block':'none';document.getElementById('studentBox').style.display=a==='Student'?'block':'none';}toggleAudience();</script>
<style>.notice-grid{display:grid;grid-template-columns:minmax(320px,.85fr) minmax(500px,1.5fr);gap:18px}.card-head{padding:18px 20px;border-bottom:1px solid var(--border)}.card-head h3{margin:0}@media(max-width:900px){.notice-grid{grid-template-columns:1fr}}</style>
<?php require '_footer.php'; ?>

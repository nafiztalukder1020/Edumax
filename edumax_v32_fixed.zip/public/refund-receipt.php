<?php
require_once __DIR__ . '/../config/app.php';
require_access('payments');

/*
 * Refund receipt lookup:
 * Supports BOTH:
 *   refund-receipt.php?refund_no=EDU-RF-2026-00001
 *   refund-receipt.php?id=1
 *
 * This keeps old/bookmarked links working and fixes View Receipt
 * links that pass the refund database ID.
 */

$refundNo = trim($_GET['refund_no'] ?? '');
$refundId = isset($_GET['id']) ? (int)$_GET['id'] : 0;

if ($refundNo === '' && $refundId <= 0) {
    http_response_code(400);
    exit('Refund receipt number or refund ID is required.');
}

$sql = "
    SELECT
        r.*,
        s.student_id AS student_code,
        s.full_name,
        s.mobile,
        s.email,
        ad.id AS admission_id,
        ad.admission_date,
        ad.cancelled_at,
        ad.final_dealing_price,
        ad.status AS admission_status,
        ad.refund_deduction_percent,
        ad.refund_deduction_amount,
        ad.refund_paid_amount,
        ad.refund_amount AS policy_refund_amount,
        c.name AS course_name,
        b.name AS batch_name
    FROM refunds r
    JOIN students s ON s.id=r.student_id
    JOIN admissions ad ON ad.id=r.admission_id
    JOIN courses c ON c.id=ad.course_id
    JOIN batches b ON b.id=ad.batch_id
";

if ($refundNo !== '') {
    $sql .= " WHERE r.refund_no=? LIMIT 1";
    $q = $pdo->prepare($sql);
    $q->execute([$refundNo]);
} else {
    $sql .= " WHERE r.id=? LIMIT 1";
    $q = $pdo->prepare($sql);
    $q->execute([$refundId]);
}

$refund = $q->fetch();

if (!$refund) {
    http_response_code(404);
    exit('Refund receipt not found.');
}

$refundNo = (string)$refund['refund_no'];

$paidQ = $pdo->prepare("
    SELECT COALESCE(SUM(amount),0)
    FROM payments
    WHERE admission_id=? AND status='Valid'
");
$paidQ->execute([(int)$refund['admission_id']]);
$grossPaid = (float)$paidQ->fetchColumn();

$refundBeforeQ = $pdo->prepare("
    SELECT COALESCE(SUM(amount),0)
    FROM refunds
    WHERE admission_id=? AND status='Valid' AND id < ?
");
$refundBeforeQ->execute([
    (int)$refund['admission_id'],
    (int)$refund['id']
]);
$refundBefore = (float)$refundBeforeQ->fetchColumn();

$totalRefunded = $refundBefore + (float)$refund['amount'];
$netPaid = max(0, $grossPaid - $totalRefunded);
// Same rule as refund-create.php: a cancelled admission has no collectible due.
$due = (($refund['admission_status'] ?? '') === 'Cancelled')
    ? 0.0
    : max(0, (float)$refund['final_dealing_price'] - $netPaid);

$processedBy = 'System';
try {
    $uq = $pdo->prepare("SELECT * FROM users WHERE id=? LIMIT 1");
    $uq->execute([(int)$refund['processed_by']]);
    $u = $uq->fetch();
    if ($u) {
        $processedBy = $u['name'] ?? ($u['full_name'] ?? ($u['username'] ?? 'System'));
    }
} catch (Throwable $e) {}

$money = static function($v) {
    return '৳'.number_format((float)$v, 2);
};

$dateTime = $refund['created_at']
    ? date('d M Y, h:i A', strtotime($refund['created_at']))
    : date('d M Y, h:i A');

$cancelDate = $refund['cancelled_at']
    ? date('d M Y', strtotime($refund['cancelled_at']))
    : '—';

$admissionDate = $refund['admission_date']
    ? date('d M Y', strtotime($refund['admission_date']))
    : '—';

$finePercent = (float)$refund['refund_deduction_percent'];
$fineAmount = (float)$refund['refund_deduction_amount'];
$policyRefund = (float)$refund['policy_refund_amount'];
$currentRefund = (float)$refund['amount'];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?=e($refundNo)?> - Refund Receipt</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
*{box-sizing:border-box}
html,body{
    margin:0;
    padding:0;
    background:#eef1f4;
    font-family:Arial,Helvetica,sans-serif;
    color:#20252b;
    font-size:11px;
}
.toolbar{
    width:100%;
    display:flex;
    justify-content:center;
    gap:8px;
    padding:6px 0 12px;
}
.btn{
    border:0;
    border-radius:5px;
    padding:7px 12px;
    font-size:10px;
    font-weight:700;
    cursor:pointer;
}
.btn.back{background:#fff;border:1px solid #d8dce1;color:#333}
.btn.print{background:#c91f2e;color:#fff;box-shadow:0 4px 10px rgba(201,31,46,.18)}
.sheet{
    width:210mm;
    margin:0 auto;
}
.page{
    width:210mm;
    height:297mm;
    min-height:297mm;
    background:#fff;
    padding:12mm 12mm 10mm;
    position:relative;
    border-top:4px solid #c91f2e;
    page-break-after:always;
    overflow:hidden;
}
.page:last-child{page-break-after:auto}

.receipt-header{
    display:flex;
    align-items:center;
    justify-content:space-between;
    border-bottom:1px solid #dfe2e6;
    padding:7mm 0 4mm;
}
.brand{
    display:flex;
    align-items:center;
    gap:10px;
}
.brand img{
    width:48px;
    height:34px;
    object-fit:contain;
}
.brand h1{
    margin:0;
    font-size:16px;
    line-height:1.2;
    color:#111827;
}
.brand p{
    margin:2px 0 0;
    font-size:7.5px;
    color:#7a8088;
}
.copy-label{
    align-self:flex-end;
    color:#c91f2e;
    font-size:8px;
    font-weight:800;
    letter-spacing:.8px;
    text-transform:uppercase;
    padding-bottom:1px;
}
.info-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    border:1px solid #dce0e5;
    border-radius:5px;
    overflow:hidden;
    margin-top:7px;
}
.info{
    min-height:27px;
    padding:6px 7px;
    border-right:1px solid #dce0e5;
    border-bottom:1px solid #dce0e5;
    font-size:8px;
    line-height:1.25;
}
.info:nth-child(3n){border-right:0}
.info:nth-last-child(-n+3){border-bottom:0}
.info b{font-weight:700}
.refund-block{
    margin-top:8px;
    border-top:1px solid #dce0e5;
    border-bottom:1px solid #dce0e5;
}
.refund-head,
.highlight{
    display:flex;
    justify-content:space-between;
    align-items:center;
    padding:6px 7px;
    background:#fff0f2;
    color:#c91f2e;
    font-weight:800;
    font-size:11px;
}
.refund-row{
    display:flex;
    justify-content:space-between;
    align-items:center;
    min-height:22px;
    padding:5px 7px;
    border-bottom:1px solid #e2e5e9;
    font-size:8px;
}
.refund-row:last-child{border-bottom:0}
.refund-row .amount{
    font-weight:700;
    white-space:nowrap;
}
.refund-row.total{
    background:#fff0f2;
    color:#c91f2e;
    font-size:12px;
    font-weight:800;
}
.refund-row.due{
    background:#fff7f8;
    color:#c91f2e;
    font-size:11px;
    font-weight:800;
}
.small-grid{
    display:grid;
    grid-template-columns:repeat(3,1fr);
    border:1px solid #dce0e5;
    border-radius:5px;
    overflow:hidden;
    margin-top:8px;
}
.small{
    min-height:25px;
    padding:6px 7px;
    border-right:1px solid #dce0e5;
    border-bottom:1px solid #dce0e5;
    font-size:8px;
}
.small:nth-child(3n){border-right:0}
.small:nth-last-child(-n+3){border-bottom:0}
.policy{
    margin-top:8px;
    padding:7px 8px;
    border:1px solid #dce0e5;
    border-left:3px solid #c91f2e;
    border-radius:5px;
    background:#fafafa;
    font-size:7.5px;
    line-height:1.45;
    color:#565d66;
}
.policy strong{
    color:#c91f2e;
    display:block;
    margin-bottom:2px;
}
.note{
    margin-top:7px;
    padding:6px 8px;
    border:1px solid #e1e4e8;
    border-radius:5px;
    font-size:7.5px;
    line-height:1.4;
    color:#60666e;
}
.office-detail{
    margin-top:7px;
    padding:6px 8px;
    border:1px solid #e1e4e8;
    border-radius:5px;
    background:#fafafa;
    font-size:7.5px;
    line-height:1.4;
    color:#555c65;
}
.thanks{
    margin-top:8px;
    font-size:7.5px;
    color:#777d85;
}
.signature-row{
    display:grid;
    grid-template-columns:1fr 1fr;
    gap:35mm;
    margin-top:15mm;
}
.signature{
    border-top:1px solid #777;
    padding-top:4px;
    text-align:center;
    font-size:7px;
    color:#555;
}
.footer{
    position:absolute;
    left:12mm;
    right:12mm;
    bottom:8mm;
    border-top:1px dashed #aeb4bb;
    padding-top:5px;
    display:flex;
    justify-content:space-between;
    font-size:6.5px;
    color:#7b8189;
}
.status{
    display:inline-block;
    padding:2px 6px;
    border-radius:10px;
    font-size:6.5px;
    font-weight:800;
    text-transform:uppercase;
}
.valid{background:#e9f7ef;color:#25804b}
.void{background:#fff0f1;color:#b21f2d}

@media print{
    @page{size:A4 portrait;margin:0}
    html,body{background:#fff}
    .toolbar{display:none}
    .sheet{width:210mm;margin:0}
    .page{
        width:210mm;
        height:297mm;
        min-height:297mm;
        margin:0;
        border-radius:0;
        break-after:page;
        page-break-after:always;
    }
    .page:last-child{
        break-after:auto;
        page-break-after:auto;
    }
}
@media screen and (max-width:700px){
    body{background:#eef1f4}
    .toolbar{position:sticky;top:0;z-index:10;background:#eef1f4}
    .sheet{width:100%;padding:0 8px}
    .page{
        width:100%;
        height:auto;
        min-height:0;
        margin-bottom:10px;
        padding:18px 14px 45px;
        border-top-width:4px;
        border-radius:5px;
        overflow:visible;
    }
    .info-grid,.small-grid{grid-template-columns:1fr}
    .info,.small{
        border-right:0!important;
        border-bottom:1px solid #dce0e5!important;
    }
    .info:last-child,.small:last-child{border-bottom:0!important}
    .signature-row{gap:20px;margin-top:40px}
    .footer{position:static;margin-top:18px}
}
</style>
</head>
<body>

<div class="toolbar">
    <button type="button" class="btn back" onclick="window.location.href='refunds.php'">← Back</button>
    <button class="btn print" onclick="window.print()">Print / Save as PDF</button>
</div>

<div class="sheet">

<?php foreach (['Student Copy','Office Copy'] as $copy): ?>
<section class="page">

    <div class="receipt-header">
        <div class="brand">
            <img src="assets/edumax-logo.png" alt="Edumax">
            <div>
                <h1>EDUMAX IELTS Center</h1>
                <p>Admission & Refund Receipt</p>
            </div>
        </div>
        <div class="copy-label"><?=e($copy)?></div>
    </div>

    <div class="info-grid">
        <div class="info"><b>Refund No:</b> <?=e($refund['refund_no'])?></div>
        <div class="info"><b>Refund Date:</b> <?=e($dateTime)?></div>
        <div class="info"><b>Student ID:</b> <?=e($refund['student_code'])?></div>

        <div class="info"><b>Student:</b> <?=e($refund['full_name'])?></div>
        <div class="info"><b>Mobile:</b> <?=e($refund['mobile'])?></div>
        <div class="info"><b>Course:</b> <?=e($refund['course_name'])?></div>

        <div class="info"><b>Batch:</b> <?=e($refund['batch_name'])?></div>
        <div class="info"><b>Admission Date:</b> <?=e($admissionDate)?></div>
        <div class="info"><b>Cancellation Date:</b> <?=e($cancelDate)?></div>

        <div class="info"><b>Admission ID:</b> #<?=e($refund['admission_id'])?></div>
        <div class="info"><b>Refund Method:</b> <?=e($refund['method'])?></div>
        <?php if ($copy === 'Office Copy'): ?>
        <div class="info"><b>Status:</b>
            <span class="status <?= $refund['status']==='Valid' ? 'valid' : 'void' ?>"><?=e($refund['status'])?></span>
        </div>
        <?php endif; ?>
    </div>

    <?php if ($copy === 'Student Copy'): ?>

        <!-- Student Copy: only the information the student/guardian needs. -->
        <div class="refund-block">
            <div class="refund-head">
                <span>This Refund</span>
                <span><?=$money($currentRefund)?></span>
            </div>

            <div class="refund-row">
                <span>Final Dealing Price</span>
                <span class="amount"><?=$money($refund['final_dealing_price'])?></span>
            </div>

            <div class="refund-row">
                <span>Total Paid</span>
                <span class="amount"><?=$money($grossPaid)?></span>
            </div>

            <div class="refund-row">
                <span>Cancellation Fine / Deduction</span>
                <span class="amount"><?=number_format($finePercent,2)?>% / <?=$money($fineAmount)?></span>
            </div>

            <div class="refund-row total">
                <span>Refund Amount</span>
                <span><?=$money($currentRefund)?></span>
            </div>
        </div>

        <div class="small-grid">
            <div class="small"><b>Refund Method:</b> <?=e($refund['method'])?></div>
            <div class="small"><b>Reason:</b> <?=e($refund['reason'] ?: 'Admission cancellation')?></div>
        </div>

        <div class="policy">
            <strong>Refund & Admission Cancellation Policy</strong>
            The refund amount is calculated according to Edumax's applicable admission cancellation policy.
            The applicable deduction is based on the cancellation date and the amount actually paid.
        </div>

        <div class="thanks">
            Thank you. Please keep this refund receipt for your records.
        </div>

    <?php else: ?>

        <!-- Office Copy: detailed internal financial/audit information. -->
        <div class="refund-block">
            <div class="refund-head">
                <span>This Refund — Money Out</span>
                <span><?=$money($currentRefund)?></span>
            </div>

            <div class="refund-row">
                <span>Final Dealing Price</span>
                <span class="amount"><?=$money($refund['final_dealing_price'])?></span>
            </div>

            <div class="refund-row">
                <span>Total Paid (Gross)</span>
                <span class="amount"><?=$money($grossPaid)?></span>
            </div>

            <div class="refund-row">
                <span>Previous Valid Refund</span>
                <span class="amount"><?=$money($refundBefore)?></span>
            </div>

            <div class="refund-row">
                <span>Cancellation Fine / Deduction</span>
                <span class="amount"><?=number_format($finePercent,2)?>% / <?=$money($fineAmount)?></span>
            </div>

            <div class="refund-row">
                <span>Policy Calculated Refund</span>
                <span class="amount"><?=$money($policyRefund)?></span>
            </div>

            <div class="refund-row total">
                <span>Refund Amount — Money Out</span>
                <span><?=$money($currentRefund)?></span>
            </div>

            <div class="refund-row">
                <span>Total Refund After This Transaction</span>
                <span class="amount"><?=$money($totalRefunded)?></span>
            </div>

            <div class="refund-row">
                <span>Net Paid After Refund</span>
                <span class="amount"><?=$money($netPaid)?></span>
            </div>

            <div class="refund-row due">
                <span>Current Due</span>
                <span><?=$money($due)?></span>
            </div>
        </div>

        <div class="small-grid">
            <div class="small"><b>Reason:</b> <?=e($refund['reason'] ?: 'Admission cancellation')?></div>
            <div class="small"><b>Processed By:</b> <?=e($processedBy)?></div>
            <div class="small"><b>Payment ID:</b> <?=!empty($refund['payment_id']) ? '#'.e($refund['payment_id']) : '—'?></div>
        </div>

        <?php if (!empty($refund['note'])): ?>
            <div class="note"><b>Note:</b> <?=nl2br(e($refund['note']))?></div>
        <?php endif; ?>

        <div class="policy">
            <strong>Refund & Admission Cancellation Policy</strong>
            Admission cancellation within the first 14 days is eligible for a 100% refund of the amount paid.
            From the 15th day onward, a 10% deduction applies for each additional 7-day period
            (15–21 days: 10%, 22–28 days: 20%, 29–35 days: 30%, and so on).
            The applicable deduction is calculated automatically according to the cancellation date.
            Refunds are subject to the cancellation conditions and applicable policy.
        </div>

        <div class="office-detail">
            <b>Office Record:</b>
            This refund is recorded as a separate Money Out transaction.
            Original valid payments remain Money In. Net Paid = Valid Payments − Valid Refunds.
            Previous Valid Refund: <?=$money($refundBefore)?>.
            Total Valid Refund after this transaction: <?=$money($totalRefunded)?>.
        </div>

    <?php endif; ?>

    <div class="signature-row">
        <div class="signature">Student / Guardian Signature</div>
        <div class="signature">Authorized Signature</div>
    </div>

    <div class="footer">
        <span>
            Mobile: 01968-373223, 01968-373227 &nbsp; | &nbsp;
            QR Tower (Lift-6), Badurtala, 1st Kandirpar, Cumilla
        </span>
        <span>Refund No: <?=e($refund['refund_no'])?> &nbsp; | &nbsp; <?=e($copy)?></span>
    </div>

</section>
<?php endforeach; ?>

</div></body>
</html>

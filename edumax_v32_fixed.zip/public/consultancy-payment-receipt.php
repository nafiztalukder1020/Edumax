<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_access('consultancy_dashboard');
$_SESSION['workspace'] = 'consultancy';

$id = (int)($_GET['id'] ?? 0);
$autoPrint = (int)($_GET['print'] ?? 0) === 1;
if ($id <= 0) die('Invalid receipt.');

$q = $pdo->prepare(
    "SELECT
        p.*, 
        f.file_no,f.service_fee,f.service_type,f.file_status,f.passport_number,
        e.enquiry_no,e.full_name,e.mobile,e.whatsapp,e.email,
        e.intake,e.program,e.ielts_status,e.ielts_score,
        co.country_name,c.counselor_name,
        u.name AS receiver_name
     FROM consultancy_payments p
     INNER JOIN consultancy_files f ON f.id=p.file_id
     INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
     LEFT JOIN consultancy_countries co ON co.id=f.country_id
     LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id
     LEFT JOIN users u ON u.id=p.received_by
     WHERE p.id=? LIMIT 1"
);
$q->execute([$id]);
$r = $q->fetch();
if (!$r) die('Receipt not found.');

# Previous valid paid amount before this transaction.
$q = $pdo->prepare(
    "SELECT COALESCE(SUM(amount),0)
     FROM consultancy_payments
     WHERE file_id=? AND status='Valid' AND id<?"
);
$q->execute([(int)$r['file_id'], (int)$r['id']]);
$previousPaid = (float)$q->fetchColumn();

# Current valid total and current due.
$q = $pdo->prepare(
    "SELECT COALESCE(SUM(amount),0)
     FROM consultancy_payments
     WHERE file_id=? AND status='Valid'"
);
$q->execute([(int)$r['file_id']]);
$totalPaid = (float)$q->fetchColumn();

$serviceFee = (float)$r['service_fee'];
$currentDue = max(0, $serviceFee - $totalPaid);
$currentPayment = (float)$r['amount'];

function money_bd(float $v): string {
    return '৳'.number_format($v, 2);
}

$dateTime = date('d M Y, h:i A', strtotime($r['created_at']));
$status = (string)$r['status'];
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<title><?=e($r['payment_no'])?> - Consultancy Payment Receipt</title>
<meta name="viewport" content="width=device-width, initial-scale=1">
<style>
*{box-sizing:border-box}
html,body{margin:0;padding:0;background:#eef1f4;color:#20242a;font-family:Arial,Helvetica,sans-serif}
.toolbar{position:sticky;top:0;z-index:20;display:flex;justify-content:center;gap:10px;padding:10px;background:#eef1f4}
.btn{border:0;border-radius:8px;padding:10px 16px;font-weight:800;cursor:pointer}
.btn-back{background:#333;color:#fff}.btn-print{background:#c91f2e;color:#fff}
.sheet{width:210mm;margin:0 auto}
.page{position:relative;width:210mm;height:297mm;min-height:297mm;background:#fff;margin:0 0 12px;padding:15mm 15mm 18mm;border-top:5px solid #c91f2e;box-shadow:0 5px 20px rgba(0,0,0,.08);break-after:page;page-break-after:always}
.page:last-child{break-after:auto;page-break-after:auto}
.brand{display:flex;align-items:center;gap:12px;border-bottom:1px solid #dfe2e6;padding-bottom:10px}
.logo{width:44mm;height:auto;object-fit:contain}
.brand h1{margin:0;font-size:18px;letter-spacing:.2px}.brand p{margin:3px 0 0;font-size:9px;color:#666}
.copy-label{margin-top:9px;display:inline-block;background:#222;color:#fff;border-radius:4px;padding:5px 9px;font-size:9px;font-weight:900;letter-spacing:.8px}
.title{text-align:center;margin:12px 0 15px}.title h2{margin:0;font-size:19px}.title p{margin:4px 0 0;color:#777;font-size:9px}
.grid{display:grid;grid-template-columns:1fr 1fr;border:1px solid #cfd4d9}
.cell{padding:8px 10px;border-right:1px solid #d9dde1;border-bottom:1px solid #d9dde1;min-height:42px}
.cell:nth-child(2n){border-right:0}.cell:nth-last-child(-n+2){border-bottom:0}
.label{display:block;color:#737b84;font-size:8px;text-transform:uppercase;letter-spacing:.3px;margin-bottom:3px}.value{display:block;font-size:11px;font-weight:750}
.section{margin-top:14px;border:1px solid #cfd4d9}.section-title{padding:7px 10px;background:#f5f6f7;font-size:9px;font-weight:900;text-transform:uppercase;letter-spacing:.4px;border-bottom:1px solid #d9dde1}
.row{display:flex;justify-content:space-between;gap:20px;padding:8px 10px;border-bottom:1px solid #e0e3e6;font-size:10px}.row:last-child{border-bottom:0}.row strong{font-size:11px}
.row.current{font-size:12px;font-weight:900;background:#fafafa}.row.due{font-size:12px;font-weight:900;background:#fff5f6}
.note{margin-top:14px;border:1px solid #d5d9dd;padding:10px;font-size:9px;line-height:1.5}
.signatures{position:absolute;left:15mm;right:15mm;bottom:24mm;display:grid;grid-template-columns:1fr 1fr;gap:38mm}
.sig{border-top:1px solid #555;text-align:center;padding-top:5px;font-size:8px;color:#555}
.footer{position:absolute;left:15mm;right:15mm;bottom:10mm;text-align:center;font-size:7px;color:#7a8087}
.void-stamp{position:absolute;top:105mm;left:50%;transform:translateX(-50%) rotate(-12deg);border:4px solid #b21f2d;color:#b21f2d;padding:8px 24px;font-size:28px;font-weight:900;letter-spacing:3px;opacity:.18}
@media print{
 @page{size:A4 portrait;margin:0}
 html,body{background:#fff}
 .toolbar{display:none}
 .sheet{width:210mm}
 .page{margin:0;box-shadow:none}
}
@media screen and (max-width:700px){
 body{background:#eef1f4}.toolbar{position:sticky}.sheet{width:100%;padding:0 8px}
 .page{width:100%;height:auto;min-height:0;padding:18px 14px 55px;margin-bottom:10px;border-radius:5px}
 .grid{grid-template-columns:1fr}.cell{border-right:0!important}.cell:last-child{border-bottom:0}
 .signatures{position:static;margin-top:55px;gap:20px}.footer{position:static;margin-top:20px}
}
</style>
</head>
<body>
<div class="toolbar">
  <button class="btn btn-back" onclick="history.length>1?history.back():location.href='consultancy-receipts.php'">← Back</button>
  <button class="btn btn-print" onclick="window.print()">Print / Save PDF</button>
</div>

<div class="sheet">
<?php foreach ([1,2] as $copy): ?>
<section class="page">
  <?php if($status==='Void'): ?><div class="void-stamp">VOID</div><?php endif; ?>

  <div class="brand">
    <img class="logo" src="assets/edumax-logo.png" alt="Edumax">
    <div>
      <h1>Edumax IELTS Center & Consultancy</h1>
      <p>QR Tower (Lift-6), Badurtala, 1st Kandirpar, Cumilla</p>
    </div>
  </div>

  <div class="copy-label"><?= $copy===1 ? 'STUDENT COPY' : 'OFFICE COPY' ?></div>

  <div class="title">
    <h2>CONSULTANCY PAYMENT RECEIPT</h2>
    <p>Official proof of consultancy payment</p>
  </div>

  <div class="grid">
    <div class="cell"><span class="label">Receipt No.</span><span class="value"><?=e($r['payment_no'])?></span></div>
    <div class="cell"><span class="label">Payment Date</span><span class="value"><?=e($dateTime)?></span></div>
    <div class="cell"><span class="label">File No.</span><span class="value"><?=e($r['file_no'])?></span></div>
    <div class="cell"><span class="label">Enquiry No.</span><span class="value"><?=e($r['enquiry_no'])?></span></div>
    <div class="cell"><span class="label">Student Name</span><span class="value"><?=e($r['full_name'])?></span></div>
    <div class="cell"><span class="label">Mobile</span><span class="value"><?=e($r['mobile'])?></span></div>
    <div class="cell"><span class="label">Country</span><span class="value"><?=e($r['country_name']??'-')?></span></div>
    <div class="cell"><span class="label">Service Type</span><span class="value"><?=e($r['service_type'])?></span></div>
    <?php if($copy===2): ?>
      <div class="cell"><span class="label">Counselor</span><span class="value"><?=e($r['counselor_name']??'Unassigned')?></span></div>
      <div class="cell"><span class="label">Passport No.</span><span class="value"><?=e($r['passport_number']??'-')?></span></div>
    <?php endif; ?>
  </div>

  <div class="section">
    <div class="section-title">Payment Summary</div>
    <div class="row"><span>Service Fee</span><strong><?=money_bd($serviceFee)?></strong></div>
    <div class="row"><span>Previous Paid</span><strong><?=money_bd($previousPaid)?></strong></div>
    <div class="row current"><span>Current Payment</span><strong><?=money_bd($currentPayment)?></strong></div>
    <div class="row"><span>Total Paid</span><strong><?=money_bd($totalPaid)?></strong></div>
    <div class="row due"><span>Current Due</span><strong><?=money_bd($currentDue)?></strong></div>
  </div>

  <div class="section">
    <div class="section-title">Payment Details</div>
    <div class="row"><span>Payment Method</span><strong><?=e($r['method'])?></strong></div>
    <?php if(!empty($r['reference_no'])): ?><div class="row"><span>Reference No.</span><strong><?=e($r['reference_no'])?></strong></div><?php endif; ?>
    <div class="row"><span>Received By</span><strong><?=e($r['receiver_name']??'-')?></strong></div>
    <div class="row"><span>Receipt Status</span><strong><?=e($status)?></strong></div>
  </div>

  <?php if($copy===2 && !empty($r['note'])): ?>
    <div class="note"><strong>Payment Note:</strong><br><?=nl2br(e($r['note']))?></div>
  <?php elseif($copy===1): ?>
    <div class="note">Thank you for your payment. Please keep this receipt for your records.</div>
  <?php endif; ?>

  <div class="signatures">
    <div class="sig">Student / Client Signature</div>
    <div class="sig">Authorized Signature</div>
  </div>

  <div class="footer">Edumax IELTS Center & Consultancy • Consultancy Payment Receipt • <?=e($r['payment_no'])?></div>
</section>
<?php endforeach; ?>
</div>

<?php if($autoPrint): ?>
<script>
window.addEventListener('load', function(){ setTimeout(function(){ window.print(); }, 250); });
</script>
<?php endif; ?>
</body>
</html>

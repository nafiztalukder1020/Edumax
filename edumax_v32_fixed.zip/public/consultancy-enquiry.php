<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

/*
 * The same page is used in two modes:
 * 1) Public/QR mode: no login required, no admin sidebar.
 * 2) Logged-in admin mode: load the normal Edumax header/sidebar.
 */
$isAdminView = !empty($_SESSION['user_id']);

// Public intake form: no admin login required.
$error = '';
$success = '';
$enquiryNo = '';
$countries = [];

function next_consultancy_enquiry_no(): string {
    global $pdo;
    $year = (int)date('Y');
    $ins = $pdo->prepare('INSERT IGNORE INTO consultancy_enquiry_sequences (enquiry_year,next_number) VALUES (?,1)');
    $ins->execute([$year]);
    $q = $pdo->prepare('SELECT next_number FROM consultancy_enquiry_sequences WHERE enquiry_year=? FOR UPDATE');
    $q->execute([$year]);
    $next = $q->fetchColumn();
    if ($next === false) throw new RuntimeException('Unable to reserve an enquiry number.');
    $u = $pdo->prepare('UPDATE consultancy_enquiry_sequences SET next_number=? WHERE enquiry_year=?');
    $u->execute([(int)$next + 1, $year]);
    return 'EDU-CQ-' . $year . '-' . str_pad((string)$next, 5, '0', STR_PAD_LEFT);
}

function normalize_mobile(string $value): string {
    return preg_replace('/[^0-9+]/', '', trim($value)) ?? '';
}

try {
    $stmt = $pdo->query("SELECT id,country_name FROM consultancy_countries WHERE status='Active' ORDER BY country_name");
    $countries = $stmt->fetchAll();

    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        require_valid_csrf();
        if (trim((string)($_POST['website'] ?? '')) !== '') throw new RuntimeException('Invalid submission.');

        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $mobile = normalize_mobile((string)($_POST['mobile'] ?? ''));
        $whatsapp = normalize_mobile((string)($_POST['whatsapp'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $countryId = (int)($_POST['country_id'] ?? 0);
        $education = trim((string)($_POST['education_level'] ?? ''));
        $institution = trim((string)($_POST['institution'] ?? ''));
        $passingYear = trim((string)($_POST['passing_year'] ?? ''));
        $resultValue = trim((string)($_POST['result_value'] ?? ''));
        $intake = trim((string)($_POST['intake'] ?? ''));
        $program = trim((string)($_POST['program'] ?? ''));
        $ieltsStatus = trim((string)($_POST['ielts_status'] ?? ''));
        $ieltsScore = trim((string)($_POST['ielts_score'] ?? ''));
        $leadSource = trim((string)($_POST['lead_source'] ?? 'QR / Front Desk'));
        $message = trim((string)($_POST['student_message'] ?? ''));
        $dob = trim((string)($_POST['dob'] ?? ''));
        $gender = trim((string)($_POST['gender'] ?? ''));

        if ($fullName === '' || $mobile === '' || $countryId <= 0) throw new RuntimeException('Name, mobile and preferred country are required.');
        if (!preg_match('/^[0-9+]{7,20}$/', $mobile)) throw new RuntimeException('Please enter a valid mobile number.');
        if ($email !== '' && !filter_var($email, FILTER_VALIDATE_EMAIL)) throw new RuntimeException('Please enter a valid email address.');
        if ($dob !== '') { $d=DateTime::createFromFormat('Y-m-d',$dob); if (!$d || $d->format('Y-m-d') !== $dob) throw new RuntimeException('Please enter a valid date of birth.'); }

        $pdo->beginTransaction();
        try {
            $countryStmt=$pdo->prepare("SELECT id,country_name FROM consultancy_countries WHERE id=? AND status='Active' FOR UPDATE");
            $countryStmt->execute([$countryId]);
            $country=$countryStmt->fetch();
            if (!$country) throw new RuntimeException('Selected country is unavailable. Please choose another country.');

            // Automatic routing: among active counselors assigned to the country,
            // choose the counselor with the fewest open enquiries. Ties are resolved by counselor id.
            $route=$pdo->prepare("SELECT c.id,c.counselor_name,
                (SELECT COUNT(*) FROM consultancy_enquiries e WHERE e.counselor_id=c.id AND e.status IN ('New','Contacted','Counselling Scheduled','In Progress')) AS open_count
                FROM consultancy_counselor_country_assignments a
                INNER JOIN consultancy_counselors c ON c.id=a.counselor_id
                WHERE a.country_id=? AND a.status='Active' AND c.status='Active'
                ORDER BY open_count ASC,c.id ASC FOR UPDATE");
            $route->execute([$countryId]);
            $counselor=$route->fetch();

            $enquiryNo=next_consultancy_enquiry_no();
            $status='New'; // New = Waiting for Counselor until the assigned counselor accepts.
            $ins=$pdo->prepare("INSERT INTO consultancy_enquiries
                (enquiry_no,full_name,mobile,whatsapp,email,dob,gender,education_level,institution,passing_year,result_value,country_id,intake,program,ielts_status,ielts_score,lead_source,student_message,counselor_id,status)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $ins->execute([$enquiryNo,$fullName,$mobile,$whatsapp ?: null,$email ?: null,$dob ?: null,$gender ?: null,$education ?: null,$institution ?: null,$passingYear ?: null,$resultValue ?: null,$countryId,$intake ?: null,$program ?: null,$ieltsStatus ?: null,$ieltsScore ?: null,$leadSource ?: null,$message ?: null,$counselor ? (int)$counselor['id'] : null,$status]);
            $enquiryId=(int)$pdo->lastInsertId();

            if ($counselor) {
                $title='New Consultancy Enquiry: ' . $fullName;
                $notificationMessage=$country['country_name'].' lead '.$enquiryNo.' has been assigned to you. Review the profile before counselling.';
                $n=$pdo->prepare("INSERT INTO consultancy_notifications (counselor_id,enquiry_id,notification_type,title,message) VALUES (?,?,?,?,?)");
                $n->execute([(int)$counselor['id'],$enquiryId,'New Enquiry',$title,$notificationMessage]);
            }
            $pdo->commit();
            $success=$counselor
                ? 'Your enquiry has been submitted successfully. A counsellor has been assigned and will review your information before counselling.'
                : 'Your enquiry has been submitted successfully. Our consultancy team will assign a counsellor shortly.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            throw $e;
        }
    }
} catch (Throwable $e) {
    $error=$e instanceof RuntimeException ? $e->getMessage() : 'Unable to submit your enquiry right now. Please try again.';
}
?>
<?php if ($isAdminView): ?>

<?php
/*
 * Logged-in staff/admin view.
 * _header.php already opens the document, topbar, sidebar and <main class="content">.
 */
require_once __DIR__ . '/_header.php';
?>

<style>
body{background:#f6f7f8}.cq-wrap{max-width:920px;margin:35px auto;padding:0 18px}.cq-card{background:#fff;border:1px solid #e6e8ec;border-radius:18px;box-shadow:0 8px 28px rgba(25,30,38,.06);overflow:hidden}.cq-head{padding:28px 30px;background:linear-gradient(135deg,#fff 0%,#faf3f4 100%);border-bottom:1px solid #eceef1}.cq-head h1{margin:0 0 6px;font-size:27px}.cq-head p{margin:0;color:#747a83}.cq-form{padding:28px 30px}.cq-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.cq-field{display:flex;flex-direction:column;gap:6px}.cq-field.full{grid-column:1/-1}.cq-field label{font-size:12px;font-weight:750;color:#444a52}.cq-field input,.cq-field select,.cq-field textarea{width:100%;box-sizing:border-box;border:1px solid #dfe2e6;border-radius:10px;padding:11px 12px;font:inherit;background:#fff}.cq-field textarea{min-height:100px;resize:vertical}.cq-actions{margin-top:22px;display:flex;justify-content:flex-end}.cq-btn{border:0;border-radius:10px;background:#c91f2e;color:#fff;padding:12px 20px;font-weight:800;cursor:pointer}.cq-alert{margin:0 0 18px;padding:12px 14px;border-radius:10px;font-size:13px}.cq-error{background:#fff1f2;color:#a71928;border:1px solid #f3c6cb}.cq-success{background:#eefaf2;color:#176b39;border:1px solid #c8e8d3}.hp{position:absolute;left:-9999px;opacity:0}.cq-note{margin-top:15px;color:#858b93;font-size:11px;line-height:1.6}@media(max-width:700px){.cq-grid{grid-template-columns:1fr}.cq-head,.cq-form{padding:22px 18px}}
</style>
<div class="cq-wrap"><div class="cq-card">
<div class="cq-head"><h1>Edumax Consultancy</h1><p>Start your study abroad enquiry</p></div>
<div class="cq-form">
<?php if ($error): ?><div class="cq-alert cq-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cq-alert cq-success"><strong>Thank you!</strong><br><?= e($success) ?><br><strong>Enquiry No: <?= e($enquiryNo) ?></strong></div><?php endif; ?>
<?php if (!$success): ?>
<form method="post" autocomplete="on">
<?= csrf_input() ?><input class="hp" type="text" name="website" tabindex="-1" autocomplete="off">
<div class="cq-grid">
<div class="cq-field"><label>Full Name *</label><input name="full_name" required maxlength="150"></div>
<div class="cq-field"><label>Mobile Number *</label><input name="mobile" required maxlength="30" inputmode="tel"></div>
<div class="cq-field"><label>WhatsApp Number</label><input name="whatsapp" maxlength="30" inputmode="tel"></div>
<div class="cq-field"><label>Email</label><input type="email" name="email" maxlength="150"></div>
<div class="cq-field"><label>Date of Birth</label><input type="date" name="dob"></div>
<div class="cq-field"><label>Gender</label><select name="gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></div>
<div class="cq-field"><label>Highest Education</label><input name="education_level" maxlength="100" placeholder="HSC / Bachelor / Masters"></div>
<div class="cq-field"><label>Institution</label><input name="institution" maxlength="180"></div>
<div class="cq-field"><label>Passing Year</label><input name="passing_year" maxlength="20" inputmode="numeric"></div>
<div class="cq-field"><label>Result / GPA</label><input name="result_value" maxlength="50"></div>
<div class="cq-field"><label>Preferred Country *</label><select name="country_id" required><option value="">Select country</option><?php foreach($countries as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['country_name']) ?></option><?php endforeach; ?></select></div>
<div class="cq-field"><label>Preferred Intake</label><input name="intake" maxlength="80" placeholder="September 2027"></div>
<div class="cq-field"><label>Interested Program / Degree</label><input name="program" maxlength="180"></div>
<div class="cq-field"><label>IELTS Status</label><select name="ielts_status"><option value="">Select</option><option>Already have IELTS</option><option>Preparing for IELTS</option><option>Don't have IELTS</option></select></div>
<div class="cq-field"><label>IELTS Score</label><input name="ielts_score" maxlength="30" placeholder="Overall 6.0"></div>
<div class="cq-field"><label>Lead Source</label><select name="lead_source"><option>QR / Front Desk</option><option>Facebook</option><option>Website</option><option>Referral</option><option>Walk-in</option><option>Other</option></select></div>
<div class="cq-field full"><label>Anything you want to tell us?</label><textarea name="student_message" maxlength="2000" placeholder="Your study abroad interest, questions or preferred universities..."></textarea></div>
</div><div class="cq-actions"><button class="cq-btn" type="submit">Submit Consultancy Enquiry</button></div>
<p class="cq-note">Your preferred country will be used to automatically route this enquiry to an available assigned counsellor. The counsellor will review your information and confirm when ready for counselling.</p>
</form>
<?php endif; ?>
</div></div></div>


</main>
</body>
</html>

<?php else: ?>

<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>Edumax Consultancy Enquiry</title>
<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="assets/edumax-modern.css">
<style>
body{background:#f6f7f8}.cq-wrap{max-width:920px;margin:35px auto;padding:0 18px}.cq-card{background:#fff;border:1px solid #e6e8ec;border-radius:18px;box-shadow:0 8px 28px rgba(25,30,38,.06);overflow:hidden}.cq-head{padding:28px 30px;background:linear-gradient(135deg,#fff 0%,#faf3f4 100%);border-bottom:1px solid #eceef1}.cq-head h1{margin:0 0 6px;font-size:27px}.cq-head p{margin:0;color:#747a83}.cq-form{padding:28px 30px}.cq-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.cq-field{display:flex;flex-direction:column;gap:6px}.cq-field.full{grid-column:1/-1}.cq-field label{font-size:12px;font-weight:750;color:#444a52}.cq-field input,.cq-field select,.cq-field textarea{width:100%;box-sizing:border-box;border:1px solid #dfe2e6;border-radius:10px;padding:11px 12px;font:inherit;background:#fff}.cq-field textarea{min-height:100px;resize:vertical}.cq-actions{margin-top:22px;display:flex;justify-content:flex-end}.cq-btn{border:0;border-radius:10px;background:#c91f2e;color:#fff;padding:12px 20px;font-weight:800;cursor:pointer}.cq-alert{margin:0 0 18px;padding:12px 14px;border-radius:10px;font-size:13px}.cq-error{background:#fff1f2;color:#a71928;border:1px solid #f3c6cb}.cq-success{background:#eefaf2;color:#176b39;border:1px solid #c8e8d3}.hp{position:absolute;left:-9999px;opacity:0}.cq-note{margin-top:15px;color:#858b93;font-size:11px;line-height:1.6}@media(max-width:700px){.cq-grid{grid-template-columns:1fr}.cq-head,.cq-form{padding:22px 18px}}
</style>
</head>
<body>
<div class="cq-wrap"><div class="cq-card">
<div class="cq-head"><h1>Edumax Consultancy</h1><p>Start your study abroad enquiry</p></div>
<div class="cq-form">
<?php if ($error): ?><div class="cq-alert cq-error"><?= e($error) ?></div><?php endif; ?>
<?php if ($success): ?><div class="cq-alert cq-success"><strong>Thank you!</strong><br><?= e($success) ?><br><strong>Enquiry No: <?= e($enquiryNo) ?></strong></div><?php endif; ?>
<?php if (!$success): ?>
<form method="post" autocomplete="on">
<?= csrf_input() ?><input class="hp" type="text" name="website" tabindex="-1" autocomplete="off">
<div class="cq-grid">
<div class="cq-field"><label>Full Name *</label><input name="full_name" required maxlength="150"></div>
<div class="cq-field"><label>Mobile Number *</label><input name="mobile" required maxlength="30" inputmode="tel"></div>
<div class="cq-field"><label>WhatsApp Number</label><input name="whatsapp" maxlength="30" inputmode="tel"></div>
<div class="cq-field"><label>Email</label><input type="email" name="email" maxlength="150"></div>
<div class="cq-field"><label>Date of Birth</label><input type="date" name="dob"></div>
<div class="cq-field"><label>Gender</label><select name="gender"><option value="">Select</option><option>Male</option><option>Female</option><option>Other</option></select></div>
<div class="cq-field"><label>Highest Education</label><input name="education_level" maxlength="100" placeholder="HSC / Bachelor / Masters"></div>
<div class="cq-field"><label>Institution</label><input name="institution" maxlength="180"></div>
<div class="cq-field"><label>Passing Year</label><input name="passing_year" maxlength="20" inputmode="numeric"></div>
<div class="cq-field"><label>Result / GPA</label><input name="result_value" maxlength="50"></div>
<div class="cq-field"><label>Preferred Country *</label><select name="country_id" required><option value="">Select country</option><?php foreach($countries as $c): ?><option value="<?= (int)$c['id'] ?>"><?= e($c['country_name']) ?></option><?php endforeach; ?></select></div>
<div class="cq-field"><label>Preferred Intake</label><input name="intake" maxlength="80" placeholder="September 2027"></div>
<div class="cq-field"><label>Interested Program / Degree</label><input name="program" maxlength="180"></div>
<div class="cq-field"><label>IELTS Status</label><select name="ielts_status"><option value="">Select</option><option>Already have IELTS</option><option>Preparing for IELTS</option><option>Don't have IELTS</option></select></div>
<div class="cq-field"><label>IELTS Score</label><input name="ielts_score" maxlength="30" placeholder="Overall 6.0"></div>
<div class="cq-field"><label>Lead Source</label><select name="lead_source"><option>QR / Front Desk</option><option>Facebook</option><option>Website</option><option>Referral</option><option>Walk-in</option><option>Other</option></select></div>
<div class="cq-field full"><label>Anything you want to tell us?</label><textarea name="student_message" maxlength="2000" placeholder="Your study abroad interest, questions or preferred universities..."></textarea></div>
</div><div class="cq-actions"><button class="cq-btn" type="submit">Submit Consultancy Enquiry</button></div>
<p class="cq-note">Your preferred country will be used to automatically route this enquiry to an available assigned counsellor. The counsellor will review your information and confirm when ready for counselling.</p>
</form>
<?php endif; ?>
</div></div></div>
</body></html>


<?php endif; ?>

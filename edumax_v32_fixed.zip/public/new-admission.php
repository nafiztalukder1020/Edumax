<?php

require_once __DIR__ . '/../config/app.php';

/*
 * Same admission form, two safe modes:
 *   /new-admission.php              = Admin mode (existing workflow)
 *   /new-admission.php?mode=public  = Public/QR mode
 */
$isPublicMode = (($_GET['mode'] ?? '') === 'public') || (($_POST['mode'] ?? '') === 'public');

require_valid_csrf();
if (!$isPublicMode) {
    require_access('new_admission');
}

$msg = '';
$error = '';

if ($isPublicMode) {
    $msg = '';
}

/**
 * Validate a Bangladesh mobile number.
 * Required format: 01XXXXXXXXX
 */
function validate_bd_mobile(string $mobile, bool $required = true): ?string
{
    $mobile = trim($mobile);

    if ($mobile === '') {
        return $required ? 'Mobile Number is required.' : null;
    }

    if (!preg_match('/^01[3-9][0-9]{8}$/', $mobile)) {
        return 'Please enter a valid Bangladesh mobile number (11 digits, e.g. 01712345678).';
    }

    return null;
}

function validate_email_address(string $email): ?string
{
    $email = trim($email);

    if ($email === '') {
        return null;
    }

    if (strlen($email) > 160 || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        return 'Please enter a valid email address.';
    }

    return null;
}



function next_student_id(): string
{
    global $pdo;

    $year = date('Y');
    $prefix = 'EDU-' . $year . '-';

    // This function is called after beginTransaction(). Lock the latest
    // matching student row so two simultaneous admissions cannot receive
    // the same serial number.
    $stmt = $pdo->prepare("
        SELECT student_id
        FROM students
        WHERE student_id LIKE ?
        ORDER BY id DESC
        LIMIT 1
        FOR UPDATE
    ");
    $stmt->execute([$prefix . '%']);
    $last = (string)($stmt->fetchColumn() ?: '');

    $next = 1;
    if ($last !== '' && preg_match('/^EDU-\d{4}-(\d+)$/', $last, $m)) {
        $next = ((int)$m[1]) + 1;
    }

    // Extra collision protection in case old/imported records are not
    // perfectly ordered by id.
    do {
        $candidate = $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
        $check = $pdo->prepare("SELECT COUNT(*) FROM students WHERE student_id = ?");
        $check->execute([$candidate]);
        $exists = (int)$check->fetchColumn() > 0;
        if ($exists) $next++;
    } while ($exists);

    return $candidate;
}

function normalize_public_mobile(string $mobile): string
{
    $mobile = preg_replace('/\D+/', '', trim($mobile)) ?? '';
    if (str_starts_with($mobile, '880')) {
        $mobile = '0' . substr($mobile, 3);
    }
    return $mobile;
}

function normalize_public_email(string $email): ?string
{
    $email = strtolower(trim($email));
    return $email === '' ? null : $email;
}

// Mock Test daily capacity: maximum 14 students per date.
function get_mock_date_bookings(PDO $pdo): array
{
    $counts = [];
    try {
        // Admissions are the primary reservation source.
        $q = $pdo->query("SELECT mock_dates FROM admissions WHERE mock_dates IS NOT NULL AND mock_dates <> '' AND status <> 'Cancelled'");
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $json) {
            $dates = json_decode((string)$json, true);
            if (is_array($dates)) foreach ($dates as $date) {
                $date = trim((string)$date);
                if ($date !== '') $counts[$date] = ($counts[$date] ?? 0) + 1;
            }
        }

        // Pending applications that do not yet have an admission also reserve a seat.
        $q = $pdo->query("SELECT a.mock_dates FROM applications a WHERE a.mock_dates IS NOT NULL AND a.mock_dates <> '' AND NOT EXISTS (SELECT 1 FROM admissions ad WHERE ad.student_id = a.student_id)");
        foreach ($q->fetchAll(PDO::FETCH_COLUMN) as $json) {
            $dates = json_decode((string)$json, true);
            if (is_array($dates)) foreach ($dates as $date) {
                $date = trim((string)$date);
                if ($date !== '') $counts[$date] = ($counts[$date] ?? 0) + 1;
            }
        }
    } catch (Throwable $e) {
        // Older databases may not have mock_dates yet; return an empty map.
    }
    return $counts;
}

$mockDateBookings = get_mock_date_bookings($pdo);

// Mock Test date storage compatibility for older installations.
try {
    $col = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='applications' AND COLUMN_NAME='mock_dates'")->fetchColumn();
    if (!(int)$col) $pdo->exec("ALTER TABLE applications ADD COLUMN mock_dates TEXT NULL AFTER mock_day");
} catch (Throwable $e) {}

$validCourses = [];
$mockPackages = [];
try {
    $qCourses = $pdo->query("SELECT id,name,course_type,regular_fee,default_discount_percent,mock_test_count,mock_test_modules,validity_days FROM courses WHERE status='Active' ORDER BY name");
    $courseRows = $qCourses->fetchAll(PDO::FETCH_ASSOC);

    foreach ($courseRows as $cr) {
        $name = trim((string)$cr['name']);
        if ($name === '') continue;

        if (strcasecmp((string)($cr['course_type'] ?? 'Regular'), 'Mock Test') === 0) {
            $mockPackages[] = [
                'name' => $name,
                'fee' => (float)$cr['regular_fee'],
                'discount' => (float)$cr['default_discount_percent'],
                'count' => (int)($cr['mock_test_count'] ?? 0),
                'modules' => (string)($cr['mock_test_modules'] ?? ''),
                'validity' => (int)($cr['validity_days'] ?? 0)
            ];
        } else {
            $validCourses[] = $name;
        }
    }

    // Keep the service course visible even if an older installation has not
    // yet been migrated to course_type.
    $hasMockService = false;
    foreach ($courseRows as $cr) {
        if (strcasecmp(trim((string)$cr['name']), 'Mock Test') === 0) {
            $hasMockService = true;
            break;
        }
    }
    if ($hasMockService || $mockPackages) $validCourses[] = 'Mock Test';

    $validCourses = array_values(array_unique($validCourses));
} catch (Throwable $e) {
    $validCourses = ['IELTS', 'Spoken English', 'Mock Test'];
    $mockPackages = [
        ['name'=>'1 Mock','fee'=>500,'discount'=>0,'count'=>1,'modules'=>'','validity'=>0],
        ['name'=>'2 Mocks','fee'=>900,'discount'=>0,'count'=>2,'modules'=>'','validity'=>0],
        ['name'=>'3 Mocks','fee'=>1200,'discount'=>0,'count'=>3,'modules'=>'','validity'=>0]
    ];
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $full_name = trim($_POST['full_name'] ?? '');
    $mobile = trim($_POST['mobile'] ?? '');
    $guardianMobile = trim($_POST['guardian_mobile'] ?? '');
    $email = trim($_POST['email'] ?? '');
    $course_interest = trim($_POST['course_interest'] ?? '');
    $mockPackage = trim($_POST['mock_package'] ?? '');
    $mockDay = trim($_POST['mock_day'] ?? '');
    $mockDates = array_values(array_filter(array_map('trim', (array)($_POST['mock_dates'] ?? []))));

    $mobileError = validate_bd_mobile($mobile, true);
    $guardianMobileError = validate_bd_mobile($guardianMobile, false);
    $emailError = validate_email_address($email);

    /*
     * Public/QR mode: mobile/email are permanently locked after the first
     * successful submission. The lock lives in public_submissions, so
     * deleting the application later does not release the identity.
     */
    if ($isPublicMode && $error === '') {
        $publicMobile = normalize_public_mobile($mobile);
        $publicEmail = normalize_public_email($email);

        $dup = $pdo->prepare("
            SELECT id
            FROM public_submissions
            WHERE mobile_normalized = ?
               OR (? IS NOT NULL AND email_normalized = ?)
            LIMIT 1
        ");
        $dup->execute([$publicMobile, $publicEmail, $publicEmail]);

        if ($dup->fetch()) {
            $error = 'Your information has already been submitted. Our team will contact you shortly.';
        }

        /* Basic honeypot anti-bot protection. */
        if (trim((string)($_POST['website'] ?? '')) !== '') {
            $error = 'Unable to process this submission.';
        }
    }

    if (
        $full_name === '' ||
        !in_array($course_interest, $validCourses, true)
    ) {

        $error = 'Student Name, Mobile Number and Course are required.';

    } elseif ($mobileError !== null) {

        $error = $mobileError;

    } elseif ($guardianMobileError !== null) {

        $error = 'Guardian Mobile: ' . $guardianMobileError;

    } elseif ($emailError !== null) {

        $error = $emailError;

    } elseif ($course_interest === 'Mock Test' && $mockPackage === '') {

        $error = 'Please select a Mock Test package.';

    } elseif ($course_interest === 'Mock Test') {

        $packageCount = 0;
        foreach ($mockPackages as $pkg) {
            if ((string)$pkg['name'] === $mockPackage) {
                $packageCount = (int)$pkg['count'];
                break;
            }
        }

        // Backward compatibility for installations that still have the
        // original three package names but have not migrated package metadata.
        if ($packageCount === 0) {
            $packageCount = ['1 Mock'=>1, '2 Mocks'=>2, '3 Mocks'=>3][$mockPackage] ?? 0;
        }

        if ($packageCount < 1) {
            $error = 'Selected Mock Test package is not configured correctly.';
        } else {
        if (count($mockDates) !== $packageCount) {
            $error = 'Please select exactly ' . $packageCount . ' Mock Test date' . ($packageCount > 1 ? 's.' : '.');
        } else {
            $seen = [];
            foreach ($mockDates as $md) {
                $dt = DateTime::createFromFormat('Y-m-d', $md);
                if (!$dt || $dt->format('Y-m-d') !== $md) {
                    $error = 'Please select valid Mock Test date(s).';
                    break;
                }
                if ($md < date('Y-m-d')) {
                    $error = 'Mock Test date cannot be in the past.';
                    break;
                }
                $dayName = $dt->format('l');
                if (!in_array($dayName, ['Monday', 'Wednesday'], true)) {
                    $error = 'Mock Test can only be scheduled on Monday or Wednesday.';
                    break;
                }
                if (isset($seen[$md])) {
                    $error = 'Each Mock Test date must be different.';
                    break;
                }
                $seen[$md] = true;
                if (($mockDateBookings[$md] ?? 0) >= 14) {
                    $error = 'This Mock Test date is already full (14 students). Please select another date.';
                    break;
                }
            }
            if ($error === '') {
                $mockDay = (new DateTime($mockDates[0]))->format('l');
            }
        }
        }

    }

    if ($error !== '') {
        // Keep the existing flow below unchanged; validation errors skip the DB transaction.
    } else {

        try {

            $pdo->beginTransaction();


            // ==========================================
            // GENERATE STUDENT ID
            // ==========================================

            // Uses the existing Student ID format and database structure,
            // but serializes concurrent allocations to prevent duplicates.
            $studentId = next_student_id();


            // ==========================================
            // SAVE STUDENT
            // ==========================================

            $studentStmt = $pdo->prepare("
                INSERT INTO students (
                    student_id,
                    full_name,
                    mobile,
                    guardian_name,
                    guardian_mobile,
                    date_of_birth,
                    gender,
                    email,
                    blood_group,
                    present_address,
                    passport_number
                )
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, NULL)
            ");

            $studentStmt->execute([

                $studentId,

                $full_name,

                $mobile,

                trim($_POST['guardian_name'] ?? '') ?: null,

                $guardianMobile ?: null,

                $_POST['date_of_birth'] ?? null ?: null,

                $_POST['gender'] ?? null ?: null,

                $email ?: null,

                // Blood Group is OPTIONAL
                trim($_POST['blood_group'] ?? '') ?: null,

                trim($_POST['present_address'] ?? '') ?: null

            ]);

            $studentPk = (int)$pdo->lastInsertId();


            // ==========================================
            // ACADEMIC QUALIFICATIONS
            // ==========================================

            $degrees = [

                'Masters' => $_POST['masters'] ?? [],

                'Honors' => $_POST['honors'] ?? [],

                'Diploma' => $_POST['diploma'] ?? [],

                'HSC/Equivalent' => $_POST['hsc'] ?? [],

                'SSC/Equivalent' => $_POST['ssc'] ?? []

            ];


            $academicStmt = $pdo->prepare("
                INSERT INTO academic_records
                    (
                        student_id,
                        degree,
                        subject,
                        result,
                        passing_year,
                        institution
                    )
                VALUES (?, ?, ?, ?, ?, ?)
            ");


            foreach ($degrees as $degree => $data) {

                $subject =
                    trim($data['subject'] ?? '');

                $result =
                    trim($data['result'] ?? '');

                $passingYear =
                    trim($data['passing_year'] ?? '');

                $institution =
                    trim($data['institution'] ?? '');


                if (
                    $subject !== '' ||
                    $result !== '' ||
                    $passingYear !== '' ||
                    $institution !== ''
                ) {

                    $academicStmt->execute([

                        $studentPk,

                        $degree,

                        $subject ?: null,

                        $result ?: null,

                        $passingYear ?: null,

                        $institution ?: null

                    ]);

                }

            }


            // ==========================================
            // IELTS OVERALL TARGET
            // ==========================================

            $ieltsOverall = null;

            if (
                $course_interest === 'IELTS' &&
                ($_POST['ielts_overall'] ?? '') !== ''
            ) {

                $ieltsOverall =
                    (float)$_POST['ielts_overall'];

            }


            // ==========================================
            // SAVE APPLICATION
            // ==========================================

            $applicationStmt = $pdo->prepare("
                INSERT INTO applications (
                    student_id,
                    status,
                    course_interest,
                    lead_source,
                    mock_package,
                    mock_day,
                    mock_dates,
                    ielts_reading,
                    ielts_writing,
                    ielts_listening,
                    ielts_speaking,
                    ielts_overall
                )
                VALUES (
                    ?,
                    'Pending',
                    ?,
                    ?,
                    ?,
                    ?,
                    ?,
                    NULL,
                    NULL,
                    NULL,
                    NULL,
                    ?
                )
            ");


            $applicationStmt->execute([

                $studentPk,

                $course_interest,

                trim($_POST['lead_source'] ?? '') ?: null,

                $course_interest === 'Mock Test' ? $mockPackage : null,

                $course_interest === 'Mock Test' ? $mockDay : null,

                $course_interest === 'Mock Test' ? json_encode($mockDates, JSON_UNESCAPED_SLASHES) : null,

                $ieltsOverall

            ]);

            /*
             * Public mode creates the permanent identity lock only after the
             * student + application have been created successfully.
             */
            if ($isPublicMode) {
                $publicMobile = normalize_public_mobile($mobile);
                $publicEmail = normalize_public_email($email);

                $publicStmt = $pdo->prepare("
                    INSERT INTO public_submissions
                    (mobile, mobile_normalized, email, email_normalized, name,
                     application_id, status, source, ip_address)
                    VALUES (?,?,?,?,?,?, 'Submitted', ?, ?)
                ");
                $publicStmt->execute([
                    $mobile,
                    $publicMobile,
                    $email !== '' ? $email : null,
                    $publicEmail,
                    $full_name,
                    (int)$pdo->lastInsertId(),
                    'QR / Public Admission Form',
                    substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45)
                ]);
            }


            // ==========================================
            // AUDIT LOG
            // ==========================================

            $auditStmt = $pdo->prepare("
                INSERT INTO audit_logs (
                    user_id,
                    action,
                    student_id,
                    details
                )
                VALUES (?, ?, ?, ?)
            ");


            if (!$isPublicMode) {
                $auditStmt->execute([

                    $_SESSION['user_id'],

                    'New Admission Application Created',

                    $studentPk,

                    'Pending application. Course: ' .
                    $course_interest .
                    '. Student ID: ' .
                    $studentId

                ]);
            }


            $pdo->commit();


            $msg =
                'Application submitted successfully. Student ID: ' .
                $studentId;


        } catch (Throwable $e) {

            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $dbMessage = $e->getMessage();
            if ($isPublicMode && (
                stripos($dbMessage, 'Duplicate entry') !== false ||
                stripos($dbMessage, 'uq_public_mobile') !== false ||
                stripos($dbMessage, 'uq_public_email') !== false
            )) {
                $error = 'Your information has already been submitted. Our team will contact you shortly.';
            } else {
                // Admin-only diagnostic: keep public submissions generic, but show the
                // exact database/PHP error to an authenticated admin so the real
                // schema/query problem can be fixed without changing the form UI.
                error_log('New Admission save failed: ' . $dbMessage);
                $error = 'Could not save application. Database error: ' . $dbMessage;
            }
        }

    }

}


if (!$isPublicMode) {
    require '_header.php';
} else {
    ?>
    <!doctype html>
    <html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Edumax Admission Registration</title>
        <link rel="stylesheet" href="assets/style.css">
        <link rel="stylesheet" href="assets/edumax-modern.css">
        <link rel="stylesheet" href="assets/responsive.css">
        <style>
            body.public-admission-page{margin:0;background:#f5f5f6;}
            .public-admission-shell{max-width:980px;margin:0 auto;padding:28px 18px 50px;}
            .public-brand{text-align:center;margin-bottom:22px;}
            .public-brand h1{margin:0;font-size:25px;color:#222;}
            .public-brand p{margin:6px 0 0;color:#666;font-size:13px;}
            @media(max-width:600px){
                .public-admission-shell{padding:18px 10px 35px;}
                .public-brand h1{font-size:21px;}
            }
        </style>
    </head>
    <body class="public-admission-page">
    <main class="public-admission-shell">
        <div class="public-brand">
            <h1>Edumax IELTS Center & Consultancy</h1>
            <p>Admission Registration Form</p>
        </div>
    <?php
}

?>


<div class="section-title">

    <div>

        <h1>
            <?= $isPublicMode ? 'Edumax Admission Registration' : 'New Admission' ?>
        </h1>

        <p>
            <?= $isPublicMode ? 'Please submit your information. Our team will contact you shortly.' : 'Student information collection' ?>
        </p>

    </div>

</div>


<?php if ($msg): ?>

    <div class="success">

        <?= e($msg) ?>

        <br>

        <small>
            Application status:
            <strong>Pending</strong>
        </small>

    </div>

<?php endif; ?>


<?php if ($error): ?>

    <div class="alert">

        <?= e($error) ?>

    </div>

<?php endif; ?>


<form
    method="POST"
    class="card"
    autocomplete="off"
    <?= $msg && $isPublicMode ? 'style="display:none"' : '' ?>
>

    <?= csrf_input() ?>
    <?php if ($isPublicMode): ?>
        <input type="hidden" name="mode" value="public">
    <?php endif; ?>


    <?php if ($isPublicMode): ?>
        <div style="background:#fff8f8;border:1px solid #f1c7cc;border-radius:12px;padding:13px 15px;margin-bottom:18px;color:#555;font-size:13px;line-height:1.5">
            <strong>Important:</strong> Please submit your information only once. Your mobile number/email will be reserved after successful submission.
        </div>
        <div style="position:absolute;left:-10000px;width:1px;height:1px;overflow:hidden" aria-hidden="true">
            <label>Website</label>
            <input name="website" tabindex="-1" autocomplete="off">
        </div>
    <?php endif; ?>


    <!-- ==========================================
         PERSONAL INFORMATION
    =========================================== -->

    <div class="section-title">

        <div>

            <h2>
                Personal Information
            </h2>

            <p>
                Please enter the student's basic information.
            </p>

        </div>

    </div>


    <div class="form-grid">


        <!-- FULL NAME -->

        <div class="field">

            <label>
                Full Name
                <span style="color:#c91f2e">*</span>
            </label>

            <input
                type="text"
                name="full_name"
                placeholder="Student full name"
                required
            >

        </div>


        <!-- MOBILE -->

        <div class="field">

            <label>
                Mobile Number
                <span style="color:#c91f2e">*</span>
            </label>

            <input
                type="tel"
                name="mobile"
                inputmode="numeric"
                pattern="01[3-9][0-9]{8}"
                minlength="11"
                maxlength="11"
                autocomplete="tel"
                placeholder="01712345678"
                required
                oninput="this.value = this.value.replace(/\D/g, '').slice(0, 11);"
            >

        </div>


        <!-- COURSE -->

        <div class="field">

            <label>
                Course
                <span style="color:#c91f2e">*</span>
            </label>

            <select
                name="course_interest"
                id="course_interest"
                required
                onchange="toggleIeltsTarget()"
            >

                <option value="">
                    Select Course
                </option>

                <?php foreach($validCourses as $courseName): ?>
                    <option value="<?=e($courseName)?>">
                        <?=e($courseName)?>
                    </option>
                <?php endforeach; ?>

            </select>

        </div>


        <!-- MOCK TEST PACKAGE + DATES -->

        <div
            class="field"
            id="mockPackageField"
            style="display:none"
        >
            <label>
                Mock Test Package
                <span style="color:#c91f2e">*</span>
            </label>
            <select name="mock_package" id="mock_package">
                <option value="">Select Package</option>
                <?php foreach ($mockPackages as $pkg): ?>
                    <?php
                        $label = $pkg['name'];
                        if ((int)$pkg['count'] > 0) {
                            $label .= ' — '.(int)$pkg['count'].' Mock'.((int)$pkg['count'] === 1 ? '' : 's');
                        }
                        $label .= ' · ৳'.number_format((float)$pkg['fee'], 0);
                        if ((int)$pkg['validity'] > 0) $label .= ' · '.$pkg['validity'].' days';
                    ?>
                    <option
                        value="<?=e($pkg['name'])?>"
                        data-count="<?= (int)$pkg['count'] ?>"
                        data-fee="<?=e((string)$pkg['fee']) ?>"
                    ><?=e($label)?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="field" id="mockDatesField" style="display:none;grid-column:1/-1">
            <label>
                Mock Test Date(s)
                <span style="color:#c91f2e">*</span>
            </label>
            <div id="mockDateInputs" style="display:grid;grid-template-columns:repeat(3,minmax(180px,1fr));gap:12px"></div>
            <small style="display:block;margin-top:7px;color:#737982">Select from the available Monday & Wednesday dates · Time: 10:00 AM – 1:00 PM</small>
        </div>

        <!-- IELTS TARGET -->

        <div
            class="field"
            id="ieltsTargetField"
            style="display:none"
        >

            <label>
                IELTS Overall Target
            </label>

            <select
                name="ielts_overall"
                id="ielts_overall"
            >

                <option value="">
                    Select Overall Target
                </option>

                <option value="5.0">5.0</option>
                <option value="5.5">5.5</option>
                <option value="6.0">6.0</option>
                <option value="6.5">6.5</option>
                <option value="7.0">7.0</option>
                <option value="7.5">7.5</option>
                <option value="8.0">8.0</option>
                <option value="8.5">8.5</option>
                <option value="9.0">9.0</option>

            </select>

        </div>


        <!-- GUARDIAN NAME -->

        <div class="field">

            <label>
                Guardian Name
            </label>

            <input
                type="text"
                name="guardian_name"
                placeholder="Guardian name"
            >

        </div>


        <!-- GUARDIAN MOBILE -->

        <div class="field">

            <label>
                Guardian Mobile
            </label>

            <input
                type="tel"
                name="guardian_mobile"
                inputmode="numeric"
                pattern="01[3-9][0-9]{8}"
                minlength="11"
                maxlength="11"
                autocomplete="tel"
                placeholder="01712345678"
                oninput="this.value = this.value.replace(/\D/g, '').slice(0, 11);"
            >

        </div>


        <!-- DATE OF BIRTH -->

        <div class="field">

            <label>
                Date of Birth
            </label>

            <input
                type="date"
                name="date_of_birth"
            >

        </div>


        <!-- GENDER -->

        <div class="field">

            <label>
                Gender
            </label>

            <select name="gender">

                <option value="">
                    Select Gender
                </option>

                <option value="Male">
                    Male
                </option>

                <option value="Female">
                    Female
                </option>

                <option value="Other">
                    Other
                </option>

            </select>

        </div>


        <!-- EMAIL -->

        <div class="field">

            <label>
                Email
            </label>

            <input
                type="email"
                name="email"
                inputmode="email"
                autocomplete="email"
                maxlength="160"
                placeholder="student@email.com"
            >

        </div>


        <!-- BLOOD GROUP - OPTIONAL -->

        <div class="field">

            <label>
                Blood Group
            </label>

            <select name="blood_group">

                <option value="">
                    Select Blood Group
                </option>

                <option value="A+">
                    A+
                </option>

                <option value="A-">
                    A−
                </option>

                <option value="B+">
                    B+
                </option>

                <option value="B-">
                    B−
                </option>

                <option value="AB+">
                    AB+
                </option>

                <option value="AB-">
                    AB−
                </option>

                <option value="O+">
                    O+
                </option>

                <option value="O-">
                    O−
                </option>

            </select>

        </div>


        <!-- LEAD SOURCE -->

        <div class="field">

            <label>
                Lead Source
            </label>

            <select name="lead_source">

                <option value="">
                    Select
                </option>

                <option value="Facebook">
                    Facebook
                </option>

                <option value="Banner / Festoon">
                    Banner / Festoon
                </option>

                <option value="Web">
                    Website
                </option>

                <option value="Poster / Leaflet">
                    Poster / Leaflet
                </option>

                <option value="Friends">
                    Friends / Family
                </option>

                <option value="Other">
                    Other
                </option>

            </select>

        </div>


        <!-- PRESENT ADDRESS -->

        <div
            class="field"
            style="grid-column:1/-1"
        >

            <label>
                Present Address
            </label>

            <textarea
                name="present_address"
                placeholder="Student's present address"
            ></textarea>

        </div>


    </div>


    <br>


    <!-- ==========================================
         ACADEMIC INFORMATION
    =========================================== -->

    <div class="section-title">

        <div>

            <h2>
                Academic Information
            </h2>

            <p>
                Add the student's latest academic qualifications if available.
            </p>

        </div>

    </div>


    <?php

    $academicRows = [

        'masters' => 'Masters',

        'honors' => 'Honors',

        'diploma' => 'Diploma',

        'hsc' => 'HSC / Equivalent',

        'ssc' => 'SSC / Equivalent'

    ];

    ?>


    <div style="display:grid;gap:14px">

        <?php foreach ($academicRows as $key => $label): ?>

            <div
                style="
                    border:1px solid #e8e9ed;
                    border-radius:14px;
                    padding:15px;
                    background:#fff
                "
            >

                <strong>
                    <?= e($label) ?>
                </strong>


                <div
                    class="form-grid"
                    style="margin-top:12px"
                >


                    <div class="field">

                        <label>
                            Subject / Group
                        </label>

                        <input
                            type="text"
                            name="<?= $key ?>[subject]"
                            placeholder="Subject / Group"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Result
                        </label>

                        <input
                            type="text"
                            name="<?= $key ?>[result]"
                            placeholder="Result"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Passing Year
                        </label>

                        <input
                            type="text"
                            name="<?= $key ?>[passing_year]"
                            placeholder="Year"
                        >

                    </div>


                    <div class="field">

                        <label>
                            Institution
                        </label>

                        <input
                            type="text"
                            name="<?= $key ?>[institution]"
                            placeholder="Institution"
                        >

                    </div>


                </div>

            </div>

        <?php endforeach; ?>

    </div>


    <br>


    <!-- ==========================================
         IELTS TARGET SCRIPT
    =========================================== -->

    <script>

    // Course-dependent fields. Keep this handler defensive so the form still
    // works if a field is temporarily unavailable during page rendering.
    function toggleIeltsTarget() {
        const courseEl = document.getElementById('course_interest');
        if (!courseEl) return;

        const course = String(courseEl.value || '').trim();
        const courseKey = course.toLowerCase();
        const box = document.getElementById('ieltsTargetField');
        const target = document.getElementById('ielts_overall');
        const mockPackageBox = document.getElementById('mockPackageField');
        const mockDatesBox = document.getElementById('mockDatesField');
        const mockPackage = document.getElementById('mock_package');
        const dateInputs = document.getElementById('mockDateInputs');

        const isIelts = courseKey === 'ielts';
        const isMock = courseKey === 'mock test';

        if (box) box.style.display = isIelts ? '' : 'none';
        if (mockPackageBox) mockPackageBox.style.display = isMock ? '' : 'none';
        if (mockDatesBox) mockDatesBox.style.display = isMock ? '' : 'none';

        if (target) {
            target.required = false;
            if (!isIelts) target.value = '';
        }

        if (mockPackage) {
            mockPackage.required = isMock;
            if (!isMock) mockPackage.value = '';
        }

        if (!isMock && dateInputs) dateInputs.innerHTML = '';
        if (isMock && typeof renderMockDates === 'function') renderMockDates();
    }

    const mockDateBookings = <?=json_encode($mockDateBookings, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE)?>;
    const MOCK_DATE_CAPACITY = 14;

    function getAvailableMockDates() {
        const dates = [];
        const d = new Date();
        d.setHours(0,0,0,0);
        // Show the next 8 weeks of actual available Mock Test dates.
        for (let i = 0; i < 56; i++) {
            const day = d.getDay();
            if (day === 1 || day === 3) {
                const y = d.getFullYear();
                const m = String(d.getMonth() + 1).padStart(2, '0');
                const dt = String(d.getDate()).padStart(2, '0');
                const value = `${y}-${m}-${dt}`;
                const booked = Number(mockDateBookings[value] || 0);
                if (booked < MOCK_DATE_CAPACITY) {
                    dates.push({ value, day: day === 1 ? 'Monday' : 'Wednesday', booked, remaining: MOCK_DATE_CAPACITY - booked });
                }
            }
            d.setDate(d.getDate() + 1);
        }
        return dates;
    }

    function renderMockDates() {
        const packageEl = document.getElementById('mock_package');
        const selected = packageEl ? packageEl.options[packageEl.selectedIndex] : null;
        const count = selected ? Number(selected.dataset.count || 0) : 0;
        const wrap = document.getElementById('mockDateInputs');
        const old = Array.from(wrap.querySelectorAll('select[name="mock_dates[]"]')).map(i => i.value);
        const available = getAvailableMockDates();
        wrap.innerHTML = '';

        for (let i = 0; i < count; i++) {
            const box = document.createElement('div');
            box.style.cssText = 'padding:12px;border:1px solid #e5e7eb;border-radius:10px;background:#fff';

            const label = document.createElement('label');
            label.style.cssText = 'display:block;margin-bottom:6px;font-weight:700';
            label.textContent = 'Mock #' + (i + 1) + ' Date';
            box.appendChild(label);

            const select = document.createElement('select');
            select.name = 'mock_dates[]';
            select.required = true;
            select.style.cssText = 'width:100%;padding:10px;border:1px solid #d9dde3;border-radius:8px;background:#fff';

            const first = document.createElement('option');
            first.value = '';
            first.textContent = 'Select available date';
            select.appendChild(first);

            available.forEach(item => {
                const option = document.createElement('option');
                option.value = item.value;
                const dt = new Date(item.value + 'T00:00:00');
                const months = ['Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec'];
                option.textContent = `${item.day}, ${months[dt.getMonth()]} ${dt.getDate()}, ${dt.getFullYear()} · 10:00 AM – 1:00 PM · ${item.remaining} seats left`;
                select.appendChild(option);
            });

            if (old[i]) select.value = old[i];
            select.addEventListener('change', validateMockDate);
            box.appendChild(select);
            wrap.appendChild(box);
        }
    }

    function validateMockDate(select) {
        if (!select.value) return;
        const dates = Array.from(document.querySelectorAll('select[name="mock_dates[]"]')).map(i => i.value).filter(Boolean);
        const count = dates.filter(v => v === select.value).length;
        if (count > 1) {
            alert('Each Mock Test date must be different.');
            select.value = '';
        }
    }

    document.addEventListener('change', function(e) {
        if (!e.target) return;
        if (e.target.id === 'course_interest') {
            toggleIeltsTarget();
            return;
        }
        if (e.target.id === 'mock_package') renderMockDates();
    });


    document.addEventListener('DOMContentLoaded', function () {
        const courseEl = document.getElementById('course_interest');
        if (courseEl) {
            courseEl.addEventListener('change', toggleIeltsTarget);
            toggleIeltsTarget();
        }
    });

    </script>


    <!-- ==========================================
         SUBMIT
    =========================================== -->

    <div class="actions">

        <button
            type="submit"
            class="btn btn-primary"
        >
            <?= $isPublicMode ? 'SUBMIT REGISTRATION' : 'SUBMIT APPLICATION' ?>
        </button>

        <?php if (!$isPublicMode): ?>
            <a
                href="admissions.php"
                class="btn btn-light"
            >
                View Applications
            </a>
        <?php endif; ?>

    </div>


    <br>


    <div
        style="
            background:#f8f8f9;
            border-radius:10px;
            padding:14px;
            font-size:13px;
            color:#666;
        "
    >

        <strong>
            Important:
        </strong>

        <?php if ($isPublicMode): ?>
            Your submission will be added as a <strong>Pending</strong> application.
            Admission will not be automatically confirmed. Our team will review it and contact you.
        <?php else: ?>
            Submitting this form will create a <strong>Pending</strong> application.
            Admission will not be automatically confirmed.
            Admin will review the application and then set course, fee, discount, payment and due.
        <?php endif; ?>

    </div>


</form>


<?php
if (!$isPublicMode) {
    require '_footer.php';
} else {
    ?>
    </main>
    </body>
    </html>
    <?php
}
?>
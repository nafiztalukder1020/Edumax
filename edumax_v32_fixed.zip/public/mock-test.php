<?php
require_once __DIR__ . '/../config/app.php';
require_access('students');

$id = (int)($_GET['admission_id'] ?? 0);

// If Mock Test is opened from the sidebar without a specific admission,
// send the user to the Mock Test Report instead of showing an error.
if ($id <= 0) {
    header('Location: mock-test-report.php');
    exit;
}

$st = $pdo->prepare("SELECT a.*, s.student_id, s.full_name, s.mobile, c.name course_name
    FROM admissions a JOIN students s ON s.id=a.student_id JOIN courses c ON c.id=a.course_id
    WHERE a.id=? LIMIT 1");
$st->execute([$id]); $adm=$st->fetch();
if (!$adm || strcasecmp((string)$adm['course_name'],'Mock Test')!==0) exit('Mock Test admission not found.');

$packageCounts=['1 Mock'=>1,'2 Mocks'=>2,'3 Mocks'=>3];
$allowed=(int)($packageCounts[$adm['mock_package']??'']??0);
if ($allowed<=0) exit('Mock Test package is not configured.');

try {
    $pdo->exec("CREATE TABLE IF NOT EXISTS mock_test_usage (
      id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
      admission_id INT UNSIGNED NOT NULL, student_id INT UNSIGNED NOT NULL,
      mock_no INT UNSIGNED NOT NULL, mock_date DATE NOT NULL, mock_day VARCHAR(20) NOT NULL,
      time_slot VARCHAR(100) NOT NULL DEFAULT '10:00 AM - 01:00 PM',
      status ENUM('Scheduled','Completed','Cancelled') NOT NULL DEFAULT 'Scheduled',
      note VARCHAR(255) NULL, marked_by INT UNSIGNED NULL,
      created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
      updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
      UNIQUE KEY uq_mock_usage_no(admission_id,mock_no),
      KEY idx_mock_usage_date(mock_date), KEY idx_mock_usage_student(student_id),
      CONSTRAINT fk_mock_usage_admission FOREIGN KEY(admission_id) REFERENCES admissions(id) ON DELETE CASCADE,
      CONSTRAINT fk_mock_usage_student FOREIGN KEY(student_id) REFERENCES students(id) ON DELETE CASCADE,
      CONSTRAINT fk_mock_usage_user FOREIGN KEY(marked_by) REFERENCES users(id) ON DELETE SET NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
} catch(Throwable $e) { exit('Mock Test usage table is not available. Run database/mock_test_usage_v2.sql'); }

$error=''; $success='';
if ($_SERVER['REQUEST_METHOD']==='POST') {
    verify_csrf();
    $action=$_POST['action']??'';
    $mockNo=(int)($_POST['mock_no']??0);
    $date=trim($_POST['mock_date']??'');
    $usageId=(int)($_POST['usage_id']??0);

    if ($action==='schedule') {
        $dt=DateTime::createFromFormat('Y-m-d',$date);
        $validDate=$dt && $dt->format('Y-m-d')===$date;
        $day=$validDate?$dt->format('l'):'';
        if ($mockNo<1 || $mockNo>$allowed) $error='Invalid Mock number.';
        elseif (!$validDate || !in_array($day,['Monday','Wednesday'],true)) $error='Mock Test can only be scheduled on Monday or Wednesday.';
        elseif ($date < date('Y-m-d')) $error='Past dates cannot be scheduled.';
        else {
            try {
                $q=$pdo->prepare("INSERT INTO mock_test_usage(admission_id,student_id,mock_no,mock_date,mock_day,time_slot,status,marked_by)
                    VALUES(?,?,?,?,?,'10:00 AM - 01:00 PM','Scheduled',?)");
                $q->execute([$adm['id'],$adm['student_id'],$mockNo,$date,$day,$_SESSION['user_id']]);
                $success='Mock #'.$mockNo.' scheduled successfully.';
            } catch(Throwable $e) { $error='This Mock number is already scheduled, or the date is invalid.'; }
        }
    } elseif ($action==='complete') {
        $q=$pdo->prepare("UPDATE mock_test_usage SET status='Completed', marked_by=? WHERE id=? AND admission_id=? AND status='Scheduled'");
        $q->execute([$_SESSION['user_id'],$usageId,$adm['id']]);
        $success=$q->rowCount()?'Mock marked as Completed.':'No schedule was updated.';
    } elseif ($action==='cancel') {
        $q=$pdo->prepare("UPDATE mock_test_usage SET status='Cancelled', marked_by=? WHERE id=? AND admission_id=? AND status='Scheduled'");
        $q->execute([$_SESSION['user_id'],$usageId,$adm['id']]);
        $success=$q->rowCount()?'Mock schedule cancelled.':'No schedule was updated.';
    }
}

$q=$pdo->prepare("SELECT mu.*, u.name AS marked_by_name
                  FROM mock_test_usage mu LEFT JOIN users u ON u.id=mu.marked_by
                  WHERE mu.admission_id=? ORDER BY mu.mock_no ASC");
$q->execute([$id]); $rows=$q->fetchAll();

$used=0; $scheduled=0; $cancelled=0;
foreach($rows as $r) {
    if($r['status']==='Completed') $used++;
    elseif($r['status']==='Scheduled') $scheduled++;
    elseif($r['status']==='Cancelled') $cancelled++;
}
$remaining=max(0,$allowed-$used-$cancelled);

require '_header.php';
?>
<div class="page-header">
  <div><h1>Mock Test Management</h1><p><?=e($adm['full_name'])?> · <?=e($adm['student_id'])?> · <?=e($adm['mock_package'])?></p></div>
</div>

<?php if($error): ?><div class="alert alert-danger"><?=e($error)?></div><?php endif; ?>
<?php if($success): ?><div class="alert alert-success"><?=e($success)?></div><?php endif; ?>

<div class="card edmx-card" style="margin-bottom:18px">
  <div class="form-grid">
    <div><small>Package</small><strong><?=e($adm['mock_package'])?></strong></div>
    <div><small>Purchased</small><strong><?=$allowed?></strong></div>
    <div><small>Completed</small><strong><?=$used?></strong></div>
    <div><small>Scheduled</small><strong><?=$scheduled?></strong></div>
    <div><small>Remaining</small><strong><?=$remaining?></strong></div>
    <div><small>Allowed Days</small><strong>Monday & Wednesday</strong></div>
    <div><small>Time</small><strong>10:00 AM – 1:00 PM</strong></div>
  </div>
</div>

<?php if($remaining>0): ?>
<div class="card edmx-card">
  <h2>Schedule Mock</h2>
  <p style="color:#666;margin-top:4px">Choose a future Monday or Wednesday. Time is fixed automatically.</p>
  <form method="post" class="form-grid" style="margin-top:14px">
    <?=csrf_input()?>
    <input type="hidden" name="action" value="schedule">
    <div><label>Mock Number</label><select name="mock_no" required>
      <?php for($i=1;$i<=$allowed;$i++): ?>
        <?php
          $already=false;
          foreach($rows as $rr) if((int)$rr['mock_no']===$i && $rr['status']!=='Cancelled') $already=true;
        ?>
        <?php if(!$already): ?><option value="<?=$i?>">Mock #<?=$i?></option><?php endif; ?>
      <?php endfor; ?>
    </select></div>
    <div><label>Date</label><input type="date" name="mock_date" min="<?=date('Y-m-d')?>" required></div>
    <div style="align-self:end"><button class="btn btn-primary">Schedule Mock</button></div>
  </form>
</div>
<?php endif; ?>

<br>
<div class="card edmx-card">
  <h2>Mock History</h2>
  <div class="table-wrap"><table class="table">
    <tr><th>Mock</th><th>Date</th><th>Day</th><th>Time</th><th>Status</th><th>Marked By</th><th>Action</th></tr>
    <?php foreach($rows as $r): ?>
    <tr>
      <td><strong>#<?=e($r['mock_no'])?></strong></td>
      <td><?=e(date('d M Y',strtotime($r['mock_date'])))?></td>
      <td><?=e($r['mock_day'])?></td>
      <td><?=e($r['time_slot'])?></td>
      <td><?=e($r['status'])?></td>
      <td><?=e($r['marked_by_name'] ?: '-')?></td>
      <td>
        <?php if($r['status']==='Scheduled'): ?>
          <form method="post" style="display:inline-flex;gap:6px;margin:0">
            <?=csrf_input()?><input type="hidden" name="usage_id" value="<?=e($r['id'])?>">
            <button class="btn btn-sm btn-primary" name="action" value="complete">Completed</button>
            <button class="btn btn-sm" name="action" value="cancel" onclick="return confirm('Cancel this Mock schedule?')">Cancel</button>
          </form>
        <?php else: ?>—<?php endif; ?>
      </td>
    </tr>
    <?php endforeach; ?>
    <?php if(!$rows): ?><tr><td colspan="7">No Mock Test has been scheduled yet.</td></tr><?php endif; ?>
  </table></div>
</div>
<?php require '_footer.php'; ?>

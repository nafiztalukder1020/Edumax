<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

/* Management users stay in the main Management System workspace. */
if (!empty($_SESSION['user_id'])) {
    require_admin();
    if (user_has_permission('consultancy_dashboard')) {
        $_SESSION['workspace'] = 'consultancy';
        header('Location: consultancy-dashboard.php');
        exit;
    }
}

if (empty($_SESSION['counselor_id'])) {
    header('Location: consultancy-counselor-login.php'); exit;
}
$counselorId=(int)$_SESSION['counselor_id'];
$name=(string)($_SESSION['counselor_name']??'Counselor');

$error='';
$notifications=[];$newCount=0;$assigned=[];$followups=[];$stats=['new'=>0,'accepted'=>0,'followups'=>0,'files'=>0];

try {
    $n=$pdo->prepare("SELECT n.id,n.enquiry_id,n.title,n.message,n.is_read,n.created_at,e.full_name,e.mobile,e.country_id,c.country_name,e.program,e.intake,e.status
        FROM consultancy_notifications n
        INNER JOIN consultancy_enquiries e ON e.id=n.enquiry_id
        LEFT JOIN consultancy_countries c ON c.id=e.country_id
        WHERE n.counselor_id=? ORDER BY n.is_read ASC,n.created_at DESC LIMIT 12");
    $n->execute([$counselorId]); $notifications=$n->fetchAll();
    $cnt=$pdo->prepare("SELECT COUNT(*) FROM consultancy_notifications WHERE counselor_id=? AND is_read=0");
    $cnt->execute([$counselorId]); $newCount=(int)$cnt->fetchColumn();

    $q=$pdo->prepare("SELECT e.id,e.enquiry_no,e.full_name,e.mobile,e.whatsapp,e.email,e.education_level,e.institution,e.passing_year,e.result_value,
        e.intake,e.program,e.ielts_status,e.ielts_score,e.status,e.created_at,c.country_name,
        (SELECT COUNT(*) FROM consultancy_followups f WHERE f.enquiry_id=e.id AND f.status='Pending') AS pending_followups
        FROM consultancy_enquiries e LEFT JOIN consultancy_countries c ON c.id=e.country_id
        WHERE e.counselor_id=? ORDER BY e.id DESC LIMIT 50");
    $q->execute([$counselorId]); $assigned=$q->fetchAll();

    foreach($assigned as $a){
        if(in_array($a['status'],['New','Unassigned'],true)) $stats['new']++;
        if(!in_array($a['status'],['New','Unassigned','Lost','Closed'],true)) $stats['accepted']++;
    }

    $f=$pdo->prepare("SELECT f.*,e.full_name,e.enquiry_no,c.country_name FROM consultancy_followups f
        INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
        LEFT JOIN consultancy_countries c ON c.id=e.country_id
        WHERE f.counselor_id=? AND f.status='Pending' ORDER BY f.scheduled_at ASC LIMIT 8");
    $f->execute([$counselorId]); $followups=$f->fetchAll(); $stats['followups']=count($followups);

    $fs=$pdo->prepare("SELECT COUNT(*) FROM consultancy_files WHERE counselor_id=? AND file_status IN ('Open','Processing')");
    $fs->execute([$counselorId]); $stats['files']=(int)$fs->fetchColumn();
} catch(Throwable $e){$error='Unable to load counselor dashboard.';}
?>
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Counselor Dashboard</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f6f8;color:#20242b;font-family:Arial,sans-serif}.top{background:#fff;border-bottom:1px solid #e6e8ec;padding:15px 24px;display:flex;justify-content:space-between;align-items:center;gap:15px}.brand{font-weight:900;color:#c91f2e;font-size:20px}.top small{display:block;color:#7a8088;font-size:11px;margin-top:3px}.logout{padding:9px 12px;border:1px solid #ddd;border-radius:9px;text-decoration:none;color:#333;font-size:12px;font-weight:800}.wrap{max-width:1240px;margin:25px auto;padding:0 18px}.head{display:flex;justify-content:space-between;align-items:end;margin-bottom:18px}.head h1{margin:0 0 5px;font-size:26px}.head p{margin:0;color:#737982;font-size:13px}.badge{padding:8px 11px;background:#fbecef;color:#a71928;border-radius:999px;font-size:11px;font-weight:800}.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}.stat,.card{background:#fff;border:1px solid #e5e8ec;border-radius:14px}.stat{padding:16px}.stat span{display:block;color:#777f88;font-size:11px}.stat strong{display:block;font-size:25px;margin-top:5px}.grid{display:grid;grid-template-columns:1.3fr .7fr;gap:18px}.card h2{font-size:16px;margin:0}.ch{padding:16px 18px;border-bottom:1px solid #eef0f2;display:flex;justify-content:space-between;align-items:center}.body{padding:15px 18px}.notif{padding:12px 0;border-bottom:1px solid #eef0f2}.notif:last-child{border-bottom:0}.notif strong{font-size:13px}.notif p{margin:4px 0;color:#666;font-size:11px;line-height:1.5}.new{border-left:3px solid #c91f2e;padding-left:10px}.table{width:100%;border-collapse:collapse}.table th,.table td{padding:11px 9px;border-bottom:1px solid #eef0f2;text-align:left;font-size:11px;vertical-align:top}.table th{font-size:9px;color:#777;text-transform:uppercase}.name{font-weight:800}.sub{font-size:10px;color:#858b93;margin-top:3px}.btn{display:inline-block;padding:7px 9px;border-radius:8px;background:#c91f2e;color:#fff;text-decoration:none;font-size:10px;font-weight:800}.btn.light{background:#fff;color:#333;border:1px solid #ddd}.follow{padding:11px 0;border-bottom:1px solid #eee;font-size:11px}.follow:last-child{border:0}.empty{text-align:center;padding:25px;color:#888;font-size:12px}
@media(max-width:900px){.grid{grid-template-columns:1fr}.stats{grid-template-columns:1fr 1fr}}@media(max-width:600px){.stats{grid-template-columns:1fr}.top{padding:13px 15px}.wrap{padding:0 12px}.head{display:block}.badge{display:inline-block;margin-top:12px}}
</style></head><body>
<div class="top"><div><div class="brand">EDUMAX CONSULTANCY</div><small>Counselor Workspace</small></div><div>Hi, <strong><?=e($name)?></strong> &nbsp; <a class="logout" href="consultancy-counselor-logout.php?_csrf=<?=e(csrf_token())?>">Logout</a></div></div>
<div class="wrap">
<div class="head"><div><h1>My Dashboard</h1><p>Only your assigned consultancy enquiries and follow-ups are shown here.</p></div><div class="badge">Counselor #<?=e((string)$counselorId)?></div></div>
<?php if($error): ?><div class="card" style="padding:13px;margin-bottom:16px;color:#a71928"><?=e($error)?></div><?php endif; ?>
<div class="stats">
<div class="stat"><span>New Assignments</span><strong><?=e((string)$stats['new'])?></strong></div>
<div class="stat"><span>My Active Enquiries</span><strong><?=e((string)$stats['accepted'])?></strong></div>
<div class="stat"><span>Pending Follow-ups</span><strong><?=e((string)$stats['followups'])?></strong></div>
<div class="stat"><span>Active Files</span><strong><?=e((string)$stats['files'])?></strong></div>
</div>
<div class="grid">
<div class="card"><div class="ch"><h2>🔔 New / Recent Assignments</h2><span style="font-size:11px;color:#777"><?=e((string)$newCount)?> unread</span></div><div class="body">
<?php if(!$notifications): ?><div class="empty">No notifications.</div><?php else: foreach($notifications as $n): ?>
<div class="notif <?=empty($n['is_read'])?'new':''?>">
<strong><?=e($n['title'])?></strong>
<p><?=e($n['message']?:($n['full_name'].' — '.$n['country_name']))?></p>
<a class="btn light" href="consultancy-counselor-enquiry.php?id=<?=e((string)$n['enquiry_id'])?>">View Student</a>
</div>
<?php endforeach; endif; ?></div></div>
<div class="card"><div class="ch"><h2>📅 My Follow-ups</h2></div><div class="body">
<?php if(!$followups): ?><div class="empty">No pending follow-ups.</div><?php else: foreach($followups as $f): ?>
<div class="follow"><strong><?=e($f['full_name'])?></strong><div class="sub"><?=e($f['country_name']?:'-')?> · <?=e(date('d M Y, h:i A',strtotime($f['scheduled_at'])))?></div></div>
<?php endforeach; endif; ?></div></div>
</div>
<div class="card" style="margin-top:18px"><div class="ch"><h2>👨‍🎓 My Assigned Students</h2></div><div style="overflow:auto"><table class="table"><thead><tr><th>Student</th><th>Country</th><th>Program</th><th>Intake</th><th>Status</th><th></th></tr></thead><tbody>
<?php if(!$assigned): ?><tr><td colspan="6" class="empty">No assigned students.</td></tr><?php else: foreach($assigned as $a): ?>
<tr><td><div class="name"><?=e($a['full_name'])?></div><div class="sub"><?=e($a['mobile'])?></div></td><td><?=e($a['country_name']?:'-')?></td><td><?=e($a['program']?:'-')?></td><td><?=e($a['intake']?:'-')?></td><td><?=e($a['status'])?></td><td><a class="btn" href="consultancy-counselor-enquiry.php?id=<?=e((string)$a['id'])?>">Open</a></td></tr>
<?php endforeach; endif; ?></tbody></table></div></div>
</div></body></html>

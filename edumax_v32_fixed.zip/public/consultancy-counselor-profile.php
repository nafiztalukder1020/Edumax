<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

if (empty($_SESSION['counselor_id'])) {
    header('Location: consultancy-counselor-login.php');
    exit;
}

$counselorId = (int)$_SESSION['counselor_id'];
$error = '';
$counselor = null;
$countries = [];

try {
    $stmt = $pdo->prepare("
        SELECT id,counselor_name,username,mobile,email,status,notes,created_at
        FROM consultancy_counselors
        WHERE id=? LIMIT 1
    ");
    $stmt->execute([$counselorId]);
    $counselor = $stmt->fetch();

    if (!$counselor || $counselor['status'] !== 'Active') {
        unset($_SESSION['counselor_id'], $_SESSION['counselor_name'], $_SESSION['counselor_username']);
        header('Location: consultancy-counselor-login.php');
        exit;
    }

    $q = $pdo->prepare("
        SELECT co.country_name
        FROM consultancy_counselor_country_assignments a
        INNER JOIN consultancy_countries co ON co.id=a.country_id
        WHERE a.counselor_id=? AND a.status='Active' AND co.status='Active'
        ORDER BY co.country_name
    ");
    $q->execute([$counselorId]);
    $countries = $q->fetchAll();
} catch (Throwable $e) {
    $error = 'Unable to load counselor profile.';
}

function h($value): string {
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>My Counselor Profile</title>
<style>
*{box-sizing:border-box}
body{margin:0;background:#f5f6f8;color:#20242b;font-family:Arial,sans-serif}
.top{background:#fff;border-bottom:1px solid #e6e8ec;padding:15px 24px;display:flex;justify-content:space-between;align-items:center;gap:15px}
.brand{font-weight:900;color:#c91f2e;font-size:20px}
.top small{display:block;color:#7a8088;font-size:11px;margin-top:3px}
.top a{padding:9px 12px;border:1px solid #ddd;border-radius:9px;text-decoration:none;color:#333;font-size:11px;font-weight:800;margin-left:5px}
.wrap{max-width:900px;margin:28px auto;padding:0 18px}
.head h1{margin:0 0 5px;font-size:27px}
.head p{margin:0 0 20px;color:#737982;font-size:13px}
.card{background:#fff;border:1px solid #e5e8ec;border-radius:14px;padding:20px;margin-bottom:16px}
.profile-head{display:flex;gap:16px;align-items:center}
.avatar{width:62px;height:62px;border-radius:50%;background:#fbecef;color:#a71928;display:flex;align-items:center;justify-content:center;font-size:25px;font-weight:900}
.name{font-size:20px;font-weight:900}
.muted{font-size:11px;color:#777;margin-top:4px}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.field{border:1px solid #eef0f2;border-radius:10px;padding:13px}
.field label{display:block;color:#858b93;font-size:10px;margin-bottom:5px}
.field strong{font-size:13px}
.badge{display:inline-block;padding:6px 9px;border-radius:999px;background:#eaf8ef;color:#18713b;font-size:10px;font-weight:800}
.country-list{display:flex;flex-wrap:wrap;gap:8px}
.country{padding:8px 11px;background:#f5f6f8;border-radius:999px;font-size:11px;font-weight:800}
.btn{display:inline-block;padding:9px 12px;border-radius:9px;background:#c91f2e;color:#fff;text-decoration:none;font-size:11px;font-weight:800}
@media(max-width:650px){.grid{grid-template-columns:1fr}.top{padding:13px 15px;align-items:flex-start}.top a{display:inline-block;margin-top:5px}}
</style>
</head>
<body>
<div class="top">
  <div><div class="brand">EDUMAX CONSULTANCY</div><small>Personal Counselor Workspace</small></div>
  <div>
    <a href="consultancy-counselor-dashboard.php">My Dashboard</a>
    <a href="consultancy-counselor-logout.php?_csrf=<?=e(csrf_token())?>">Logout</a>
  </div>
</div>

<div class="wrap">
  <div class="head">
    <h1>My Profile</h1>
    <p>Your counselor account information and assigned countries.</p>
  </div>

  <?php if ($error): ?>
    <div class="card" style="color:#a71928"><?=h($error)?></div>
  <?php endif; ?>

  <?php if ($counselor): ?>
    <div class="card">
      <div class="profile-head">
        <div class="avatar"><?=h(strtoupper(substr((string)$counselor['counselor_name'],0,1)))?></div>
        <div>
          <div class="name"><?=h($counselor['counselor_name'])?></div>
          <div class="muted">
            Counselor #<?=h($counselorId)?> ��
            <span class="badge"><?=h($counselor['status'])?></span>
          </div>
        </div>
      </div>
    </div>

    <div class="card">
      <h2 style="font-size:16px;margin-top:0">Account Information</h2>
      <div class="grid">
        <div class="field"><label>Full Name</label><strong><?=h($counselor['counselor_name'])?></strong></div>
        <div class="field"><label>Username</label><strong><?=h($counselor['username'] ?: '-')?></strong></div>
        <div class="field"><label>Mobile</label><strong><?=h($counselor['mobile'] ?: '-')?></strong></div>
        <div class="field"><label>Email</label><strong><?=h($counselor['email'] ?: '-')?></strong></div>
        <div class="field"><label>Account Status</label><strong><?=h($counselor['status'])?></strong></div>
        <div class="field"><label>Joined</label><strong><?=h(date('d M Y', strtotime($counselor['created_at'])))?></strong></div>
      </div>
    </div>

    <div class="card">
      <h2 style="font-size:16px;margin-top:0">Assigned Countries</h2>
      <?php if (!$countries): ?>
        <div style="color:#858b93;font-size:12px">No active country assignment.</div>
      <?php else: ?>
        <div class="country-list">
          <?php foreach ($countries as $country): ?>
            <span class="country"><?=h($country['country_name'])?></span>
          <?php endforeach; ?>
        </div>
      <?php endif; ?>
    </div>

    <?php if (!empty($counselor['notes'])): ?>
      <div class="card">
        <h2 style="font-size:16px;margin-top:0">Admin Note</h2>
        <div style="color:#666;font-size:12px;line-height:1.6"><?=nl2br(h($counselor['notes']))?></div>
      </div>
    <?php endif; ?>

    <a class="btn" href="consultancy-counselor-dashboard.php">Back to My Dashboard</a>
  <?php endif; ?>
</div>
</body>
</html>

<?php
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/batch-capacity.php';
edumax_ensure_batch_capacity_column($pdo);
require_access('batch');
ensure_archive_columns();
try { $pdo->exec("ALTER TABLE batches ADD COLUMN slot_capacities TEXT NULL AFTER max_students"); } catch (Throwable $e) {}

// Admin page for changing an existing student's time slot inside the same batch.
// It never changes course, fee, payment or admission status.
$error = '';
$success = '';

$batchId = (int)($_GET['batch_id'] ?? $_POST['batch_id'] ?? 0);
if ($batchId <= 0) {
    exit('Batch is required.');
}

$batchQ = $pdo->prepare("
    SELECT b.id, b.name, b.course_id, b.status, b.is_archived, b.time_slots,
           c.name AS course_name, COALESCE(b.max_students,50) AS max_students, b.slot_capacities
    FROM batches b
    LEFT JOIN courses c ON c.id=b.course_id
    WHERE b.id=?
    LIMIT 1
");
$batchQ->execute([$batchId]);
$batch = $batchQ->fetch();

if (!$batch) {
    exit('Batch not found.');
}

$slots = json_decode((string)($batch['time_slots'] ?? ''), true);
if (!is_array($slots)) $slots = [];
$cleanSlots = [];
foreach ($slots as $slot) {
    $slot = trim((string)$slot);
    if ($slot !== '' && !in_array($slot, $cleanSlots, true)) $cleanSlots[] = $slot;
}
$slots = $cleanSlots;
$capacity = !empty($slots) ? edumax_batch_capacity($pdo, $batchId, (string)$slots[0]) : edumax_batch_capacity($pdo, $batchId);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    try {
        $admissionId = (int)($_POST['admission_id'] ?? 0);
        $newSlot = trim((string)($_POST['time_slot'] ?? ''));

        if ($admissionId <= 0) throw new RuntimeException('Invalid student selected.');
        if ($newSlot === '' || !in_array($newSlot, $slots, true)) {
            throw new RuntimeException('Please select a valid time slot from this batch.');
        }
        if ((int)$batch['is_archived'] === 1 || ($batch['status'] ?? '') === 'Closed') {
            throw new RuntimeException('Archived/Closed batches cannot change student time slots.');
        }

        $pdo->beginTransaction();

        // Lock the batch so two admins cannot take the last seat at the same time.
        $lock = $pdo->prepare("
            SELECT b.id, b.status, b.is_archived, b.time_slots,
                   COALESCE(b.max_students,50) AS max_students, b.slot_capacities
            FROM batches b
            WHERE b.id=?
            FOR UPDATE
        ");
        $lock->execute([$batchId]);
        $lockedBatch = $lock->fetch();
        if (!$lockedBatch) throw new RuntimeException('Batch not found.');
        if ((int)$lockedBatch['is_archived'] === 1 || ($lockedBatch['status'] ?? '') === 'Closed') {
            throw new RuntimeException('Archived/Closed batches cannot change student time slots.');
        }

        $lockedSlots = json_decode((string)($lockedBatch['time_slots'] ?? ''), true);
        if (!is_array($lockedSlots) || !in_array($newSlot, $lockedSlots, true)) {
            throw new RuntimeException('Selected time slot is no longer available in this batch.');
        }

        $studentQ = $pdo->prepare("
            SELECT a.id, a.student_id, a.time_slot, a.status,
                   s.student_id AS student_code, s.full_name, s.mobile
            FROM admissions a
            INNER JOIN students s ON s.id=a.student_id
            WHERE a.id=? AND a.batch_id=?
            LIMIT 1
            FOR UPDATE
        ");
        $studentQ->execute([$admissionId, $batchId]);
        $student = $studentQ->fetch();

        if (!$student) throw new RuntimeException('Student admission was not found in this batch.');
        if (($student['status'] ?? '') === 'Cancelled') {
            throw new RuntimeException('Cancelled admissions cannot be assigned to a time slot.');
        }

        $oldSlot = trim((string)($student['time_slot'] ?? ''));
        if ($oldSlot === $newSlot) {
            $pdo->commit();
            $success = 'No change needed. Student is already in this time slot.';
        } else {
            $countQ = $pdo->prepare("
                SELECT COUNT(*)
                FROM admissions
                WHERE batch_id=? AND time_slot=? AND status <> 'Cancelled' AND id<>?
            ");
            $countQ->execute([$batchId, $newSlot, $admissionId]);
            $current = (int)$countQ->fetchColumn();
            $maxStudents=edumax_batch_capacity($pdo, $batchId, $newSlot);

            if ($current >= $maxStudents) {
                throw new RuntimeException(
                    'The selected time slot is FULL ('.$current.'/'.$maxStudents.'). Please select another slot.'
                );
            }

            $update = $pdo->prepare("
                UPDATE admissions
                SET time_slot=?
                WHERE id=? AND batch_id=? AND status <> 'Cancelled'
            ");
            $update->execute([$newSlot, $admissionId, $batchId]);

            if ($update->rowCount() !== 1) {
                throw new RuntimeException('Student time slot could not be updated.');
            }

            $audit = $pdo->prepare("
                INSERT INTO audit_logs (user_id, action, student_id, details)
                VALUES (?,?,?,?)
            ");
            $audit->execute([
                (int)($_SESSION['user_id'] ?? 0),
                'Student Time Slot Updated',
                (int)$student['student_id'],
                'Batch #'.$batchId.' - '.$student['student_code'].' moved from "'.$oldSlot.'" to "'.$newSlot.'"'
            ]);

            $pdo->commit();
            $success = $student['full_name'].' moved from '.$oldSlot.' to '.$newSlot.'.';
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $e->getMessage();
    }
}

// Reload current students after any update.
$listQ = $pdo->prepare("
    SELECT a.id AS admission_id, a.time_slot, a.status,
           s.student_id, s.full_name, s.mobile
    FROM admissions a
    INNER JOIN students s ON s.id=a.student_id
    WHERE a.batch_id=? AND a.status <> 'Cancelled'
    ORDER BY
      CASE WHEN a.time_slot IS NULL OR a.time_slot='' THEN 1 ELSE 0 END,
      a.time_slot ASC,
      s.full_name ASC
");
$listQ->execute([$batchId]);
$students = $listQ->fetchAll();

// Current occupancy per slot.
$occupancy = [];
$countQ = $pdo->prepare("
    SELECT time_slot, COUNT(*) AS total
    FROM admissions
    WHERE batch_id=? AND status <> 'Cancelled'
    GROUP BY time_slot
");
$countQ->execute([$batchId]);
foreach ($countQ->fetchAll() as $r) {
    $occupancy[(string)$r['time_slot']] = (int)$r['total'];
}

require '_header.php';
?>
<style>
.slot-manage-head{display:flex;justify-content:space-between;align-items:flex-start;gap:15px;flex-wrap:wrap;margin-bottom:18px}
.slot-summary{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:18px}
.slot-summary-card{border:1px solid #ececf0;border-radius:12px;background:#fff;padding:14px}
.slot-summary-card small{display:block;color:#777;font-size:11px;font-weight:700;text-transform:uppercase;margin-bottom:5px}
.slot-summary-card strong{font-size:20px}
.slot-list{display:flex;gap:7px;flex-wrap:wrap}
.slot-chip{display:inline-flex;padding:6px 10px;border-radius:999px;background:#f1f2f4;font-size:12px;font-weight:700}
.student-slot-table td{vertical-align:middle}
.student-slot-form{display:flex;gap:7px;align-items:center;min-width:260px}
.student-slot-form select{min-width:170px}
@media(max-width:850px){.slot-summary{grid-template-columns:repeat(2,minmax(0,1fr))}.student-slot-table{min-width:850px}}
@media(max-width:520px){.slot-summary{grid-template-columns:1fr}.student-slot-form{min-width:230px}}
</style>

<div class="slot-manage-head">
  <div>
    <h1>Student Time Slot Management</h1>
    <p class="muted"><?=e($batch['course_name'] ?? 'Course')?> — <?=e($batch['name'])?></p>
  </div>
  <a class="btn btn-secondary" href="batch-management.php">← Back to Batch Management</a>
</div>

<?php if($success): ?><div class="alert alert-success"><?=e($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert"><?=e($error)?></div><?php endif; ?>

<div class="card" style="margin-bottom:18px">
  <div class="slot-summary">
    <div class="slot-summary-card"><small>Total Students</small><strong><?=count($students)?></strong></div>
    <div class="slot-summary-card"><small>Capacity / Slot</small><strong><?=$capacity?></strong></div>
    <div class="slot-summary-card"><small>Available Slots</small><strong><?=count($slots)?></strong></div>
    <div class="slot-summary-card"><small>Status</small><strong><?=e($batch['status'])?></strong></div>
  </div>
  <div>
    <strong>Available Time Slots</strong>
    <div class="slot-list" style="margin-top:8px">
      <?php foreach($slots as $slot): ?>
        <span class="slot-chip"><?=e($slot)?> · <?=($occupancy[$slot] ?? 0)?>/<?=$capacity?></span>
      <?php endforeach; ?>
      <?php if(!$slots): ?><span class="muted">No time slots configured for this batch.</span><?php endif; ?>
    </div>
  </div>
</div>

<div class="card">
  <div class="card-header">
    <div>
      <h2>Students in This Batch</h2>
      <p class="muted">Admin can change an individual student's time slot without changing course, fee, payment or admission data.</p>
    </div>
  </div>

  <div class="table-wrap">
    <table class="table student-slot-table">
      <thead>
        <tr>
          <th>Student ID</th>
          <th>Student</th>
          <th>Mobile</th>
          <th>Current Time Slot</th>
          <th>Change Time Slot</th>
        </tr>
      </thead>
      <tbody>
      <?php if(!$students): ?>
        <tr><td colspan="5">No active students found in this batch.</td></tr>
      <?php else: foreach($students as $student): ?>
        <tr>
          <td><strong><?=e($student['student_id'])?></strong></td>
          <td><strong><?=e($student['full_name'])?></strong></td>
          <td><?=e($student['mobile'] ?? '-')?></td>
          <td><?=e($student['time_slot'] ?: 'Not Assigned')?></td>
          <td>
            <form method="post" class="student-slot-form">
              <?=csrf_input()?>
              <input type="hidden" name="batch_id" value="<?=$batchId?>">
              <input type="hidden" name="admission_id" value="<?=$student['admission_id']?>">
              <select name="time_slot" required>
                <option value="">Select Slot</option>
                <?php foreach($slots as $slot): ?>
                  <option value="<?=e($slot)?>" <?=((string)$student['time_slot']===(string)$slot)?'selected':''?>>
                    <?=e($slot)?> (<?=($occupancy[$slot] ?? 0)?>/<?=$capacity?>)
                  </option>
                <?php endforeach; ?>
              </select>
              <button class="btn btn-primary" type="submit">Update</button>
            </form>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require '_footer.php'; ?>

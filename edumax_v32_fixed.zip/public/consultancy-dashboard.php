<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';

/*
 * Consultancy Management Dashboard
 *
 * IMPORTANT:
 * - This page is for authenticated Management System users.
 * - Counselor Workspace remains separate in consultancy-counselor-dashboard.php.
 * - No IELTS functionality is changed here.
 */
require_access('consultancy_dashboard');

$error = '';
$stats = [
    'enquiries' => 0,
    'new' => 0,
    'followups' => 0,
    'files' => 0,
    'payments' => 0.0,
];
$recent = [];

try {
    $q = $pdo->query("
        SELECT
            COUNT(*) AS total,
            SUM(status IN ('New','Unassigned')) AS new_count
        FROM consultancy_enquiries
    ");
    $row = $q->fetch() ?: [];
    $stats['enquiries'] = (int)($row['total'] ?? 0);
    $stats['new'] = (int)($row['new_count'] ?? 0);

    $q = $pdo->query("
        SELECT COUNT(*)
        FROM consultancy_followups
        WHERE status='Pending'
          AND scheduled_at <= DATE_ADD(NOW(), INTERVAL 1 DAY)
    ");
    $stats['followups'] = (int)$q->fetchColumn();

    $q = $pdo->query("
        SELECT COUNT(*)
        FROM consultancy_files
        WHERE file_status IN ('Open','Processing')
    ");
    $stats['files'] = (int)$q->fetchColumn();

    $q = $pdo->query("
        SELECT COALESCE(SUM(amount),0)
        FROM consultancy_payments
        WHERE status='Valid'
    ");
    $stats['payments'] = (float)$q->fetchColumn();

    $q = $pdo->query("
        SELECT
            e.id,
            e.enquiry_no,
            e.full_name,
            e.mobile,
            e.status,
            e.created_at,
            co.country_name,
            c.counselor_name
        FROM consultancy_enquiries e
        LEFT JOIN consultancy_countries co ON co.id=e.country_id
        LEFT JOIN consultancy_counselors c ON c.id=e.counselor_id
        ORDER BY e.id DESC
        LIMIT 12
    ");
    $recent = $q->fetchAll();

} catch (Throwable $e) {
    $error = 'Unable to load consultancy dashboard data.';
}

require_once __DIR__ . '/_header.php';
?>

<style>
.cd-wrap{max-width:1240px;margin:28px auto;padding:0 18px}
.cd-head{display:flex;justify-content:space-between;align-items:end;gap:18px;margin-bottom:20px}
.cd-head h1{margin:0 0 5px;font-size:28px}
.cd-head p{margin:0;color:#747a83;font-size:13px}
.cd-actions{display:flex;gap:8px;flex-wrap:wrap}
.cd-btn{display:inline-flex;align-items:center;justify-content:center;padding:9px 12px;border-radius:9px;text-decoration:none;font-size:11px;font-weight:800;border:1px solid #ddd;background:#fff;color:#333}
.cd-btn.primary{background:#c91f2e;border-color:#c91f2e;color:#fff}
.cd-alert{padding:12px 14px;border-radius:10px;margin-bottom:18px;background:#fff1f2;color:#a71928;font-size:13px}
.cd-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}
.cd-stat{background:#fff;border:1px solid #e5e8ec;border-radius:14px;padding:17px}
.cd-stat span{display:block;color:#777f88;font-size:11px}
.cd-stat strong{display:block;font-size:25px;margin-top:6px}
.cd-stat small{display:block;margin-top:5px;color:#8a9098;font-size:10px}
.cd-grid{display:grid;grid-template-columns:1.35fr .65fr;gap:18px}
.cd-card{background:#fff;border:1px solid #e5e8ec;border-radius:14px;overflow:hidden}
.cd-card-head{padding:16px 18px;border-bottom:1px solid #eef0f2;display:flex;justify-content:space-between;align-items:center}
.cd-card-head h2{margin:0;font-size:16px}
.cd-body{padding:0 18px}
.cd-table{width:100%;border-collapse:collapse}
.cd-table th,.cd-table td{padding:12px 8px;border-bottom:1px solid #eef0f2;text-align:left;vertical-align:top;font-size:11px}
.cd-table th{font-size:9px;color:#777;text-transform:uppercase;letter-spacing:.04em}
.cd-name{font-weight:800}
.cd-sub{font-size:10px;color:#858b93;margin-top:3px}
.cd-badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:800;background:#f2f3f5;color:#555}
.cd-badge.new{background:#fff4df;color:#8b6100}
.cd-badge.progress{background:#eef4ff;color:#315b9b}
.cd-empty{text-align:center;padding:30px 12px;color:#858b93;font-size:12px}
.cd-links{display:grid;gap:9px;padding:15px}
.cd-link{display:flex;align-items:center;justify-content:space-between;padding:12px 13px;border:1px solid #e5e8ec;border-radius:10px;text-decoration:none;color:#25282d;background:#fff;font-size:11px;font-weight:800}
.cd-link span{color:#8a9098;font-size:10px}
@media(max-width:950px){.cd-grid{grid-template-columns:1fr}.cd-stats{grid-template-columns:repeat(2,1fr)}}
@media(max-width:600px){.cd-wrap{padding:0 12px}.cd-head{display:block}.cd-actions{margin-top:14px}.cd-stats{grid-template-columns:1fr 1fr}.cd-table{min-width:720px}.cd-card:has(.cd-table){overflow:auto}}
</style>

<div class="cd-wrap">
    <div class="cd-head">
        <div>
            <h1>Consultancy Dashboard</h1>
            <p>Overview of consultancy enquiries, follow-ups, active files and payments.</p>
        </div>
        <div class="cd-actions">
            <a class="cd-btn primary" href="consultancy-enquiry.php">Public Enquiry Form</a>
            <a class="cd-btn" href="consultancy-enquiries.php">View Enquiries</a>
        </div>
    </div>

    <?php if ($error !== ''): ?>
        <div class="cd-alert"><?=e($error)?></div>
    <?php endif; ?>

    <div class="cd-stats">
        <div class="cd-stat">
            <span>Total Enquiries</span>
            <strong><?=number_format($stats['enquiries'])?></strong>
            <small>All consultancy enquiries</small>
        </div>
        <div class="cd-stat">
            <span>New Enquiries</span>
            <strong><?=number_format($stats['new'])?></strong>
            <small>New / unassigned</small>
        </div>
        <div class="cd-stat">
            <span>Pending Follow-ups</span>
            <strong><?=number_format($stats['followups'])?></strong>
            <small>Due within the next day</small>
        </div>
        <div class="cd-stat">
            <span>Active Files</span>
            <strong><?=number_format($stats['files'])?></strong>
            <small>Open / processing</small>
        </div>
    </div>

    <div class="cd-grid">
        <section class="cd-card">
            <div class="cd-card-head">
                <h2>Recent Enquiries</h2>
                <a class="cd-btn" href="consultancy-enquiries.php">All Enquiries</a>
            </div>

            <div class="cd-body">
                <?php if (!$recent): ?>
                    <div class="cd-empty">No consultancy enquiries found.</div>
                <?php else: ?>
                    <table class="cd-table">
                        <thead>
                            <tr>
                                <th>Student</th>
                                <th>Country</th>
                                <th>Counselor</th>
                                <th>Status</th>
                                <th>Date</th>
                                <th></th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($recent as $item): ?>
                            <?php
                                $status = (string)($item['status'] ?? '');
                                $statusClass = in_array($status, ['New','Unassigned'], true)
                                    ? 'new'
                                    : (in_array($status, ['In Progress','Counselling','Counselling Scheduled','Follow-up'], true) ? 'progress' : '');
                            ?>
                            <tr>
                                <td>
                                    <div class="cd-name"><?=e($item['full_name'])?></div>
                                    <div class="cd-sub"><?=e($item['mobile'] ?? '-')?> · <?=e($item['enquiry_no'])?></div>
                                </td>
                                <td><?=e($item['country_name'] ?? '-')?></td>
                                <td><?=e($item['counselor_name'] ?? 'Unassigned')?></td>
                                <td><span class="cd-badge <?=$statusClass?>"><?=e($status)?></span></td>
                                <td><?=e(date('d M Y', strtotime((string)$item['created_at'])))?></td>
                                <td><a class="cd-btn" href="consultancy-enquiries.php?view=<?=e((string)$item['id'])?>">Open</a></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </section>

        <aside class="cd-card">
            <div class="cd-card-head">
                <h2>Consultancy</h2>
            </div>
            <div class="cd-links">
                <a class="cd-link" href="consultancy-enquiries.php">Enquiries <span>Manage</span></a>
                <a class="cd-link" href="consultancy-followups.php">Follow-ups <span>Track</span></a>
                <a class="cd-link" href="consultancy-file-opening.php">File Opening <span>Files</span></a>
                <a class="cd-link" href="consultancy-payments.php">Consultancy Payments <span><?=e(number_format($stats['payments'],2))?> ৳</span></a>
                <a class="cd-link" href="consultancy-counselors-independent.php">Counselor Management <span>Manage</span></a>
                <a class="cd-link" href="consultancy-counselor-access.php">Counselor Access <span>Login</span></a>
            </div>
        </aside>
    </div>
</div>

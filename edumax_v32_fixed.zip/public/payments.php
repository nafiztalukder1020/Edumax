<?php
require_once __DIR__ . '/../config/app.php';
require_access('payments');

$q=trim($_GET['q']??'');
$method=$_GET['method']??'';
$from=$_GET['from']??'';
$to=$_GET['to']??'';
$where=["p.status='Valid'"]; $params=[];
if($q!==''){ $where[]='(p.receipt_no LIKE ? OR s.student_id LIKE ? OR s.full_name LIKE ? OR s.mobile LIKE ?)'; $like='%'.$q.'%'; array_push($params,$like,$like,$like,$like);}
if(in_array($method,['Cash','bKash','Nagad','Bank','Other'],true)){ $where[]='p.method=?'; $params[]=$method; }
if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)){ $where[]='DATE(p.created_at)>=?'; $params[]=$from; }
if(preg_match('/^\d{4}-\d{2}-\d{2}$/',$to)){ $where[]='DATE(p.created_at)<=?'; $params[]=$to; }
$sql="SELECT p.*,s.student_id,s.full_name,a.final_dealing_price,c.name course_name FROM payments p JOIN students s ON s.id=p.student_id JOIN admissions a ON a.id=p.admission_id JOIN courses c ON c.id=a.course_id WHERE ".implode(' AND ',$where)." ORDER BY p.id DESC LIMIT 200";
$st=$pdo->prepare($sql);$st->execute($params);$rows=$st->fetchAll();
$total=0;foreach($rows as $r)$total+=(float)$r['amount'];
require '_header.php';
?>
<div class="section-title"><div><h1>Payments</h1><p>Payment transaction history. New payments are recorded through Admission Processing or Due Payment only.</p></div></div>
<div class="card" style="margin-bottom:18px"><form method="get" class="form-grid"><div><label>Search</label><input name="q" value="<?=e($q)?>" placeholder="Receipt, Student ID, name or mobile"></div><div><label>Payment Method</label><select name="method"><option value="">All Methods</option><?php foreach(['Cash','bKash','Nagad','Bank','Other'] as $m): ?><option value="<?=e($m)?>" <?=$method===$m?'selected':''?>><?=e($m)?></option><?php endforeach;?></select></div><div><label>From</label><input type="date" name="from" value="<?=e($from)?>"></div><div><label>To</label><input type="date" name="to" value="<?=e($to)?>"></div><div style="align-self:end"><button class="btn btn-primary">Filter</button> <a class="btn btn-light" href="payments.php">Reset</a></div></form></div>
<div class="card" style="margin-bottom:18px"><div class="form-grid"><div><small>Transactions</small><strong><?=number_format(count($rows))?></strong></div><div><small>Total Amount</small><strong>৳ <?=number_format($total,2)?></strong></div></div></div>
<div class="card table-wrap"><table class="table"><tr><th>Receipt</th><th>Student</th><th>Course</th><th>Amount</th><th>Method</th><th>Date</th><th>Action</th></tr><?php foreach($rows as $r):?><tr><td><?php if(!empty($r['receipt_no'])): ?><?=e($r['receipt_no'])?><?php else: ?><span class="badge pending">Pending Approval</span><?php endif; ?></td><td><strong><?=e($r['full_name'])?></strong><br><small><?=e($r['student_id'])?></small></td><td><?=e($r['course_name'])?></td><td>৳<?=number_format((float)$r['amount'],2)?></td><td><?=e($r['method'])?></td><td><?=e($r['created_at'])?></td><td><?php if(!empty($r['receipt_no'])): ?><a class="btn btn-light" href="receipt.php?receipt=<?=urlencode($r['receipt_no'])?>" target="_blank">View Receipt</a><?php else: ?><span class="muted">Available after approval</span><?php endif; ?></td></tr><?php endforeach;?><?php if(!$rows):?><tr><td colspan="7">No payment transactions found.</td></tr><?php endif;?></table></div>
<?php require '_footer.php'; ?>
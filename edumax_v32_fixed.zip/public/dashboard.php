<?php
require_once __DIR__ . '/../config/app.php';
require_access('dashboard');

$totalStudents=(int)$pdo->query("SELECT COUNT(*) FROM students")->fetchColumn();
$mockAdmissions=0; $mockCollection=0;
try {
    $mockAdmissions=(int)$pdo->query("SELECT COUNT(*) FROM admissions a INNER JOIN courses c ON c.id=a.course_id WHERE LOWER(c.name)='mock test' AND a.status<>'Cancelled'")->fetchColumn();
    $mockCollection=(float)$pdo->query("
    SELECT GREATEST(
        COALESCE((
            SELECT SUM(p.amount)
            FROM payments p
            INNER JOIN admissions a ON a.id=p.admission_id
            INNER JOIN courses c ON c.id=a.course_id
            WHERE LOWER(c.name)='mock test'
              AND p.status='Valid'
        ),0)
        -
        COALESCE((
            SELECT SUM(r.amount)
            FROM refunds r
            INNER JOIN admissions a2 ON a2.id=r.admission_id
            INNER JOIN courses c2 ON c2.id=a2.course_id
            WHERE LOWER(c2.name)='mock test'
              AND r.status='Valid'
        ),0),
        0
    )
")->fetchColumn();
} catch(Throwable $e) {}
$mockScheduled=0; $mockCompleted=0;
try {
    $mockScheduled=(int)$pdo->query("SELECT COUNT(*) FROM mock_test_usage WHERE status='Scheduled' AND mock_date>=CURDATE()")->fetchColumn();
    $mockCompleted=(int)$pdo->query("SELECT COUNT(*) FROM mock_test_usage WHERE status='Completed' AND mock_date>=DATE_FORMAT(CURDATE(),'%Y-%m-01') AND mock_date<=CURDATE()")->fetchColumn();
} catch(Throwable $e) {}
$pending=(int)$pdo->query("SELECT COUNT(*) FROM applications WHERE status='Pending'")->fetchColumn();
$collection=(float)$pdo->query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE status='Valid' AND DATE(created_at)=CURDATE()")->fetchColumn();
$totalPaid=(float)$pdo->query("SELECT COALESCE(SUM(p.amount),0) FROM payments p WHERE p.status='Valid'")->fetchColumn();
$totalDeal=(float)$pdo->query("SELECT COALESCE(SUM(final_dealing_price),0) FROM admissions WHERE status<>'Cancelled'")->fetchColumn();
$totalDue=max(0,$totalDeal-$totalPaid);
require '_header.php';

/* Attendance dashboard summary */
$todayAttendance = ['total'=>0,'present'=>0,'absent'=>0,'rate'=>0];
try {
    $stmt = $pdo->query("
        SELECT
            COUNT(*) AS total,
            SUM(CASE WHEN status='Present' THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN status='Absent' THEN 1 ELSE 0 END) AS absent
        FROM attendance
        WHERE attendance_date = CURDATE()
    ");
    $todayAttendance = $stmt->fetch() ?: $todayAttendance;
    $todayAttendance['total'] = (int)($todayAttendance['total'] ?? 0);
    $todayAttendance['present'] = (int)($todayAttendance['present'] ?? 0);
    $todayAttendance['absent'] = (int)($todayAttendance['absent'] ?? 0);
    $todayAttendance['rate'] = $todayAttendance['total'] > 0
        ? ($todayAttendance['present'] / $todayAttendance['total']) * 100
        : 0;
} catch (Throwable $e) {}

$todayClasses = 0;
try {
    $stmt = $pdo->query("SELECT COUNT(*) FROM class_schedules WHERE class_date = CURDATE() AND status IN ('Scheduled','Rescheduled','Completed')");
    $todayClasses = (int)$stmt->fetchColumn();
} catch (Throwable $e) {}

$attendanceBatchRows = [];
try {
    $stmt = $pdo->query("
        SELECT
            b.name AS batch_name,
            c.name AS course_name,
            COUNT(att.id) AS marked,
            SUM(CASE WHEN att.status='Present' THEN 1 ELSE 0 END) AS present,
            SUM(CASE WHEN att.status='Absent' THEN 1 ELSE 0 END) AS absent
        FROM attendance att
        INNER JOIN batches b ON b.id=att.batch_id
        INNER JOIN courses c ON c.id=b.course_id
        WHERE att.attendance_date >= DATE_FORMAT(CURDATE(), '%Y-%m-01')
          AND att.attendance_date <= CURDATE()
        GROUP BY b.id, b.name, c.name
        ORDER BY b.name ASC
        LIMIT 8
    ");
    $attendanceBatchRows = $stmt->fetchAll();
} catch (Throwable $e) {}

/*
=========================================================
STEP 6 — ADMIN DASHBOARD
=========================================================
*/

$today = date('Y-m-d');
$monthStart = date('Y-m-01');

$from = $_GET['from'] ?? $monthStart;
$to   = $_GET['to'] ?? $today;

if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $from)) $from = $monthStart;
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $to)) $to = $today;

/* Total students */
$totalStudents = (int)$pdo->query("
    SELECT COUNT(*) FROM students
")->fetchColumn();

/* Pending applications */
$pendingApplications = (int)$pdo->query("
    SELECT COUNT(*) FROM applications
    WHERE status = 'Pending'
")->fetchColumn();

/* Active/approved admissions */
$activeStudents = (int)$pdo->query("
    SELECT COUNT(*) FROM admissions
    WHERE status IN ('Approved','Active')
")->fetchColumn();

/* Overall collection */
$totalCollection = (float)$pdo->query("
    SELECT GREATEST(
        COALESCE((SELECT SUM(amount) FROM payments WHERE status='Valid'),0)
        -
        COALESCE((SELECT SUM(amount) FROM refunds WHERE status='Valid'),0),
        0
    )
")->fetchColumn();

/* Overall due */
$totalDue = (float)$pdo->query("
    SELECT COALESCE(SUM(
        GREATEST(
            a.final_dealing_price
            -
            GREATEST(
                COALESCE((
                    SELECT SUM(p.amount)
                    FROM payments p
                    WHERE p.admission_id = a.id
                      AND p.status = 'Valid'
                ),0)
                -
                COALESCE((
                    SELECT SUM(r.amount)
                    FROM refunds r
                    WHERE r.admission_id = a.id
                      AND r.status = 'Valid'
                ),0),
                0
            ),
            0
        )
    ),0)
    FROM admissions a
    WHERE a.status <> 'Cancelled'
")->fetchColumn();

/* Date range collection */
$rangeStmt = $pdo->prepare("
    SELECT GREATEST(
        COALESCE((
            SELECT SUM(p.amount)
            FROM payments p
            WHERE p.status='Valid'
              AND DATE(p.created_at) BETWEEN ? AND ?
        ),0)
        -
        COALESCE((
            SELECT SUM(r.amount)
            FROM refunds r
            WHERE r.status='Valid'
              AND DATE(r.created_at) BETWEEN ? AND ?
        ),0),
        0
    )
");
$rangeStmt->execute([$from, $to, $from, $to]);
$rangeCollection = (float)$rangeStmt->fetchColumn();

/* Date range admissions */
$rangeAdmissionStmt = $pdo->prepare("
    SELECT COUNT(*)
    FROM admissions
    WHERE DATE(admission_date) BETWEEN ? AND ?
");
$rangeAdmissionStmt->execute([$from, $to]);
$rangeAdmissions = (int)$rangeAdmissionStmt->fetchColumn();

/* Recent admissions */
$recentAdmissions = $pdo->query("
    SELECT
        a.id,
        a.status,
        a.admission_date,
        a.final_dealing_price,
        s.student_id,
        s.full_name,
        s.mobile,
        c.name AS course_name,
        b.name AS batch_name,
        a.time_slot
    FROM admissions a
    INNER JOIN students s ON s.id = a.student_id
    INNER JOIN courses c ON c.id = a.course_id
    INNER JOIN batches b ON b.id = a.batch_id
    ORDER BY a.id DESC
    LIMIT 8
")->fetchAll();

/* Recent payments */
$recentPayments = $pdo->query("
    SELECT
        p.id,
        p.receipt_no,
        p.amount,
        p.method,
        p.created_at,
        s.student_id,
        s.full_name
    FROM payments p
    INNER JOIN students s ON s.id = p.student_id
    WHERE p.status='Valid'
    ORDER BY p.id DESC
    LIMIT 8
")->fetchAll();

/* Monthly collection for current year */
$monthlyStmt = $pdo->query("
    SELECT
        month_key,
        SUM(collection) AS collection
    FROM (
        SELECT
            DATE_FORMAT(p.created_at,'%Y-%m') AS month_key,
            p.amount AS collection
        FROM payments p
        WHERE p.status='Valid'
          AND YEAR(p.created_at)=YEAR(CURDATE())

        UNION ALL

        SELECT
            DATE_FORMAT(r.created_at,'%Y-%m') AS month_key,
            -r.amount AS collection
        FROM refunds r
        WHERE r.status='Valid'
          AND YEAR(r.created_at)=YEAR(CURDATE())
    ) x
    GROUP BY month_key
    ORDER BY month_key
");
$monthlyRows = $monthlyStmt->fetchAll();

/* Course-wise admissions */
$courseStmt = $pdo->query("
    SELECT
        c.name,
        COUNT(a.id) AS total
    FROM admissions a
    INNER JOIN courses c ON c.id=a.course_id
    WHERE a.status <> 'Cancelled'
    GROUP BY c.id, c.name
    ORDER BY total DESC
    LIMIT 8
");
$courseRows = $courseStmt->fetchAll();

/* Students with outstanding dues */
$dueStudents = $pdo->query("
    SELECT
        s.student_id,
        s.full_name,
        a.final_dealing_price,
        GREATEST(
            COALESCE((
                SELECT SUM(p.amount)
                FROM payments p
                WHERE p.admission_id = a.id
                  AND p.status = 'Valid'
            ),0)
            -
            COALESCE((
                SELECT SUM(r.amount)
                FROM refunds r
                WHERE r.admission_id = a.id
                  AND r.status = 'Valid'
            ),0),
            0
        ) AS total_paid,
        GREATEST(
            a.final_dealing_price -
            GREATEST(
                COALESCE((
                    SELECT SUM(p2.amount)
                    FROM payments p2
                    WHERE p2.admission_id = a.id
                      AND p2.status = 'Valid'
                ),0)
                -
                COALESCE((
                    SELECT SUM(r2.amount)
                    FROM refunds r2
                    WHERE r2.admission_id = a.id
                      AND r2.status = 'Valid'
                ),0),
                0
            ),
            0
        ) AS due
    FROM admissions a
    INNER JOIN students s ON s.id = a.student_id
    WHERE a.status <> 'Cancelled'
    HAVING due > 0
    ORDER BY due DESC
    LIMIT 6
")->fetchAll();

/* Month labels + zero-filled collection values for the current year */
$monthlyMap = [];
foreach ($monthlyRows as $row) {
    $monthlyMap[$row['month_key']] = (float)$row['collection'];
}
$monthLabels = [];
$monthValues = [];
for ($m = 1; $m <= 12; $m++) {
    $key = date('Y') . '-' . str_pad((string)$m, 2, '0', STR_PAD_LEFT);
    $monthLabels[] = date('M', strtotime($key . '-01'));
    $monthValues[] = $monthlyMap[$key] ?? 0;
}
?>

<div class="form-grid" style="margin-bottom:18px">
<div class="card"><small>Mock Admissions</small><h2><?=e((string)$mockAdmissions)?></h2></div>
<div class="card"><small>Mock Collection</small><h2>৳<?=number_format($mockCollection,2)?></h2></div>
<div class="card"><small>Upcoming Mock Schedules</small><h2><?=e((string)$mockScheduled)?></h2></div>
<div class="card"><small>Mocks Completed This Month</small><h2><?=e((string)$mockCompleted)?></h2></div>
</div>
<div class="section-title">
    <div>
        <h1>Admin Dashboard</h1>
        <p>Admission, collection and due summary</p>
    </div>
</div>

<form method="GET" class="card" style="margin-bottom:20px;">
    <div class="form-grid">
        <div class="field">
            <label>From Date</label>
            <input type="date" name="from" value="<?= e($from) ?>">
        </div>
        <div class="field">
            <label>To Date</label>
            <input type="date" name="to" value="<?= e($to) ?>">
        </div>
        <div class="field" style="display:flex;align-items:end;">
            <button class="btn btn-primary" type="submit">Apply Date Filter</button>
        </div>
    </div>
</form>

<div class="grid" style="margin-bottom:20px;">
    <div class="kpi">
        <small>Total Students</small>
        <strong><?= number_format($totalStudents) ?></strong>
    </div>
    <div class="kpi">
        <small>Active / Approved</small>
        <strong><?= number_format($activeStudents) ?></strong>
    </div>
    <div class="kpi">
        <small>Pending Applications</small>
        <strong><?= number_format($pendingApplications) ?></strong>
    </div>
    <div class="kpi">
        <small>Total Collection</small>
        <strong>৳ <?= number_format($totalCollection,2) ?></strong>
    </div>
    <div class="kpi">
        <small>Total Due</small>
        <strong>৳ <?= number_format($totalDue,2) ?></strong>
    </div>
</div>

<div class="grid" style="margin-bottom:20px;">
    <div class="kpi">
        <small>Today's Classes</small>
        <strong><?= number_format($todayClasses) ?></strong>
        <small><?= e(date('d M Y')) ?></small>
    </div>
    <div class="kpi">
        <small>Today's Present</small>
        <strong><?= number_format($todayAttendance['present']) ?></strong>
        <small>Marked attendance</small>
    </div>
    <div class="kpi">
        <small>Today's Absent</small>
        <strong><?= number_format($todayAttendance['absent']) ?></strong>
        <small>Marked attendance</small>
    </div>
    <div class="kpi">
        <small>Attendance Rate</small>
        <strong><?= number_format($todayAttendance['rate'],1) ?>%</strong>
        <small>Today's marked records</small>
    </div>
</div>

<div class="card" style="margin-bottom:20px;">
    <div class="section-title" style="margin-bottom:8px;">
        <div>
            <h2>Attendance Overview</h2>
            <p>This month's attendance by batch</p>
        </div>
        <a class="btn btn-primary" href="attendance-report.php">View Attendance Report</a>
    </div>
    <div style="overflow-x:auto;margin-top:12px;">
        <table style="width:100%;border-collapse:collapse;min-width:620px;">
            <thead>
                <tr>
                    <th style="text-align:left;padding:10px;">Batch</th>
                    <th style="text-align:left;padding:10px;">Course</th>
                    <th style="padding:10px;">Marked</th>
                    <th style="padding:10px;">Present</th>
                    <th style="padding:10px;">Absent</th>
                    <th style="padding:10px;">Rate</th>
                </tr>
            </thead>
            <tbody>
            <?php if (!$attendanceBatchRows): ?>
                <tr><td colspan="6" style="text-align:center;padding:25px;color:var(--muted);">No attendance data for this month.</td></tr>
            <?php else: ?>
                <?php foreach ($attendanceBatchRows as $ar): ?>
                    <?php $marked=(int)$ar['marked']; $present=(int)$ar['present']; $rate=$marked>0?($present/$marked)*100:0; ?>
                    <tr>
                        <td style="padding:10px;"><strong><?= e($ar['batch_name']) ?></strong></td>
                        <td style="padding:10px;"><?= e($ar['course_name']) ?></td>
                        <td style="padding:10px;text-align:center;"><?= number_format($marked) ?></td>
                        <td style="padding:10px;text-align:center;"><?= number_format($present) ?></td>
                        <td style="padding:10px;text-align:center;"><?= number_format((int)$ar['absent']) ?></td>
                        <td style="padding:10px;text-align:center;"><strong><?= number_format($rate,1) ?>%</strong></td>
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="grid" style="margin-bottom:20px;">
    <div class="kpi">
        <small>Selected Period Admissions</small>
        <strong><?= number_format($rangeAdmissions) ?></strong>
        <small><?= e($from) ?> → <?= e($to) ?></small>
    </div>
    <div class="kpi">
        <small>Selected Period Collection</small>
        <strong>৳ <?= number_format($rangeCollection,2) ?></strong>
        <small><?= e($from) ?> → <?= e($to) ?></small>
    </div>
</div>


<div class="card dashboard-chart-card" style="margin-bottom:20px;">
    <div class="section-title">
        <div>
            <h2><span class="dash-section-icon">▥</span> Monthly Collection — <?= date('Y') ?></h2>
            <p>Valid payment transactions by month</p>
        </div>
        <span class="chart-year"><?= date('Y') ?></span>
    </div>

    <div class="collection-chart" aria-label="Monthly collection chart">
        <?php
        $chartMax = max($monthValues);
        $chartMax = $chartMax > 0 ? $chartMax : 1;
        ?>
        <?php foreach ($monthValues as $i => $value): ?>
            <div class="chart-column">
                <div class="chart-value">
                    <?= $value > 0 ? '৳ '.number_format($value,0) : '—' ?>
                </div>
                <div class="chart-track">
                    <div
                        class="chart-bar"
                        style="height:<?= max(4, round(($value/$chartMax)*100)) ?>%;"
                        title="<?= $monthLabels[$i] ?>: ৳ <?= number_format($value,2) ?>"
                    ></div>
                </div>
                <div class="chart-label"><?= e($monthLabels[$i]) ?></div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

<div class="grid" style="margin-bottom:20px;">
    <div class="card">
        <h2>Recent Admissions</h2>
        <div style="overflow-x:auto;margin-top:12px;">
            <table style="width:100%;border-collapse:collapse;min-width:650px;">
                <thead>
                    <tr>
                        <th style="text-align:left;padding:9px;">Student</th>
                        <th style="text-align:left;padding:9px;">Course / Batch</th>
                        <th style="padding:9px;">Date</th>
                        <th style="padding:9px;">Status</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($recentAdmissions as $row): ?>
                    <tr>
                        <td style="padding:9px;">
                            <strong><?= e($row['full_name']) ?></strong><br>
                            <small><?= e($row['student_id']) ?></small>
                        </td>
                        <td style="padding:9px;">
                            <strong><?= e($row['course_name']) ?></strong><br>
                            <small><?= e($row['batch_name']) ?><?= !empty($row['time_slot']) ? ' • '.e($row['time_slot']) : '' ?></small>
                        </td>
                        <td style="padding:9px;text-align:center;"><?= e($row['admission_date']) ?></td>
                        <td style="padding:9px;text-align:center;"><?= e($row['status']) ?></td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card">
        <h2>Recent Payments</h2>
        <div style="overflow-x:auto;margin-top:12px;">
            <table style="width:100%;border-collapse:collapse;min-width:600px;">
                <thead>
                    <tr>
                        <th style="text-align:left;padding:9px;">Student</th>
                        <th style="padding:9px;">Amount</th>
                        <th style="padding:9px;">Method</th>
                    </tr>
                </thead>
                <tbody>
                <?php foreach ($recentPayments as $row): ?>
                    <tr>
                        <td style="padding:9px;">
                            <strong><?= e($row['full_name']) ?></strong><br>
                            <small><?= e($row['receipt_no']) ?></small>
                        </td>
                        <td style="padding:9px;text-align:center;">
                            ৳ <?= number_format((float)$row['amount'],2) ?>
                        </td>
                        <td style="padding:9px;text-align:center;">
                            <?= e($row['method']) ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<div class="card">
    <h2>Course-wise Admissions</h2>

    <div style="overflow-x:auto;margin-top:12px;">
        <table style="width:100%;border-collapse:collapse;">
            <thead>
                <tr>
                    <th style="text-align:left;padding:10px;">Course</th>
                    <th style="text-align:right;padding:10px;">Students</th>
                </tr>
            </thead>
            <tbody>
            <?php foreach ($courseRows as $row): ?>
                <tr>
                    <td style="padding:10px;"><?= e($row['name']) ?></td>
                    <td style="padding:10px;text-align:right;"><?= number_format((int)$row['total']) ?></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<div class="card edmx-card" style="margin-top:18px"><h2>Mock Test Overview</h2><div class="form-grid"><div><small>Mock Admissions</small><strong><?=number_format($mockAdmissions)?></strong></div><div><small>Mock Collection</small><strong>৳ <?=number_format($mockCollection,2)?></strong></div><div><small>Schedule</small><strong>Monday & Wednesday</strong></div><div><small>Time</small><strong>10:00 AM – 1:00 PM</strong></div></div></div>

<?php require '_footer.php'; ?>

<?php
$upcomingClasses = [];
try {
    $stmtClass = $pdo->prepare("SELECT cs.*, b.name AS batch_name, c.name AS course_name
        FROM class_schedules cs
        JOIN batches b ON b.id=cs.batch_id
        JOIN courses c ON c.id=b.course_id
        WHERE cs.class_date >= CURDATE() AND cs.status IN ('Scheduled','Rescheduled')
        ORDER BY cs.class_date ASC, cs.time_slot ASC LIMIT 8");
    $stmtClass->execute();
    $upcomingClasses = $stmtClass->fetchAll();
} catch (Throwable $e) {}
?>
<div class="card" style="margin-top:20px;">
  <div style="padding:18px;display:flex;justify-content:space-between;align-items:center;border-bottom:1px solid var(--border);">
    <div><strong>Upcoming Classes</strong><div style="color:var(--muted);font-size:12px;margin-top:4px;">Next scheduled sessions</div></div>
    <a class="btn btn-primary" href="class-management.php">Manage Classes</a>
  </div>
  <div class="table-wrap">
    <table class="table">
      <thead><tr><th>Date</th><th>Time</th><th>Batch</th><th>Topic</th><th>Teacher</th><th>Status</th></tr></thead>
      <tbody>
      <?php if (!$upcomingClasses): ?><tr><td colspan="6" style="text-align:center;padding:25px;">No upcoming classes.</td></tr><?php endif; ?>
      <?php foreach($upcomingClasses as $cc): ?>
        <tr>
          <td><?=e(date('d M Y',strtotime($cc['class_date'])))?></td>
          <td><?=e($cc['time_slot'])?></td>
          <td><strong><?=e($cc['batch_name'])?></strong><br><small><?=e($cc['course_name'])?></small></td>
          <td><?=e($cc['topic'] ?: '-')?></td>
          <td><?=e($cc['teacher_name'] ?: '-')?></td>
          <td><?=e($cc['status'])?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

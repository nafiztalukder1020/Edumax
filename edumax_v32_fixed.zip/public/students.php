<?php
require_once __DIR__ . '/../config/app.php';
require_access('students');
ensure_archive_columns();
$q = trim($_GET['q'] ?? '');
$statusFilter = trim($_GET['status'] ?? '');
$courseFilter = trim($_GET['course'] ?? '');
$batchFilter = (int)($_GET['batch_id'] ?? 0);
$archiveFilter = trim($_GET['archive'] ?? 'current');
if (!in_array($archiveFilter, ['current','archived','all'], true)) $archiveFilter = 'current';

// Delete a pending application only. Processed admissions are never deleted from this screen.
$deleteError = '';
$deleteSuccess = '';

$importError = '';
$importSuccess = '';
$importReport = [];

function student_import_slots(string $raw): array {
    $raw = trim($raw);
    if ($raw === '') return [];
    $decoded = json_decode($raw, true);
    if (is_array($decoded)) {
        $out = [];
        foreach ($decoded as $v) {
            $v = trim((string)$v);
            if ($v !== '' && !in_array($v, $out, true)) $out[] = $v;
        }
        return $out;
    }
    $out = [];
    foreach (preg_split('/[,|]+/', $raw) as $v) {
        $v = trim((string)$v);
        if ($v !== '' && !in_array($v, $out, true)) $out[] = $v;
    }
    return $out;
}

/*
 * Bulk batch import:
 * Import existing students from a CSV exported from Excel.
 * Required column: Student ID
 * The student's latest non-cancelled admission is moved to the selected
 * batch/time slot. No new student/admission/payment is created.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import_batch_students') {
    require_valid_csrf();

    $targetBatchId = (int)($_POST['import_batch_id'] ?? 0);
    $targetSlot = trim((string)($_POST['import_time_slot'] ?? ''));

    if ($targetBatchId <= 0) {
        $importError = 'Please select a target batch.';
    } elseif (!isset($_FILES['student_csv']) || (int)($_FILES['student_csv']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $importError = 'Please upload a CSV file exported from Excel.';
    } else {
        $file = $_FILES['student_csv'];
        $size = (int)($file['size'] ?? 0);
        $name = (string)($file['name'] ?? '');
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

        if ($size <= 0 || $size > 5 * 1024 * 1024) {
            $importError = 'CSV file must be between 1 byte and 5 MB.';
        } elseif (!in_array($ext, ['csv','txt'], true)) {
            $importError = 'Only CSV/TXT files are supported. In Excel, use Save As → CSV UTF-8.';
        } else {
            try {
                $batchStmt = $pdo->prepare("
                    SELECT id, course_id, name, status, is_archived, time_slots, max_students, slot_capacities
                    FROM batches
                    WHERE id=?
                    LIMIT 1
                ");
                $batchStmt->execute([$targetBatchId]);
                $targetBatch = $batchStmt->fetch();

                if (!$targetBatch) {
                    throw new RuntimeException('Selected batch was not found.');
                }
                if ((int)$targetBatch['is_archived'] === 1 || ($targetBatch['status'] ?? '') === 'Closed') {
                    throw new RuntimeException('Archived/Closed batches cannot receive imported students.');
                }

                $targetSlots = student_import_slots((string)($targetBatch['time_slots'] ?? ''));
                if ($targetSlots && $targetSlot === '') {
                    throw new RuntimeException('Please select a time slot for the selected batch.');
                }
                if ($targetSlots && !in_array($targetSlot, $targetSlots, true)) {
                    throw new RuntimeException('Selected time slot is not available in the target batch.');
                }

                $fh = fopen($file['tmp_name'], 'rb');
                if (!$fh) throw new RuntimeException('Could not read the uploaded CSV file.');

                $header = fgetcsv($fh);
                if (!$header) {
                    fclose($fh);
                    throw new RuntimeException('The CSV file is empty.');
                }

                $normalizeHeader = static function($v) {
                    $v = trim((string)$v);
                    $v = preg_replace('/^\xEF\xBB\xBF/', '', $v);
                    return strtolower(preg_replace('/[^a-z0-9]+/', '_', $v));
                };

                $headerMap = [];
                foreach ($header as $i => $h) {
                    $headerMap[$normalizeHeader($h)] = $i;
                }

                $studentIdCol = null;
                foreach (['student_id','studentid','student_code','id'] as $candidate) {
                    if (array_key_exists($candidate, $headerMap)) {
                        $studentIdCol = $headerMap[$candidate];
                        break;
                    }
                }
                if ($studentIdCol === null) {
                    fclose($fh);
                    throw new RuntimeException('CSV must contain a "Student ID" column.');
                }

                $studentCodes = [];
                while (($row = fgetcsv($fh, 0, $delimiter)) !== false) {
                    $rawCode = trim((string)($row[$studentIdCol] ?? ''));
                    if ($rawCode !== '') $studentCodes[] = $rawCode;
                }
                fclose($fh);

                $studentCodes = array_values(array_unique($studentCodes));
                if (!$studentCodes) throw new RuntimeException('No Student IDs were found in the CSV file.');
                if (count($studentCodes) > 500) throw new RuntimeException('Maximum 500 students can be imported at once.');

                $pdo->beginTransaction();

                // Lock target batch for a consistent capacity check.
                $lockBatch = $pdo->prepare("
                    SELECT id, course_id, name, status, is_archived, time_slots, max_students, slot_capacities
                    FROM batches
                    WHERE id=?
                    FOR UPDATE
                ");
                $lockBatch->execute([$targetBatchId]);
                $targetBatch = $lockBatch->fetch();
                if (!$targetBatch || (int)$targetBatch['is_archived'] === 1 || ($targetBatch['status'] ?? '') === 'Closed') {
                    throw new RuntimeException('Target batch is no longer available.');
                }

                $targetSlots = student_import_slots((string)($targetBatch['time_slots'] ?? ''));
                if ($targetSlots && !in_array($targetSlot, $targetSlots, true)) {
                    throw new RuntimeException('Selected time slot is no longer available in the target batch.');
                }

                $isICU = stripos((string)$targetBatch['name'], 'ICU') !== false;

                // Existing target occupancy, excluding cancelled admissions.
                $occupied = 0;
                if (!$isICU && $targetSlot !== '') {
                    $occ = $pdo->prepare("
                        SELECT COUNT(*)
                        FROM admissions
                        WHERE batch_id=? AND time_slot=? AND status <> 'Cancelled'
                    ");
                    $occ->execute([$targetBatchId, $targetSlot]);
                    $occupied = (int)$occ->fetchColumn();
                }

                $findStudent = $pdo->prepare("SELECT id, student_id, full_name FROM students WHERE student_id=? LIMIT 1");
                $findAdmission = $pdo->prepare("
                    SELECT a.id, a.course_id, a.batch_id, a.time_slot, a.status
                    FROM admissions a
                    WHERE a.student_id=? AND a.status <> 'Cancelled'
                    ORDER BY a.id DESC
                    LIMIT 1
                    FOR UPDATE
                ");
                $history = $pdo->prepare("
                    INSERT INTO student_batch_transfers
                    (student_id, admission_id, from_batch_id, from_time_slot, to_batch_id, to_time_slot, reason, transferred_by)
                    VALUES (?,?,?,?,?,?,?,?)
                ");
                $updateAdmission = $pdo->prepare("
                    UPDATE admissions
                    SET batch_id=?, time_slot=?
                    WHERE id=? AND student_id=?
                ");
                $auditImport = $pdo->prepare("
                    INSERT INTO audit_logs (user_id, action, student_id, details)
                    VALUES (?,?,?,?)
                ");

                $seen = [];
                foreach ($studentCodes as $code) {
                    if (isset($seen[$code])) continue;
                    $seen[$code] = true;

                    $findStudent->execute([$code]);
                    $student = $findStudent->fetch();
                    if (!$student) {
                        $importReport[] = ['code'=>$code, 'status'=>'Failed', 'reason'=>'Student ID not found.'];
                        continue;
                    }

                    $findAdmission->execute([(int)$student['id']]);
                    $current = $findAdmission->fetch();
                    if (!$current) {
                        $importReport[] = ['code'=>$code, 'status'=>'Failed', 'reason'=>'No active/non-cancelled admission found.'];
                        continue;
                    }

                    if ((int)$current['course_id'] !== (int)$targetBatch['course_id']) {
                        $importReport[] = ['code'=>$code, 'status'=>'Failed', 'reason'=>'Student course does not match target batch course.'];
                        continue;
                    }

                    $fromBatchId = (int)$current['batch_id'];
                    $fromSlot = trim((string)($current['time_slot'] ?? ''));

                    if ($fromBatchId === $targetBatchId && $fromSlot === $targetSlot) {
                        $importReport[] = ['code'=>$code, 'status'=>'Skipped', 'reason'=>'Already in selected batch/time slot.'];
                        continue;
                    }

                    if (!$isICU && $targetSlot !== '') {
                        // Do not count the same admission as a new seat when moving within the same batch.
                        $extra = ($fromBatchId === $targetBatchId && $fromSlot === $targetSlot) ? 0 : 1;
                        $slotCapacityMap = json_decode((string)($targetBatch['slot_capacities'] ?? ''), true);
                        $targetCapacity = (is_array($slotCapacityMap) && isset($slotCapacityMap[$targetSlot])) ? max(1,(int)$slotCapacityMap[$targetSlot]) : max(1,(int)($targetBatch['max_students'] ?? 50));
                        if ($occupied + $extra > $targetCapacity) {
                            $importReport[] = ['code'=>$code, 'status'=>'Failed', 'reason'=>'Target time slot is full ('.$targetCapacity.' students).'];
                            continue;
                        }
                    }

                    $history->execute([
                        (int)$student['id'],
                        (int)$current['id'],
                        $fromBatchId > 0 ? $fromBatchId : null,
                        $fromSlot !== '' ? $fromSlot : null,
                        $targetBatchId,
                        $targetSlot !== '' ? $targetSlot : null,
                        'Bulk batch import',
                        (int)($_SESSION['user_id'] ?? 0)
                    ]);

                    $updateAdmission->execute([
                        $targetBatchId,
                        $targetSlot !== '' ? $targetSlot : null,
                        (int)$current['id'],
                        (int)$student['id']
                    ]);

                    if ($updateAdmission->rowCount() !== 1) {
                        throw new RuntimeException('Could not update admission for '.$code.'.');
                    }

                    $auditImport->execute([
                        (int)($_SESSION['user_id'] ?? 0),
                        'Bulk Batch Import',
                        (int)$student['id'],
                        'Moved '.$code.' from batch #'.$fromBatchId.' / '.$fromSlot.' to batch #'.$targetBatchId.' / '.$targetSlot
                    ]);

                    if (!$isICU && $targetSlot !== '') $occupied++;

                    $importReport[] = ['code'=>$code, 'status'=>'Imported', 'reason'=>'Moved successfully.'];
                }

                $pdo->commit();

                $imported = count(array_filter($importReport, fn($r) => $r['status'] === 'Imported'));
                $failed = count(array_filter($importReport, fn($r) => $r['status'] === 'Failed'));
                $skipped = count(array_filter($importReport, fn($r) => $r['status'] === 'Skipped'));
                $importSuccess = "Batch import completed: {$imported} imported, {$skipped} skipped, {$failed} failed.";
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $importError = $e->getMessage();
                $importReport = [];
            }
        }
    }
}


/*
 * Import real / legacy student records from an Excel-exported CSV.
 * This creates a complete student + application + admission + payment history.
 * Student IDs are generated by the system; existing mobile numbers are skipped
 * to prevent duplicate student records.
 */
$realImportError = '';
$realImportSuccess = '';
$realImportReport = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'import_real_students') {
    require_valid_csrf();

    $targetBatchId = (int)($_POST['real_import_batch_id'] ?? 0);
    $targetSlot = trim((string)($_POST['real_import_time_slot'] ?? ''));
    $paymentMethod = trim((string)($_POST['real_import_payment_method'] ?? 'Other'));

    if (!in_array($paymentMethod, ['Cash','bKash','Nagad','Bank','Other'], true)) {
        $realImportError = 'Invalid payment method.';
    } elseif ($targetBatchId <= 0) {
        $realImportError = 'Please select the target batch.';
    } elseif (!isset($_FILES['real_student_csv']) || (int)($_FILES['real_student_csv']['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) {
        $realImportError = 'Please upload the real student CSV file.';
    } else {
        $file = $_FILES['real_student_csv'];
        $size = (int)($file['size'] ?? 0);
        $name = (string)($file['name'] ?? '');
        $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));

        if ($size <= 0 || $size > 5 * 1024 * 1024) {
            $realImportError = 'CSV file must be between 1 byte and 5 MB.';
        } elseif (!in_array($ext, ['csv','txt'], true)) {
            $realImportError = 'Only CSV/TXT files are supported. Excel → Save As → CSV UTF-8.';
        } else {
            try {
                $batchStmt = $pdo->prepare("
                    SELECT b.id,b.course_id,b.name,b.status,b.is_archived,b.time_slots,b.max_students,b.slot_capacities,c.name AS course_name
                    FROM batches b
                    INNER JOIN courses c ON c.id=b.course_id
                    WHERE b.id=?
                    LIMIT 1
                ");
                $batchStmt->execute([$targetBatchId]);
                $targetBatch = $batchStmt->fetch();

                if (!$targetBatch) throw new RuntimeException('Selected batch was not found.');
                if ((int)$targetBatch['is_archived'] === 1 || ($targetBatch['status'] ?? '') === 'Closed') {
                    throw new RuntimeException('Archived/Closed batches cannot receive imported students.');
                }

                $targetSlots = student_import_slots((string)($targetBatch['time_slots'] ?? ''));
                if ($targetSlots && $targetSlot === '') {
                    throw new RuntimeException('Please select a time slot for the selected batch.');
                }
                if ($targetSlots && !in_array($targetSlot, $targetSlots, true)) {
                    throw new RuntimeException('Selected time slot is not available in the target batch.');
                }

                $fh = fopen($file['tmp_name'], 'rb');
                if (!$fh) throw new RuntimeException('Could not read the uploaded CSV file.');

                /*
                 * Read the first line and detect the delimiter used by Excel.
                 * Some Excel exports use comma, semicolon or tab depending on
                 * regional settings. This also makes header matching tolerant
                 * of BOM, extra spaces and punctuation.
                 */
                $firstLine = fgets($fh);
                if ($firstLine === false) {
                    fclose($fh);
                    throw new RuntimeException('The CSV file is empty.');
                }

                $delimiter = ',';
                $delimiterCounts = [
                    ',' => substr_count($firstLine, ','),
                    ';' => substr_count($firstLine, ';'),
                    "\t" => substr_count($firstLine, "\t"),
                ];
                arsort($delimiterCounts);
                $detectedDelimiter = array_key_first($delimiterCounts);
                if (($delimiterCounts[$detectedDelimiter] ?? 0) > 0) {
                    $delimiter = $detectedDelimiter;
                }
                rewind($fh);

                $header = fgetcsv($fh, 0, $delimiter);
                if (!$header) {
                    fclose($fh);
                    throw new RuntimeException('The CSV file is empty.');
                }

                $normalizeHeader = static function($v) {
                    $v = trim((string)$v);
                    $v = preg_replace('/^\xEF\xBB\xBF/', '', $v);
                    $v = preg_replace('/[^a-zA-Z0-9]+/', '_', $v);
                    return strtolower(trim($v, '_'));
                };

                // Secondary key removes underscores/spaces so headers such as
                // "Student Name", "student_name" and "Student-Name" all match.
                $headerMap = [];
                $headerLooseMap = [];
                foreach ($header as $i => $h) {
                    $normalized = $normalizeHeader($h);
                    $headerMap[$normalized] = $i;
                    $headerLooseMap[preg_replace('/[^a-z0-9]/', '', $normalized)] = $i;
                }

                $findCol = static function(array $map, array $looseMap, array $candidates) {
                    foreach ($candidates as $candidate) {
                        if (array_key_exists($candidate, $map)) return $map[$candidate];
                        $loose = preg_replace('/[^a-z0-9]/', '', strtolower($candidate));
                        if (array_key_exists($loose, $looseMap)) return $looseMap[$loose];
                    }
                    return null;
                };

                $nameCol = $findCol($headerMap, $headerLooseMap, ['student_name','name','full_name']);
                $mobileCol = $findCol($headerMap, $headerLooseMap, ['student_phone_num','student_phone','mobile','phone']);
                $guardianCol = $findCol($headerMap, $headerLooseMap, ['gurdian_phone_num','guardian_phone_num','guardian_mobile','guardian_phone']);
                $dateCol = $findCol($headerMap, $headerLooseMap, ['date','admission_date']);
                $dealCol = $findCol($headerMap, $headerLooseMap, ['dealing_price','final_dealing_price','deal_price']);
                $firstCol = $findCol($headerMap, $headerLooseMap, ['1st_payment','first_payment','payment_1']);
                $secondCol = $findCol($headerMap, $headerLooseMap, ['2nd_payment','second_payment','payment_2']);
                $totalCol = $findCol($headerMap, $headerLooseMap, ['total_payment','paid','total_paid']);
                $dueCol = $findCol($headerMap, $headerLooseMap, ['due','due_amount']);
                $memoCol = $findCol($headerMap, $headerLooseMap, ['memo_num','memo_number','memo']);
                $referenceCol = $findCol($headerMap, $headerLooseMap, ['reference','lead_source']);
                $idCardCol = $findCol($headerMap, $headerLooseMap, ['id_card','idcard']);

                if ($nameCol === null || $mobileCol === null || $dateCol === null || $dealCol === null) {
                    fclose($fh);
                    throw new RuntimeException('CSV needs at least: Student Name, Student Phone Num, Date and Dealing Price columns.');
                }

                $records = [];
                while (($row = fgetcsv($fh)) !== false) {
                    $get = static function($col) use ($row) {
                        return $col === null ? '' : trim((string)($row[$col] ?? ''));
                    };

                    $nameValue = $get($nameCol);
                    $mobileValue = $get($mobileCol);
                    if ($nameValue === '' && $mobileValue === '') continue;

                    $records[] = [
                        'name'=>$nameValue,
                        'mobile'=>$mobileValue,
                        'guardian_mobile'=>$get($guardianCol),
                        'date'=>$get($dateCol),
                        'deal'=>$get($dealCol),
                        'first'=>$get($firstCol),
                        'second'=>$get($secondCol),
                        'total'=>$get($totalCol),
                        'due'=>$get($dueCol),
                        'memo'=>$get($memoCol),
                        'reference'=>$get($referenceCol),
                        'id_card'=>$get($idCardCol),
                    ];
                }
                fclose($fh);

                if (!$records) throw new RuntimeException('No student records were found in the CSV.');
                if (count($records) > 500) throw new RuntimeException('Maximum 500 students can be imported at once.');

                $pdo->beginTransaction();

                $lockBatch = $pdo->prepare("
                    SELECT b.id,b.course_id,b.name,b.status,b.is_archived,b.time_slots,b.max_students,b.slot_capacities,c.name AS course_name
                    FROM batches b INNER JOIN courses c ON c.id=b.course_id
                    WHERE b.id=? FOR UPDATE
                ");
                $lockBatch->execute([$targetBatchId]);
                $targetBatch = $lockBatch->fetch();
                if (!$targetBatch || (int)$targetBatch['is_archived'] === 1 || ($targetBatch['status'] ?? '') === 'Closed') {
                    throw new RuntimeException('Target batch is no longer available.');
                }

                $targetSlots = student_import_slots((string)($targetBatch['time_slots'] ?? ''));
                if ($targetSlots && !in_array($targetSlot, $targetSlots, true)) {
                    throw new RuntimeException('Selected time slot is no longer available.');
                }

                $isICU = stripos((string)$targetBatch['name'], 'ICU') !== false;
                $occupied = 0;
                if (!$isICU && $targetSlot !== '') {
                    $occ = $pdo->prepare("SELECT COUNT(*) FROM admissions WHERE batch_id=? AND time_slot=? AND status<>'Cancelled'");
                    $occ->execute([$targetBatchId,$targetSlot]);
                    $occupied = (int)$occ->fetchColumn();
                }

                $year = (int)date('Y');
                $seqStmt = $pdo->prepare("SELECT COALESCE(MAX(CAST(SUBSTRING_INDEX(student_id,'-',-1) AS UNSIGNED)),0) FROM students WHERE student_id LIKE ?");
                $seqStmt->execute(['EDU-'.$year.'-%']);
                $nextSequence = (int)$seqStmt->fetchColumn() + 1;

                $findExisting = $pdo->prepare("SELECT id,student_id,full_name FROM students WHERE mobile=? LIMIT 1");
                $insertStudent = $pdo->prepare("
                    INSERT INTO students
                    (student_id,full_name,mobile,guardian_name,guardian_mobile,date_of_birth,gender,email,blood_group,present_address,passport_number)
                    VALUES (?,?,?,NULL,?,NULL,NULL,NULL,NULL,NULL,NULL)
                ");
                $insertApplication = $pdo->prepare("
                    INSERT INTO applications
                    (student_id,status,course_interest,lead_source,ielts_reading,ielts_writing,ielts_listening,ielts_speaking,ielts_overall)
                    VALUES (?,'Active',?, ?,NULL,NULL,NULL,NULL,NULL)
                ");
                $insertAdmission = $pdo->prepare("
                    INSERT INTO admissions
                    (student_id,course_id,batch_id,time_slot,admission_date,counsellor,
                     regular_fee,regular_discount_percent,regular_discount_amount,discount,
                     special_discount_percent,special_discount_amount,do_discount,
                     final_dealing_price,reference,status,mock_package,mock_day,mock_dates)
                    VALUES (?,?,?,?,?,NULL,?,?,?,?,?,?,?,?,?,?,NULL,NULL,NULL)
                ");
                $insertPayment = $pdo->prepare("
                    INSERT INTO payments
                    (student_id,admission_id,receipt_no,amount,method,note,received_by,status,created_at)
                    VALUES (?,?,?,?,?,?,?,'Valid',?)
                ");
                $insertMaterial = $pdo->prepare("
                    INSERT INTO student_materials
                    (student_id,material_type,status,given_at,given_by)
                    VALUES (?,?, 'Given',NOW(),?)
                    ON DUPLICATE KEY UPDATE status='Given',given_at=NOW(),given_by=VALUES(given_by)
                ");
                $audit = $pdo->prepare("
                    INSERT INTO audit_logs (user_id,action,student_id,details)
                    VALUES (?,?,?,?)
                ");

                foreach ($records as $rec) {
                    $nameValue = trim($rec['name']);
                    $mobileValue = normalize_bd_mobile($rec['mobile']);
                    $guardianValue = normalize_bd_mobile($rec['guardian_mobile']);

                    if ($nameValue === '' || $mobileValue === '') {
                        $realImportReport[] = ['name'=>$nameValue ?: '-', 'status'=>'Failed', 'reason'=>'Student Name or Mobile is missing.'];
                        continue;
                    }

                    $dateRaw = trim($rec['date']);
                    $admissionDate = '';
                    $dateObj = DateTime::createFromFormat('d.m.Y',$dateRaw);
                    if ($dateObj && $dateObj->format('d.m.Y') === $dateRaw) {
                        $admissionDate = $dateObj->format('Y-m-d');
                    } else {
                        $dateObj = DateTime::createFromFormat('Y-m-d',$dateRaw);
                        if ($dateObj && $dateObj->format('Y-m-d') === $dateRaw) $admissionDate = $dateRaw;
                    }
                    if ($admissionDate === '') {
                        $realImportReport[] = ['name'=>$nameValue, 'status'=>'Failed', 'reason'=>'Invalid Date: '.$dateRaw];
                        continue;
                    }
                    if ($admissionDate > date('Y-m-d')) {
                        // Typos like 24.08.2028 used to be imported as future admissions/payments.
                        $realImportReport[] = ['name'=>$nameValue, 'status'=>'Failed', 'reason'=>'Admission date is in the future: '.$dateRaw];
                        continue;
                    }
                    if (!preg_match('/^01[3-9][0-9]{8}$/', $mobileValue)) {
                        $realImportReport[] = ['name'=>$nameValue, 'status'=>'Failed', 'reason'=>'Invalid mobile number: '.$rec['mobile']];
                        continue;
                    }

                    $deal = (float)preg_replace('/[^\d.\-]/','', $rec['deal']);
                    $first = (float)preg_replace('/[^\d.\-]/','', $rec['first']);
                    $second = (float)preg_replace('/[^\d.\-]/','', $rec['second']);
                    $csvTotal = (float)preg_replace('/[^\d.\-]/','', $rec['total']);
                    $csvDue = (float)preg_replace('/[^\d.\-]/','', $rec['due']);
                    $paid = max(0,$first) + max(0,$second);

                    if ($deal < 0 || $paid < 0) {
                        $realImportReport[] = ['name'=>$nameValue, 'status'=>'Failed', 'reason'=>'Invalid financial value.'];
                        continue;
                    }

                    $findExisting->execute([$mobileValue]);
                    $existing = $findExisting->fetch();
                    if ($existing) {
                        $realImportReport[] = ['name'=>$nameValue, 'status'=>'Skipped', 'reason'=>'Mobile already exists as '.$existing['student_id'].'.'];
                        continue;
                    }

                    if (!$isICU && $targetSlot !== '') {
                        $slotCapacityMap = json_decode((string)($targetBatch['slot_capacities'] ?? ''), true);
                        $targetCapacity = (is_array($slotCapacityMap) && isset($slotCapacityMap[$targetSlot])) ? max(1,(int)$slotCapacityMap[$targetSlot]) : max(1,(int)($targetBatch['max_students'] ?? 50));
                        if (($occupied + 1) > $targetCapacity) {
                            $realImportReport[] = ['name'=>$nameValue, 'status'=>'Failed', 'reason'=>'Target time slot is full ('.$targetCapacity.' students).'];
                            continue;
                        }
                    }

                    $studentId = 'EDU-'.$year.'-'.str_pad((string)$nextSequence,4,'0',STR_PAD_LEFT);
                    $nextSequence++;

                    $insertStudent->execute([
                        $studentId,$nameValue,$mobileValue,$guardianValue !== '' ? $guardianValue : null
                    ]);
                    $studentPk = (int)$pdo->lastInsertId();

                    $status = ($paid + 0.0001 >= $deal) ? 'Active' : 'Approved';
                    $leadSource = trim($rec['reference']) !== '' ? trim($rec['reference']) : null;
                    $memo = trim($rec['memo']) !== '' ? 'Imported Excel Memo: '.trim($rec['memo']) : 'Imported from Excel';
                    $finalDue = max(0,$deal-$paid);

                    $insertApplication->execute([$studentPk,$targetBatch['course_name'],$leadSource]);
                    $applicationId = (int)$pdo->lastInsertId();

                    $insertAdmission->execute([
                        $studentPk,(int)$targetBatch['course_id'],$targetBatchId,
                        $targetSlot !== '' ? $targetSlot : null,$admissionDate,
                        $deal,0,0,0,0,0,0,$deal,$leadSource,$status
                    ]);
                    $admissionId = (int)$pdo->lastInsertId();

                    $paymentReceipts = [];
                    if ($first > 0.0001) {
                        $receipt = next_receipt_number();
                        $insertPayment->execute([
                            $studentPk,$admissionId,$receipt,$first,$paymentMethod,
                            $memo.' | 1st Payment'.($rec['memo']!==''?' | Memo: '.$rec['memo']:''),
                            (int)($_SESSION['user_id'] ?? 0),$admissionDate.' 12:00:00'
                        ]);
                        $paymentReceipts[] = $receipt;
                    }
                    if ($second > 0.0001) {
                        $receipt = next_receipt_number();
                        $insertPayment->execute([
                            $studentPk,$admissionId,$receipt,$second,$paymentMethod,
                            $memo.' | 2nd Payment'.($rec['memo']!==''?' | Memo: '.$rec['memo']:''),
                            (int)($_SESSION['user_id'] ?? 0),$admissionDate.' 12:00:00'
                        ]);
                        $paymentReceipts[] = $receipt;
                    }

                    if (strcasecmp(trim($rec['id_card']),'OK')===0) {
                        $insertMaterial->execute([$studentPk,'ID Card',(int)($_SESSION['user_id'] ?? 0)]);
                    }

                    $audit->execute([
                        (int)($_SESSION['user_id'] ?? 0),
                        'Real Student Import',
                        $studentPk,
                        'Imported '.$studentId.' | '.$nameValue.' | Course: '.$targetBatch['course_name'].' | Batch: '.$targetBatch['name'].' | Deal: '.$deal.' | Paid: '.$paid.' | CSV Due: '.$csvDue.' | Calculated Due: '.$finalDue.' | Receipts: '.($paymentReceipts ? implode(', ',$paymentReceipts) : 'none')
                    ]);

                    if (!$isICU && $targetSlot !== '') $occupied++;

                    $reason = 'Imported successfully.';
                    if (abs($csvTotal - $paid) > 0.01 && $csvTotal > 0) {
                        $reason .= ' CSV Total Payment differs from 1st + 2nd payment; system used 1st + 2nd.';
                    }
                    if (abs($csvDue - $finalDue) > 0.01 && ($rec['due'] ?? '') !== '') {
                        $reason .= ' CSV Due differs from calculated due; system used calculated due.';
                    }

                    $realImportReport[] = ['name'=>$nameValue,'status'=>'Imported','reason'=>$studentId.' | '.$reason];
                }

                $pdo->commit();

                $imported = count(array_filter($realImportReport, fn($r)=>$r['status']==='Imported'));
                $failed = count(array_filter($realImportReport, fn($r)=>$r['status']==='Failed'));
                $skipped = count(array_filter($realImportReport, fn($r)=>$r['status']==='Skipped'));
                $realImportSuccess = "Real student import completed: {$imported} imported, {$skipped} skipped, {$failed} failed.";
            } catch (Throwable $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $realImportError = $e->getMessage();
                $realImportReport = [];
            }
        }
    }
}

/*
 * Safe cleanup delete:
 * A processed student is never blindly hard-deleted. Super Admin can delete
 * only a student whose admissions are all Cancelled AND who has no financial,
 * attendance, performance, materials or refund history.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_student_cleanup') {
    require_valid_csrf();

    if (!is_super_admin()) {
        http_response_code(403);
        exit('Only Super Admin can permanently delete student records.');
    }

    $studentId = (int)($_POST['student_db_id'] ?? 0);

    if ($studentId <= 0) {
        $deleteError = 'Invalid student selected.';
    } else {
        try {
            $pdo->beginTransaction();

            $check = $pdo->prepare("
                SELECT
                    s.id, s.student_id, s.full_name,
                    (SELECT COUNT(*) FROM admissions a WHERE a.student_id=s.id) AS admission_count,
                    (SELECT COUNT(*) FROM admissions a WHERE a.student_id=s.id AND a.status <> 'Cancelled') AS live_admission_count,
                    (SELECT COUNT(*) FROM payments p WHERE p.student_id=s.id) AS payment_count,
                    (SELECT COUNT(*) FROM refunds r WHERE r.student_id=s.id) AS refund_count,
                    (SELECT COUNT(*) FROM attendance atn WHERE atn.student_id=s.id) AS attendance_count,
                    (SELECT COUNT(*) FROM performance_evaluations pe WHERE pe.student_id=s.id) AS performance_count,
                    (SELECT COUNT(*) FROM student_materials sm WHERE sm.student_id=s.id) AS material_count,
                    (SELECT COUNT(*) FROM guardian_report_links gr WHERE gr.student_id=s.id) AS guardian_link_count
                FROM students s
                WHERE s.id=?
                LIMIT 1
            ");
            $check->execute([$studentId]);
            $target = $check->fetch();

            if (!$target) throw new RuntimeException('Student not found.');

            if ((int)$target['live_admission_count'] > 0) {
                throw new RuntimeException('This student still has an active/approved admission. Cancel it first.');
            }

            $protectedCounts = [
                'payment' => (int)$target['payment_count'],
                'refund' => (int)$target['refund_count'],
                'attendance' => (int)$target['attendance_count'],
                'performance' => (int)$target['performance_count'],
                'material' => (int)$target['material_count'],
                'guardian' => (int)$target['guardian_link_count'],
            ];
            foreach ($protectedCounts as $type => $count) {
                if ($count > 0) {
                    throw new RuntimeException('Cannot delete: this student has '.$type.' history.');
                }
            }

            // Admissions may exist only as Cancelled records in this cleanup path.
            // Detach audit logs first because audit history must survive deletion.
            $audit = $pdo->prepare("
                INSERT INTO audit_logs (user_id, action, student_id, details)
                VALUES (?, 'Delete Cancelled Student', ?, ?)
            ");
            $audit->execute([
                (int)($_SESSION['user_id'] ?? 0),
                $studentId,
                'Deleted cancelled student '.$target['student_id'].' - '.$target['full_name']
            ]);

            $pdo->prepare('UPDATE audit_logs SET student_id=NULL WHERE student_id=?')->execute([$studentId]);

            // Delete cancelled admissions explicitly because admissions.student_id is not ON DELETE CASCADE.
            $pdo->prepare("DELETE FROM admissions WHERE student_id=? AND status='Cancelled'")->execute([$studentId]);

            // Applications/academic/material/performance/guardian/transfer records use
            // ON DELETE CASCADE in the current schema; notices use ON DELETE SET NULL.
            $pdo->prepare('DELETE FROM students WHERE id=?')->execute([$studentId]);

            $pdo->commit();
            $deleteSuccess = 'Cancelled student record deleted successfully.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $deleteError = $e->getMessage();
        }
    }
}
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_application') {
    require_valid_csrf();

    if (!is_super_admin()) {
        http_response_code(403);
        exit('Only Super Admin can delete applications.');
    }

    $studentId = (int)($_POST['student_db_id'] ?? 0);

    if ($studentId <= 0) {
        $deleteError = 'Invalid application selected.';
    } else {
        try {
            $pdo->beginTransaction();

            // A pending application must not have an admission/payment. This prevents destructive deletion of processed data.
            $check = $pdo->prepare("
                SELECT s.id, s.student_id, s.full_name,
                       EXISTS(SELECT 1 FROM admissions ad WHERE ad.student_id=s.id) AS has_admission,
                       EXISTS(SELECT 1 FROM payments p WHERE p.student_id=s.id) AS has_payment,
                       EXISTS(SELECT 1 FROM applications a WHERE a.student_id=s.id AND a.status='Pending') AS has_pending_application
                FROM students s
                WHERE s.id=?
                LIMIT 1
            ");
            $check->execute([$studentId]);
            $target = $check->fetch();

            if (!$target) {
                throw new RuntimeException('Application not found.');
            }

            if ((int)$target['has_admission'] === 1 || (int)$target['has_payment'] === 1) {
                throw new RuntimeException('This student has a processed admission or payment and cannot be deleted here.');
            }

            if ((int)$target['has_pending_application'] !== 1) {
                throw new RuntimeException('Only pending applications can be deleted.');
            }

            // Keep audit history, but detach it from the student row before the student is removed.
            $audit = $pdo->prepare("
                INSERT INTO audit_logs (user_id, action, student_id, details)
                VALUES (?, 'Delete Pending Application', ?, ?)
            ");
            $audit->execute([
                (int)$_SESSION['user_id'],
                $studentId,
                'Deleted pending application for '.$target['student_id'].' - '.$target['full_name']
            ]);

            $pdo->prepare('UPDATE audit_logs SET student_id=NULL WHERE student_id=?')->execute([$studentId]);

            // Applications and academic records use ON DELETE CASCADE; the student row is the pending applicant record.
            $pdo->prepare('DELETE FROM students WHERE id=?')->execute([$studentId]);

            $pdo->commit();
            $deleteSuccess = 'Pending application deleted successfully.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            $deleteError = $e->getMessage();
        }
    }
}

// Pull all students with their latest admission and actual payment totals.
$sql = "SELECT s.id, s.student_id, s.full_name, s.mobile, s.guardian_name, s.email,
               s.is_archived, s.archived_batch_id,
               la.id AS admission_id, la.status AS admission_status,
               c.name AS course_name, b.name AS batch_name,
               la.final_dealing_price,
               COALESCE(pt.total_paid,0) AS total_paid
        FROM students s
        LEFT JOIN (
            SELECT a1.*
            FROM admissions a1
            INNER JOIN (
                SELECT student_id, MAX(id) max_id FROM admissions GROUP BY student_id
            ) x ON x.student_id=a1.student_id AND x.max_id=a1.id
        ) la ON la.student_id=s.id
        LEFT JOIN courses c ON c.id=la.course_id
        LEFT JOIN batches b ON b.id=la.batch_id
        LEFT JOIN (
            SELECT admission_id, SUM(CASE WHEN status='Valid' THEN amount ELSE 0 END) total_paid
            FROM payments GROUP BY admission_id
        ) pt ON pt.admission_id=la.id
        WHERE 1=1";
$params = [];
if ($q !== '') {
    $sql .= " AND (s.full_name LIKE ? OR s.mobile LIKE ? OR s.student_id LIKE ?)";
    $x = "%{$q}%";
    array_push($params, $x, $x, $x);
}
if ($courseFilter !== '') {
    $sql .= " AND c.name = ?";
    $params[] = $courseFilter;
}
if ($batchFilter > 0) {
    $sql .= " AND la.batch_id = ?";
    $params[] = $batchFilter;
}
if ($archiveFilter === 'current') {
    $sql .= " AND s.is_archived = 0";
} elseif ($archiveFilter === 'archived') {
    // Archived Students means students belonging to a closed/archived batch.
    // This prevents unrelated archived records from appearing here.
    $sql .= " AND s.is_archived = 1 AND b.is_archived = 1 AND b.status = 'Closed'";
}
$sql .= " ORDER BY s.id DESC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$rows = $stmt->fetchAll();

$courses = $pdo->query("SELECT name FROM courses ORDER BY name")->fetchAll(PDO::FETCH_COLUMN);
$batchOptions = $pdo->query("SELECT b.id, b.name, b.status, b.is_archived, b.time_slots, c.name AS course_name FROM batches b LEFT JOIN courses c ON c.id=b.course_id ORDER BY b.is_archived ASC, b.start_date DESC, b.name ASC")->fetchAll();
$archivedStudentCount = (int)$pdo->query("SELECT COUNT(*) FROM students s INNER JOIN admissions a ON a.student_id=s.id INNER JOIN (SELECT student_id, MAX(id) max_id FROM admissions GROUP BY student_id) x ON x.student_id=a.student_id AND x.max_id=a.id INNER JOIN batches b ON b.id=a.batch_id WHERE s.is_archived=1 AND b.is_archived=1 AND b.status='Closed'")->fetchColumn();

// Calculate display status from actual payment state so stale Active/Approved flags cannot mislead.
$displayRows = [];
$allStatusRows = [];
foreach ($rows as $r) {
    $final = (float)($r['final_dealing_price'] ?? 0);
    $paid = (float)($r['total_paid'] ?? 0);
    $due = max(0, $final - $paid);
    if (empty($r['admission_id'])) {
        $status = 'Pending';
    } elseif (($r['admission_status'] ?? '') === 'Cancelled') {
        $status = 'Cancelled';
    } else {
        $status = $due <= 0 ? 'Active' : 'Approved';
    }
    $r['display_status'] = $status;
    $r['due'] = $due;
    $allStatusRows[] = $r;
    if ($statusFilter !== '' && $status !== $statusFilter) continue;
    $displayRows[] = $r;
}

require '_header.php';
?>
<style>
.student-toolbar{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin-bottom:16px}.student-toolbar input,.student-toolbar select{min-height:42px;padding:10px 12px;border:1px solid #e4e5e9;border-radius:10px;background:#fff}.student-toolbar input{min-width:280px}.student-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px;margin-bottom:16px}.student-stat{background:#fff;border:1px solid #ececf0;border-radius:14px;padding:15px}.student-stat small{display:block;color:#777d86;font-size:11px;font-weight:700;text-transform:uppercase;margin-bottom:6px}.student-stat strong{font-size:22px}.student-table td{vertical-align:middle}.student-name{font-weight:700;color:#252930}.student-meta{font-size:12px;color:#7b8088;margin-top:3px}.status-pill{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:12px;font-weight:700;background:#f1f2f4;color:#555}.status-pill.active{background:#eaf7ef;color:#237a46}.status-pill.approved{background:#fff7df;color:#946600}.status-pill.pending{background:#eef4ff;color:#315f9b}.status-pill.cancelled{background:#fff0f1;color:#b31e2c}.archived-label{display:inline-flex;margin-top:4px;padding:3px 7px;border-radius:999px;background:#f0f0f1;color:#62656b;font-size:10px;font-weight:800}.amount-due{color:#c91f2e;font-weight:700}.btn-archive-quick{background:#fff!important;color:#6b5a2a!important;border:1px solid #d9cda7!important;font-weight:800}.btn-archive-quick:hover,.btn-archive-quick.active{background:#f6f0dc!important;color:#57491f!important;border-color:#c9b878!important}.archive-toggle{display:inline-flex;align-items:center;border:1px solid #e4e5e9;border-radius:10px;background:#fff;overflow:hidden;min-height:42px}.archive-toggle-btn{display:inline-flex;align-items:center;height:40px;padding:0 12px;color:#667085;text-decoration:none;font-size:13px;font-weight:700;border-right:1px solid #e4e5e9}.archive-toggle-btn:last-child{border-right:0}.archive-toggle-btn.active{background:#20242b;color:#fff}.archive-toggle-btn.archived.active{background:#6b5a2a;color:#fff}.action-links{display:flex;gap:8px;flex-wrap:wrap;align-items:center}.action-links a{white-space:nowrap}.action-links form{display:inline}.delete-app-btn{border:0!important;background:transparent!important;color:#c91f2e!important;padding:0!important;min-height:0!important;font:inherit!important;font-size:13px!important;cursor:pointer}.delete-app-btn:hover{text-decoration:underline;box-shadow:none!important;transform:none!important}.batch-import-card{padding:18px}.import-form{margin-top:8px}.import-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin-bottom:14px}.import-file-field input[type=file]{width:100%;padding:9px;border:1px solid #e4e5e9;border-radius:10px;background:#fff}.import-help{border:1px dashed #d8dbe0;border-radius:10px;padding:11px 13px;background:#fafafa;font-size:12px;line-height:1.55}.import-help strong{display:block;margin-bottom:4px}.import-report{margin-top:16px;border-top:1px solid #ececf0;padding-top:12px}.import-report-list{margin-top:8px;max-height:260px;overflow:auto;border:1px solid #ececf0;border-radius:10px}.import-result-row{display:grid;grid-template-columns:180px 90px 1fr;gap:10px;padding:8px 10px;border-bottom:1px solid #ececf0;font-size:12px}.import-result-row:last-child{border-bottom:0}.import-result-row.imported{background:#f2fbf5}.import-result-row.imported span:nth-child(2){color:#237a46;font-weight:800}.import-result-row.failed span:nth-child(2){color:#b31e2c;font-weight:800}.import-result-row.skipped span:nth-child(2){color:#946600;font-weight:800}.import-result-row.failed{background:#fff5f6}.import-result-row.skipped{background:#fffaf0}@media(max-width:700px){.import-grid{grid-template-columns:1fr}.import-result-row{grid-template-columns:1fr;gap:3px}}@media(max-width:900px){.student-stats{grid-template-columns:repeat(2,minmax(0,1fr))}}@media(max-width:620px){.archive-toggle{width:100%;justify-content:stretch}.archive-toggle-btn{flex:1;justify-content:center}.student-stats{grid-template-columns:1fr}.student-toolbar input{min-width:100%}.student-toolbar select{flex:1}}
</style>

<div class="section-title">
    <div>
        <h1>Students</h1>
        <p class="muted">
            <?= $archiveFilter === 'archived'
                ? 'Showing students from closed / archived batches only.'
                : 'All registered students with admission, payment and status overview.' ?>
        </p>
    </div>
</div>

<?php if ($deleteSuccess): ?><div class="success" style="margin-bottom:16px"><?=e($deleteSuccess)?></div><?php endif; ?>
<?php if ($deleteError): ?><div class="alert" style="margin-bottom:16px"><?=e($deleteError)?></div><?php endif; ?>


<div class="card batch-import-card" style="margin-bottom:16px;border:1px solid #e3d7b0">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap">
        <div>
            <h2>Import Real Students & Admission Data</h2>
            <p class="muted">Import your existing Excel student list and create Student ID, admission, payment history and ID Card status automatically.</p>
        </div>
    </div>

    <?php if ($realImportSuccess): ?><div class="success" style="margin:12px 0"><?=e($realImportSuccess)?></div><?php endif; ?>
    <?php if ($realImportError): ?><div class="alert" style="margin:12px 0"><?=e($realImportError)?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="import-form">
        <?=csrf_input()?>
        <input type="hidden" name="action" value="import_real_students">

        <div class="import-grid">
            <div class="field">
                <label>Target Batch *</label>
                <select name="real_import_batch_id" id="realImportBatch" required>
                    <option value="">Select Batch</option>
                    <?php foreach($batchOptions as $batchOpt): ?>
                        <?php if((int)$batchOpt['is_archived']===0 && $batchOpt['status']!=='Closed'): ?>
                            <option value="<?=$batchOpt['id']?>" data-slots="<?=e((string)($batchOpt['time_slots'] ?? ''))?>">
                                <?=e($batchOpt['course_name'].' — '.$batchOpt['name'])?>
                            </option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label>Time Slot *</label>
                <select name="real_import_time_slot" id="realImportTimeSlot" required>
                    <option value="">Select Time Slot</option>
                </select>
            </div>

            <div class="field">
                <label>Payment Method for Imported Payments *</label>
                <select name="real_import_payment_method" required>
                    <option value="Other" selected>Other (method not in old Excel)</option>
                    <option value="Cash">Cash</option>
                    <option value="bKash">bKash</option>
                    <option value="Nagad">Nagad</option>
                    <option value="Bank">Bank</option>
                </select>
            </div>

            <div class="field import-file-field">
                <label>Real Student CSV *</label>
                <input type="file" name="real_student_csv" accept=".csv,.txt" required>
                <small class="muted">Your current Excel format is supported. Maximum 500 students / 5 MB.</small>
            </div>

            <div class="import-help" style="grid-column:1/-1">
                <strong>Supported columns from your Excel</strong>
                <div>Student Name • Student Phone Num • Gurdian Phone Num • Date • Dealing Price • 1st Payment • 2nd Payment • Total Payment • Due • Memo Num • Reference • ID Card</div>
                <div class="muted" style="margin-top:5px">The system generates new EDU Student IDs. Existing mobile numbers are skipped to prevent duplicates. Payment method is selected above because the old Excel does not contain a payment-method column.</div>
                <div class="muted" style="margin-top:4px"><strong>Important:</strong> the import does not silently change your amounts or dates. If CSV Total/Due differs from the calculated 1st+2nd payment / Deal−Paid, the result will be reported after import.</div>
            </div>
        </div>

        <button class="btn btn-primary" type="submit" onclick="return confirm('Import these real student records into the system? New students, admissions and payment transactions will be created. Existing mobile numbers will be skipped.');">Import Real Students</button>
    </form>

    <?php if ($realImportReport): ?>
        <div class="import-report">
            <strong>Import Result</strong>
            <div class="import-report-list">
                <?php foreach($realImportReport as $ir): ?>
                    <div class="import-result-row <?=strtolower($ir['status'])?>">
                        <span><strong><?=e($ir['name'])?></strong></span>
                        <span><?=e($ir['status'])?></span>
                        <span><?=e($ir['reason'])?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="card batch-import-card" style="margin-bottom:16px">
    <div class="card-header" style="display:flex;justify-content:space-between;align-items:flex-start;gap:16px;flex-wrap:wrap">
        <div>
            <h2>Batch-wise Student Import</h2>
            <p class="muted">Bulk move existing students into a selected batch + time slot using a CSV exported from Excel.</p>
        </div>
    </div>

    <?php if ($importSuccess): ?><div class="success" style="margin:12px 0"><?=e($importSuccess)?></div><?php endif; ?>
    <?php if ($importError): ?><div class="alert" style="margin:12px 0"><?=e($importError)?></div><?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="import-form">
        <?=csrf_input()?>
        <input type="hidden" name="action" value="import_batch_students">

        <div class="import-grid">
            <div class="field">
                <label>Target Batch *</label>
                <select name="import_batch_id" id="importBatch" required>
                    <option value="">Select Batch</option>
                    <?php foreach($batchOptions as $batchOpt): ?>
                        <?php if((int)$batchOpt['is_archived']===0 && $batchOpt['status']!=='Closed'): ?>
                            <option value="<?=$batchOpt['id']?>" data-slots="<?=e((string)($batchOpt['time_slots'] ?? ''))?>">
                                <?=e($batchOpt['course_name'].' — '.$batchOpt['name'])?>
                            </option>
                        <?php endif; ?>
                    <?php endforeach; ?>
                </select>
            </div>

            <div class="field">
                <label>Time Slot</label>
                <select name="import_time_slot" id="importTimeSlot">
                    <option value="">Select Time Slot</option>
                </select>
            </div>

            <div class="field import-file-field">
                <label>CSV File *</label>
                <input type="file" name="student_csv" accept=".csv,.txt" required>
                <small class="muted">CSV must contain a <strong>Student ID</strong> column. Maximum 500 students / 5 MB.</small>
            </div>

            <div class="import-help">
                <strong>Excel format</strong>
                <div>Student ID</div>
                <div>EDU-2026-0001</div>
                <div>EDU-2026-0002</div>
                <div class="muted">Excel → Save As → CSV UTF-8 → upload here.</div>
            </div>
        </div>

        <button class="btn btn-primary" type="submit">Import Students to Batch</button>
    </form>

    <?php if ($importReport): ?>
        <div class="import-report">
            <strong>Import Result</strong>
            <div class="import-report-list">
                <?php foreach($importReport as $ir): ?>
                    <div class="import-result-row <?=strtolower($ir['status'])?>">
                        <span><strong><?=e($ir['code'])?></strong></span>
                        <span><?=e($ir['status'])?></span>
                        <span><?=e($ir['reason'])?></span>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    <?php endif; ?>
</div>

<div class="student-stats">
    <div class="student-stat"><small>Total Students</small><strong><?= count($allStatusRows) ?></strong></div>
    <div class="student-stat"><small>Pending</small><strong><?= count(array_filter($allStatusRows, fn($r)=>$r['display_status']==='Pending')) ?></strong></div>
    <div class="student-stat"><small>Approved / Due</small><strong><?= count(array_filter($allStatusRows, fn($r)=>$r['display_status']==='Approved')) ?></strong></div>
    <div class="student-stat"><small>Active</small><strong><?= count(array_filter($allStatusRows, fn($r)=>$r['display_status']==='Active')) ?></strong></div>
</div>

<form class="student-toolbar" method="get">
    <input name="q" value="<?= e($q) ?>" placeholder="Search Student ID / Name / Mobile">
    <select name="course"><option value="">All Courses</option><?php foreach($courses as $course): ?><option value="<?= e($course) ?>" <?= $courseFilter===$course?'selected':'' ?>><?= e($course) ?></option><?php endforeach; ?></select>
    <select name="batch_id">
        <option value="0">All Batches</option>
        <?php foreach($batchOptions as $batchOpt): ?>
            <option value="<?=$batchOpt['id']?>" <?= $batchFilter===(int)$batchOpt['id']?'selected':'' ?>><?=e($batchOpt['course_name'].' — '.$batchOpt['name'])?><?=((int)$batchOpt['is_archived']===1?' (Archived)':'')?></option>
        <?php endforeach; ?>
    </select>

    <div class="archive-toggle" role="group" aria-label="Student list">
        <a class="archive-toggle-btn <?= $archiveFilter==='current' ? 'active' : '' ?>" href="students.php?<?=http_build_query(['archive'=>'current','q'=>$q,'course'=>$courseFilter,'batch_id'=>$batchFilter,'status'=>$statusFilter])?>">Current</a>
        <a class="archive-toggle-btn <?= $archiveFilter==='archived' ? 'active archived' : '' ?>" href="students.php?<?=http_build_query(['archive'=>'archived','q'=>$q,'course'=>$courseFilter,'batch_id'=>$batchFilter,'status'=>$statusFilter])?>">Archived<?= $archivedStudentCount > 0 ? ' ('.$archivedStudentCount.')' : '' ?></a>
        <a class="archive-toggle-btn <?= $archiveFilter==='all' ? 'active' : '' ?>" href="students.php?<?=http_build_query(['archive'=>'all','q'=>$q,'course'=>$courseFilter,'batch_id'=>$batchFilter,'status'=>$statusFilter])?>">All</a>
    </div>

    <select name="status"><option value="">All Status</option><?php foreach(['Pending','Approved','Active','Cancelled'] as $s): ?><option value="<?= $s ?>" <?= $statusFilter===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select>
    <button class="btn btn-primary" type="submit">Search</button>
    <?php if($q!=='' || $courseFilter!=='' || $statusFilter!=='' || $batchFilter>0 || $archiveFilter!=='current'): ?><a class="btn btn-secondary" href="students.php">Reset</a><?php endif; ?>
</form>

<div class="card table-wrap">
<table class="table student-table">
<thead><tr><th>Student ID</th><th>Name</th><th>Course</th><th>Batch + Time Slot</th><th>Status</th><th>Action</th></tr></thead>
<tbody>
<?php if(!$displayRows): ?><tr><td colspan="6">No student found.</td></tr>
<?php else: foreach($displayRows as $r): ?>
<?php
    $batchTime = $r['batch_name'] ?: '-';
    if (!empty($r['admission_id'])) {
        try {
            $ts = $pdo->prepare("SELECT time_slot FROM admissions WHERE id=? LIMIT 1");
            $ts->execute([(int)$r['admission_id']]);
            $slot = $ts->fetchColumn();
            if ($slot) $batchTime .= ' / '.$slot;
        } catch(Throwable $e) {}
    }
?>
<tr>
<td><strong><?= e($r['student_id']) ?></strong></td>
<td><div class="student-name"><?= e($r['full_name']) ?></div><?php if((int)($r['is_archived'] ?? 0)===1): ?><div class="archived-label">Archived</div><?php endif; ?></td>
<td><?= e($r['course_name'] ?: '-') ?></td>
<td><?= e($batchTime) ?></td>
<td><span class="status-pill <?= strtolower(e($r['display_status'])) ?>"><?= e($r['display_status']) ?></span></td>
<td><div class="action-links">
    <a href="student-profile.php?id=<?= urlencode($r['student_id']) ?>">View</a>
    <?php if($r['display_status']==='Approved' && $r['due']>0): ?>
        <a href="due-payment.php?id=<?= urlencode($r['student_id']) ?>">Due Payment</a>
    <?php elseif($r['display_status']==='Pending'): ?>
        <a href="admission-review.php?id=<?= urlencode($r['student_id']) ?>">Process</a>
        <?php if (is_super_admin()): ?>
            <form method="post" onsubmit="return confirm('Delete this pending application and its applicant record? This cannot be undone.');">
                <?=csrf_input()?>
                <input type="hidden" name="action" value="delete_application">
                <input type="hidden" name="student_db_id" value="<?= (int)$r['id'] ?>">
                <button type="submit" class="delete-app-btn">Delete Application</button>
            </form>
        <?php endif; ?>
    <?php elseif($r['display_status']==='Cancelled' && is_super_admin()): ?>
        <form method="post" onsubmit="return confirm('Delete this cancelled student record? This is allowed only when there is no payment, refund, attendance or performance history. This cannot be undone.');">
            <?=csrf_input()?>
            <input type="hidden" name="action" value="delete_student_cleanup">
            <input type="hidden" name="student_db_id" value="<?= (int)$r['id'] ?>">
            <button type="submit" class="delete-app-btn">Delete Student</button>
        </form>
    <?php endif; ?>
</div></td>
</tr>
<?php endforeach; endif; ?>
</tbody>
</table>
</div>

<script>
(function(){
    function parseSlots(raw){
        raw = (raw || '').trim();
        if(!raw) return [];
        try {
            const parsed = JSON.parse(raw);
            if(Array.isArray(parsed)) return [...new Set(parsed.map(String).map(s=>s.trim()).filter(Boolean))];
        } catch(e) {}
        return [...new Set(raw.split(/[,|]+/).map(s=>s.trim()).filter(Boolean))];
    }

    // Keep the import selectors independent and support both old JSON data
    // and comma/pipe-separated legacy time-slot values.
    function setupBatchSlotSelector(batchId, slotId){
        const batch = document.getElementById(batchId);
        const slot = document.getElementById(slotId);
        if(!batch || !slot) return;

        function refreshSlots(){
            const opt = batch.options[batch.selectedIndex];
            let slots = parseSlots(opt ? opt.dataset.slots : '');

            // Older batches may have an empty time_slots value. Use the
            // standard Edumax slots instead of leaving the selector unusable.
            if(!slots.length && opt && opt.value){
                slots = ['10:00 AM','12:00 PM','3:00 PM','5:00 PM'];
            }

            slot.innerHTML = '<option value="">Select Time Slot</option>';
            slots.forEach(function(s){
                const o = document.createElement('option');
                o.value = s;
                o.textContent = s;
                slot.appendChild(o);
            });
            slot.disabled = !opt || !opt.value || !slots.length;
            slot.required = true;
        }

        batch.addEventListener('change', refreshSlots);
        refreshSlots();
    }

    setupBatchSlotSelector('realImportBatch','realImportTimeSlot');
    setupBatchSlotSelector('importBatch','importTimeSlot');
})();
</script>

<?php require '_footer.php'; ?>

<?php
require_once __DIR__ . '/../config/app.php';
require_access('payments');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
}

$studentCode = trim($_GET['id'] ?? $_POST['student_code'] ?? '');
$errors = [];
$student = null;
$admissions = [];

function load_cancelled_admissions(PDO $pdo, int $studentId): array {
    $q = $pdo->prepare("
        SELECT ad.id, ad.final_dealing_price, ad.status, ad.admission_date,
               ad.cancelled_at, ad.refund_deduction_percent,
               ad.refund_deduction_amount, ad.refund_paid_amount, ad.refund_amount,
               c.name AS course_name, b.name AS batch_name
        FROM admissions ad
        JOIN courses c ON c.id = ad.course_id
        JOIN batches b ON b.id = ad.batch_id
        WHERE ad.student_id = ?
          AND ad.status = 'Cancelled'
          AND c.name <> 'Mock Test'
        ORDER BY ad.id DESC
    ");
    $q->execute([$studentId]);
    return $q->fetchAll();
}

if ($studentCode !== '') {
    $s = $pdo->prepare("SELECT * FROM students WHERE student_id=? LIMIT 1");
    $s->execute([$studentCode]);
    $student = $s->fetch();

    if ($student) {
        $admissions = load_cancelled_admissions($pdo, (int)$student['id']);
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && !isset($_POST['lookup'])) {
    $studentCode = trim($_POST['student_code'] ?? '');
    $admissionId = (int)($_POST['admission_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);
    $method = $_POST['method'] ?? 'Cash';
    $reason = trim($_POST['reason'] ?? '');
    $note = trim($_POST['note'] ?? '');
    $paymentId = (int)($_POST['payment_id'] ?? 0);

    $s = $pdo->prepare("SELECT * FROM students WHERE student_id=? LIMIT 1");
    $s->execute([$studentCode]);
    $student = $s->fetch();

    if (!$student) $errors[] = 'Student not found.';
    if ($amount <= 0) $errors[] = 'Refund amount must be greater than zero.';
    if (!in_array($method, ['Cash','bKash','Nagad','Bank','Other'], true)) $errors[] = 'Invalid refund method.';
    if ($admissionId <= 0) $errors[] = 'Select a cancelled admission.';

    if (!$errors) {
        try {
            $pdo->beginTransaction();

            $lk = $pdo->prepare("
                SELECT ad.id, ad.student_id, ad.final_dealing_price, ad.status,
                       ad.refund_paid_amount, ad.refund_amount,
                       c.name AS course_name, b.name AS batch_name
                FROM admissions ad
                JOIN courses c ON c.id=ad.course_id
                JOIN batches b ON b.id=ad.batch_id
                WHERE ad.id=? AND ad.student_id=?
                  AND ad.status='Cancelled'
                  AND c.name <> 'Mock Test'
                FOR UPDATE
            ");
            $lk->execute([$admissionId, (int)$student['id']]);
            $ad = $lk->fetch();

            if (!$ad) throw new RuntimeException('Cancelled regular admission not found.');

            // All valid payments are Money In. Valid refunds are Money Out.
            $paidQ = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE admission_id=? AND status='Valid'");
            $paidQ->execute([$admissionId]);
            $grossPaid = (float)$paidQ->fetchColumn();

            $refQ = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE admission_id=? AND status='Valid'");
            $refQ->execute([$admissionId]);
            $alreadyRefunded = (float)$refQ->fetchColumn();

            $available = max(0, $grossPaid - $alreadyRefunded);
            if ($available <= 0) {
                throw new RuntimeException('No refundable paid amount remains for this admission.');
            }
            if ($amount > $available + 0.0001) {
                throw new RuntimeException(
                    'Refund cannot exceed available refundable paid amount: ৳'.number_format($available, 2)
                );
            }

            // Cancellation policy snapshot is the maximum amount authorized for this cancellation.
            $policyRefund = (float)($ad['refund_amount'] ?? 0);
            $policyPaid   = (float)($ad['refund_paid_amount'] ?? 0);

            if ($policyRefund <= 0) {
                throw new RuntimeException('No calculated refundable amount is recorded for this cancelled admission.');
            }

            $policyAlreadyRefunded = min($alreadyRefunded, $policyRefund);
            $policyRemaining = max(0, $policyRefund - $policyAlreadyRefunded);

            if ($amount > $policyRemaining + 0.0001) {
                throw new RuntimeException(
                    'Refund exceeds the remaining cancellation-policy amount: ৳'.number_format($policyRemaining, 2)
                );
            }

            if ($paymentId > 0) {
                $pq = $pdo->prepare("
                    SELECT id FROM payments
                    WHERE id=? AND admission_id=? AND status='Valid'
                    LIMIT 1
                ");
                $pq->execute([$paymentId, $admissionId]);
                if (!$pq->fetch()) {
                    throw new RuntimeException('Selected payment is not valid for this admission.');
                }
            }

            $year = (int)date('Y');
            $pdo->exec("INSERT IGNORE INTO refund_sequences (year,last_number) VALUES (".$year.",0)");

            $seqStmt = $pdo->prepare("SELECT last_number FROM refund_sequences WHERE year=? FOR UPDATE");
            $seqStmt->execute([$year]);
            $seq = (int)$seqStmt->fetchColumn() + 1;

            $upSeq = $pdo->prepare("UPDATE refund_sequences SET last_number=? WHERE year=?");
            $upSeq->execute([$seq, $year]);

            $refundNo = 'EDU-RF-'.$year.'-'.str_pad((string)$seq, 5, '0', STR_PAD_LEFT);

            $ins = $pdo->prepare("
                INSERT INTO refunds
                    (refund_no,student_id,admission_id,payment_id,amount,method,reason,note,processed_by,status)
                VALUES (?,?,?,?,?,?,?,?,?,'Valid')
            ");
            $ins->execute([
                $refundNo,
                (int)$student['id'],
                $admissionId,
                $paymentId > 0 ? $paymentId : null,
                $amount,
                $method,
                $reason !== '' ? $reason : 'Admission cancellation',
                $note !== '' ? $note : null,
                $_SESSION['user_id']
            ]);

            // Financial meaning:
            // Net Paid = Valid Payments - Valid Refunds
            // For a cancelled admission, collectible Due is settled to zero.
            $newAlreadyRefunded = $alreadyRefunded + $amount;
            $netPaid = max(0, $grossPaid - $newAlreadyRefunded);
            $due = ($ad['status'] === 'Cancelled')
                ? 0
                : max(0, (float)$ad['final_dealing_price'] - $netPaid);

            $audit = $pdo->prepare("
                INSERT INTO audit_logs (user_id,action,student_id,details)
                VALUES (?,?,?,?)
            ");
            $audit->execute([
                $_SESSION['user_id'],
                'Refund Created',
                (int)$student['id'],
                'Refund: '.$amount.
                ', method: '.$method.
                ', refund no: '.$refundNo.
                ', admission: '.$admissionId.
                ', gross paid: '.$grossPaid.
                ', total refund: '.$newAlreadyRefunded.
                ', net paid: '.$netPaid.
                ', due: '.$due
            ]);

            $pdo->commit();

            // Refund receipt is the proof of Money Out.
            header('Location: refund-receipt.php?refund_no='.urlencode($refundNo));
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $errors[] = $e->getMessage();
        }
    }

    if ($student) {
        $admissions = load_cancelled_admissions($pdo, (int)$student['id']);
    }
}

require '_header.php';
?>
<div class="section-title">
    <div>
        <h1>Process Refund</h1>
        <p>Refund is recorded separately as Money Out and reduces Net Collection. Payment history is preserved for audit.</p>
    </div>
    <a class="btn btn-light" href="refunds.php">← Refunds</a>
</div>

<?php foreach ($errors as $er): ?>
    <div class="alert"><?=e($er)?></div>
<?php endforeach; ?>

<div class="card">
<form method="post" class="form-grid">
<?= csrf_input() ?>

<div>
    <label>Student ID</label>
    <input name="student_code" value="<?=e($studentCode)?>" placeholder="EDU-2026-0001" required>
</div>

<div style="align-self:end">
    <button class="btn btn-light" type="submit" name="lookup" value="1">Load Student</button>
</div>

<?php if ($student): ?>
    <div style="grid-column:1/-1" class="info-cell">
        <strong><?=e($student['full_name'])?></strong><br>
        <small><?=e($student['mobile'])?></small>
    </div>

    <div style="grid-column:1/-1">
        <label>Cancelled Admission</label>
        <select name="admission_id" id="admission_id" required>
            <option value="">Select cancelled admission</option>
            <?php foreach ($admissions as $a): ?>
                <option
                    value="<?=e($a['id'])?>"
                    data-refund="<?=e((float)$a['refund_amount'])?>"
                    data-paid="<?=e((float)$a['refund_paid_amount'])?>"
                    data-fine="<?=e((float)$a['refund_deduction_percent'])?>"
                    <?=((int)($_POST['admission_id']??0)==(int)$a['id'])?'selected':''?>
                >
                    <?=e(
                        $a['course_name'].' · '.$a['batch_name'].
                        ' · Refund ৳'.number_format((float)$a['refund_amount'],2).
                        ' · Fine '.number_format((float)$a['refund_deduction_percent'],2).'%'
                    )?>
                </option>
            <?php endforeach; ?>
        </select>
    </div>

    <div>
        <label>Refund Amount</label>
        <input
            type="number"
            name="amount"
            id="refund_amount"
            min="0.01"
            step="0.01"
            value="<?=e($_POST['amount']??'')?>"
            required
        >
        <small id="refund_hint" style="display:block;margin-top:6px"></small>
    </div>

    <div>
        <label>Method</label>
        <select name="method">
            <?php foreach (['Cash','bKash','Nagad','Bank','Other'] as $m): ?>
                <option <?=$m===($_POST['method']??'Cash')?'selected':''?>><?=e($m)?></option>
            <?php endforeach; ?>
        </select>
    </div>

    <div>
        <label>Related Payment ID <small>(optional)</small></label>
        <input type="number" name="payment_id" value="<?=e($_POST['payment_id'] ?? '')?>" placeholder="Optional — leave blank">
    </div>

    <div>
        <label>Reason</label>
        <input name="reason" value="<?=e($_POST['reason']??'Admission cancellation')?>" placeholder="Admission cancellation">
    </div>

    <div style="grid-column:1/-1">
        <label>Note</label>
        <textarea name="note" rows="3"><?=e($_POST['note']??'')?></textarea>
    </div>

    <div style="grid-column:1/-1">
        <button class="btn btn-primary">Process Refund & Generate Receipt</button>
    </div>
<?php endif; ?>
</form>
</div>

<script>
(function(){
    const select=document.getElementById('admission_id');
    const amount=document.getElementById('refund_amount');
    const hint=document.getElementById('refund_hint');
    if(!select || !amount) return;

    function sync(){
        const o=select.options[select.selectedIndex];
        if(!o || !o.value){
            hint.textContent='';
            return;
        }
        const refund=parseFloat(o.dataset.refund||'0');
        const paid=parseFloat(o.dataset.paid||'0');
        const fine=parseFloat(o.dataset.fine||'0');

        amount.max=refund.toFixed(2);
        if(!amount.value) amount.value=refund.toFixed(2);

        hint.textContent =
            'Calculated refund: ৳'+refund.toFixed(2)+
            ' | Paid basis: ৳'+paid.toFixed(2)+
            ' | Deduction: '+fine.toFixed(2)+'%';
    }

    select.addEventListener('change', function(){
        amount.value='';
        sync();
    });

    sync();
})();
</script>

<?php require '_footer.php'; ?>

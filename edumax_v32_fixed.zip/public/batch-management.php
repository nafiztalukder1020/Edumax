<?php
require_once __DIR__ . '/../config/app.php';
require_valid_csrf();
require_access('batch');
ensure_archive_columns();
ensure_batch_schedule_columns();

// Per-batch maximum student capacity. Existing batches default to 50.
try {
    $pdo->exec("ALTER TABLE batches ADD COLUMN max_students INT UNSIGNED NOT NULL DEFAULT 50 AFTER schedule_months");
} catch (Throwable $e) {
    // Column already exists or older MySQL refused the DDL; continue.
}

// Phase 1 batch controls: per-slot capacity + primary teacher assignment.
try {
    $pdo->exec("ALTER TABLE batches ADD COLUMN slot_capacities TEXT NULL AFTER max_students");
} catch (Throwable $e) {
    // Column already exists or older MySQL refused the DDL; continue.
}
try {
    $pdo->exec("ALTER TABLE batches ADD COLUMN teacher_id INT UNSIGNED NULL AFTER slot_capacities");
} catch (Throwable $e) {
    // Column already exists or older MySQL refused the DDL; continue.
}
$error = '';
$success = '';
$currentRole = strtolower(trim((string)($_SESSION['role'] ?? '')));

/*
 * Batch capacity management:
 * Any authorized admin role may manage the configured BASE capacity.
 * Capacity override for individual admissions/transfers is handled
 * separately in the admission/transfer workflow.
 */
$canManageCapacity = in_array(
    $currentRole,
    [
        'super admin',
        'admission admin',
        'accounts',
        'reception'
    ],
    true
);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    try {
        $action = $_POST['action'] ?? '';

        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $courseId = (int)($_POST['course_id'] ?? 0);
            $name = trim($_POST['name'] ?? '');
            $startDate = trim($_POST['start_date'] ?? '');
            $status = $_POST['status'] ?? 'Upcoming';
            $slots = $_POST['time_slots'] ?? [];
            $days = $_POST['class_days'] ?? [];
            $scheduleMonths = (int)($_POST['schedule_months'] ?? 3);
            $scheduleMonths = max(1, min(12, $scheduleMonths));
            $maxStudents = (int)($_POST['max_students'] ?? 50);
            $maxStudents = max(1, $maxStudents);
            $teacherId = (int)($_POST['teacher_id'] ?? 0);
            $slotCapacities = $_POST['slot_capacity'] ?? [];

            // Capacity is an Admin-level setting. Non-admin users cannot change it.
            if (!$canManageCapacity) {
                if ($id > 0) {
                    $capacityQ = $pdo->prepare("SELECT max_students, slot_capacities FROM batches WHERE id=? LIMIT 1");
                    $capacityQ->execute([$id]);
                    $capacityRow = $capacityQ->fetch();
                    if ($capacityRow) {
                        $maxStudents = max(1, (int)($capacityRow['max_students'] ?? 50));
                        $existingCaps = json_decode((string)($capacityRow['slot_capacities'] ?? ''), true);
                        $slotCapacities = is_array($existingCaps) ? $existingCaps : [];
                    }
                } else {
                    $maxStudents = 50;
                    $slotCapacities = [];
                }
            }
            $clean = [];
            if (is_array($slots)) {
                foreach ($slots as $slot) {
                    $slot = trim((string)$slot);
                    if ($slot !== '' && !in_array($slot, $clean, true)) $clean[] = $slot;
                }
            }
            $cleanDays = [];
            if (is_array($days)) {
                foreach ($days as $day) {
                    $day = (int)$day;
                    if ($day >= 0 && $day <= 6 && !in_array($day, $cleanDays, true)) $cleanDays[] = $day;
                }
            }
            sort($cleanDays);
            if ($courseId <= 0 || $name === '') throw new RuntimeException('Course and Batch Name are required.');
            if (!in_array($status, ['Active','Upcoming','Closed'], true)) $status = 'Upcoming';
            if (!$cleanDays) throw new RuntimeException('Please select at least one class day.');
            if (!$clean) throw new RuntimeException('Please add at least one time slot.');

            // Map capacities for dynamically added slots by their position.
            if (isset($_POST['slot_capacity_new']) && is_array($_POST['slot_capacity_new'])) {
                $newCaps = array_values($_POST['slot_capacity_new']);
                $existingNamedCaps = is_array($slotCapacities) ? $slotCapacities : [];
                $namedIndex = 0;
                foreach ($clean as $slotIndex => $slotName) {
                    if (array_key_exists($slotName, $existingNamedCaps)) continue;
                    if (array_key_exists($namedIndex, $newCaps)) {
                        $existingNamedCaps[$slotName] = $newCaps[$namedIndex];
                    }
                    $namedIndex++;
                }
                $slotCapacities = $existingNamedCaps;
            }

            // Build a capacity map for each configured time slot.
            $cleanCapacities = [];
            foreach ($clean as $slotName) {
                $rawCap = is_array($slotCapacities) ? ($slotCapacities[$slotName] ?? $maxStudents) : $maxStudents;
                $slotCap = (int)$rawCap;
                $slotCap = max(1, $slotCap);
                $cleanCapacities[$slotName] = $slotCap;
            }

            // Optional primary teacher assignment. Daily class schedules may still
            // use a different teacher when the Class Management workflow requires it.
            if ($teacherId > 0) {
                $teacherCheck = $pdo->prepare("SELECT id FROM teachers WHERE id=? AND status='Active' LIMIT 1");
                $teacherCheck->execute([$teacherId]);
                if (!$teacherCheck->fetchColumn()) {
                    throw new RuntimeException('Selected teacher was not found or is inactive.');
                }
            } else {
                $teacherId = null;
            }

            // Prevent duplicate ACTIVE/UPCOMING batch names.
            // Archived batches are historical records, so they should not block
            // editing/reusing the same batch name.
            // The current batch is always excluded during edit.
            $duplicateCheck = $pdo->prepare("
                SELECT id
                FROM batches
                WHERE LOWER(TRIM(name)) = LOWER(TRIM(?))
                  AND id <> ?
                  AND COALESCE(is_archived, 0) = 0
                LIMIT 1
            ");
            $duplicateCheck->execute([$name, $id]);

            if ($duplicateCheck->fetchColumn()) {
                throw new RuntimeException(
                    'এই নামে আরেকটি Active/Upcoming Batch আছে। একই নামে নতুন Batch তৈরি করা যাবে না।'
                );
            }

            if ($startDate !== '') {
                $startObj = DateTime::createFromFormat('Y-m-d', $startDate);
                if (!$startObj || $startObj->format('Y-m-d') !== $startDate) {
                    throw new RuntimeException('Invalid batch start date.');
                }
            }

            $courseCheck = $pdo->prepare("SELECT id FROM courses WHERE id=? LIMIT 1");
            $courseCheck->execute([$courseId]);
            if (!$courseCheck->fetchColumn()) {
                throw new RuntimeException('Selected course was not found.');
            }

            foreach ($clean as $slotValue) {
                if (mb_strlen($slotValue) > 100) {
                    throw new RuntimeException('Each time slot must be 100 characters or fewer.');
                }
            }

            $json = json_encode($clean, JSON_UNESCAPED_UNICODE);
            $daysJson = json_encode($cleanDays, JSON_UNESCAPED_UNICODE);
            $capacityJson = json_encode($cleanCapacities, JSON_UNESCAPED_UNICODE);
            if ($id > 0) {
                $existing = $pdo->prepare("SELECT id,is_archived FROM batches WHERE id=? LIMIT 1");
                $existing->execute([$id]);
                $existingRow = $existing->fetch();
                if (!$existingRow) throw new RuntimeException('Batch not found.');
                if ((int)$existingRow['is_archived'] === 1) {
                    throw new RuntimeException('Archived batches cannot be edited. Restore the batch first.');
                }

                $q=$pdo->prepare("UPDATE batches SET course_id=?, name=?, start_date=?, status=?, time_slots=?, class_days=?, schedule_months=?, max_students=?, slot_capacities=?, teacher_id=? WHERE id=?");
                $q->execute([$courseId,$name,$startDate ?: null,$status,$json,$daysJson,$scheduleMonths,$maxStudents,$capacityJson,$teacherId,$id]);
                $generated = generate_batch_schedule($id);
                $success='Batch updated successfully. '.$generated.' new class slot(s) generated.';
            } else {
                $q=$pdo->prepare("INSERT INTO batches (course_id,name,start_date,status,time_slots,class_days,schedule_months,max_students,slot_capacities,teacher_id) VALUES (?,?,?,?,?,?,?,?,?,?)");
                $q->execute([$courseId,$name,$startDate ?: null,$status,$json,$daysJson,$scheduleMonths,$maxStudents,$capacityJson,$teacherId]);
                $newId=(int)$pdo->lastInsertId();
                $generated = generate_batch_schedule($newId);
                $success='Batch created successfully. '.$generated.' class slot(s) generated for '.$scheduleMonths.' months.';
            }
        } elseif ($action === 'generate_schedule') {
            $id=(int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Invalid batch selected.');

            $q=$pdo->prepare("SELECT id,is_archived FROM batches WHERE id=? LIMIT 1");
            $q->execute([$id]);
            $target=$q->fetch();
            if (!$target) throw new RuntimeException('Batch not found.');
            if ((int)$target['is_archived'] === 1) throw new RuntimeException('Archived batches cannot generate new class slots.');

            $generated=generate_batch_schedule($id);
            $success=$generated.' new class slot(s) generated from the batch start date for the configured schedule period.';
        } elseif ($action === 'delete') {
            $id=(int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Invalid batch selected.');

            $q=$pdo->prepare("SELECT id,name,is_archived FROM batches WHERE id=? LIMIT 1");
            $q->execute([$id]);
            $target=$q->fetch();
            if (!$target) throw new RuntimeException('Batch not found.');
            if ((int)$target['is_archived'] === 1) throw new RuntimeException('Archived batches cannot be deleted.');

            $q=$pdo->prepare("SELECT COUNT(*) FROM admissions WHERE batch_id=?");
            $q->execute([$id]);
            if ((int)$q->fetchColumn()>0) {
                throw new RuntimeException('This batch is already used in admissions. Archive it instead of deleting it.');
            }

            $q=$pdo->prepare("SELECT COUNT(*) FROM attendance WHERE batch_id=?");
            $q->execute([$id]);
            if ((int)$q->fetchColumn()>0) {
                throw new RuntimeException('This batch has attendance history. Archive it instead of deleting it.');
            }

            $pdo->beginTransaction();

            // Remove generated class schedule rows first. Older deployments may
            // have created class_schedules without ON DELETE CASCADE, so relying
            // on the FK alone can make an otherwise deletable batch fail.
            $pdo->prepare("DELETE FROM class_schedules WHERE batch_id=?")->execute([$id]);

            // At this point admissions/attendance are guaranteed to be empty,
            // so the batch itself can be safely removed.
            $pdo->prepare("DELETE FROM batches WHERE id=?")->execute([$id]);
            $pdo->commit();
            $success='Batch deleted successfully.';

        } elseif ($action === 'archive') {
            $id=(int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Invalid batch selected.');

            $q=$pdo->prepare("SELECT id,name,status,is_archived FROM batches WHERE id=? LIMIT 1");
            $q->execute([$id]);
            $target=$q->fetch();
            if (!$target) throw new RuntimeException('Batch not found.');
            if ((int)$target['is_archived'] === 1) throw new RuntimeException('Batch is already archived.');
            if ($target['status'] !== 'Closed') throw new RuntimeException('Only a Closed/finished batch can be archived. Set the batch status to Closed first.');

            $pdo->beginTransaction();
            $pdo->prepare("UPDATE batches SET is_archived=1 WHERE id=?")->execute([$id]);
            // Archive students whose latest admission belongs to this batch.
            $archiveStudents=$pdo->prepare("
                UPDATE students s
                INNER JOIN (
                    SELECT a1.student_id, a1.batch_id
                    FROM admissions a1
                    INNER JOIN (SELECT student_id, MAX(id) max_id FROM admissions GROUP BY student_id) x
                      ON x.student_id=a1.student_id AND x.max_id=a1.id
                    WHERE a1.batch_id=?
                ) la ON la.student_id=s.id
                SET s.is_archived=1, s.archived_batch_id=?, s.archived_at=NOW()
                WHERE s.is_archived=0
            
            " );
            $archiveStudents->execute([$id,$id]);
            $affected=$archiveStudents->rowCount();
            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'Archive Batch', ?)");
            $audit->execute([(int)($_SESSION['user_id'] ?? 0), 'Archived batch #'.$id.' - '.$target['name'].'; students archived: '.$affected]);
            $pdo->commit();
            $success='Batch archived successfully. '.$affected.' student(s) were moved to the student archive.';

        } elseif ($action === 'unarchive') {
            $id=(int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Invalid batch selected.');
            $q=$pdo->prepare("SELECT id,name,is_archived FROM batches WHERE id=? LIMIT 1");
            $q->execute([$id]);
            $target=$q->fetch();
            if (!$target) throw new RuntimeException('Batch not found.');
            if ((int)$target['is_archived'] !== 1) throw new RuntimeException('Batch is not archived.');

            $pdo->beginTransaction();
            $pdo->prepare("UPDATE batches SET is_archived=0 WHERE id=?")->execute([$id]);
            $pdo->prepare("UPDATE students SET is_archived=0, archived_batch_id=NULL, archived_at=NULL WHERE is_archived=1 AND archived_batch_id=?")->execute([$id]);
            $pdo->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'Unarchive Batch', ?)")->execute([(int)($_SESSION['user_id'] ?? 0), 'Unarchived batch #'.$id.' - '.$target['name']]);
            $pdo->commit();
            $success='Batch restored to the active batch list and linked students restored.';
        }
    } catch (Throwable $e) {
        $error=$e->getMessage();
    }
}

$courses=$pdo->query("SELECT id,name FROM courses ORDER BY name")->fetchAll();
$teachers=[];
try {
    $teachers=$pdo->query("SELECT id,name,subject FROM teachers WHERE status='Active' ORDER BY name")->fetchAll();
} catch (Throwable $e) {
    $teachers=[];
}
$dayOptions = [0=>'Sunday',1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday'];
$showArchived = (int)($_GET['archived'] ?? 0) === 1;
$sort = $_GET['sort'] ?? 'start_date';
$dir = strtolower($_GET['dir'] ?? 'desc');
$allowedSorts = [
    'name' => 'b.name',
    'start_date' => 'b.start_date',
    'status' => 'b.status',
    'course' => 'c.name',
];
$sortSql = $allowedSorts[$sort] ?? $allowedSorts['start_date'];
$dirSql = $dir === 'asc' ? 'ASC' : 'DESC';
$whereArchived = $showArchived ? 'b.is_archived=1' : 'b.is_archived=0';
$batchesStmt=$pdo->query("SELECT b.*, c.name AS course_name, t.name AS teacher_name FROM batches b LEFT JOIN courses c ON c.id=b.course_id LEFT JOIN teachers t ON t.id=b.teacher_id WHERE {$whereArchived} ORDER BY {$sortSql} {$dirSql}, b.id DESC");
$batches=$batchesStmt->fetchAll();
$archivedCount=(int)$pdo->query("SELECT COUNT(*) FROM batches WHERE is_archived=1")->fetchColumn();

$edit=null;
if (isset($_GET['edit'])) {
    foreach($batches as $b) if((int)$b['id']===(int)$_GET['edit']) {$edit=$b;break;}
}
$editSlots=$edit ? json_decode((string)($edit['time_slots'] ?? ''),true) : [];
if (!is_array($editSlots) || !$editSlots) $editSlots=['10:00 AM','12:00 PM','3:00 PM','5:00 PM'];
$editDays=$edit ? json_decode((string)($edit['class_days'] ?? ''),true) : [];
if (!is_array($editDays) || !$editDays) {
    $nameForDays = strtolower((string)($edit['name'] ?? ''));
    $editDays=[];
    $map=['sun'=>0,'sunday'=>0,'mon'=>1,'monday'=>1,'tue'=>2,'tues'=>2,'tuesday'=>2,'wed'=>3,'wednesday'=>3,'thu'=>4,'thur'=>4,'thurs'=>4,'thursday'=>4,'fri'=>5,'friday'=>5,'sat'=>6,'saturday'=>6];
    foreach($map as $needle=>$day){ if (strpos($nameForDays,$needle)!==false && !in_array($day,$editDays,true)) $editDays[]=$day; }
    if (!$editDays) $editDays=[];
}
$editMonths=(int)($edit['schedule_months'] ?? 3); if($editMonths<1||$editMonths>12)$editMonths=3;
$editTeacherId=(int)($edit['teacher_id'] ?? 0);
$editCapMap=json_decode((string)($edit['slot_capacities'] ?? ''),true);
if (!is_array($editCapMap)) $editCapMap=[];

require_once __DIR__ . '/_header.php';
?>
<div class="page-header">
  <div><h1>Batch Management</h1><p>Manage batches and their available time slots.</p></div>
</div>

<?php if($success): ?><div class="alert alert-success"><?=e($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert"><?=e($error)?></div><?php endif; ?>

<div class="card">
  <div class="card-header"><div><h2><?= $edit ? 'Edit Batch' : 'Create New Batch' ?></h2><p class="muted">Configure batch days and multiple time slots.</p></div></div>
  <form method="post"><?=csrf_input()?>
    <input type="hidden" name="action" value="save">
    <input type="hidden" name="id" value="<?=e((string)($edit['id'] ?? 0))?>">
    <div class="form-grid">
      <div class="field"><label>Course</label><select name="course_id" required><option value="">Select Course</option>
      <?php foreach($courses as $c): ?><option value="<?=$c['id']?>" <?=((int)($edit['course_id'] ?? 0)===(int)$c['id'])?'selected':''?>><?=e($c['name'])?></option><?php endforeach; ?>
      </select></div>
      <div class="field"><label>Batch Name / Days</label><input name="name" value="<?=e($edit['name'] ?? '')?>" placeholder="Saturday–Wednesday" required></div>
      <div class="field"><label>Start Date</label><input type="date" name="start_date" value="<?=e($edit['start_date'] ?? '')?>"></div>
      <div class="field"><label>Default Capacity Per Time Slot</label><input type="number" name="max_students" min="1" value="<?=e((string)($edit['max_students'] ?? 50))?>" required <?= $canManageCapacity ? '' : 'disabled' ?>><small class="muted"><?= $canManageCapacity ? 'Set any capacity you need. No fixed maximum.' : 'Only Super Admin / Admission Admin can change capacity.' ?></small></div>
      <div class="field"><label>Primary Teacher</label><select name="teacher_id"><option value="0">No Primary Teacher</option><?php foreach($teachers as $t): ?><option value="<?=$t['id']?>" <?=($editTeacherId===(int)$t['id'])?'selected':''?>><?=e($t['name'])?><?=!empty($t['subject'])?' — '.e($t['subject']):''?></option><?php endforeach; ?></select><small class="muted">Default teacher for this batch. Daily class assignment can still be managed separately.</small></div>
      <div class="field"><label>Status</label><select name="status"><?php foreach(['Active','Upcoming','Closed'] as $st): ?><option value="<?=$st?>" <?=($edit['status'] ?? 'Upcoming')===$st?'selected':''?>><?=$st?></option><?php endforeach; ?></select></div>
      <div class="field batch-days-field"><label>Class Days</label><div class="day-checks"><?php foreach($dayOptions as $dayNo=>$dayLabel): ?><label class="day-check"><input type="checkbox" name="class_days[]" value="<?=$dayNo?>" <?=in_array($dayNo,$editDays,true)?'checked':''?>><span><?=e($dayLabel)?></span></label><?php endforeach; ?></div><small class="muted">These days repeat automatically from the start date.</small></div>
      <div class="field"><label>Auto Schedule Period</label><select name="schedule_months"><?php for($m=1;$m<=12;$m++): ?><option value="<?=$m?>" <?=$editMonths===$m?'selected':''?>><?=$m?> month<?=$m>1?'s':''?></option><?php endfor; ?></select><small class="muted">Recommended: 3 months. Existing class details are never overwritten.</small></div>
    </div>
    <div class="field" style="margin-top:20px"><label>Time Slots</label>
      <div id="slotList">
      <?php foreach($editSlots as $slot): $slotCap=max(1,(int)($editCapMap[$slot] ?? ($edit['max_students'] ?? 50))); ?><div class="slot-row"><input type="text" name="time_slots[]" value="<?=e((string)$slot)?>" placeholder="10:00 AM"><input class="slot-capacity-input" type="number" name="slot_capacity[<?=e((string)$slot)?>]" value="<?=$slotCap?>" min="1" title="Capacity" <?= $canManageCapacity ? '' : 'disabled' ?>><button type="button" class="btn btn-secondary remove-slot">Remove</button></div><?php endforeach; ?>
      </div>
      <button type="button" class="btn btn-secondary" id="addSlot" style="margin-top:10px">+ Add Time Slot</button>
    </div>
    <div style="margin-top:24px;display:flex;gap:10px"><button class="btn btn-primary" type="submit"><?= $edit ? 'Update Batch' : 'Save Batch' ?></button><?php if($edit): ?><a class="btn btn-secondary" href="batch-management.php">Cancel</a><?php endif; ?></div>
  </form>
</div>

<div class="card" style="margin-top:24px">
  <div class="card-header batch-list-head">
    <div><h2><?= $showArchived ? 'Archived Batches' : 'Existing Batches' ?></h2><p class="muted"><?= $showArchived ? 'Archived batches are hidden from the normal list and are not deleted.' : 'Finished batches can be archived instead of deleted.' ?></p></div>
    <div class="batch-view-links">
      <?php if($showArchived): ?><a class="btn btn-secondary" href="batch-management.php">Active Batches</a><?php elseif($archivedCount>0): ?><a class="btn btn-secondary" href="batch-management.php?archived=1">Archived (<?=$archivedCount?>)</a><?php endif; ?>
    </div>
  </div>
  <div class="batch-sortbar">
    <span>Sort by:</span>
    <?php foreach(['name'=>'Batch Name','start_date'=>'Start Date','status'=>'Status','course'=>'Course'] as $key=>$label): ?>
      <?php $nextDir=($sort===$key && $dir==='asc')?'desc':'asc'; ?>
      <a class="sort-link <?= $sort===$key ? 'active' : '' ?>" href="batch-management.php?<?=http_build_query(['archived'=>$showArchived?1:0,'sort'=>$key,'dir'=>$nextDir])?>">
        <?=e($label)?> <?= $sort===$key ? ($dir==='asc'?'↑':'↓') : '↕' ?>
      </a>
    <?php endforeach; ?>
  </div>
  <div class="table-wrap"><table class="batch-table"><thead><tr><th>Course</th><th>Batch</th><th>Start Date</th><th>Class Days</th><th>Time Slots</th><th>Primary Teacher</th><th>Capacity</th><th>Status</th><th>Action</th></tr></thead><tbody>
  <?php if(!$batches): ?><tr><td colspan="9" class="muted">No batches found.</td></tr><?php else: foreach($batches as $b): $slots=json_decode((string)($b['time_slots'] ?? ''),true); $slots=is_array($slots)?$slots:[]; ?>
    <tr>
      <td><?=e($b['course_name'] ?? '—')?></td>
      <td><a class="batch-name-link" href="students.php?batch_id=<?=$b['id']?>"><strong><?=e($b['name'])?></strong></a><div class="batch-student-hint">View students</div></td>
      <td><?=e($b['start_date'] ?? '—')?></td>
      <td><?php $rowDays=json_decode((string)($b['class_days'] ?? ''),true); $rowDays=is_array($rowDays)?$rowDays:[]; foreach($rowDays as $dn): ?><span class="tag"><?=e($dayOptions[(int)$dn] ?? (string)$dn)?></span> <?php endforeach; if(!$rowDays): ?><span class="muted">Not set</span><?php endif; ?></td>
      <td><?php foreach($slots as $slot): ?><span class="tag"><?=e((string)$slot)?></span> <?php endforeach; if(!$slots): ?><span class="muted">No time slot</span><?php endif; ?></td>
      <td><?=e($b['teacher_name'] ?? '—')?></td>
      <td><?php $capMap=json_decode((string)($b['slot_capacities'] ?? ''),true); $capMap=is_array($capMap)?$capMap:[]; $fallbackCap=max(1,(int)($b['max_students'] ?? 50)); foreach($slots as $slotName): $cap=max(1,(int)($capMap[$slotName] ?? $fallbackCap)); $cntStmt=$pdo->prepare("SELECT COUNT(*) FROM admissions WHERE batch_id=? AND time_slot=? AND status <> 'Cancelled'"); $cntStmt->execute([(int)$b['id'],(string)$slotName]); $enrolled=(int)$cntStmt->fetchColumn(); $available=max(0,$cap-$enrolled); ?><div><span class="tag"><?=e((string)$slotName)?></span> <strong><?= $enrolled ?>/<?= $cap ?></strong> <small class="batch-student-hint"><?= $available>0 ? $available.' seat(s) available' : 'FULL' ?></small></div><?php endforeach; ?></td>
      <td><span class="batch-status <?=strtolower(e($b['status']))?>"><?=e($b['status'])?></span></td>
      <td><div class="batch-actions">
        <?php if(!$showArchived): ?>
          <a class="btn btn-secondary" href="batch-management.php?edit=<?=$b['id']?>">Edit</a>
          <a class="btn btn-secondary" href="batch-student-slots.php?batch_id=<?=$b['id']?>">Student Slots</a>
          <form method="post" onsubmit="return confirm('Generate any missing class slots for this batch? Existing teacher/topic/routine data will not be changed.');">
            <?=csrf_input()?><input type="hidden" name="action" value="generate_schedule"><input type="hidden" name="id" value="<?=$b['id']?>"><button class="btn btn-secondary" type="submit">Generate Schedule</button>
          </form>
          <form method="post" onsubmit="return confirm('Delete this batch permanently? Only batches with no admission or attendance history can be deleted.');">
            <?=csrf_input()?>
            <input type="hidden" name="action" value="delete">
            <input type="hidden" name="id" value="<?=$b['id']?>">
            <button class="btn btn-danger" type="submit">Delete</button>
          </form>
          <?php if($b['status']==='Closed'): ?>
            <form method="post" onsubmit="return confirm('Archive this finished batch? Its linked students will be hidden from the main Students list, but nothing will be deleted.');">
              <?=csrf_input()?>
              <input type="hidden" name="action" value="archive">
              <input type="hidden" name="id" value="<?=$b['id']?>">
              <button class="btn btn-archive" type="submit">Archive</button>
            </form>
          <?php endif; ?>
        <?php else: ?>
          <form method="post" onsubmit="return confirm('Restore this batch and its linked students to the active lists?');">
            <?=csrf_input()?>
            <input type="hidden" name="action" value="unarchive">
            <input type="hidden" name="id" value="<?=$b['id']?>">
            <button class="btn btn-secondary" type="submit">Restore</button>
          </form>
        <?php endif; ?>
      </div></td>
    </tr>
  <?php endforeach; endif; ?></tbody></table></div>
</div>

<style>
.slot-row{display:flex;gap:10px;margin-bottom:10px}.day-checks{display:flex;gap:7px;flex-wrap:wrap;margin-bottom:5px}.day-check{display:inline-flex!important;align-items:center;gap:6px;padding:8px 10px;border:1px solid #e7e8ec;border-radius:9px;background:#fff;font-size:12px;font-weight:700;cursor:pointer}.day-check input{min-height:0!important;width:auto!important;padding:0!important}.day-check:has(input:checked){border-color:#edc1c7;background:#fff1f3;color:#a81825}.slot-row input{flex:1}.tag{display:inline-block;padding:5px 9px;margin:2px;border-radius:999px;background:#f1f1f1;font-size:13px}.batch-list-head{display:flex;align-items:center;justify-content:space-between;gap:14px}.batch-view-links{display:flex;gap:8px}.batch-sortbar{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:0 20px 14px;color:#737982;font-size:12px}.sort-link{padding:7px 10px;border:1px solid #e7e8ec;border-radius:9px;background:#fff;color:#555!important;font-weight:700}.sort-link.active{border-color:#edc1c7;background:#fff1f3;color:#a81825!important}.batch-name-link{color:#20242b!important}.batch-name-link:hover{color:#c91f2e!important;text-decoration:underline}.batch-student-hint{font-size:10px;color:#8a8f97;margin-top:2px}.batch-status{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:800;background:#f1f2f4}.batch-status.active{background:#eaf7ef;color:#237a46}.batch-status.upcoming{background:#eef4ff;color:#315f9b}.batch-status.closed{background:#f1f1f2;color:#5b5d62}.batch-actions{display:flex;gap:6px;flex-wrap:wrap}.batch-actions form{display:inline}.btn-archive{background:#6b5a2a!important;color:#fff!important;border:0!important}@media(max-width:760px){.batch-list-head{align-items:flex-start;flex-direction:column}.batch-sortbar{padding-left:14px;padding-right:14px}.batch-actions{min-width:150px}.batch-table{min-width:1050px}}
</style>
<script>
document.addEventListener('DOMContentLoaded',()=>{const list=document.getElementById('slotList'),add=document.getElementById('addSlot');
function bind(b){b.addEventListener('click',()=>{let rows=list.querySelectorAll('.slot-row');if(rows.length<=1){rows[0].querySelector('input').value='';return}b.closest('.slot-row').remove()})}
list.querySelectorAll('.remove-slot').forEach(bind);
add.addEventListener('click',()=>{let r=document.createElement('div');r.className='slot-row';r.innerHTML='<input type="text" name="time_slots[]" placeholder="e.g. 6:00 PM"><input class="slot-capacity-input" type="number" name="slot_capacity_new[]" value="<?= (int)($edit['max_students'] ?? 50) ?>" min="1" title="Capacity" <?= $canManageCapacity ? '' : 'disabled' ?>><button type="button" class="btn btn-secondary remove-slot">Remove</button>';list.appendChild(r);bind(r.querySelector('.remove-slot'));r.querySelector('input').focus()})
});
</script>
<?php require_once __DIR__ . '/_footer.php'; ?>

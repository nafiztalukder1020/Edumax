<?php
require_once __DIR__ . '/../config/app.php';
require_access('admissions');
require_once __DIR__ . '/batch-capacity.php';
edumax_ensure_batch_capacity_column($pdo);
edumax_ensure_capacity_override_columns($pdo);
// Compatibility for older databases from the project base.
try {
    $col = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='applications' AND COLUMN_NAME='course_interest'")->fetchColumn();
    if (!(int)$col) $pdo->exec("ALTER TABLE applications ADD COLUMN course_interest VARCHAR(50) NULL AFTER status");
    $col = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='admissions' AND COLUMN_NAME='time_slot'")->fetchColumn();
    if (!(int)$col) $pdo->exec("ALTER TABLE admissions ADD COLUMN time_slot VARCHAR(100) NULL AFTER batch_id");
    $col = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='applications' AND COLUMN_NAME='mock_dates'")->fetchColumn();
    if (!(int)$col) $pdo->exec("ALTER TABLE applications ADD COLUMN mock_dates TEXT NULL AFTER mock_day");
    $col = $pdo->query("SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME='admissions' AND COLUMN_NAME='mock_dates'")->fetchColumn();
    if (!(int)$col) $pdo->exec("ALTER TABLE admissions ADD COLUMN mock_dates TEXT NULL AFTER mock_day");
} catch (Throwable $e) {}

$studentCode = trim($_GET['id'] ?? '');
if ($studentCode === '') exit('Student ID is required.');

$stmt = $pdo->prepare("SELECT s.*, a.id application_id, a.status application_status, a.course_interest, a.lead_source, a.ielts_overall, a.mock_package, a.mock_day, a.mock_dates FROM students s LEFT JOIN applications a ON a.student_id=s.id WHERE s.student_id=? LIMIT 1");
$stmt->execute([$studentCode]);
$student = $stmt->fetch();
if (!$student) exit('Student not found.');

$academicStmt = $pdo->prepare("SELECT id,degree,subject,result,passing_year,institution FROM academic_records WHERE student_id=? ORDER BY FIELD(degree,'Masters','Honors','Diploma','HSC/Equivalent','SSC/Equivalent'), id");
$academicStmt->execute([$student['id']]);
$academics = $academicStmt->fetchAll();

$admissionStmt = $pdo->prepare("SELECT ad.*, c.name course_name, b.name batch_name FROM admissions ad JOIN courses c ON c.id=ad.course_id JOIN batches b ON b.id=ad.batch_id WHERE ad.student_id=? LIMIT 1");
$admissionStmt->execute([$student['id']]);
$admission = $admissionStmt->fetch();

$success=''; $error='';
$currentRole = strtolower(trim((string)($_SESSION['role'] ?? '')));
$canOverrideCapacity = in_array($currentRole, ['super admin', 'admission admin'], true);
require_valid_csrf();

/*
 * Student information edit.
 * Personal, application and existing academic-record fields may be corrected
 * after submission. Financial/admission-deal fields are intentionally never
 * edited here once an admission exists.
 */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '') === 'update_student_info') {
    try {
        $pdo->beginTransaction();

        $fullName = trim((string)($_POST['full_name'] ?? ''));
        $mobile = trim((string)($_POST['mobile'] ?? ''));
        $guardianName = trim((string)($_POST['guardian_name'] ?? ''));
        $guardianMobile = trim((string)($_POST['guardian_mobile'] ?? ''));
        $dob = trim((string)($_POST['date_of_birth'] ?? ''));
        $gender = trim((string)($_POST['gender'] ?? ''));
        $email = trim((string)($_POST['email'] ?? ''));
        $bloodGroup = trim((string)($_POST['blood_group'] ?? ''));
        $presentAddress = trim((string)($_POST['present_address'] ?? ''));

        if ($fullName === '' || $mobile === '') {
            throw new RuntimeException('Student name and mobile are required.');
        }

        if ($dob !== '') {
            $dobObj = DateTime::createFromFormat('Y-m-d', $dob);
            if (!$dobObj || $dobObj->format('Y-m-d') !== $dob) {
                throw new RuntimeException('Invalid date of birth.');
            }
            if ($dob > date('Y-m-d')) {
                throw new RuntimeException('Date of birth cannot be in the future.');
            }
        }

        $u = $pdo->prepare("
            UPDATE students
            SET full_name=?, mobile=?, guardian_name=?, guardian_mobile=?,
                date_of_birth=?, gender=?, email=?, blood_group=?, present_address=?
            WHERE id=?
        ");
        $u->execute([
            $fullName, $mobile, $guardianName ?: null, $guardianMobile ?: null,
            $dob ?: null, $gender ?: null, $email ?: null, $bloodGroup ?: null,
            $presentAddress ?: null, (int)$student['id']
        ]);

        // Application fields can be corrected. Course cannot be changed here
        // after an admission exists, because that would alter the financial record.
        if (!empty($student['application_id'])) {
            $leadSource = trim((string)($_POST['lead_source'] ?? ''));
            $ieltsOverall = trim((string)($_POST['ielts_overall'] ?? ''));
            $mockPackagePost = trim((string)($_POST['mock_package'] ?? ''));
            $mockDayPost = trim((string)($_POST['mock_day'] ?? ''));
            $mockDatesPost = $_POST['mock_dates'] ?? [];
            if (!is_array($mockDatesPost)) $mockDatesPost = [];

            $cleanDates = [];
            foreach ($mockDatesPost as $md) {
                $md = trim((string)$md);
                if ($md === '') continue;
                $dt = DateTime::createFromFormat('Y-m-d', $md);
                if (!$dt || $dt->format('Y-m-d') !== $md) {
                    throw new RuntimeException('Invalid Mock Test date.');
                }
                $cleanDates[] = $md;
            }

            $au = $pdo->prepare("
                UPDATE applications
                SET lead_source=?, ielts_overall=?, mock_package=?, mock_day=?, mock_dates=?
                WHERE id=? AND student_id=?
            ");
            $au->execute([
                $leadSource ?: null,
                $ieltsOverall ?: null,
                $mockPackagePost ?: null,
                $mockDayPost ?: null,
                $cleanDates ? json_encode(array_values($cleanDates), JSON_UNESCAPED_SLASHES) : null,
                (int)$student['application_id'],
                (int)$student['id']
            ]);
        }

        // Update existing academic rows without deleting/recreating history.
        if (!empty($_POST['academic']) && is_array($_POST['academic'])) {
            $acadUpdate = $pdo->prepare("
                UPDATE academic_records
                SET degree=?, subject=?, result=?, passing_year=?, institution=?
                WHERE id=? AND student_id=?
            ");
            foreach ($_POST['academic'] as $academicId => $ac) {
                if (!is_array($ac) || !ctype_digit((string)$academicId)) continue;
                $degree = trim((string)($ac['degree'] ?? ''));
                $subject = trim((string)($ac['subject'] ?? ''));
                $result = trim((string)($ac['result'] ?? ''));
                $passingYear = trim((string)($ac['passing_year'] ?? ''));
                $institution = trim((string)($ac['institution'] ?? ''));
                if ($degree === '') continue;
                $acadUpdate->execute([
                    $degree, $subject ?: null, $result ?: null,
                    $passingYear ?: null, $institution ?: null,
                    (int)$academicId, (int)$student['id']
                ]);
            }
        }

        $audit = $pdo->prepare("
            INSERT INTO audit_logs (user_id, action, student_id, details)
            VALUES (?, ?, ?, ?)
        ");
        $audit->execute([
            (int)$_SESSION['user_id'],
            'Student Information Updated',
            (int)$student['id'],
            'Student information corrected after submission. Admission deal/financial fields were not changed.'
        ]);

        $pdo->commit();

        header('Location: admission-review.php?id='.urlencode($studentCode).'&updated=1');
        exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $e->getMessage();
    }
}

/*
 * Final approval is a separate action from payment.
 * Pending admissions may be approved only after the deal has been saved.
 * The approval transaction assigns receipts to any valid payments that were
 * recorded before approval, then moves the admission to Approved or Active
 * depending on whether the final price is fully paid.
 */
if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['action'] ?? '') === 'approve_admission') {
    if (!$admission) {
        $error = 'Save the admission deal before approving.';
    } elseif (($admission['status'] ?? '') === 'Cancelled') {
        $error = 'Cancelled admissions cannot be approved.';
    } else {
        try {
            $pdo->beginTransaction();

            $lock = $pdo->prepare("
                SELECT id, student_id, course_id, batch_id, time_slot,
                       admission_date, regular_fee, discount, do_discount,
                       final_dealing_price, status
                FROM admissions
                WHERE id=? AND student_id=?
                FOR UPDATE
            ");
            $lock->execute([(int)$admission['id'], (int)$student['id']]);
            $locked = $lock->fetch();

            if (!$locked) {
                throw new RuntimeException('Admission not found. Please refresh the page.');
            }
            if ($locked['status'] === 'Cancelled') {
                throw new RuntimeException('Cancelled admissions cannot be approved.');
            }

            if ((int)$locked['course_id'] <= 0 || (int)$locked['batch_id'] <= 0 ||
                trim((string)$locked['time_slot']) === '' ||
                (float)$locked['regular_fee'] < 0 ||
                (float)$locked['final_dealing_price'] < 0) {
                throw new RuntimeException('Complete the admission deal before approval.');
            }

            $sum = $pdo->prepare("
                SELECT COALESCE(SUM(amount),0)
                FROM payments
                WHERE admission_id=? AND status='Valid'
            ");
            $sum->execute([(int)$locked['id']]);
            $paid = (float)$sum->fetchColumn();
            $final = (float)$locked['final_dealing_price'];
            $due = max(0, $final - $paid);

            // Generate receipts only now: after final approval.
            $pendingPayments = $pdo->prepare("
                SELECT id, amount
                FROM payments
                WHERE admission_id=? AND status='Valid'
                  AND (receipt_no IS NULL OR receipt_no='')
                ORDER BY id ASC
                FOR UPDATE
            ");
            $pendingPayments->execute([(int)$locked['id']]);
            $pendingRows = $pendingPayments->fetchAll();

            $assignReceipt = $pdo->prepare("
                UPDATE payments
                SET receipt_no=?
                WHERE id=? AND admission_id=? AND status='Valid'
            ");

            foreach ($pendingRows as $pendingPayment) {
                $receipt = next_receipt_number();
                $assignReceipt->execute([
                    $receipt,
                    (int)$pendingPayment['id'],
                    (int)$locked['id']
                ]);
            }

            $newStatus = $due <= 0.0001 ? 'Active' : 'Approved';

            $updateAdmission = $pdo->prepare("
                UPDATE admissions
                SET status=?
                WHERE id=? AND status <> 'Cancelled'
            ");
            $updateAdmission->execute([$newStatus, (int)$locked['id']]);

            if (!empty($student['application_id'])) {
                $updateApplication = $pdo->prepare("
                    UPDATE applications SET status=? WHERE id=?
                ");
                $updateApplication->execute([
                    $newStatus,
                    (int)$student['application_id']
                ]);
            }

            $receiptList = [];
            foreach ($pendingRows as $pendingPayment) {
                $qReceipt = $pdo->prepare("SELECT receipt_no FROM payments WHERE id=? LIMIT 1");
                $qReceipt->execute([(int)$pendingPayment['id']]);
                $receiptList[] = (string)$qReceipt->fetchColumn();
            }

            $audit = $pdo->prepare("
                INSERT INTO audit_logs (user_id, action, student_id, details)
                VALUES (?, ?, ?, ?)
            ");
            $audit->execute([
                (int)$_SESSION['user_id'],
                'Admission Approved',
                (int)$student['id'],
                'Admission '.$locked['id'].' approved. Final price: '.$final.
                ', total paid: '.$paid.', due: '.$due.
                ', status: '.$newStatus.
                ', receipts: '.($receiptList ? implode(', ', $receiptList) : 'none')
            ]);

            $pdo->commit();

            header('Location: admission-review.php?id='.urlencode($studentCode).'&approved=1');
            exit;
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $error = $e->getMessage();
        }
    }
}

// Requested mock dates are needed for the page display, not only on POST.
$mockDates = json_decode((string)($student['mock_dates'] ?? '[]'), true);
if (!is_array($mockDates)) $mockDates = [];

if ($_SERVER['REQUEST_METHOD']==='POST' && !$admission) {
    $courseId=(int)($_POST['course_id']??0);
    $batchId=(int)($_POST['batch_id']??0);
    $timeSlot=trim($_POST['time_slot']??'');
    $admissionDate=$_POST['admission_date']??date('Y-m-d');
    $regularFee=0;
    $discountPercent=0;
    $outsideDiscount=max(0,(float)($_POST['outside_discount']??0));
    $firstPayment=max(0,(float)($_POST['first_payment']??0));
    $capacityOverride = isset($_POST['capacity_override']) && $_POST['capacity_override'] === '1';
    $capacityOverrideReason = trim((string)($_POST['capacity_override_reason'] ?? ''));
    $paymentMethod=$_POST['payment_method']??'Cash';
    if (!in_array($paymentMethod,$allowedMethods ?? ['Cash','bKash','Nagad','Bank','Other'],true)) {
        $paymentMethod='Cash';
    }
    $reference=trim($_POST['reference']??'');
    $idCardGiven = isset($_POST['id_card_given']) && $_POST['id_card_given'] === '1';
    $ieltsBookGiven = isset($_POST['ielts_book_given']) && $_POST['ielts_book_given'] === '1';
    $allowedMethods=['Cash','bKash','Nagad','Bank','Other'];
    $courseName='';
    $isMockTest = strcasecmp(trim((string)$student['course_interest']), 'Mock Test') === 0;
    $mockPackage = trim((string)($student['mock_package'] ?? ''));
    $mockDay = trim((string)($student['mock_day'] ?? ''));
    $mockDates = json_decode((string)($student['mock_dates'] ?? '[]'), true);
    $packageCounts=['1 Mock'=>1,'2 Mocks'=>2,'3 Mocks'=>3];
    if (!is_array($mockDates)) $mockDates = [];

    $admissionDateObj = DateTime::createFromFormat('Y-m-d',$admissionDate);
    if (!$admissionDateObj || $admissionDateObj->format('Y-m-d') !== $admissionDate) {
        $error='Invalid admission date.';
    } elseif ($admissionDate > date('Y-m-d')) {
        $error='Admission date cannot be in the future.';
    }

    if($error==='' && $isMockTest) {
        // Mock Test uses a fixed service batch and fixed 10 AM–1 PM time.
        $mockCourseStmt=$pdo->prepare("SELECT id FROM courses WHERE name='Mock Test' AND status='Active' LIMIT 1");
        $mockCourseStmt->execute();
        $mockCourseId=(int)$mockCourseStmt->fetchColumn();
        if($mockCourseId<=0) $error='Mock Test course is not configured. Please run the Mock Test database migration.';
        else $courseId=$mockCourseId;

        $mockBatchStmt=$pdo->prepare("SELECT id FROM batches WHERE course_id=? AND name='Mock Test' AND status IN ('Active','Upcoming') ORDER BY id ASC LIMIT 1");
        $mockBatchStmt->execute([$courseId]);
        $batchId=(int)$mockBatchStmt->fetchColumn();
        $timeSlot='10:00 AM - 01:00 PM';

        if($error==='') {
            if(!in_array($mockPackage,['1 Mock','2 Mocks','3 Mocks'],true)) $error='Invalid Mock Test package.';
            elseif(!in_array($mockDay,['Monday','Wednesday'],true)) $error='Invalid Mock Test day. Please select Monday or Wednesday.';
            elseif($batchId<=0) $error='Mock Test service batch is not configured. Please run the Mock Test database migration.';
            else {
                $requiredDates=(int)($packageCounts[$mockPackage]??0);
                if(count($mockDates)!==$requiredDates) $error='Mock Test package requires exactly '.$requiredDates.' date'.($requiredDates>1?'s.':'.');
                else {
                    $seen=[];
                    foreach($mockDates as $md){
                        $dt=DateTime::createFromFormat('Y-m-d',$md);
                        if(!$dt || $dt->format('Y-m-d')!==$md){$error='Invalid Mock Test date.';break;}
                        if($md<date('Y-m-d')){$error='Mock Test date cannot be in the past.';break;}
                        $dn=$dt->format('l');
                        if(!in_array($dn,['Monday','Wednesday'],true)){$error='Mock Test can only be scheduled on Monday or Wednesday.';break;}
                        if(isset($seen[$md])){$error='Each Mock Test date must be different.';break;}
                        $seen[$md]=true;
                    }
                }
            }
        }

        $packagePrices=['1 Mock'=>500,'2 Mocks'=>900,'3 Mocks'=>1200];
        $regularFee=(float)($packagePrices[$mockPackage]??0);
        $discountPercent=0;
        $outsideDiscount=0;
    } else {
        if($courseId<=0) $error='Please select a course.';
        elseif($batchId<=0) $error='Please select a batch.';
        elseif($timeSlot==='') $error='Please select a time slot.';

        if($error==='') {
            $courseStmt=$pdo->prepare("SELECT name, regular_fee, default_discount_percent FROM courses WHERE id=? AND status='Active' LIMIT 1");
            $courseStmt->execute([$courseId]);
            $courseRow=$courseStmt->fetch();
            if(!$courseRow) $error='Invalid course selected.';
            else {
                $courseName=strtolower(trim((string)$courseRow['name']));
                $regularFee=(float)($courseRow['regular_fee']??0);
                $discountPercent=(float)($courseRow['default_discount_percent']??0);
                if($regularFee<0 || $discountPercent<0 || $discountPercent>100) $error='Invalid fee/discount configuration for this course.';
                elseif($regularFee<=0 && strpos($courseName,'mock')===false) $error='Regular fee is not configured for this course. Please set it in Course & Fees.';
            }
        }

        if($error==='') {
            $slotStmt=$pdo->prepare("SELECT course_id,time_slots,status,COALESCE(max_students,50) AS max_students,slot_capacities FROM batches WHERE id=? LIMIT 1");
            $slotStmt->execute([$batchId]); $slot=$slotStmt->fetch();
            $slots=$slot?json_decode((string)$slot['time_slots'],true):[];
            if(!$slot || (int)$slot['course_id']!==$courseId) $error='Selected batch does not belong to the selected course.';
            elseif($slot['status']==='Closed') $error='Closed batches cannot be selected.';
            elseif(!is_array($slots)||!in_array($timeSlot,$slots,true)) $error='Please select a valid time slot for the selected batch.';
        }
    }

    $discount=round($regularFee*$discountPercent/100,2);
    $afterRegular=max(0,$regularFee-$discount);
    $doDiscount=min($afterRegular,$outsideDiscount);
    $finalPrice=max(0,$afterRegular-$doDiscount);
    if($error==='' && $firstPayment>$finalPrice) $error='1st payment cannot be greater than the final dealing price.';

    if($error==='') {
        // Materials table is prepared before the transaction because CREATE TABLE (DDL)
        // can implicitly commit on MySQL.
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS student_materials (
                id BIGINT UNSIGNED AUTO_INCREMENT PRIMARY KEY,
                student_id INT UNSIGNED NOT NULL,
                material_type VARCHAR(30) NOT NULL,
                status VARCHAR(20) NOT NULL DEFAULT 'Pending',
                given_at DATETIME NULL,
                given_by INT UNSIGNED NULL,
                note VARCHAR(255) NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                UNIQUE KEY uq_student_material (student_id, material_type),
                KEY idx_material_type_status (material_type,status),
                KEY idx_student_material_student (student_id),
                CONSTRAINT fk_student_material_student FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
                CONSTRAINT fk_student_material_user FOREIGN KEY (given_by) REFERENCES users(id) ON DELETE SET NULL
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch(Throwable $e) {
            $error='Materials setup failed. Please check the student_materials table.';
        }
    }

    if ($capacityOverride) {
        if (!$canOverrideCapacity) {
            $error='You are not authorized to use the batch capacity override.';
        } elseif (strlen($capacityOverrideReason) > 255) {
            $error='Capacity override reason must be 255 characters or less.';
        } elseif ($capacityOverrideReason === '') {
            $error='Please enter a reason when using capacity override.';
        }
    }

    if($error==='') {
        try {
            $pdo->beginTransaction();
            // Re-check inside transaction so the deal cannot be duplicated by two submissions.
            $check=$pdo->prepare("SELECT id FROM admissions WHERE student_id=? LIMIT 1");
            $check->execute([$student['id']]);
            if($check->fetchColumn()) throw new Exception('This admission has already been processed. Refresh the page.');

            $status='Pending';

            // Capacity is enforced per batch + time slot. Mock Test keeps its own
            // date-based capacity rules, so the regular 50-seat rule is skipped there.
            if (!$isMockTest) {
                edumax_lock_and_assert_batch_slot_available($pdo, $batchId, $timeSlot, null, $capacityOverride);
            }

            $ins=$pdo->prepare("INSERT INTO admissions (student_id,course_id,batch_id,time_slot,capacity_override,capacity_override_reason,capacity_override_by,admission_date,counsellor,regular_fee,regular_discount_percent,regular_discount_amount,discount,special_discount_percent,special_discount_amount,do_discount,final_dealing_price,reference,status,mock_package,mock_day,mock_dates) VALUES (?,?,?,?,?,?,?, ?,NULL,?,?,?,?,?,?,?,?,?,?,?, ?, ?)");
            $specialPercent = $afterRegular > 0 ? round(($doDiscount / $afterRegular) * 100, 2) : 0;
            $ins->execute([$student['id'],$courseId,$batchId,$timeSlot,$capacityOverride?1:0,$capacityOverrideReason?:null,$capacityOverride?(int)$_SESSION['user_id']:null,$admissionDate,$regularFee,$discountPercent,$discount,$discount,$specialPercent,$doDiscount,$doDiscount,$finalPrice,$reference?:null,$status,$isMockTest?$mockPackage:null,$isMockTest?$mockDay:null,$isMockTest?json_encode($mockDates, JSON_UNESCAPED_SLASHES):null]);
            $admissionId=(int)$pdo->lastInsertId();

            // Generate a receipt only when an actual payment is recorded.
            // Zero-payment admissions do not create a fake payment transaction.
            $paymentNote = $reference !== '' ? $reference : null;
            $receiptNo = null;
            if ($firstPayment > 0.0001) {
                $receiptNo = next_receipt_number();
                $p=$pdo->prepare("INSERT INTO payments (student_id,admission_id,receipt_no,amount,method,note,received_by,status) VALUES (?,?,?,?,?,?,?,'Valid')");
                $p->execute([$student['id'],$admissionId,$receiptNo,$firstPayment,$paymentMethod,$paymentNote,$_SESSION['user_id']]);
            }

            // Save materials given during admission.
            $materialStmt=$pdo->prepare("INSERT INTO student_materials
                (student_id,material_type,status,given_at,given_by)
                VALUES (?,?, 'Given',NOW(),?)
                ON DUPLICATE KEY UPDATE
                    status='Given', given_at=NOW(), given_by=VALUES(given_by)");

            if($idCardGiven) {
                $materialStmt->execute([$student['id'],'ID Card',$_SESSION['user_id']]);
            }

            if($ieltsBookGiven && strpos(strtolower((string)$courseName),'ielts')!==false) {
                $materialStmt->execute([$student['id'],'IELTS Book',$_SESSION['user_id']]);
            }

            if(!empty($student['application_id'])) {
                $u=$pdo->prepare("UPDATE applications SET status=? WHERE id=?"); $u->execute([$status,$student['application_id']]);
            }
            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,?,?)");
            $audit->execute([$_SESSION['user_id'],'Admission Created',$student['id'],'Initial deal created. Final price: '.$finalPrice.', 1st payment: '.$firstPayment.', status: '.$status.', receipt: '.($receiptNo ?: 'none').'. Materials: ID Card='.($idCardGiven?'Given':'Pending').', IELTS Book='.($ieltsBookGiven?'Given':'Pending').($capacityOverride ? '. CAPACITY OVERRIDE: '.$capacityOverrideReason : '')]);
            $pdo->commit();
            header('Location: admission-review.php?id='.urlencode($studentCode).'&saved=1'); exit;
        } catch(Throwable $e) {
            if($pdo->inTransaction()) $pdo->rollBack();
            $error=$e->getMessage();
        }
    }
}

if(isset($_GET['updated'])) $success='Student information updated successfully.';
if(isset($_GET['saved'])) $success='Admission saved successfully. The admission remains Pending until final approval; the payment receipt will be available after approval.';
if(isset($_GET['approved'])) $success='Admission approved successfully. Receipt(s) are now available.';

// Refresh admission after save / normal load.
$admissionStmt->execute([$student['id']]); $admission=$admissionStmt->fetch();
$currentPaid=0; $payments=[];
if($admission){
    $sum=$pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE admission_id=? AND status='Valid'");
    $sum->execute([$admission['id']]); $currentPaid=(float)$sum->fetchColumn();
    $ph=$pdo->prepare("SELECT p.*,u.name received_by_name FROM payments p LEFT JOIN users u ON u.id=p.received_by WHERE p.admission_id=? ORDER BY p.id ASC");
    $ph->execute([$admission['id']]); $payments=$ph->fetchAll();
}
$finalValue=(float)($admission['final_dealing_price']??0);
$dueValue=max(0,$finalValue-$currentPaid);
$firstPaymentValue=(float)($payments[0]['amount']??0);

$courses=$pdo->query("SELECT id,name FROM courses WHERE status='Active' ORDER BY name")->fetchAll();
$batches=$pdo->query("SELECT b.*,c.name course_name FROM batches b JOIN courses c ON c.id=b.course_id WHERE b.status IN ('Active','Upcoming') ORDER BY b.start_date ASC,b.name ASC")->fetchAll();
$batchSlotCounts=[];
try {
    $capQ=$pdo->query("SELECT batch_id,time_slot,COUNT(*) AS enrolled FROM admissions WHERE status <> 'Cancelled' GROUP BY batch_id,time_slot");
    foreach($capQ->fetchAll() as $cr){
        $batchSlotCounts[(int)$cr['batch_id']][(string)$cr['time_slot']] = (int)$cr['enrolled'];
    }
} catch(Throwable $e) {
    $batchSlotCounts=[];
}
require '_header.php';
?>
<style>
/* Materials Given at Admission — isolated styling so global form CSS cannot break the checkbox layout */
#admissionForm .materials-field{
    grid-column:1/-1 !important;
    width:100% !important;
    margin-top:6px !important;
}

#admissionForm .materials-box{
    width:100% !important;
    box-sizing:border-box !important;
    padding:16px 18px !important;
    border:1px solid #eceef2 !important;
    border-radius:12px !important;
    background:#fafbfc !important;
}

#admissionForm .materials-title{
    display:block !important;
    margin:0 0 12px !important;
    font-size:15px !important;
    font-weight:700 !important;
    color:#17191d !important;
}

#admissionForm .material-check{
    display:flex !important;
    flex-direction:row !important;
    align-items:center !important;
    justify-content:flex-start !important;
    gap:10px !important;
    width:auto !important;
    margin:9px 0 !important;
    padding:0 !important;
    cursor:pointer !important;
    font-size:14px !important;
    font-weight:500 !important;
    color:#333 !important;
}

#admissionForm .material-check::before,
#admissionForm .material-check::after{
    content:none !important;
}

#admissionForm .material-check input[type="checkbox"]{
    appearance:auto !important;
    -webkit-appearance:checkbox !important;
    display:inline-block !important;
    width:18px !important;
    height:18px !important;
    min-width:18px !important;
    max-width:18px !important;
    margin:0 !important;
    padding:0 !important;
    flex:0 0 18px !important;
    position:static !important;
    transform:none !important;
    accent-color:#C91F2E;
}

#admissionForm .material-check span{
    display:inline-block !important;
    margin:0 !important;
    padding:0 !important;
    line-height:1.4 !important;
}

#admissionForm .materials-hint{
    margin-top:10px !important;
    font-size:11px !important;
    line-height:1.5 !important;
    color:#737982 !important;
}

#admissionForm #final_preview{font-weight:800;color:#c91f2e}
#admissionForm #due_preview{font-weight:800;color:#b31e2c}
#admissionForm #first_payment:invalid{border-color:#c91f2e}
</style>
<div class="section-title">
<div>
    <h1>Admission Processing</h1>
    <p><?=e($student['full_name'])?> · <?=e($student['student_id'])?></p>
</div>
<div class="actions" style="display:flex;gap:8px;flex-wrap:wrap">
    <a href="admissions.php" class="btn btn-light">← Back</a>

    <?php if($admission && strcasecmp((string)($admission['course_name'] ?? ''),'Mock Test')===0): ?>
        <a href="mock-test.php?admission_id=<?=urlencode((string)$admission['id'])?>" class="btn btn-primary">
            Mock Test
        </a>
    <?php endif; ?>

    <?php if($admission && $dueValue>0 && $admission['status']==='Approved'): ?>
        <a href="due-payment.php?id=<?=urlencode($studentCode)?>" class="btn btn-primary">+ Due Payment</a>
    <?php endif; ?>
</div>
</div>
<?php if($success): ?><div class="success"><?=e($success)?></div><?php endif; ?>
<?php if($error): ?><div class="alert"><?=e($error)?></div><?php endif; ?>

<div class="card edmx-card">
<div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap">
    <h2 style="margin:0">Student Information</h2>
    <button type="button" class="btn btn-light" id="editStudentBtn" onclick="toggleStudentEdit()">✎ Edit Information</button>
</div>

<div id="studentInfoView" class="form-grid" style="margin-top:16px">
<div><small>Student ID</small><strong><?=e($student['student_id'])?></strong></div>
<div><small>Full Name</small><strong><?=e($student['full_name'])?></strong></div>
<div><small>Mobile</small><strong><?=e($student['mobile'])?></strong></div>
<div><small>Guardian</small><strong><?=e($student['guardian_name']?:'-')?></strong></div>
<div><small>Guardian Mobile</small><strong><?=e($student['guardian_mobile']?:'-')?></strong></div>
<div><small>Date of Birth</small><strong><?=e($student['date_of_birth']?:'-')?></strong></div>
<div><small>Gender</small><strong><?=e($student['gender']?:'-')?></strong></div>
<div><small>Email</small><strong><?=e($student['email']?:'-')?></strong></div>
<div><small>Blood Group</small><strong><?=e($student['blood_group']?:'-')?></strong></div>
<div style="grid-column:1/-1"><small>Present Address</small><strong><?=e($student['present_address']?:'-')?></strong></div>
</div>

<form method="post" id="studentInfoEdit" style="display:none;margin-top:16px">
<?=csrf_input()?>
<input type="hidden" name="action" value="update_student_info">
<div class="form-grid">
<div><label>Student ID</label><input type="text" value="<?=e($student['student_id'])?>" readonly></div>
<div><label>Full Name</label><input type="text" name="full_name" value="<?=e($student['full_name'])?>" required></div>
<div><label>Mobile</label><input type="text" name="mobile" value="<?=e($student['mobile'])?>" required></div>
<div><label>Guardian Name</label><input type="text" name="guardian_name" value="<?=e($student['guardian_name']??'')?>"></div>
<div><label>Guardian Mobile</label><input type="text" name="guardian_mobile" value="<?=e($student['guardian_mobile']??'')?>"></div>
<div><label>Date of Birth</label><input type="date" name="date_of_birth" value="<?=e($student['date_of_birth']??'')?>"></div>
<div><label>Gender</label><select name="gender"><option value="">Select</option><option value="Male" <?=$student['gender']==='Male'?'selected':''?>>Male</option><option value="Female" <?=$student['gender']==='Female'?'selected':''?>>Female</option><option value="Other" <?=$student['gender']==='Other'?'selected':''?>>Other</option></select></div>
<div><label>Email</label><input type="email" name="email" value="<?=e($student['email']??'')?>"></div>
<div><label>Blood Group</label><input type="text" name="blood_group" value="<?=e($student['blood_group']??'')?>"></div>
<div style="grid-column:1/-1"><label>Present Address</label><textarea name="present_address" rows="3"><?=e($student['present_address']??'')?></textarea></div>
</div>

<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px">
<button type="button" class="btn btn-light" onclick="toggleStudentEdit(false)">Cancel</button>
<button type="submit" class="btn btn-primary">✓ Update Information</button>
</div>
</form>
</div><br>

<div class="card edmx-card"><h2>Application Information</h2><div class="form-grid"><div><small>Course</small><strong><?=e($student['course_interest']?:($admission['course_name']??'-'))?></strong></div><?php if(strcasecmp((string)$student['course_interest'],'IELTS')===0 || !empty($student['ielts_overall'])): ?><div><small>IELTS Overall Target</small><strong><?=e($student['ielts_overall']?:'-')?></strong></div><?php endif; ?><?php if(strcasecmp((string)$student['course_interest'],'Mock Test')===0): ?><div><small>Mock Package</small><strong><?=e($student['mock_package']?:'-')?></strong></div><div style="grid-column:1/-1"><small>Requested Mock Dates</small><strong><?=e($mockDates ? implode(' · ', array_map(fn($d)=>date('d M Y', strtotime($d)), $mockDates)) : ($student['mock_day']?:'-'))?> · 10:00 AM – 1:00 PM</strong></div><?php endif; ?><div><small>Lead Source</small><strong><?=e($student['lead_source']?:'-')?></strong></div></div></div><br>

<div class="card edmx-card">
<div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap">
<h2 style="margin:0">Academic Information</h2>
<button type="button" class="btn btn-light" id="editAcademicBtn" onclick="toggleAcademicEdit()">✎ Edit Academic</button>
</div>
<div id="academicView" class="table-wrap" style="margin-top:14px"><table class="table"><tr><th>Degree</th><th>Subject / Group</th><th>Result</th><th>Passing Year</th><th>Institution</th></tr><?php foreach($academics as $ac): ?><tr><td><?=e($ac['degree'])?></td><td><?=e($ac['subject']?:'-')?></td><td><?=e($ac['result']?:'-')?></td><td><?=e($ac['passing_year']?:'-')?></td><td><?=e($ac['institution']?:'-')?></td></tr><?php endforeach; ?><?php if(!$academics): ?><tr><td colspan="5">No academic information found.</td></tr><?php endif; ?></table></div>
<form method="post" id="academicEdit" style="display:none;margin-top:14px">
<?=csrf_input()?>
<input type="hidden" name="action" value="update_student_info">
<div class="table-wrap"><table class="table"><tr><th>Degree</th><th>Subject / Group</th><th>Result</th><th>Passing Year</th><th>Institution</th></tr>
<?php foreach($academics as $ac): ?><tr>
<td><input type="text" name="academic[<?=e($ac['id']??'')?>][degree]" value="<?=e($ac['degree'])?>" required></td>
<td><input type="text" name="academic[<?=e($ac['id']??'')?>][subject]" value="<?=e($ac['subject']??'')?>"></td>
<td><input type="text" name="academic[<?=e($ac['id']??'')?>][result]" value="<?=e($ac['result']??'')?>"></td>
<td><input type="text" name="academic[<?=e($ac['id']??'')?>][passing_year]" value="<?=e($ac['passing_year']??'')?>"></td>
<td><input type="text" name="academic[<?=e($ac['id']??'')?>][institution]" value="<?=e($ac['institution']??'')?>"></td>
</tr><?php endforeach; ?>
<?php if(!$academics): ?><tr><td colspan="5">No academic records available to edit.</td></tr><?php endif; ?>
</table></div>
<div style="display:flex;justify-content:flex-end;gap:10px;margin-top:14px">
<button type="button" class="btn btn-light" onclick="toggleAcademicEdit(false)">Cancel</button>
<button type="submit" class="btn btn-primary">✓ Update Academic Information</button>
</div>
</form>
</div><br>

<?php if(!$admission): ?>
<div class="card edmx-card"><h2>Initial Admission Deal</h2><p style="color:#737982;margin-top:4px">Enter the first deal and 1st payment. After saving, all deal/payment fields are permanently locked from normal editing.</p><form method="post" id="admissionForm"><?=csrf_input()?><div class="form-grid">
<div><label>Course</label><select name="course_id" id="course_id" required><option value="">Select Course</option><?php foreach($courses as $c): ?><option value="<?=$c['id']?>" <?=($student['course_interest']===$c['name']?'selected':'')?>><?=e($c['name'])?></option><?php endforeach; ?></select></div>
<div id="regularBatchField"><label>Batch</label><select name="batch_id" id="batch_id"><option value="">Select Batch</option><?php foreach($batches as $b): ?><?php $slotCounts=$batchSlotCounts[(int)$b['id']]??[]; ?><option value="<?=$b['id']?>" data-course="<?=$b['course_id']?>" data-slots='<?=e($b['time_slots']??'[]')?>' data-capacity="<?=e((string)($b['max_students']??50))?>" data-slotcapacities='<?=e((string)($b['slot_capacities']??'{}'))?>' data-counts='<?=e(json_encode($slotCounts,JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES))?>'><?=e($b['name'])?> — <?=e($b['course_name'])?></option><?php endforeach; ?></select></div>
<div id="regularTimeField"><label>Time Slot</label><select name="time_slot" id="time_slot"><option value="">Select batch first</option></select></div>
<?php if($canOverrideCapacity): ?>
<div id="capacityOverrideField" style="grid-column:1/-1;display:none;padding:14px 16px;border:1px solid #f0d5d8;border-radius:12px;background:#fff8f9">
    <label style="display:flex;align-items:center;gap:9px;font-weight:700;cursor:pointer">
        <input type="checkbox" name="capacity_override" id="capacity_override" value="1">
        <span>Allow One-Time Capacity Override</span>
    </label>
    <div id="capacityOverrideReasonWrap" style="display:none;margin-top:10px">
        <label>Override Reason</label>
        <input type="text" name="capacity_override_reason" id="capacity_override_reason" maxlength="255" placeholder="e.g. Special approval / urgent admission">
    </div>
    <small id="capacityOverrideHint" style="display:block;margin-top:8px;color:#737982">Only use this when the selected time slot is full. The configured batch capacity will not be changed.</small>
</div>
<?php endif; ?>
<?php if(strcasecmp((string)$student['course_interest'],'Mock Test')===0): ?>
<div id="mockServiceInfo" style="grid-column:1/-1;padding:14px 16px;border:1px solid #f0d5d8;border-radius:12px;background:#fff8f9"><strong style="color:#c91f2e">Mock Test Schedule</strong><div style="margin-top:6px"><?=e($student['mock_package']?:'-')?> · <?=e($mockDates ? implode(', ', array_map(fn($d)=>date('d M Y', strtotime($d)), $mockDates)) : ($student['mock_day']?:'-'))?> · 10:00 AM – 1:00 PM</div></div>
<?php endif; ?>
<div><label>Admission Date</label><input type="date" name="admission_date" value="<?=date('Y-m-d')?>" required></div>
<div><label>Regular Fee</label><input type="text" id="regular_fee" value="Auto" readonly></div>
<div><label>Regular Discount</label><input type="text" id="discount_percent" value="Auto" readonly></div>
<div><label>Outside Discount (Manual Amount)</label><input type="number" step="0.01" min="0" name="outside_discount" id="outside_discount" value="0"></div>
<div><label>Final Dealing Price</label><input type="text" id="final_preview" value="৳ 0.00" readonly></div>
<div><label>1st Payment</label><input type="number" step="0.01" min="0" name="first_payment" id="first_payment" required></div>
<div><label>Due After 1st Payment</label><input type="text" id="due_preview" value="৳ 0.00" readonly></div>
<div><label>Payment Method</label><select name="payment_method"><option>Cash</option><option>bKash</option><option>Nagad</option><option>Bank</option><option>Other</option></select></div>
<div><label>Reference</label><input type="text" name="reference" placeholder="Optional reference"></div>
<div class="materials-field">
    <div class="materials-box">
        <div class="materials-title">Materials Given at Admission</div>

        <label class="material-check" for="id_card_given">
            <input id="id_card_given" type="checkbox" name="id_card_given" value="1">
            <span>🎫 ID Card Given</span>
        </label>

        <label id="ieltsBookOption" class="material-check" for="ielts_book_given">
            <input id="ielts_book_given" type="checkbox" name="ielts_book_given" value="1">
            <span>📘 IELTS Book Given</span>
        </label>

        <div id="materialsHint" class="materials-hint">
            ID Card is available for every student. IELTS Book is available only for IELTS students.
        </div>
    </div>
</div>
</div><div class="actions" style="margin-top:18px"><button class="btn btn-primary" type="submit">Save Admission & Lock Deal</button></div></form></div>
<script>
const course=document.getElementById('course_id'), batch=document.getElementById('batch_id'), slot=document.getElementById('time_slot');
const outside=document.getElementById('outside_discount'), firstPayment=document.getElementById('first_payment');
const fp=document.getElementById('final_preview'), duePreview=document.getElementById('due_preview'), form=document.getElementById('admissionForm');
const regularBatchField=document.getElementById('regularBatchField'), regularTimeField=document.getElementById('regularTimeField');
const studentCourse = <?=json_encode((string)($student['course_interest']??''))?>;
const mockPackage = <?=json_encode((string)($student['mock_package']??''))?>;
const mockPrices = {'1 Mock':500,'2 Mocks':900,'3 Mocks':1200};

function loadSlots(){
    slot.innerHTML='<option value="">Select time slot</option>';
    const opt=batch.options[batch.selectedIndex];
    if(!opt||!opt.value) return;
    let slots=[]; let counts={}; let slotCapacities={};
    const defaultCapacity=parseInt(opt.dataset.capacity||'50',10)||50;
    try{slots=JSON.parse(opt.dataset.slots||'[]')}catch(e){}
    try{counts=JSON.parse(opt.dataset.counts||'{}')}catch(e){}
    try{slotCapacities=JSON.parse(opt.dataset.slotcapacities||'{}')}catch(e){}
    slots.forEach(s=>{
        const o=document.createElement('option');
        const enrolled=parseInt(counts[s]||0,10);
        const configured=parseInt(slotCapacities[s],10);
        const capacity=Number.isFinite(configured) && configured>0 ? configured : defaultCapacity;
        const available=Math.max(0,capacity-enrolled);
        o.value=s; o.textContent=s+' — '+enrolled+'/'+capacity+(available>0?' ('+available+' seats)':' (FULL)');
        o.disabled=false;
        o.dataset.full=available<=0?'1':'0';
        slot.appendChild(o);
    });
    refreshCapacityOverride();
}

const capacityOverrideField=document.getElementById('capacityOverrideField');
const capacityOverrideCheckbox=document.getElementById('capacity_override');
const capacityOverrideReasonWrap=document.getElementById('capacityOverrideReasonWrap');
const capacityOverrideReason=document.getElementById('capacity_override_reason');

function refreshCapacityOverride(){
    if(!capacityOverrideField || !capacityOverrideCheckbox) return;
    const selected=slot.options[slot.selectedIndex];
    const isFull=!!selected && selected.dataset.full==='1';
    capacityOverrideField.style.display=isFull?'block':'none';
    if(!isFull){
        capacityOverrideCheckbox.checked=false;
        if(capacityOverrideReason) capacityOverrideReason.value='';
    }
    if(capacityOverrideReasonWrap) capacityOverrideReasonWrap.style.display=capacityOverrideCheckbox.checked?'block':'none';
    if(capacityOverrideReason) capacityOverrideReason.required=capacityOverrideCheckbox.checked;
}

if(capacityOverrideCheckbox) capacityOverrideCheckbox.addEventListener('change',refreshCapacityOverride);

function getPricing(){
    const name=(course.options[course.selectedIndex]?.text||'').toLowerCase();
    if(studentCourse.toLowerCase()==='mock test'){
        const fee=mockPrices[mockPackage]||0;
        return {fee,percent:0,final:fee};
    }
    const fee=name.includes('spoken')?12000:(name.includes('ielts')?20000:0);
    const percent=name.includes('spoken')?50:(name.includes('ielts')?40:0);
    const regularDiscount=fee*percent/100;
    const afterRegular=Math.max(0,fee-regularDiscount);
    const extra=Math.min(Math.max(0,parseFloat(outside.value)||0),afterRegular);
    return {fee,percent,final:Math.max(0,afterRegular-extra)};
}

function pricing(){
    const p=getPricing();
    fp.value='৳ '+p.final.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
    document.getElementById('regular_fee').value=p.fee?'৳ '+p.fee.toLocaleString():'Auto';
    document.getElementById('discount_percent').value=p.fee?(p.percent+'% fixed'):'Auto';

    const paid=Math.max(0,parseFloat(firstPayment.value)||0);
    const due=Math.max(0,p.final-paid);
    duePreview.value='৳ '+due.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});

    firstPayment.max=p.final.toFixed(2);
    firstPayment.setCustomValidity(paid>p.final ? '1st payment cannot be greater than the final dealing price.' : '');
}

const ieltsBookOption=document.getElementById('ieltsBookOption');
const ieltsBookCheckbox=document.querySelector('input[name="ielts_book_given"]');

function updateMaterialOptions(){
    const name=(course.options[course.selectedIndex]?.text||'').toLowerCase();
    const isIelts=name.includes('ielts');
    ieltsBookOption.style.display=isIelts?'flex':'none';
    if(!isIelts) ieltsBookCheckbox.checked=false;
}

function filterBatches(){
    const isMock=studentCourse.toLowerCase()==='mock test';
    if(isMock){
        regularBatchField.style.display='none';
        regularTimeField.style.display='none';
        batch.required=false;
        slot.required=false;
    }else{
        regularBatchField.style.display='';
        regularTimeField.style.display='';
        batch.required=true;
        slot.required=true;
        [...batch.options].forEach(o=>{
            if(o.value) o.hidden=o.dataset.course!==course.value;
        });
    }
    updateMaterialOptions();
}

batch.addEventListener('change',loadSlots);
slot.addEventListener('change',refreshCapacityOverride);
course.addEventListener('change',()=>{
    filterBatches();
    batch.value='';
    slot.innerHTML='<option value="">Select batch first</option>';
    pricing();
});
outside.addEventListener('input',pricing);
firstPayment.addEventListener('input',pricing);

form.addEventListener('submit',(event)=>{
    pricing();
    if(!form.checkValidity()){
        event.preventDefault();
        form.reportValidity();
    }
});

// Select the student's course automatically on initial load.
filterBatches();
const initialCourse=course.value;
if(initialCourse){
    const firstMatchingBatch=[...batch.options].find(o=>o.value && o.dataset.course===initialCourse);
    if(firstMatchingBatch){
        batch.value=firstMatchingBatch.value;
        loadSlots();
    }
}
pricing();
</script>
<?php else: ?>
<div class="card edmx-card"><div style="display:flex;justify-content:space-between;gap:12px;align-items:center;flex-wrap:wrap"><div><h2>Admission Deal — Locked</h2><p style="color:#737982;margin-top:4px">This original deal cannot be edited after the first payment is saved.</p></div><span class="badge <?=strtolower($admission['status'])?>"><?=e($admission['status'])?></span></div>
<?php if(($admission['status'] ?? '') === 'Pending'): ?>
<form method="post" style="margin-top:16px;display:flex;justify-content:flex-end;gap:10px" onsubmit="return confirm('Approve this admission? The saved payment receipt will be generated and the deal will remain locked.');">
    <?=csrf_input()?>
    <input type="hidden" name="action" value="approve_admission">
    <button class="btn btn-primary" type="submit">✓ Final Approve Admission</button>
</form>
<?php endif; ?>
<br><div class="form-grid">
<div><small>Course</small><strong><?=e($admission['course_name'])?></strong></div><?php if(strcasecmp((string)($admission['course_name']??''),'Mock Test')===0): ?><div><small>Mock Package</small><strong><?=e($admission['mock_package']??'-')?></strong></div><div><small>Mock Day</small><strong><?=e($admission['mock_day']??'-')?></strong></div><?php endif; ?><div><small>Batch</small><strong><?=e($admission['batch_name'])?></strong></div><div><small>Time Slot</small><strong><?=e($admission['time_slot']?:'-')?></strong></div><div><small>Admission Date</small><strong><?=e($admission['admission_date'])?></strong></div><div><small>Regular Fee</small><strong>৳ <?=number_format((float)$admission['regular_fee'],2)?></strong></div><div><small>Regular Discount</small><strong>৳ <?=number_format((float)$admission['discount'],2)?></strong></div><div><small>Outside Discount</small><strong>৳ <?=number_format((float)$admission['do_discount'],2)?></strong></div><div><small>Final Dealing Price</small><strong>৳ <?=number_format($finalValue,2)?></strong></div><div><small>1st Payment</small><strong>৳ <?=number_format($firstPaymentValue,2)?></strong></div><div><small>Total Paid</small><strong>৳ <?=number_format($currentPaid,2)?></strong></div><div><small>Total Due</small><strong style="color:<?= $dueValue>0?'#c91f2e':'#198754' ?>">৳ <?=number_format($dueValue,2)?></strong></div>
</div><?php if($dueValue>0 && $admission['status']==='Approved'): ?><div style="margin-top:18px"><a class="btn btn-primary" href="due-payment.php?id=<?=urlencode($studentCode)?>">+ 2nd / Due Payment</a></div><?php endif; ?></div><br>
<div class="card edmx-card"><h2>Payment History</h2><div class="table-wrap"><table class="table"><tr><th>#</th><th>Receipt</th><th>Amount</th><th>Method</th><th>Date</th><th>Received By</th><th>Status</th></tr><?php foreach($payments as $i=>$p): ?><tr><td><?=($i+1)?></td><td><?php if(!empty($p['receipt_no'])): ?><a href="receipt.php?receipt=<?=urlencode($p['receipt_no'])?>"><?=e($p['receipt_no'])?></a><?php else: ?><span class="badge pending">Pending Approval</span><?php endif; ?></td><td>৳ <?=number_format((float)$p['amount'],2)?></td><td><?=e($p['method'])?></td><td><?=e(date('d M Y, h:i A',strtotime($p['created_at'])))?></td><td><?=e($p['received_by_name']?:'-')?></td><td><?=e($p['status'])?></td></tr><?php endforeach; ?></table></div></div>
<?php endif; ?>

<script>
function toggleStudentEdit(show) {
    const view = document.getElementById('studentInfoView');
    const form = document.getElementById('studentInfoEdit');
    const btn = document.getElementById('editStudentBtn');
    if (!view || !form) return;
    const open = typeof show === 'boolean' ? show : form.style.display === 'none';
    view.style.display = open ? 'none' : 'grid';
    form.style.display = open ? 'block' : 'none';
    if (btn) btn.textContent = open ? '✕ Close Edit' : '✎ Edit Information';
}
function toggleAcademicEdit(show) {
    const view = document.getElementById('academicView');
    const form = document.getElementById('academicEdit');
    const btn = document.getElementById('editAcademicBtn');
    if (!view || !form) return;
    const open = typeof show === 'boolean' ? show : form.style.display === 'none';
    view.style.display = open ? 'none' : 'block';
    form.style.display = open ? 'block' : 'none';
    if (btn) btn.textContent = open ? '✕ Close Edit' : '✎ Edit Academic';
}
</script>
<?php require '_footer.php'; ?>

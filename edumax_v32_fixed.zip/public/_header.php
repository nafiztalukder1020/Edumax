<?php
require_once __DIR__ . '/../config/app.php';

require_admin();

$canIeltsWorkspace = user_has_permission('dashboard');
$canConsultancyWorkspace = user_has_permission('consultancy_dashboard');
$activeWorkspace = (($_SESSION['workspace'] ?? 'ielts') === 'consultancy' && $canConsultancyWorkspace)
    ? 'consultancy'
    : 'ielts';
?>
<!doctype html>
<html lang="en">
<head>

<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">

<title>Edumax Admission Management System</title>

<link rel="stylesheet" href="assets/style.css">
<link rel="stylesheet" href="assets/edumax-modern.css">
<link rel="stylesheet" href="assets/responsive.css">

<style>
.edmx-top-accent{
    position:fixed;
    top:0;
    left:0;
    right:0;
    height:3px;
    background:linear-gradient(
        90deg,
        #cf1f32,
        #5b5c60,
        #cf1f32
    );
    z-index:9999;
}


/* ==========================================
   GLOBAL STUDENT SEARCH
========================================== */

.global-student-search{
    display:flex;
    align-items:center;
    gap:8px;

    width:280px;
    height:40px;

    padding:0 12px;

    border:1px solid #e4e5e9;
    border-radius:11px;

    background:#fff;

    box-sizing:border-box;

    transition:
        border-color .2s ease,
        box-shadow .2s ease;
}

.global-student-search:focus-within{
    border-color:#c91f2e;
    box-shadow:0 0 0 3px rgba(201,31,46,.08);
}

.global-student-search .search-icon{
    flex:0 0 auto;

    width:20px;
    height:20px;

    display:flex;
    align-items:center;
    justify-content:center;

    color:#777d86;

    font-size:18px;
    line-height:1;
}

.global-student-search input{
    width:100%;

    border:0 !important;
    outline:0 !important;

    background:transparent !important;

    padding:0 !important;
    margin:0 !important;

    min-height:0 !important;

    box-shadow:none !important;

    font-size:13px;
    color:#20242b;
}

.global-student-search input::placeholder{
    color:#8a9098;
}

.global-student-search button{
    flex:0 0 auto;

    border:0;
    background:transparent;

    padding:0;

    cursor:pointer;

    color:#777d86;

    font-size:17px;

    display:flex;
    align-items:center;
    justify-content:center;
}

.global-student-search button:hover{
    color:#c91f2e;
}


/* Tablet */

@media(max-width:1000px){

    .global-student-search{
        width:230px;
    }

}


/* Mobile */

@media(max-width:680px){

    .global-student-search{
        display:none;
    }

}


/* ==========================================
   SIDEBAR LAYOUT
========================================== */

.edmx-sidebar-layout-final{}

.sidebar{
    position:fixed!important;
    top:0!important;
    bottom:0!important;
    left:0!important;
    width:var(--sidebar)!important;
    z-index:1100!important;
    overflow-y:auto!important;
}


/* ==========================================
   VECTOR SIDEBAR ICONS
========================================== */
.nav-icon{
    width:20px!important; min-width:20px!important; height:20px!important;
    display:inline-flex!important; align-items:center!important; justify-content:center!important;
    flex:0 0 20px!important; margin-right:12px!important;
    color:currentColor!important; line-height:0!important;
}
.nav-icon svg{
    width:18px!important; height:18px!important; display:block!important;
    fill:none!important; stroke:currentColor!important; stroke-width:1.9!important;
    stroke-linecap:round!important; stroke-linejoin:round!important;
}


/* ==========================================
   WORKSPACE SWITCHER
========================================== */
.workspace-switcher{
    margin:0 0 18px;
    padding:0 2px 16px;
    border-bottom:1px solid rgba(255,255,255,.09);
}
.workspace-switcher-label{
    margin:0 0 8px 2px;
    color:rgba(255,255,255,.48);
    font-size:9px;
    font-weight:800;
    letter-spacing:.12em;
    text-transform:uppercase;
}
.workspace-toggle{
    display:flex;
    align-items:center;
    width:100%;
    min-height:40px;
    padding:3px;
    gap:2px;
    background:rgba(255,255,255,.07);
    border:1px solid rgba(255,255,255,.10);
    border-radius:11px;
    box-sizing:border-box;
}
.workspace-toggle a{
    position:relative;
    flex:1 1 50%;
    min-width:0;
    min-height:32px;
    display:flex;
    align-items:center;
    justify-content:center;
    padding:0 7px;
    border-radius:8px;
    color:rgba(255,255,255,.62);
    text-decoration:none;
    font-size:10px;
    font-weight:800;
    letter-spacing:.01em;
    white-space:nowrap;
    transition:all .18s ease;
}
.workspace-toggle a:hover{
    color:#fff;
    background:rgba(255,255,255,.07);
}
.workspace-toggle a.active{
    color:#c91f2e;
    background:#fff;
    box-shadow:0 3px 10px rgba(0,0,0,.12);
}
.workspace-toggle .workspace-dot{
    width:6px;
    height:6px;
    margin-right:5px;
    border-radius:50%;
    background:currentColor;
    flex:0 0 6px;
}

</style>

</head>

<body>

<div class="edmx-top-accent"></div>


<!-- ==========================================
     TOPBAR
========================================== -->

<header class="topbar">

    <button
        class="menu-toggle"
        type="button"
        aria-label="Open menu"
        onclick="event.stopPropagation(); document.body.classList.toggle('sidebar-open'); this.setAttribute('aria-expanded', document.body.classList.contains('sidebar-open') ? 'true' : 'false')"
    >
        ☰
    </button>


    <a
        class="mobile-brand"
        href="<?= $activeWorkspace === 'consultancy' ? 'consultancy-dashboard.php' : 'dashboard.php' ?>"
    >
        <img
            src="assets/edumax-logo.png"
            class="top-logo"
            alt="Edumax IELTS Center"
        >
    </a>


    <div class="topbar-spacer"></div>


    <div class="topbar-right">


        <!-- ==========================================
             GLOBAL STUDENT SEARCH
        =========================================== -->

        <?php if (user_has_permission('students')): ?>

            <form
                method="get"
                action="students.php"
                class="global-student-search"
                role="search"
            >

                <span
                    class="search-icon"
                    aria-hidden="true"
                >
                    
                </span>


                <input
                    type="search"
                    name="q"
                    value="<?=e($_GET['q'] ?? '')?>"
                    placeholder="Search student..."
                    autocomplete="off"
                    aria-label="Search student by name, mobile or student ID"
                >


                <button
                    type="submit"
                    aria-label="Search"
                    title="Search"
                >
                    
                </button>

            </form>

        <?php endif; ?>


        <!-- ==========================================
             USER CHIP
        =========================================== -->

        <div class="user-chip">

            <span class="user-avatar">
                <?=e(
                    strtoupper(
                        substr(
                            $_SESSION['user_name'] ?? 'A',
                            0,
                            1
                        )
                    )
                )?>
            </span>


            <span class="admin-name">
                <?=e(
                    $_SESSION['user_name'] ?? 'Admin'
                )?>
            </span>

        </div>


        <!-- ==========================================
             LOGOUT
        =========================================== -->

        <a
            class="logout-link"
            href="logout.php?_csrf=<?=e(csrf_token())?>"
        >
            Logout
        </a>


    </div>

</header>


<div class="layout">


<!-- ==========================================
     SIDEBAR
========================================== -->

<aside
    class="sidebar"
    id="sidebar"
>


    <!-- SIDEBAR BRAND -->

    <div class="sidebar-brand">

        <a href="<?= $activeWorkspace === 'consultancy' ? 'consultancy-dashboard.php' : 'dashboard.php' ?>">

            <img
                src="assets/edumax-logo.png"
                alt="Edumax IELTS Center"
            >

        </a>


        <span>
            <?= $activeWorkspace === 'consultancy' ? 'Consultancy Management' : 'Admission Management' ?>
        </span>

    </div>


    <?php if ($canIeltsWorkspace && $canConsultancyWorkspace): ?>

        <div class="workspace-switcher">

            <div class="workspace-switcher-label">Workspace</div>

            <div class="workspace-toggle" role="group" aria-label="Workspace switcher">

                <a
                    href="workspace-switch.php?to=ielts"
                    class="<?= $activeWorkspace === 'ielts' ? 'active' : '' ?>"
                    aria-current="<?= $activeWorkspace === 'ielts' ? 'page' : 'false' ?>"
                >
                    <span class="workspace-dot"></span>IELTS
                </a>

                <a
                    href="workspace-switch.php?to=consultancy"
                    class="<?= $activeWorkspace === 'consultancy' ? 'active' : '' ?>"
                    aria-current="<?= $activeWorkspace === 'consultancy' ? 'page' : 'false' ?>"
                >
                    <span class="workspace-dot"></span>Consultancy
                </a>

            </div>

        </div>

    <?php endif; ?>


    <!-- ==========================================
         NAVIGATION
    =========================================== -->

    <nav>

        <?php

        $currentPage =
            basename($_SERVER['PHP_SELF']);

        ?>


        <?php

        $workspace = $activeWorkspace;

        if ($workspace === 'consultancy') {

            $navItems = [

                [
                    'consultancy_dashboard',
                    'consultancy-dashboard.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="3" width="7" height="7" rx="1"/><rect x="14" y="3" width="7" height="7" rx="1"/><rect x="3" y="14" width="7" height="7" rx="1"/><rect x="14" y="14" width="7" height="7" rx="1"/></svg>',
                    'Dashboard'
                ],

                [
                    'consultancy_countries',
                    'country-management.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M4 12h16M12 4c2.2 2.3 3.3 4.9 3.3 8s-1.1 5.7-3.3 8c-2.2-2.3-3.3-4.9-3.3-8S9.8 6.3 12 4Z"/></svg>',
                    'Country Management'
                ],

                [
                    'consultancy_enquiries',
                    'consultancy-enquiries.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="5" width="18" height="14" rx="2"/><path d="M3 8h18M7 12h5M7 15h8"/></svg>',
                    'Enquiries'
                ],

                [
                    'consultancy_dashboard',
                    'consultancy-enquiry.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h5"/><path d="M16.5 15.5v5M14 18h5"/></svg>',
                    'Public Enquiry Form'
                ],

                [
                    'consultancy_dashboard',
                    'consultancy-followups.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="8"/><path d="M12 7v5l3 2"/></svg>',
                    'Follow-ups'
                ],

                [
                    'consultancy_dashboard',
                    'consultancy-file-opening.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="5" y="3" width="14" height="18" rx="2"/><path d="M8 8h8M8 12h8M8 16h5"/></svg>',
                    'File Opening'
                ],

                [
                    'consultancy_dashboard',
                    'consultancy-payments.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 7h16v10H4z"/><path d="M8 11h8M8 14h5"/></svg>',
                    'Consultancy Payments'
                ],

                [
                    'consultancy_dashboard',
                    'consultancy-counselors-independent.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="9" cy="8" r="3"/><path d="M3.5 20a5.5 5.5 0 0 1 11 0"/><circle cx="17" cy="9" r="2.3"/><path d="M15 15.5a4.5 4.5 0 0 1 5.5 4"/></svg>',
                    'Counselor Management'
                ],

                [
                    'consultancy_dashboard',
                    'consultancy-counselors.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v14H4z"/><path d="M8 9h8M8 13h5"/><path d="M8 17h8"/></svg>',
                    'Consultation Counselors'
                ],

                [
                    'consultancy_dashboard',
                    'consultancy-counselor-access.php',
                    '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3"/><path d="M5 20a7 7 0 0 1 14 0"/><path d="M18 12h3M19.5 10.5v3"/></svg>',
                    'Counselor Access'
                ],

            ];

        } else {

        $navItems = [

            [
                'dashboard',
                'dashboard.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M3 10.5 12 3l9 7.5"/><path d="M5.5 9.5V21h13V9.5M9 21v-6h6v6"/></svg>',
                'Dashboard'
            ],

            [
                'new_admission',
                'new-admission.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14"/></svg>',
                'New Admission'
            ],

            [
                'admissions',
                'course-management.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 5h16v14H4z"/><path d="M8 9h8M8 13h5"/></svg>',
                'Course & Fees'
            ],

            [
                'admissions',
                'admissions.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h5"/></svg>',
                'Admissions'
            ],

            [
                'students',
                'students.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="3"/><path d="M5 21a7 7 0 0 1 14 0"/></svg>',
                'Students'
            ],

            [
                'student_performance',
                'student-performance.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 19V5M4 19h16"/><path d="M7 15l3-4 3 2 5-7"/></svg>',
                'Student Performance'
            ],

            [
                'students',
                'materials.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m4 7 8-4 8 4-8 4-8-4Z"/><path d="M4 7v10l8 4 8-4V7M12 11v10"/></svg>',
                'Materials'
            ],

            [
                'batch',
                'batch-management.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M7 2v4M17 2v4M3 9h18M8 13h2M14 13h2M8 17h2M14 17h2"/></svg>',
                'Batch Management'
            ],

            [
                'classes',
                'class-management.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="3" width="16" height="18" rx="2"/><path d="M8 7h8M8 11h8M8 15h5"/></svg>',
                'Class Management'
            ],

            [
                'teachers',
                'teacher-room-management.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="7" r="3"/><path d="M5 21a7 7 0 0 1 14 0"/><path d="M18 4.5h3M19.5 3v3"/></svg>',
                'Teachers & Rooms'
            ],

            [
                'attendance',
                'attendance.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>',
                'Attendance'
            ],

            [
                'payments',
                'payments.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M7 4h11M6 8h12M10 4c3 2 3 5 0 8l-3 4c-1 1-1 3 2 4 3 1 6-1 8-4"/></svg>',
                'Payments'
            ],

            [
                'receipts',
                'receipts.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M6 3h12v18H6z"/><path d="M9 7h6M9 11h6M9 15h4"/></svg>',
                'Receipts'
            ],

            [
                'refunds',
                'refunds.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M9 8 4 12l5 4"/><path d="M4 12h10a6 6 0 0 1 6 6"/></svg>',
                'Refunds'
            ],

            [
                'reports',
                'reports.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M4 20V10M10 20V4M16 20v-7M22 20V7"/></svg>',
                'Reports'
            ],

            [
                'system_check',
                'system-check.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="m5 12 4 4L19 6"/></svg>',
                'System Check'
            ],

           

            [
                'new_admission',
                'qr-code.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="4" y="4" width="6" height="6"/><rect x="14" y="4" width="6" height="6"/><rect x="4" y="14" width="6" height="6"/><path d="M14 14h3v3h3v3h-6v-6M14 18h3"/></svg>',
                'Public Admission QR'
            ],

            [
                'students',
                'mock-test.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="17" rx="2"/><path d="M7 2v4M17 2v4M3 9h18M8 13h3M8 17h5M16 13h1M16 17h1"/></svg>',
                'Mock Test'
            ],

            [
                'admin_users',
                'admin-users.php',
                '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M18.4 5.6l-2.1 2.1M7.7 16.3l-2.1 2.1"/><circle cx="12" cy="12" r="4"/></svg>',
                'Admin Users'
            ],
        ];

        }

        ?>


        <?php foreach(
            $navItems
            as [
                $perm,
                $href,
                $icon,
                $label
            ]
        ): ?>

            <?php if(
                user_has_permission($perm)
            ): ?>

                <a
                    href="<?=e($href)?>"
                    class="<?=
                        $currentPage === $href
                            ? 'active'
                            : ''
                    ?>"
                >

                    <span class="nav-icon">
                        <?=$icon?>
                    </span>

                    <span>
                        <?=e($label)?>
                    </span>

                </a>

            <?php endif; ?>

        <?php endforeach; ?>


    </nav>


    <!-- ==========================================
         SIDEBAR FOOTER
    =========================================== -->

    <div class="sidebar-footer">

        <div class="sidebar-status-dot"></div>

        <div>

            <strong>
                System Online
            </strong>

            <small>
                Edumax AMS
            </small>

        </div>

    </div>


</aside>


<!-- ==========================================
     MAIN CONTENT
========================================== -->

<main class="content">

<script>
(function () {
    var sidebar = document.getElementById('sidebar');

    function closeSidebar() {
        document.body.classList.remove('sidebar-open');
        var toggle = document.querySelector('.menu-toggle');
        if (toggle) toggle.setAttribute('aria-expanded', 'false');
    }

    if (sidebar) {
        sidebar.addEventListener('click', function (event) {
            var link = event.target.closest('a');
            if (link) {
                closeSidebar();
                // IMPORTANT: never prevent the link's default navigation.
            }
        });
    }

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') closeSidebar();
    });
})();
</script>
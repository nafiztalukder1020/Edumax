<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';

/*
 * Consultancy Counselor Management
 *
 * IMPORTANT:
 * - Consultancy section only.
 * - Does not modify IELTS pages, tables, batches, admissions or payments.
 * - Uses the existing consultancy permission system.
 * - Assignment history is preserved.
 */

require_access('consultancy_dashboard');

$error = '';
$success = '';
$currentUserId = (int)($_SESSION['user_id'] ?? 0);

try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        require_valid_csrf();

        $action = (string)($_POST['action'] ?? '');

        /* Add country */
        if ($action === 'add_country') {
            $countryName = trim((string)($_POST['country_name'] ?? ''));

            if ($countryName === '') {
                $error = 'Country name is required.';
            } else {
                $stmt = $pdo->prepare("
                    INSERT INTO consultancy_countries
                        (country_name, status, created_by, updated_by)
                    VALUES (?, 'Active', ?, ?)
                ");

                $stmt->execute([
                    $countryName,
                    $currentUserId ?: null,
                    $currentUserId ?: null
                ]);

                $success = 'Country added successfully.';
            }
        }

        /* Activate / deactivate country */
        elseif ($action === 'toggle_country') {
            $countryId = (int)($_POST['country_id'] ?? 0);

            if ($countryId > 0) {
                $stmt = $pdo->prepare("
                    UPDATE consultancy_countries
                    SET
                        status = CASE
                            WHEN status = 'Active' THEN 'Inactive'
                            ELSE 'Active'
                        END,
                        updated_by = ?
                    WHERE id = ?
                ");

                $stmt->execute([
                    $currentUserId ?: null,
                    $countryId
                ]);

                $success = 'Country status updated.';
            } else {
                $error = 'Invalid country.';
            }
        }

        /* Assign counselor to country */
        elseif ($action === 'assign_counselor') {
            $countryId = (int)($_POST['country_id'] ?? 0);
            $counselorId = (int)($_POST['counselor_id'] ?? 0);

            if ($countryId <= 0 || $counselorId <= 0) {
                $error = 'Please select both country and counselor.';
            } else {
                $pdo->beginTransaction();

                try {
                    /*
                     * Verify country is active.
                     */
                    $countryCheck = $pdo->prepare("
                        SELECT id
                        FROM consultancy_countries
                        WHERE id = ?
                          AND status = 'Active'
                        LIMIT 1
                    ");

                    $countryCheck->execute([$countryId]);

                    /*
                     * Verify counselor is active.
                     */
                    $userCheck = $pdo->prepare("
                        SELECT id
                        FROM consultancy_counselors
                        WHERE id = ?
                          AND LOWER(TRIM(status)) = 'active'
                        LIMIT 1
                    ");

                    $userCheck->execute([$counselorId]);

                    if (!$countryCheck->fetchColumn()) {
                        throw new RuntimeException(
                            'Selected country is not active.'
                        );
                    }

                    if (!$userCheck->fetchColumn()) {
                        throw new RuntimeException(
                            'Selected counselor is not active or is not a Counselor.'
                        );
                    }

                    /*
                     * Prevent duplicate active assignment.
                     */
                    $duplicate = $pdo->prepare("
                        SELECT id
                        FROM consultancy_counselor_country_assignments
                        WHERE country_id = ?
                          AND counselor_id = ?
                          AND status = 'Active'
                        LIMIT 1
                    ");

                    $duplicate->execute([
                        $countryId,
                        $counselorId
                    ]);

                    if ($duplicate->fetchColumn()) {
                        throw new RuntimeException(
                            'This counselor is already assigned to this country.'
                        );
                    }

                    /*
                     * Create assignment.
                     */
                    $insert = $pdo->prepare("
                        INSERT INTO consultancy_counselor_country_assignments
                            (
                                country_id,
                                counselor_id,
                                status,
                                assigned_at,
                                assigned_by
                            )
                        VALUES (?, ?, 'Active', NOW(), ?)
                    ");

                    $insert->execute([
                        $countryId,
                        $counselorId,
                        $currentUserId ?: null
                    ]);

                    $pdo->commit();

                    $success = 'Counselor assigned successfully.';
                } catch (Throwable $e) {
                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $error = $e instanceof RuntimeException
                        ? $e->getMessage()
                        : 'Unable to assign counselor.';
                }
            }
        }

        /*
         * End assignment.
         * Historical record remains in database.
         */
        elseif ($action === 'end_assignment') {
            $assignmentId = (int)($_POST['assignment_id'] ?? 0);

            if ($assignmentId > 0) {
                $stmt = $pdo->prepare("
                    UPDATE consultancy_counselor_country_assignments
                    SET
                        status = 'Inactive',
                        ended_at = NOW(),
                        unassigned_by = ?
                    WHERE id = ?
                      AND status = 'Active'
                ");

                $stmt->execute([
                    $currentUserId ?: null,
                    $assignmentId
                ]);

                if ($stmt->rowCount() > 0) {
                    $success =
                        'Assignment ended. Historical record has been preserved.';
                } else {
                    $error =
                        'Assignment was not found or has already been ended.';
                }
            } else {
                $error = 'Invalid assignment.';
            }
        }
    }

    /*
     * Independent Consultancy counselors.
     *
     * Count active countries from the actual assignment table.
     */
    $stmt = $pdo->query("
        SELECT
            c.id,
            c.counselor_name AS name,
            c.username,
            c.status,
            c.created_at,
            COUNT(
                DISTINCT CASE
                    WHEN a.status = 'Active'
                    THEN a.country_id
                END
            ) AS active_country_count
        FROM consultancy_counselors c
        LEFT JOIN consultancy_counselor_country_assignments a
            ON a.counselor_id = c.id
        GROUP BY
            c.id,
            c.counselor_name,
            c.username,
            c.status,
            c.created_at
        ORDER BY
            CASE
                WHEN LOWER(TRIM(c.status)) = 'active'
                THEN 0
                ELSE 1
            END,
            c.counselor_name ASC
    ");

    $counselors = $stmt->fetchAll();

    /*
     * Countries.
     *
     * Active counselor count comes from the same assignment table
     * used by the assignment system.
     */
    $stmt = $pdo->query("
        SELECT
            c.id,
            c.country_name,
            c.status,
            c.created_at,
            COUNT(
                DISTINCT CASE
                    WHEN a.status = 'Active'
                    THEN a.counselor_id
                END
            ) AS active_counselor_count
        FROM consultancy_countries c
        LEFT JOIN consultancy_counselor_country_assignments a
            ON a.country_id = c.id
        GROUP BY
            c.id,
            c.country_name,
            c.status,
            c.created_at
        ORDER BY
            CASE
                WHEN c.status = 'Active'
                THEN 0
                ELSE 1
            END,
            c.country_name ASC
    ");

    $countries = $stmt->fetchAll();

    /*
     * Assignment + historical records.
     */
    $stmt = $pdo->query("
        SELECT
            cc.id,
            cc.status,
            cc.assigned_at,
            cc.ended_at,
            c.country_name,
            u.counselor_name AS counselor_name,
            u.username AS counselor_username
        FROM consultancy_counselor_country_assignments cc
        INNER JOIN consultancy_countries c
            ON c.id = cc.country_id
        INNER JOIN consultancy_counselors u
            ON u.id = cc.counselor_id
        ORDER BY
            c.country_name ASC,
            CASE
                WHEN cc.status = 'Active'
                THEN 0
                ELSE 1
            END,
            cc.assigned_at DESC
    ");

    $assignments = $stmt->fetchAll();

} catch (Throwable $e) {
    $counselors = $counselors ?? [];
    $countries = $countries ?? [];
    $assignments = $assignments ?? [];

    if ($error === '') {
        $error =
            'Unable to load consultancy counselor information right now.';
    }
}

$totalCounselors = count($counselors);
$activeCounselors = 0;
$assignedCounselors = 0;

foreach ($counselors as $c) {
    if (
        strcasecmp(
            (string)$c['status'],
            'Active'
        ) === 0
    ) {
        $activeCounselors++;
    }

    if ((int)$c['active_country_count'] > 0) {
        $assignedCounselors++;
    }
}
?>

<?php require_once __DIR__ . '/_header.php'; ?>

<style>
:root{
    --red:#c91f2e;
    --dark:#20242b;
    --muted:#6f747c;
    --border:#e6e8ec;
    --soft:#f7f8fa
}

.consultancy-page{
    padding:28px 30px 50px
}

.page-head{
    display:flex;
    align-items:flex-start;
    justify-content:space-between;
    gap:20px;
    margin-bottom:22px
}

.page-title h1{
    margin:0 0 7px;
    color:#17202b;
    font-size:28px;
    line-height:1.2;
    font-weight:800
}

.page-title h1:after{
    content:"";
    display:block;
    width:46px;
    height:3px;
    margin-top:10px;
    background:var(--red);
    border-radius:4px
}

.page-title p{
    margin:0;
    color:#7a8088;
    font-size:13px
}

.workspace-badge{
    padding:10px 14px;
    background:#fff;
    border:1px solid var(--border);
    border-radius:11px;
    color:#454b54;
    font-size:12px;
    font-weight:700
}

.workspace-badge span{
    display:inline-block;
    width:7px;
    height:7px;
    margin-right:6px;
    border-radius:50%;
    background:var(--red)
}

.notice{
    padding:12px 14px;
    border-radius:10px;
    margin-bottom:18px;
    font-size:13px
}

.notice.success{
    background:#edf8f0;
    border:1px solid #cfe9d5;
    color:#24723b
}

.notice.error{
    background:#fff1f2;
    border:1px solid #f1c9cd;
    color:#a3212e
}

.card{
    background:#fff;
    border:1px solid var(--border);
    border-radius:16px;
    box-shadow:0 4px 18px rgba(25,31,40,.035)
}

.summary-grid{
    display:grid;
    grid-template-columns:repeat(3,minmax(0,1fr));
    gap:16px;
    margin-bottom:18px
}

.summary-card{
    padding:20px
}

.summary-card .label{
    color:#626871;
    font-size:12px;
    font-weight:700
}

.summary-card .value{
    margin-top:8px;
    color:#151b23;
    font-size:26px;
    line-height:1;
    font-weight:800
}

.management-grid{
    display:grid;
    grid-template-columns:360px minmax(0,1fr);
    gap:18px;
    margin-bottom:18px
}

.form-card{
    padding:20px
}

.form-card h2,
.table-head h2{
    margin:0;
    color:#20242b;
    font-size:17px
}

.form-card p,
.table-head p{
    margin:5px 0 16px;
    color:#858a91;
    font-size:12px
}

.form-group{
    margin-bottom:13px
}

.form-group label{
    display:block;
    margin-bottom:6px;
    color:#4c525b;
    font-size:12px;
    font-weight:800
}

.form-control{
    width:100%;
    box-sizing:border-box;
    border:1px solid #dfe2e7;
    border-radius:8px;
    padding:10px 11px;
    background:#fff;
    color:#30353d;
    font-size:13px;
    outline:none
}

.form-control:focus{
    border-color:#c91f2e;
    box-shadow:0 0 0 3px rgba(201,31,46,.08)
}

.btn-small{
    display:inline-flex;
    align-items:center;
    justify-content:center;
    min-height:34px;
    padding:7px 11px;
    border:1px solid #dfe2e7;
    border-radius:8px;
    background:#fff;
    color:#555b64;
    font-size:11px;
    font-weight:800;
    cursor:pointer
}

.btn-small:hover{
    border-color:#c91f2e;
    color:#c91f2e
}

.btn-primary{
    border-color:var(--red);
    background:var(--red);
    color:#fff
}

.btn-primary:hover{
    background:#ad1825;
    color:#fff
}

.btn-small.activate{
    border-color:#b9dfc3;
    color:#28753d;
    background:#f5fbf6
}

.btn-danger{
    border-color:#f1c9cd;
    color:#a3212e;
    background:#fff6f7
}

.table-card{
    overflow:hidden
}

.table-head{
    padding:19px 20px;
    border-bottom:1px solid var(--border);
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:15px
}

.table-wrap{
    width:100%;
    overflow-x:auto
}

table{
    width:100%;
    border-collapse:collapse;
    min-width:760px
}

th,
td{
    padding:14px 16px;
    text-align:left;
    border-bottom:1px solid #eef0f3;
    vertical-align:middle
}

th{
    background:#fafbfc;
    color:#686e77;
    font-size:11px;
    font-weight:800;
    text-transform:uppercase;
    letter-spacing:.03em
}

td{
    color:#30353d;
    font-size:13px
}

.name-cell strong{
    display:block;
    color:#20242b;
    font-size:14px
}

.name-cell span{
    display:block;
    margin-top:3px;
    color:#8a8f96;
    font-size:11px
}

.badge{
    display:inline-flex;
    align-items:center;
    padding:5px 9px;
    border-radius:999px;
    font-size:11px;
    font-weight:800
}

.badge.active{
    background:#eaf7ee;
    color:#28753d
}

.badge.inactive{
    background:#f0f1f3;
    color:#70757d
}

.country-count{
    font-weight:800;
    color:#20242b
}

.country-list{
    padding:0 20px
}

.country-row{
    display:flex;
    align-items:center;
    justify-content:space-between;
    gap:12px;
    padding:13px 0;
    border-bottom:1px solid #eef0f3
}

.country-row:last-child{
    border-bottom:0
}

.country-name{
    font-weight:800;
    color:#20242b
}

.country-meta{
    margin-top:3px;
    color:#858a91;
    font-size:11px
}

.action-row{
    display:flex;
    gap:7px;
    flex-wrap:wrap
}

.empty{
    padding:45px 20px;
    text-align:center;
    color:#81868e;
    font-size:13px
}

.empty strong{
    display:block;
    margin-bottom:6px;
    color:#333941;
    font-size:15px
}

.section-title{
    margin:0 0 13px;
    padding:0 20px;
    color:#20242b;
    font-size:16px
}

.mt{
    margin-top:18px
}

@media(max-width:950px){
    .management-grid{
        grid-template-columns:1fr
    }

    .summary-grid{
        grid-template-columns:repeat(3,minmax(0,1fr))
    }
}

@media(max-width:800px){
    .consultancy-page{
        padding:22px 18px 40px
    }

    .page-head{
        flex-direction:column
    }

    .summary-grid{
        grid-template-columns:1fr
    }

    .table-wrap{
        overflow-x:auto
    }
}
</style>

<div class="consultancy-page">

    <div class="page-head">
        <div class="page-title">
            <h1>Consultation Counselors</h1>
            <p>
                Manage counselor assignments for consultancy country
                routing and assignment history.
            </p>
        </div>

        <div class="workspace-badge">
            <span></span>
            Consultancy Workspace
        </div>
    </div>

    <?php if ($success): ?>
        <div class="notice success">
            <?=e($success)?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="notice error">
            <?=e($error)?>
        </div>
    <?php endif; ?>

    <div class="summary-grid">

        <div class="card summary-card">
            <div class="label">Total Counselors</div>
            <div class="value">
                <?=e((string)$totalCounselors)?>
            </div>
        </div>

        <div class="card summary-card">
            <div class="label">Active Counselors</div>
            <div class="value">
                <?=e((string)$activeCounselors)?>
            </div>
        </div>

        <div class="card summary-card">
            <div class="label">With Country Assignment</div>
            <div class="value">
                <?=e((string)$assignedCounselors)?>
            </div>
        </div>

    </div>

    <div class="management-grid">

        <div>
            <div class="card form-card">

                <h2>Assign Counselor</h2>

                <p>
                    One counselor can handle multiple countries,
                    and a country can have multiple active counselors.
                </p>

                <form method="post">

                    <?=csrf_input()?>

                    <input
                        type="hidden"
                        name="action"
                        value="assign_counselor"
                    >

                    <div class="form-group">

                        <label>Country</label>

                        <select
                            class="form-control"
                            name="country_id"
                            required
                        >
                            <option value="">
                                Select Country
                            </option>

                            <?php foreach ($countries as $country): ?>

                                <?php
                                if ((string)$country['status'] !== 'Active') {
                                    continue;
                                }
                                ?>

                                <option
                                    value="<?=e((string)$country['id'])?>"
                                >
                                    <?=e((string)$country['country_name'])?>
                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <div class="form-group">

                        <label>Counselor</label>

                        <select
                            class="form-control"
                            name="counselor_id"
                            required
                        >
                            <option value="">
                                Select Counselor
                            </option>

                            <?php foreach ($counselors as $counselor): ?>

                                <?php
                                if (
                                    strcasecmp(
                                        (string)$counselor['status'],
                                        'Active'
                                    ) !== 0
                                ) {
                                    continue;
                                }
                                ?>

                                <option
                                    value="<?=e((string)$counselor['id'])?>"
                                >
                                    <?=e((string)$counselor['name'])?>

                                    <?php
                                    if (!empty($counselor['username'])):
                                    ?>
                                        —
                                        <?=e(
                                            (string)$counselor['username']
                                        )?>
                                    <?php endif; ?>

                                </option>

                            <?php endforeach; ?>

                        </select>

                    </div>

                    <button
                        class="btn-small btn-primary"
                        type="submit"
                    >
                        Assign Counselor
                    </button>

                </form>

            </div>
        </div>

        <div class="card table-card">

            <div class="table-head">

                <div>
                    <h2>Active Country Routing</h2>

                    <p>
                        Active countries available for counselor assignment.
                    </p>
                </div>

            </div>

            <div class="country-list">

                <?php
                $activeCountries = array_filter(
                    $countries,
                    static function ($country) {
                        return (string)$country['status'] === 'Active';
                    }
                );
                ?>

                <?php if (!$activeCountries): ?>

                    <div class="empty">
                        <strong>No Active Country Found</strong>
                        Add countries from Country Management.
                    </div>

                <?php else: ?>

                    <?php foreach ($activeCountries as $country): ?>

                        <div class="country-row">

                            <div>

                                <div class="country-name">
                                    <?=e(
                                        (string)$country['country_name']
                                    )?>
                                </div>

                                <div class="country-meta">
                                    <?=e(
                                        (string)$country[
                                            'active_counselor_count'
                                        ]
                                    )?>
                                    active counselor(s)
                                </div>

                            </div>

                            <span class="badge active">
                                Active
                            </span>

                        </div>

                    <?php endforeach; ?>

                <?php endif; ?>

            </div>

        </div>

    </div>

    <div class="card table-card">

        <div class="table-head">

            <div>
                <h2>Counselor List</h2>

                <p>
                    Counselor accounts come from the independent
                    Consultancy Counselor Management.
                </p>
            </div>

        </div>

        <?php if (!$counselors): ?>

            <div class="empty">
                <strong>No Counselor Found</strong>
                Create the counselor first from Counselor Management.
            </div>

        <?php else: ?>

            <div class="table-wrap">

                <table>

                    <thead>
                        <tr>
                            <th>Counselor</th>
                            <th>Username</th>
                            <th>Status</th>
                            <th>Assigned Countries</th>
                            <th>Created At</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($counselors as $counselor): ?>

                        <?php
                        $active =
                            strcasecmp(
                                (string)$counselor['status'],
                                'Active'
                            ) === 0;
                        ?>

                        <tr>

                            <td>
                                <div class="name-cell">
                                    <strong>
                                        <?=e(
                                            (string)$counselor['name']
                                        )?>
                                    </strong>

                                    <span>
                                        ID #
                                        <?=e(
                                            (string)$counselor['id']
                                        )?>
                                    </span>
                                </div>
                            </td>

                            <td>
                                <?=e(
                                    (string)$counselor['username']
                                )?>
                            </td>

                            <td>

                                <span
                                    class="badge <?=$active
                                        ? 'active'
                                        : 'inactive'?>"
                                >
                                    <?=$active
                                        ? 'Active'
                                        : 'Inactive'?>
                                </span>

                            </td>

                            <td>
                                <span class="country-count">
                                    <?=e(
                                        (string)$counselor[
                                            'active_country_count'
                                        ]
                                    )?>
                                </span>
                            </td>

                            <td>
                                <?=!empty($counselor['created_at'])
                                    ? e(
                                        (string)$counselor['created_at']
                                    )
                                    : '—'?>
                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>

    <div class="card table-card mt">

        <div class="table-head">

            <div>

                <h2>
                    Counselor Assignment &amp; History
                </h2>

                <p>
                    Ending an assignment keeps the historical
                    record for future counselors.
                </p>

            </div>

        </div>

        <?php if (!$assignments): ?>

            <div class="empty">
                <strong>No Assignment Found</strong>
                Assign a counselor to a country to start the history.
            </div>

        <?php else: ?>

            <div class="table-wrap">

                <table>

                    <thead>
                        <tr>
                            <th>Country</th>
                            <th>Counselor</th>
                            <th>Status</th>
                            <th>Assigned At</th>
                            <th>Ended At</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>

                    <?php foreach ($assignments as $assignment): ?>

                        <?php
                        $active =
                            (string)$assignment['status'] === 'Active';
                        ?>

                        <tr>

                            <td>
                                <strong>
                                    <?=e(
                                        (string)$assignment[
                                            'country_name'
                                        ]
                                    )?>
                                </strong>
                            </td>

                            <td>

                                <?=e(
                                    (string)$assignment[
                                        'counselor_name'
                                    ]
                                )?>

                                <div class="name-cell">

                                    <span>
                                        <?=e(
                                            (string)$assignment[
                                                'counselor_username'
                                            ]
                                        )?>
                                    </span>

                                </div>

                            </td>

                            <td>

                                <span
                                    class="badge <?=$active
                                        ? 'active'
                                        : 'inactive'?>"
                                >
                                    <?=$active
                                        ? 'Active'
                                        : 'History'?>
                                </span>

                            </td>

                            <td>
                                <?=e(
                                    (string)$assignment['assigned_at']
                                )?>
                            </td>

                            <td>
                                <?=!empty($assignment['ended_at'])
                                    ? e(
                                        (string)$assignment['ended_at']
                                    )
                                    : '—'?>
                            </td>

                            <td>

                                <?php if ($active): ?>

                                    <form
                                        method="post"
                                        style="margin:0"
                                        onsubmit="return confirm(
                                            'End this counselor assignment? Historical data will be preserved.'
                                        );"
                                    >

                                        <?=csrf_input()?>

                                        <input
                                            type="hidden"
                                            name="action"
                                            value="end_assignment"
                                        >

                                        <input
                                            type="hidden"
                                            name="assignment_id"
                                            value="<?=e(
                                                (string)$assignment['id']
                                            )?>"
                                        >

                                        <button
                                            class="btn-small btn-danger"
                                            type="submit"
                                        >
                                            End Assignment
                                        </button>

                                    </form>

                                <?php else: ?>

                                    <span class="country-meta">
                                        History preserved
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                    </tbody>

                </table>

            </div>

        <?php endif; ?>

    </div>

</div>

<?php require_once __DIR__ . '/_footer.php'; ?>
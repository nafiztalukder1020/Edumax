<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_admin();

$to = strtolower(trim((string)($_GET['to'] ?? 'auto')));
$canIelts = user_has_permission('dashboard');
$canConsultancy = user_has_permission('consultancy_dashboard');

if ($to === 'consultancy' && $canConsultancy) {
    $_SESSION['workspace'] = 'consultancy';
    header('Location: consultancy-dashboard.php');
    exit;
}

if ($to === 'ielts' && $canIelts) {
    $_SESSION['workspace'] = 'ielts';
    header('Location: dashboard.php');
    exit;
}

if ($canIelts && $canConsultancy) {
    $_SESSION['workspace'] = 'ielts';
    header('Location: dashboard.php');
    exit;
}

if ($canConsultancy) {
    $_SESSION['workspace'] = 'consultancy';
    header('Location: consultancy-dashboard.php');
    exit;
}

if ($canIelts) {
    $_SESSION['workspace'] = 'ielts';
    header('Location: dashboard.php');
    exit;
}

http_response_code(403);
exit('Access denied. You do not have access to any workspace.');

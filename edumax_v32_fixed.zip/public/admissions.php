<?php
require_once __DIR__ . '/../config/app.php';
require_access('admissions');
$q = trim($_GET['q'] ?? '');
$status = trim($_GET['status'] ?? '');

// Delete a pending application only. Processed admissions are protected.
$deleteError = '';
$deleteSuccess = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'delete_application') {
    require_valid_csrf();

    if (!is_super_admin()) {
        http_response_code(403);
        exit('Only Super Admin can delete applications.');
    }

    $studentId = (int)($_POST['student_db_id'] ?? 0);
    if ($studentId <= 0) {
        $deleteError = 'Invalid application selected.';
    } else {
        try {
            $pdo->beginTransaction();
            $check = $pdo->prepare("
                SELECT s.id, s.student_id, s.full_name,
                       EXISTS(SELECT 1 FROM admissions ad WHERE ad.student_id=s.id) AS has_admission,
                       EXISTS(SELECT 1 FROM payments p WHERE p.student_id=s.id) AS has_payment,
                       EXISTS(SELECT 1 FROM applications a WHERE a.student_id=s.id AND a.status='Pending') AS has_pending_application
                FROM students s WHERE s.id=? LIMIT 1
            ");
            $check->execute([$studentId]);
            $target = $check->fetch();
            if (!$target) throw new RuntimeException('Application not found.');
            if ((int)$target['has_admission'] === 1 || (int)$target['has_payment'] === 1) {
                throw new RuntimeException('This student has a processed admission or payment and cannot be deleted here.');
            }
            if ((int)$target['has_pending_application'] !== 1) {
                throw new RuntimeException('Only pending applications can be deleted.');
            }

            $audit = $pdo->prepare("INSERT INTO audit_logs (user_id, action, student_id, details) VALUES (?, 'Delete Pending Application', ?, ?)");
            $audit->execute([(int)$_SESSION['user_id'], $studentId, 'Deleted pending application for '.$target['student_id'].' - '.$target['full_name']]);
            $pdo->prepare('UPDATE audit_logs SET student_id=NULL WHERE student_id=?')->execute([$studentId]);
            $pdo->prepare('DELETE FROM students WHERE id=?')->execute([$studentId]);
            $pdo->commit();
            $deleteSuccess = 'Pending application deleted successfully.';
        } catch (Throwable $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $deleteError = $e->getMessage();
        }
    }
}

$processedSql = "SELECT
    ad.id,
    ad.student_id AS student_db_id,
    ad.status AS db_status,
    s.student_id,
    s.full_name,
    s.mobile,
    c.name AS course_name,
    b.name AS batch_name,
    ad.time_slot,
    ad.final_dealing_price,
    GREATEST(0, COALESCE((SELECT SUM(p.amount) FROM payments p WHERE p.admission_id=ad.id AND p.status='Valid'),0) - COALESCE((SELECT SUM(r.amount) FROM refunds r WHERE r.admission_id=ad.id AND r.status='Valid'),0)) AS total_paid,
    CASE
        WHEN ad.status='Cancelled' THEN 0
        ELSE GREATEST(0, ad.final_dealing_price-GREATEST(0, COALESCE((SELECT SUM(p2.amount) FROM payments p2 WHERE p2.admission_id=ad.id AND p2.status='Valid'),0) - COALESCE((SELECT SUM(r2.amount) FROM refunds r2 WHERE r2.admission_id=ad.id AND r2.status='Valid'),0)))
    END AS total_due,
    CASE
        WHEN ad.status='Cancelled' THEN 'Cancelled'
        WHEN ad.status='Pending' THEN 'Pending'
        WHEN GREATEST(0, ad.final_dealing_price-GREATEST(0, COALESCE((SELECT SUM(p3.amount) FROM payments p3 WHERE p3.admission_id=ad.id AND p3.status='Valid'),0) - COALESCE((SELECT SUM(r3.amount) FROM refunds r3 WHERE r3.admission_id=ad.id AND r3.status='Valid'),0))) <= 0 THEN 'Active'
        ELSE 'Approved'
    END AS effective_status,
    1 AS is_processed
FROM admissions ad
JOIN students s ON s.id=ad.student_id
JOIN courses c ON c.id=ad.course_id
JOIN batches b ON b.id=ad.batch_id";

$pendingSql = "SELECT
    NULL AS id,
    s.id AS student_db_id,
    a.status AS db_status,
    s.student_id,
    s.full_name,
    s.mobile,
    COALESCE(a.course_interest,'') AS course_name,
    '-' AS batch_name,
    '-' AS time_slot,
    0 AS final_dealing_price,
    0 AS total_paid,
    0 AS total_due,
    'Pending' AS effective_status,
    0 AS is_processed
FROM applications a
JOIN students s ON s.id=a.student_id
LEFT JOIN admissions ad ON ad.student_id=a.student_id
WHERE ad.id IS NULL AND a.status='Pending'";

$conditions = [];
$params = [];
if ($q !== '') {
    $conditions[] = "(s.student_id LIKE ? OR s.full_name LIKE ? OR s.mobile LIKE ? OR course_name LIKE ? OR batch_name LIKE ?)";
    $like = '%' . $q . '%';
    $params = [$like,$like,$like,$like,$like];
}
if (in_array($status, ['Pending','Approved','Active','Cancelled'], true)) {
    $conditions[] = "effective_status = ?";
    $params[] = $status;
}
$where = $conditions ? ' WHERE ' . implode(' AND ', $conditions) : '';

// MySQL permits filtering an outer UNION query by its aliases.
$sql = "SELECT * FROM (({$processedSql}) UNION ALL ({$pendingSql})) AS admission_list {$where} ORDER BY is_processed ASC, id DESC, student_id DESC";
$st = $pdo->prepare($sql);
$st->execute($params);
$rows = $st->fetchAll();

// Keep stored admission status synchronized with the real payment state.
foreach ($rows as $r) {
    if ((int)$r['is_processed'] === 1 && ($r['db_status'] ?? '') !== 'Cancelled' && ($r['db_status'] ?? '') !== $r['effective_status']) {
        $sync = $pdo->prepare("UPDATE admissions SET status=? WHERE id=?");
        $sync->execute([$r['effective_status'], (int)$r['id']]);
    }
}

require '_header.php';
?>
<?php if ($deleteSuccess): ?><div class="success" style="margin-bottom:16px"><?=e($deleteSuccess)?></div><?php endif; ?>
<?php if ($deleteError): ?><div class="alert" style="margin-bottom:16px"><?=e($deleteError)?></div><?php endif; ?>

<div class="section-title">
    <div><h1>Admissions</h1><p>All applications, processed admissions and payment status</p></div>
    <a class="btn btn-primary" href="new-admission.php">+ New Admission</a>
</div>

<div class="card" style="margin-bottom:18px">
    <form method="get" class="form-grid">
        <div>
            <label>Search</label>
            <input name="q" value="<?=e($q)?>" placeholder="Student ID, name, mobile, course or batch">
        </div>
        <div>
            <label>Status</label>
            <select name="status">
                <option value="">All Status</option>
                <?php foreach (['Pending','Approved','Active','Cancelled'] as $s): ?>
                    <option value="<?=e($s)?>" <?=($status===$s?'selected':'')?>><?=$s?></option>
                <?php endforeach; ?>
            </select>
        </div>
        <div style="align-self:end">
            <button class="btn btn-primary" type="submit">Filter</button>
            <a class="btn btn-light" href="admissions.php">Reset</a>
        </div>
    </form>
</div>

<div class="card table-wrap">
    <div style="padding:18px 18px 0">
        <h2 style="margin:0 0 4px">Admission List</h2>
        <p style="margin:0 0 14px;color:#737982;font-size:13px">New applications appear here immediately as Pending until the first admission deal is processed.</p>
    </div>
    <table class="table">
        <tr>
            <th>Student ID</th><th>Student</th><th>Mobile</th><th>Course</th><th>Batch</th><th>Time Slot</th>
            <th>Final Fee</th><th>Paid</th><th>Due</th><th>Status</th><th>Action</th>
        </tr>
        <?php foreach ($rows as $r):
            $due = ($r['effective_status'] === 'Cancelled') ? 0.0 : (float)$r['total_due'];
            $effectiveStatus = $r['effective_status'];
            $processed = (int)$r['is_processed'] === 1;
        ?>
        <tr>
            <td><?=e($r['student_id'])?></td>
            <td><strong><?=e($r['full_name'])?></strong></td>
            <td><?=e($r['mobile'])?></td>
            <td><?=e($r['course_name'] ?: '-')?></td>
            <td><?=e($r['batch_name'] ?: '-')?></td>
            <td><?=e($r['time_slot'] ?: '-')?></td>
            <td><?=$processed ? '৳ '.number_format((float)$r['final_dealing_price'],2) : '-'?></td>
            <td><?=$processed ? '৳ '.number_format((float)$r['total_paid'],2) : '-'?></td>
            <td style="color:<?=($processed && $due>0)?'#c91f2e':'#198754'?>;font-weight:700"><?=$processed ? '৳ '.number_format($due,2) : '-'?></td>
            <td><span class="badge <?=strtolower($effectiveStatus)?>"><?=e($effectiveStatus)?></span></td>
            <td>
                <?php if (!$processed): ?>
                    <a class="btn btn-primary" href="admission-review.php?id=<?=urlencode($r['student_id'])?>">Process</a>
                    <?php if (is_super_admin()): ?>
                        <form method="post" style="display:inline" onsubmit="return confirm('Delete this pending application and its applicant record? This cannot be undone.');">
                            <?=csrf_input()?>
                            <input type="hidden" name="action" value="delete_application">
                            <input type="hidden" name="student_db_id" value="<?= (int)$r['student_db_id'] ?>">
                            <button type="submit" class="btn btn-danger">Delete</button>
                        </form>
                    <?php endif; ?>
                <?php else: ?>
                    <a href="admission-review.php?id=<?=urlencode($r['student_id'])?>">View</a>
                    <?php if ($due > 0 && $effectiveStatus === 'Approved'): ?>
                        · <a href="due-payment.php?id=<?=urlencode($r['student_id'])?>" style="font-weight:700;color:#c91f2e">+ Due Payment</a>
                    <?php endif; ?>
                    · <a href="student-profile.php?id=<?=urlencode($r['student_id'])?>">Profile</a>
                    <?php if ($effectiveStatus !== 'Cancelled' && strcasecmp(trim((string)$r['course_name']), 'Mock Test') !== 0): ?>
                        · <a href="admission-cancel.php?id=<?=urlencode($r['id'])?>" style="font-weight:700;color:#c91f2e">Cancel Admission</a>
                    <?php endif; ?>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
        <?php if (!$rows): ?>
            <tr><td colspan="11">No admissions or pending applications found.</td></tr>
        <?php endif; ?>
    </table>
</div>
<?php require '_footer.php'; ?>

<?php
/**
 * Edumax Admission Management
 * Attendance — Batch-first version
 *
 * Fix:
 * - Batch select korlei active/admitted students show korbe.
 * - Class Session optional.
 * - Class session thakle selected time-slot অনুযায়ী students filter hobe.
 * - Class session na thakleo attendance mark/save kora jabe.
 * - Existing UI/CSS classes preserved.
 */

require_once __DIR__ . '/../config/app.php';
require_access('attendance');

$message = '';
$error = '';

$selectedBatch = (int)($_GET['batch_id'] ?? $_POST['batch_id'] ?? 0);
$selectedClass = (int)($_GET['class_id'] ?? $_POST['class_id'] ?? 0);
$attendanceDate = $_GET['attendance_date'] ?? $_POST['attendance_date'] ?? date('Y-m-d');

$attendanceDateObj = DateTime::createFromFormat('Y-m-d', $attendanceDate);
if (!$attendanceDateObj || $attendanceDateObj->format('Y-m-d') !== $attendanceDate) {
    $attendanceDate = date('Y-m-d');
}

/* Active / upcoming batches */
$batches = $pdo->query("
    SELECT
        b.id,
        b.name,
        c.name AS course_name
    FROM batches b
    INNER JOIN courses c ON c.id = b.course_id
    ORDER BY
        CASE b.status
            WHEN 'Active' THEN 1
            WHEN 'Upcoming' THEN 2
            ELSE 3
        END,
        b.start_date DESC,
        b.id DESC
")->fetchAll();

/*
 * Class sessions are optional now.
 * If a batch/date has sessions, they are shown in the dropdown.
 * If not, students can still be loaded by batch.
 */
$classSchedules = [];

if ($selectedBatch > 0) {
    $classStmt = $pdo->prepare("
        SELECT
            id,
            class_date,
            time_slot,
            teacher_name,
            room,
            topic,
            class_type,
            status
        FROM class_schedules
        WHERE batch_id = ?
          AND class_date = ?
          AND status <> 'Cancelled'
        ORDER BY time_slot ASC, id ASC
    ");
    $classStmt->execute([$selectedBatch, $attendanceDate]);
    $classSchedules = $classStmt->fetchAll();
}

/* Selected class session */
$selectedClassRow = null;

if ($selectedClass > 0) {
    $classSelect = $pdo->prepare("
        SELECT
            id,
            batch_id,
            class_date,
            time_slot,
            teacher_name,
            room,
            topic,
            class_type,
            status
        FROM class_schedules
        WHERE id = ?
          AND status <> 'Cancelled'
        LIMIT 1
    ");
    $classSelect->execute([$selectedClass]);
    $selectedClassRow = $classSelect->fetch() ?: null;

    if ($selectedClassRow) {
        $selectedBatch = (int)$selectedClassRow['batch_id'];
        $attendanceDate = $selectedClassRow['class_date'];
    }
}

/*
 * Save attendance.
 * Class session is NOT mandatory anymore.
 */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['save_attendance'])) {

    require_valid_csrf();

    if ($selectedBatch <= 0) {
        $error = 'Please select a batch.';
    } else {

        $checkBatch = $pdo->prepare("SELECT id FROM batches WHERE id = ? LIMIT 1");
        $checkBatch->execute([$selectedBatch]);

        if (!$checkBatch->fetch()) {
            $error = 'Selected batch was not found.';
        } else {

            /*
             * If a class was supplied, verify it belongs to the selected
             * batch/date. Otherwise attendance is saved batch-wise.
             */
            if ($selectedClass > 0) {
                $classCheck = $pdo->prepare("
                    SELECT
                        id,
                        batch_id,
                        class_date,
                        time_slot,
                        teacher_name,
                        room,
                        topic,
                        class_type,
                        status
                    FROM class_schedules
                    WHERE id = ?
                      AND batch_id = ?
                      AND class_date = ?
                      AND status <> 'Cancelled'
                    LIMIT 1
                ");
                $classCheck->execute([
                    $selectedClass,
                    $selectedBatch,
                    $attendanceDate
                ]);
                $selectedClassRow = $classCheck->fetch() ?: null;

                if (!$selectedClassRow) {
                    $error = 'Selected class session was not found or is cancelled.';
                }
            }

            if ($error === '') {

                $postedStudents = $_POST['status'] ?? [];

                try {
                    $pdo->beginTransaction();

                    /*
                     * If a class session is selected, only students from
                     * that time slot are accepted.
                     *
                     * Without a class session, any active student in the
                     * selected batch is accepted.
                     */
                    if ($selectedClassRow) {
                        $studentCheck = $pdo->prepare("
                            SELECT a.student_id
                            FROM admissions a
                            WHERE a.student_id = ?
                              AND a.batch_id = ?
                              AND a.time_slot = ?
                              AND a.status <> 'Cancelled'
                              AND NOT EXISTS (
                                  SELECT 1
                                  FROM admissions a2
                                  WHERE a2.student_id = a.student_id
                                    AND a2.batch_id = a.batch_id
                                    AND a2.status <> 'Cancelled'
                                    AND a2.id > a.id
                              )
                            LIMIT 1
                        ");
                    } else {
                        $studentCheck = $pdo->prepare("
                            SELECT a.student_id
                            FROM admissions a
                            WHERE a.student_id = ?
                              AND a.batch_id = ?
                              AND a.status <> 'Cancelled'
                              AND NOT EXISTS (
                                  SELECT 1
                                  FROM admissions a2
                                  WHERE a2.student_id = a.student_id
                                    AND a2.batch_id = a.batch_id
                                    AND a2.status <> 'Cancelled'
                                    AND a2.id > a.id
                              )
                            LIMIT 1
                        ");
                    }

                    $upsert = $pdo->prepare("
                        INSERT INTO attendance (
                            student_id,
                            batch_id,
                            attendance_date,
                            status,
                            marked_by
                        )
                        VALUES (?, ?, ?, ?, ?)
                        ON DUPLICATE KEY UPDATE
                            status = VALUES(status),
                            marked_by = VALUES(marked_by),
                            updated_at = CURRENT_TIMESTAMP
                    ");

                    foreach ($postedStudents as $studentId => $status) {

                        $studentId = (int)$studentId;

                        if (!in_array($status, ['Present', 'Absent'], true)) {
                            continue;
                        }

                        if ($selectedClassRow) {
                            $studentCheck->execute([
                                $studentId,
                                $selectedBatch,
                                $selectedClassRow['time_slot']
                            ]);
                        } else {
                            $studentCheck->execute([
                                $studentId,
                                $selectedBatch
                            ]);
                        }

                        if ($studentCheck->fetch()) {
                            $upsert->execute([
                                $studentId,
                                $selectedBatch,
                                $attendanceDate,
                                $status,
                                (int)($_SESSION['user_id'] ?? 0)
                            ]);
                        }
                    }

                    /* Optional audit */
                    try {
                        $audit = $pdo->prepare("
                            INSERT INTO audit_logs (user_id, action, student_id, details)
                            VALUES (?, ?, NULL, ?)
                        ");

                        $classText = $selectedClassRow
                            ? ', Class ID: '.$selectedClass.', Time: '.$selectedClassRow['time_slot']
                            : ', Class Session: Not Scheduled';

                        $audit->execute([
                            (int)($_SESSION['user_id'] ?? 0),
                            'Attendance Saved',
                            'Batch ID: '.$selectedBatch.$classText.', Date: '.$attendanceDate
                        ]);
                    } catch (Throwable $auditIgnore) {
                        /* Attendance should not fail because optional audit fails. */
                    }

                    $pdo->commit();
                    $message = 'Attendance saved successfully.';

                } catch (Throwable $e) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $error = $e->getMessage();
                }
            }
        }
    }
}

/*
 * Load students whenever a batch is selected.
 *
 * IMPORTANT:
 * Previous version required $selectedClassRow before loading students.
 * That was the reason students stayed hidden when no class session existed.
 */
$students = [];

if ($selectedBatch > 0) {

    if ($selectedClassRow) {

        $studentStmt = $pdo->prepare("
            SELECT
                s.id,
                s.student_id,
                s.full_name,
                s.mobile,
                a.time_slot,
                COALESCE(att.status, 'Absent') AS attendance_status
            FROM admissions a
            INNER JOIN students s
                ON s.id = a.student_id
            LEFT JOIN attendance att
                ON att.student_id = s.id
                AND att.batch_id = a.batch_id
                AND att.attendance_date = ?
            WHERE a.batch_id = ?
              AND a.time_slot = ?
              AND a.status <> 'Cancelled'
              AND NOT EXISTS (
                  SELECT 1
                  FROM admissions a2
                  WHERE a2.student_id = a.student_id
                    AND a2.batch_id = a.batch_id
                    AND a2.status <> 'Cancelled'
                    AND a2.id > a.id
              )
            ORDER BY s.full_name ASC
        ");

        $studentStmt->execute([
            $attendanceDate,
            $selectedBatch,
            $selectedClassRow['time_slot']
        ]);

    } else {

        /*
         * No class session:
         * show all active/admitted students of the selected batch.
         */
        $studentStmt = $pdo->prepare("
            SELECT
                s.id,
                s.student_id,
                s.full_name,
                s.mobile,
                a.time_slot,
                COALESCE(att.status, 'Absent') AS attendance_status
            FROM admissions a
            INNER JOIN students s
                ON s.id = a.student_id
            LEFT JOIN attendance att
                ON att.student_id = s.id
                AND att.batch_id = a.batch_id
                AND att.attendance_date = ?
            WHERE a.batch_id = ?
              AND a.status <> 'Cancelled'
              AND NOT EXISTS (
                  SELECT 1
                  FROM admissions a2
                  WHERE a2.student_id = a.student_id
                    AND a2.batch_id = a.batch_id
                    AND a2.status <> 'Cancelled'
                    AND a2.id > a.id
              )
            ORDER BY s.full_name ASC
        ");

        $studentStmt->execute([
            $attendanceDate,
            $selectedBatch
        ]);
    }

    $students = $studentStmt->fetchAll();
}

require '_header.php';
?>

<div class="section-title">
    <div>
        <h1>Attendance</h1>
        <p>Mark attendance from the scheduled class session.</p>
    </div>
</div>

<?php if ($message): ?>
    <div class="success"><?= e($message) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert"><?= e($error) ?></div>
<?php endif; ?>

<form method="GET" class="card attendance-filter-card">

    <div class="form-grid">

        <div class="field">
            <label>Batch *</label>

            <select name="batch_id" required onchange="this.form.submit()">
                <option value="">Select Batch</option>

                <?php foreach ($batches as $batch): ?>
                    <option
                        value="<?= (int)$batch['id'] ?>"
                        <?= $selectedBatch === (int)$batch['id'] ? 'selected' : '' ?>
                    >
                        <?= e($batch['name']) ?> — <?= e($batch['course_name']) ?>
                    </option>
                <?php endforeach; ?>

            </select>
        </div>

        <div class="field">
            <label>Attendance Date *</label>

            <input
                type="date"
                name="attendance_date"
                value="<?= e($attendanceDate) ?>"
                required
                onchange="this.form.submit()"
            >
        </div>

        <div class="field">
            <label>Class Session <span style="font-weight:400;">(Optional)</span></label>

            <select name="class_id" onchange="this.form.submit()">
                <option value="">All Batch Students</option>

                <?php foreach ($classSchedules as $class): ?>
                    <option
                        value="<?= (int)$class['id'] ?>"
                        <?= $selectedClass === (int)$class['id'] ? 'selected' : '' ?>
                    >
                        <?= e($class['time_slot']) ?>
                        — <?= e($class['teacher_name'] ?: 'Teacher not assigned') ?>
                        <?= $class['topic'] ? ' — '.e($class['topic']) : '' ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <?php if ($selectedBatch > 0 && !$classSchedules): ?>
                <small class="field-help">
                    No class session found for this batch on the selected date.
                    Students are still available for attendance.
                </small>
            <?php elseif ($selectedBatch > 0 && $classSchedules): ?>
                <small class="field-help">
                    Select a class session to show only that time-slot students,
                    or keep “All Batch Students”.
                </small>
            <?php endif; ?>
        </div>

    </div>

    <button class="btn btn-primary" type="submit">
        VIEW STUDENTS
    </button>

</form>

<?php if ($selectedBatch > 0): ?>

<form method="POST" class="card attendance-card"><?=csrf_input()?>

    <input type="hidden" name="batch_id" value="<?= (int)$selectedBatch ?>">
    <input type="hidden" name="class_id" value="<?= (int)$selectedClass ?>">
    <input type="hidden" name="attendance_date" value="<?= e($attendanceDate) ?>">

    <div class="attendance-toolbar">

        <div>
            <h2>Student Attendance</h2>

            <p>
                <?= count($students) ?> student(s)
                · <?= e($attendanceDate) ?>

                <?php if ($selectedClassRow): ?>
                    · <?= e($selectedClassRow['time_slot']) ?>

                    <?php if (!empty($selectedClassRow['teacher_name'])): ?>
                        · <?= e($selectedClassRow['teacher_name']) ?>
                    <?php endif; ?>

                <?php else: ?>
                    · All Batch Students
                <?php endif; ?>
            </p>
        </div>

        <div class="attendance-actions">
            <button type="button" class="btn btn-light" onclick="markAll('Present')">
                ✓ Mark All Present
            </button>

            <button type="button" class="btn btn-light" onclick="markAll('Absent')">
                × Mark All Absent
            </button>
        </div>

    </div>

    <?php if ($students): ?>

        <div class="attendance-summary">

            <div>
                <span>Total</span>
                <strong id="attTotal"><?= count($students) ?></strong>
            </div>

            <div class="present">
                <span>Present</span>
                <strong id="attPresent">0</strong>
            </div>

            <div class="absent">
                <span>Absent</span>
                <strong id="attAbsent"><?= count($students) ?></strong>
            </div>

        </div>

        <div class="attendance-list">

            <?php foreach ($students as $student): ?>

                <div class="attendance-row">

                    <div class="student-mini-avatar">
                        <?= e(strtoupper(substr($student['full_name'], 0, 1))) ?>
                    </div>

                    <div class="attendance-student">

                        <strong><?= e($student['full_name']) ?></strong>

                        <small>
                            <?= e($student['student_id']) ?>

                            <?php if (!empty($student['time_slot'])): ?>
                                · <?= e($student['time_slot']) ?>
                            <?php endif; ?>

                        </small>

                    </div>

                    <div class="attendance-radio">

                        <label class="attendance-option present-option">
                            <input
                                type="radio"
                                name="status[<?= (int)$student['id'] ?>]"
                                value="Present"
                                <?= $student['attendance_status'] === 'Present' ? 'checked' : '' ?>
                                onchange="updateAttendanceCount()"
                            >
                            <span>Present</span>
                        </label>

                        <label class="attendance-option absent-option">
                            <input
                                type="radio"
                                name="status[<?= (int)$student['id'] ?>]"
                                value="Absent"
                                <?= $student['attendance_status'] !== 'Present' ? 'checked' : '' ?>
                                onchange="updateAttendanceCount()"
                            >
                            <span>Absent</span>
                        </label>

                    </div>

                </div>

            <?php endforeach; ?>

        </div>

        <div class="attendance-save">

            <button
                class="btn btn-primary attendance-save-btn"
                type="submit"
                name="save_attendance"
            >
                SAVE ATTENDANCE
            </button>

        </div>

    <?php else: ?>

        <div class="empty-state">
            No active/admitted students found in this batch.
        </div>

    <?php endif; ?>

</form>

<?php endif; ?>

<script>
function markAll(status) {
    document
        .querySelectorAll('input[type="radio"][value="' + status + '"]')
        .forEach(function(input) {
            input.checked = true;
        });

    updateAttendanceCount();
}

function updateAttendanceCount() {

    const present =
        document.querySelectorAll(
            'input[type="radio"][value="Present"]:checked'
        ).length;

    const absent =
        document.querySelectorAll(
            'input[type="radio"][value="Absent"]:checked'
        ).length;

    const presentEl = document.getElementById('attPresent');
    const absentEl = document.getElementById('attAbsent');

    if (presentEl) presentEl.textContent = present;
    if (absentEl) absentEl.textContent = absent;
}

document.addEventListener('DOMContentLoaded', updateAttendanceCount);
</script>

<?php require '_footer.php'; ?>

<?php
require_once __DIR__ . '/../config/app.php';
require_access('receipts');

$receiptNo = trim($_GET['receipt'] ?? '');
if ($receiptNo === '') exit('Receipt number is required.');

$stmt = $pdo->prepare("SELECT p.*, s.student_id AS student_code, s.full_name, s.mobile, a.admission_date, a.regular_fee, a.discount, a.do_discount, a.final_dealing_price, a.time_slot, c.name AS course_name, b.name AS batch_name, u.name AS received_by_name FROM payments p JOIN students s ON s.id=p.student_id JOIN admissions a ON a.id=p.admission_id JOIN courses c ON c.id=a.course_id JOIN batches b ON b.id=a.batch_id LEFT JOIN users u ON u.id=p.received_by WHERE p.receipt_no=? AND p.status='Valid' LIMIT 1");
$stmt->execute([$receiptNo]);
$r = $stmt->fetch();
if (!$r) exit('Receipt not found.');

$paidStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE admission_id=? AND status='Valid' AND id<=?");
$paidStmt->execute([$r['admission_id'], $r['id']]);
$totalPaid = (float)$paidStmt->fetchColumn();

$refundStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE admission_id=? AND status='Valid'");
$refundStmt->execute([$r['admission_id']]);
$totalRefunded = (float)$refundStmt->fetchColumn();

$netPaid = max(0, $totalPaid - $totalRefunded);
$due = max(0, (float)$r['final_dealing_price'] - $netPaid);
$numberStmt = $pdo->prepare("SELECT COUNT(*) FROM payments WHERE admission_id=? AND status='Valid' AND id<=?");
$numberStmt->execute([$r['admission_id'], $r['id']]);
$paymentNumber = (int)$numberStmt->fetchColumn();
$paymentLabel = $paymentNumber === 1 ? '1st Payment' : ($paymentNumber === 2 ? '2nd Payment' : $paymentNumber . 'th Payment');
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title><?=e($r['receipt_no'])?> - Edumax Receipt</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#eef0f3;font-family:Arial,Helvetica,sans-serif;color:#20242b}.toolbar{max-width:900px;margin:18px auto;display:flex;gap:10px;justify-content:flex-end}.btn{border:0;padding:11px 18px;border-radius:9px;cursor:pointer;font-weight:700}.print{background:linear-gradient(135deg,#c91f2e,#9f1522);color:#fff;box-shadow:0 6px 16px rgba(201,31,46,.2)}.back{background:#fff;border:1px solid #ddd}.sheet{width:210mm;margin:14px auto 30px;background:#fff}.copy{width:210mm;min-height:297mm;height:297mm;padding:12mm;position:relative;overflow:hidden;background:#fff;border:1px solid #d9dce1}.copy + .copy{page-break-before:always;margin-top:0}.copy:before{content:"";position:absolute;top:0;left:0;right:0;height:6px;background:linear-gradient(90deg,#c91f2e,#e65b67,#9f1522)}.copy:last-child{margin-bottom:0}.brand{display:flex;align-items:center;gap:14px;border-bottom:1px solid #e5e7eb;padding-bottom:12px}.brand img{width:70px;height:60px;object-fit:contain}.brand h1{margin:0;font-size:22px}.brand p{margin:4px 0 0;color:#737982;font-size:11px}.copy-title{text-align:right;font-weight:800;color:#c91f2e;margin-top:-20px;font-size:11px;letter-spacing:.6px}.meta{display:grid;grid-template-columns:repeat(3,1fr);gap:0;margin:16px 0;border:1px solid #e5e7eb;border-radius:8px;overflow:hidden;font-size:11px}.meta>div{padding:9px 10px;border-right:1px solid #e5e7eb;border-bottom:1px solid #e5e7eb}.meta>div:nth-child(3n){border-right:0}.meta>div:nth-last-child(-n+3){border-bottom:0}.row{display:flex;justify-content:space-between;border-bottom:1px solid #e5e7eb;padding:8px 10px;font-size:11px}.total{font-size:15px;font-weight:800;background:#fff4f5;color:#7f1721}.due{font-size:15px;font-weight:800;color:#c91f2e;background:#fff5f6}.footer{display:flex;justify-content:space-between;margin-top:22px;padding-top:12px;border-top:1px dashed #aaa;font-size:9px;color:#666}.cut{text-align:center;color:#777;font-size:8px;border-top:1px dashed #999;padding-top:4px;margin-bottom:8px;text-transform:uppercase;letter-spacing:.5px}@media print{@page{size:A4 portrait;margin:0}html,body{width:210mm;margin:0;padding:0;background:#fff}.toolbar{display:none}.sheet{margin:0;width:210mm;padding:0}.copy{width:210mm;height:297mm;min-height:297mm;margin:0!important;border:0;border-radius:0;break-after:page;page-break-after:always;break-inside:avoid;page-break-inside:avoid}.copy:last-child{break-after:auto;page-break-after:auto}}@media screen and (max-width:700px){.toolbar{margin:10px 0;padding:0 10px;justify-content:stretch}.toolbar .btn{flex:1}.sheet{width:100%;margin:0;padding:10px;background:transparent}.copy{width:100%;height:auto;min-height:0;padding:18px 14px;margin-bottom:12px;border-radius:12px;overflow:visible}.copy + .copy{page-break-before:auto}.brand{align-items:flex-start}.brand img{width:58px;height:50px}.brand h1{font-size:17px}.copy-title{margin-top:8px;text-align:left}.meta{grid-template-columns:1fr;margin:12px 0}.meta>div{border-right:0!important;border-bottom:1px solid #e5e7eb!important}.meta>div:last-child{border-bottom:0!important}.row{gap:14px}.footer{gap:14px;flex-direction:column}.footer span:last-child{text-align:right}}.refund-policy{margin-top:16px;padding:10px 12px;border:1px solid #e5e7eb;border-left:4px solid #c91f2e;border-radius:7px;background:#fafafa;font-size:9.5px;line-height:1.55;color:#4b5563}.refund-policy strong:first-child{display:block;color:#7f1721;font-size:10.5px;margin-bottom:3px}.refund-policy p{margin:0}.back{color:#20242b;text-decoration:none;display:inline-flex;align-items:center;justify-content:center}
@media screen and (max-width:700px){.toolbar .back{min-height:44px}}

.contact-footer{display:flex;justify-content:space-between;gap:16px;margin-top:10px;padding-top:7px;border-top:1px solid #e5e7eb;font-size:9px;color:#555;text-align:center}.contact-footer span{flex:1}@media screen and (max-width:700px){.contact-footer{flex-direction:column;gap:5px;font-size:9px}.contact-footer span{text-align:center}}
</style>
<script>
function goBack(){
    if (document.referrer && window.history.length > 1) {
        window.history.back();
        return;
    }
    window.location.href = 'receipts.php';
}
</script>
</head>
<body>
<div class="toolbar"><button type="button" class="btn back" onclick="goBack()">← Back</button><button type="button" class="btn print" onclick="window.print()">Print / Save as PDF</button></div>
<div class="sheet">
<?php for($copy=1;$copy<=2;$copy++): ?>
<section class="copy">
<div class="brand"><img src="assets/edumax-logo.png" alt="Edumax Logo"><div><h1>EDUMAX IELTS Center</h1><p>Admission & Payment Receipt</p></div></div>
<div class="copy-title"><?= $copy===1 ? 'STUDENT COPY' : 'OFFICE COPY' ?></div>
<div class="meta">
<div><strong>Receipt No:</strong> <?=e($r['receipt_no'])?></div><div><strong>Payment Date:</strong> <?=e(date('d M Y, h:i A',strtotime($r['created_at'])))?></div>
<div><strong>Student ID:</strong> <?=e($r['student_code'])?></div><div><strong>Student:</strong> <?=e($r['full_name'])?></div>
<div><strong>Mobile:</strong> <?=e($r['mobile'])?></div><div><strong>Course:</strong> <?=e($r['course_name'])?></div>
<div><strong>Batch:</strong> <?=e($r['batch_name'])?></div><div><strong>Time Slot:</strong> <?=e($r['time_slot'] ?: '-')?></div><div><strong>Admission Date:</strong> <?=e($r['admission_date'])?></div><div><strong>Payment:</strong> <?=e($paymentLabel)?></div>
</div>
<?php if($copy===1): ?>
<div class="row total"><span>This Payment</span><span>৳<?=number_format((float)$r['amount'],2)?></span></div>
<div class="row"><span>Final Dealing Price</span><strong>৳<?=number_format((float)$r['final_dealing_price'],2)?></strong></div>
<div class="row"><span>Total Paid</span><strong>৳<?=number_format($totalPaid,2)?></strong></div>
<div class="row due"><span>Current Due</span><span>৳<?=number_format($due,2)?></span></div>
<div class="meta" style="margin-top:18px;margin-bottom:0"><div><strong>Payment Method:</strong> <?=e($r['method'])?></div><div><strong>Received By:</strong> <?=e($r['received_by_name'] ?: '-')?></div></div>
<div class="refund-policy">
<strong>Refund &amp; Admission Cancellation Policy</strong>
<p>Admission cancellation within the first <strong>14 days</strong> is eligible for a <strong>100% refund of the amount paid</strong>. From the 15th day onward, a <strong>10% deduction</strong> applies for each additional 7-day period (15–21 days: 10%, 22–28 days: 20%, 29–35 days: 30%, and so on). The applicable deduction will be calculated automatically according to the cancellation date. Refunds are subject to admission cancellation and the applicable policy.</p>
</div>
<p style="font-size:11px;color:#666;margin-top:18px">Thank you for your payment. Please keep this receipt for your records.</p>
<div class="footer"><span>Computer generated receipt.</span><span>Authorized Signature: __________________</span></div><div class="contact-footer"><span>Mobile: 01968-373223 | 01968-373227</span><span>QR Tower (Lift-6), Badurtala, 1st Kandirpar, Cumilla</span></div>
<?php else: ?>
<div class="row"><span>Regular Fee</span><strong>৳<?=number_format((float)$r['regular_fee'],2)?></strong></div>
<div class="row"><span>Regular Discount</span><strong>- ৳<?=number_format((float)$r['discount'],2)?></strong></div>
<div class="row"><span>Outside / Special Discount</span><strong>- ৳<?=number_format((float)$r['do_discount'],2)?></strong></div>
<div class="row total"><span>Final Dealing Price</span><span>৳<?=number_format((float)$r['final_dealing_price'],2)?></span></div>
<div class="row"><span><?=e($paymentLabel)?></span><strong>৳<?=number_format((float)$r['amount'],2)?></strong></div>
<div class="row"><span>Total Paid</span><strong>৳<?=number_format($totalPaid,2)?></strong></div>
<div class="row due"><span>Current Due</span><span>৳<?=number_format($due,2)?></span></div>
<div class="meta" style="margin-bottom:0"><div><strong>Payment Method:</strong> <?=e($r['method'])?></div><div><strong>Received By:</strong> <?=e($r['received_by_name'] ?: '-')?></div><div><strong>Receipt:</strong> <?=e($r['receipt_no'])?></div><div><strong>Payment:</strong> <?=e($paymentLabel)?></div><div style="grid-column:1/-1"><strong>Note:</strong> <?=e($r['note'] ?: '-')?></div></div>
<div class="refund-policy">
<strong>Refund &amp; Admission Cancellation Policy</strong>
<p>Admission cancellation within the first <strong>14 days</strong> is eligible for a <strong>100% refund of the amount paid</strong>. From the 15th day onward, a <strong>10% deduction</strong> applies for each additional 7-day period (15–21 days: 10%, 22–28 days: 20%, 29–35 days: 30%, and so on). The applicable deduction will be calculated automatically according to the cancellation date. Refunds are subject to admission cancellation and the applicable policy.</p>
</div>
<div class="footer"><span>Computer generated receipt. Keep this office copy for future reference.</span><span>Authorized Signature: __________________</span></div><div class="contact-footer"><span>Mobile: 01968-373223 | 01968-373227</span><span>QR Tower (Lift-6), Badurtala, 1st Kandirpar, Cumilla</span></div>
<?php endif; ?>
</section>
<?php endfor; ?>
</div>
</body></html>

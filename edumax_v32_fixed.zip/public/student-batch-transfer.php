<?php
require_once __DIR__ . '/../config/app.php';
require_access('students');

$studentCode = trim((string)($_GET['id'] ?? $_POST['student_id'] ?? ''));

if ($studentCode === '') {
    http_response_code(400);
    exit('Student ID is required.');
}

$studentStmt = $pdo->prepare("
    SELECT *
    FROM students
    WHERE student_id=?
    LIMIT 1
");
$studentStmt->execute([$studentCode]);
$student = $studentStmt->fetch();

if (!$student) {
    http_response_code(404);
    exit('Student not found.');
}

/*
 * Any of these admin roles may transfer and override capacity.
 */
if (!has_role(['Super Admin', 'Admission Admin', 'Accounts', 'Reception'])) {
    http_response_code(403);
    exit('You do not have permission to transfer students.');
}

/*
 * The current database has admissions.time_slot.
 * Keep this check so the page gives a useful message instead of HTTP 500
 * if an older database is ever used.
 */
$hasAdmissionTimeSlot = false;
try {
    $col = $pdo->query("SHOW COLUMNS FROM admissions LIKE 'time_slot'");
    $hasAdmissionTimeSlot = (bool)$col->fetch();
} catch (Throwable $e) {
    $hasAdmissionTimeSlot = false;
}

if (!$hasAdmissionTimeSlot) {
    http_response_code(500);
    exit('Database error: admissions.time_slot is missing.');
}

/* Optional override columns: detect them so the page itself never crashes
 * if an older database has not received the override migration yet. */
$hasCapacityOverride = false;
$hasCapacityOverrideReason = false;
$hasCapacityOverrideBy = false;

try {
    $q = $pdo->query("SHOW COLUMNS FROM admissions LIKE 'capacity_override'");
    $hasCapacityOverride = (bool)$q->fetch();

    $q = $pdo->query("SHOW COLUMNS FROM admissions LIKE 'capacity_override_reason'");
    $hasCapacityOverrideReason = (bool)$q->fetch();

    $q = $pdo->query("SHOW COLUMNS FROM admissions LIKE 'capacity_override_by'");
    $hasCapacityOverrideBy = (bool)$q->fetch();
} catch (Throwable $e) {
    $hasCapacityOverride = false;
    $hasCapacityOverrideReason = false;
    $hasCapacityOverrideBy = false;
}

function transfer_slots(string $raw): array
{
    $raw = trim($raw);
    if ($raw === '') {
        return [];
    }

    $decoded = json_decode($raw, true);

    if (is_array($decoded)) {
        $out = [];
        foreach ($decoded as $v) {
            $v = trim((string)$v);
            if ($v !== '' && !in_array($v, $out, true)) {
                $out[] = $v;
            }
        }
        return $out;
    }

    $out = [];
    foreach (preg_split('/[,|]+/', $raw) as $v) {
        $v = trim((string)$v);
        if ($v !== '' && !in_array($v, $out, true)) {
            $out[] = $v;
        }
    }

    return $out;
}

/*
 * Current active admission.
 */
$currentStmt = $pdo->prepare("
    SELECT
        a.id AS admission_id,
        a.student_id,
        a.course_id,
        a.batch_id,
        a.time_slot,
        a.status,
        c.name AS course_name,
        b.name AS batch_name
    FROM admissions a
    LEFT JOIN courses c ON c.id=a.course_id
    LEFT JOIN batches b ON b.id=a.batch_id
    WHERE a.student_id=?
      AND a.status <> 'Cancelled'
    ORDER BY a.id DESC
    LIMIT 1
");
$currentStmt->execute([(int)$student['id']]);
$current = $currentStmt->fetch();

if (!$current) {
    http_response_code(404);
    exit('This student has no processed admission to transfer.');
}

$error = '';
$success = isset($_GET['transfer']) && $_GET['transfer'] === 'success';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (function_exists('require_valid_csrf')) {
        require_valid_csrf();
    } elseif (function_exists('verify_csrf')) {
        verify_csrf();
    }

    $toBatchId = (int)($_POST['to_batch_id'] ?? 0);
    $toTimeSlot = trim((string)($_POST['to_time_slot'] ?? ''));
    $reason = trim((string)($_POST['reason'] ?? ''));
    $capacityOverride = isset($_POST['capacity_override']) && $_POST['capacity_override'] === '1';

    if ($toBatchId <= 0) {
        $error = 'Please select a new batch.';
    } elseif ($toTimeSlot === '') {
        $error = 'Please select a new time slot.';
    } elseif (strlen($reason) > 255) {
        $error = 'Reason must be 255 characters or less.';
    }

    if ($capacityOverride && $reason === '') {
        $error = 'An override reason is required when exceeding the base capacity.';
    }

    if ($error === '') {
        try {
            $pdo->beginTransaction();

            /*
             * Lock the current admission and re-read its current state.
             */
            $lock = $pdo->prepare("
                SELECT
                    id,
                    student_id,
                    course_id,
                    batch_id,
                    time_slot,
                    status
                FROM admissions
                WHERE id=?
                  AND student_id=?
                FOR UPDATE
            ");
            $lock->execute([
                (int)$current['admission_id'],
                (int)$student['id']
            ]);
            $admission = $lock->fetch();

            if (!$admission || ($admission['status'] ?? '') === 'Cancelled') {
                throw new RuntimeException('Current admission is no longer available.');
            }

            $fromBatchId = (int)($admission['batch_id'] ?? 0);
            $fromTimeSlot = trim((string)($admission['time_slot'] ?? ''));

            if ($toBatchId === $fromBatchId && $toTimeSlot === $fromTimeSlot) {
                throw new RuntimeException('Please select a different batch or time slot.');
            }

            /*
             * Lock target batch before checking capacity.
             * This keeps concurrent transfers from bypassing the base capacity.
             */
            $batchLock = $pdo->prepare("
                SELECT
                    id,
                    course_id,
                    name,
                    status,
                    is_archived,
                    start_date,
                    time_slots,
                    COALESCE(max_students,50) AS max_students,
                    slot_capacities
                FROM batches
                WHERE id=?
                FOR UPDATE
            ");
            $batchLock->execute([$toBatchId]);
            $target = $batchLock->fetch();

            if (!$target) {
                throw new RuntimeException('Selected batch was not found.');
            }

            if ((int)($target['is_archived'] ?? 0) === 1) {
                throw new RuntimeException('Archived batches cannot receive students.');
            }

            if (($target['status'] ?? '') === 'Closed') {
                throw new RuntimeException('Closed batches cannot receive students.');
            }

            if ((int)$admission['course_id'] !== (int)$target['course_id']) {
                throw new RuntimeException('Target batch must belong to the same course.');
            }

            $targetSlots = transfer_slots((string)($target['time_slots'] ?? ''));

            if ($targetSlots && !in_array($toTimeSlot, $targetSlots, true)) {
                throw new RuntimeException('Selected time slot is not available in the selected batch.');
            }

            /*
             * Base capacity comes from Batch Management.
             * Slot-specific capacity overrides the batch default when configured.
             */
            $slotCapMap = json_decode((string)($target['slot_capacities'] ?? ''), true);
            if (!is_array($slotCapMap)) {
                $slotCapMap = [];
            }

            $capacity = max(1, (int)($target['max_students'] ?? 50));

            if (array_key_exists($toTimeSlot, $slotCapMap)) {
                $capacity = max(1, (int)$slotCapMap[$toTimeSlot]);
            }

            /*
             * Count active students in target batch + time slot.
             * Exclude this admission so same-batch slot changes do not
             * count the student twice.
             */
            $countStmt = $pdo->prepare("
                SELECT COUNT(*)
                FROM admissions
                WHERE batch_id=?
                  AND time_slot=?
                  AND status <> 'Cancelled'
                  AND id <> ?
            ");
            $countStmt->execute([
                $toBatchId,
                $toTimeSlot,
                (int)$admission['id']
            ]);

            $enrolledBefore = (int)$countStmt->fetchColumn();
            $enrolledAfter = $enrolledBefore + 1;
            $isOverCapacity = $enrolledBefore >= $capacity;

            /*
             * Base capacity is NOT a hard ceiling.
             * Any authorized admin may exceed it when Override is checked.
             */
            if ($isOverCapacity && !$capacityOverride) {
                throw new RuntimeException(
                    'This time slot is FULL (' .
                    $enrolledBefore . '/' . $capacity .
                    '). Check "Override Base Capacity & Continue" and provide a reason.'
                );
            }

            if ($isOverCapacity && $capacityOverride && $reason === '') {
                throw new RuntimeException(
                    'An override reason is required when exceeding the base capacity.'
                );
            }

            /*
             * Save override state on the admission.
             */
            $overrideValue = ($isOverCapacity && $capacityOverride) ? 1 : 0;
            $overrideReason = $overrideValue ? $reason : null;
            $overrideBy = $overrideValue
                ? (int)($_SESSION['user_id'] ?? 0)
                : null;

            /*
             * Update live admission.
             */
            $setParts = ['batch_id=?', 'time_slot=?'];
            $updateParams = [$toBatchId, $toTimeSlot];

            if ($hasCapacityOverride) {
                $setParts[] = 'capacity_override=?';
                $updateParams[] = $overrideValue;
            }
            if ($hasCapacityOverrideReason) {
                $setParts[] = 'capacity_override_reason=?';
                $updateParams[] = $overrideReason;
            }
            if ($hasCapacityOverrideBy) {
                $setParts[] = 'capacity_override_by=?';
                $updateParams[] = $overrideBy;
            }

            $updateParams[] = (int)$admission['id'];
            $updateParams[] = (int)$student['id'];

            $update = $pdo->prepare("
                UPDATE admissions
                SET " . implode(', ', $setParts) . "
                WHERE id=?
                  AND student_id=?
            ");

            $update->execute($updateParams);

            if ($update->rowCount() !== 1) {
                throw new RuntimeException('The admission could not be updated.');
            }

            /*
             * Transfer history.
             */
            $hist = $pdo->prepare("
                INSERT INTO student_batch_transfers
                (
                    student_id,
                    admission_id,
                    from_batch_id,
                    from_time_slot,
                    to_batch_id,
                    to_time_slot,
                    reason,
                    transferred_by
                )
                VALUES (?,?,?,?,?,?,?,?)
            ");

            $hist->execute([
                (int)$student['id'],
                (int)$admission['id'],
                $fromBatchId > 0 ? $fromBatchId : null,
                $fromTimeSlot !== '' ? $fromTimeSlot : null,
                $toBatchId,
                $toTimeSlot,
                $reason !== '' ? $reason : null,
                (int)($_SESSION['user_id'] ?? 0)
            ]);

            /*
             * Audit log.
             */
            $auditDetails =
                'Admission #' . $admission['id'] .
                '; From batch #' . $fromBatchId .
                ' / ' . ($fromTimeSlot !== '' ? $fromTimeSlot : 'Not set') .
                '; To batch #' . $toBatchId .
                ' / ' . $toTimeSlot .
                '; Base capacity: ' . $capacity .
                '; Students before: ' . $enrolledBefore .
                '; Students after: ' . $enrolledAfter;

            if ($overrideValue) {
                $auditDetails .=
                    '; CAPACITY OVERRIDE: YES' .
                    '; Override reason: ' . $reason .
                    '; Override by user #' . $overrideBy;
            } else {
                $auditDetails .= '; CAPACITY OVERRIDE: NO';
                if ($reason !== '') {
                    $auditDetails .= '; Reason: ' . $reason;
                }
            }

            $audit = $pdo->prepare("
                INSERT INTO audit_logs
                    (user_id, action, student_id, details)
                VALUES (?,?,?,?)
            ");

            $audit->execute([
                (int)($_SESSION['user_id'] ?? 0),
                'Batch Transfer',
                (int)$student['id'],
                $auditDetails
            ]);

            $pdo->commit();

            /*
             * IMPORTANT:
             * Do NOT call flash(). This project does not define flash().
             * Redirect back to this page with a simple success flag instead.
             */
            header(
                'Location: student-batch-transfer.php?id=' .
                urlencode($student['student_id']) .
                '&transfer=success'
            );
            exit;

        } catch (Throwable $e) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }

            $error = 'Transfer failed: ' . $e->getMessage();
        }
    }
}

/*
 * Load active/upcoming, non-archived batches for the same course.
 */
$batchStmt = $pdo->prepare("
    SELECT
        b.id,
        b.name,
        b.status,
        b.start_date,
        b.time_slots,
        COALESCE(b.max_students,50) AS max_students,
        b.slot_capacities
    FROM batches b
    WHERE b.course_id=?
      AND b.status <> 'Closed'
      AND COALESCE(b.is_archived,0)=0
    ORDER BY b.start_date IS NULL, b.start_date, b.id DESC
");
$batchStmt->execute([(int)$current['course_id']]);
$batches = $batchStmt->fetchAll();

/*
 * Build slot capacity display.
 * FULL slots remain selectable because override is allowed.
 */
foreach ($batches as &$b) {
    $bSlots = transfer_slots((string)($b['time_slots'] ?? ''));
    $b['slot_info'] = [];

    foreach ($bSlots as $slotName) {
        $cntStmt = $pdo->prepare("
            SELECT COUNT(*)
            FROM admissions
            WHERE batch_id=?
              AND time_slot=?
              AND status <> 'Cancelled'
        ");
        $cntStmt->execute([
            (int)$b['id'],
            $slotName
        ]);

        $enrolled = (int)$cntStmt->fetchColumn();

        $slotCapMap = json_decode((string)($b['slot_capacities'] ?? ''), true);
        if (!is_array($slotCapMap)) {
            $slotCapMap = [];
        }

        $cap = max(1, (int)($b['max_students'] ?? 50));

        if (array_key_exists($slotName, $slotCapMap)) {
            $cap = max(1, (int)$slotCapMap[$slotName]);
        }

        $b['slot_info'][] = [
            'slot' => $slotName,
            'enrolled' => $enrolled,
            'capacity' => $cap,
            'full' => $enrolled >= $cap
        ];
    }
}
unset($b);

require '_header.php';
?>

<style>
.transfer-wrap{max-width:920px;margin:0 auto}
.transfer-card{padding:24px}
.transfer-title{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:22px}
.transfer-current{border:1px solid #e8e9ed;background:#fafbfc;border-radius:14px;padding:18px;margin-bottom:22px}
.transfer-current-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:12px}
.transfer-current-grid div{background:#fff;border:1px solid #eceef2;border-radius:11px;padding:12px}
.transfer-current-grid small,
.transfer-field label{display:block;color:#737982;font-size:11px;font-weight:700;text-transform:uppercase;letter-spacing:.4px;margin-bottom:6px}
.transfer-current-grid strong{color:#20242b}
.transfer-form{border-top:1px solid #eceef2;padding-top:22px}
.transfer-fields{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.transfer-field.wide{grid-column:1/-1}
.transfer-field select,
.transfer-field input{width:100%;box-sizing:border-box;padding:11px 12px;border:1px solid #dfe1e6;border-radius:10px;background:#fff;font-size:14px}
.transfer-help{margin-top:16px;padding:13px 15px;border-radius:11px;background:#fff7e6;color:#805a00;font-size:12px;line-height:1.6}
.transfer-actions{display:flex;gap:10px;margin-top:20px}
.transfer-empty{padding:13px;background:#fff0f1;color:#b31e2c;border-radius:10px;font-size:12px;margin-top:10px}
.transfer-error{padding:13px;background:#fff0f1;color:#b31e2c;border-radius:10px;margin-bottom:16px}
.transfer-success{padding:13px;background:#eefbf3;color:#16743a;border:1px solid #bfe8cd;border-radius:10px;margin-bottom:16px;font-size:13px;font-weight:700}
.slot-capacity-note{margin-top:6px;color:#737982;font-size:11px}
.slot-capacity-note.full{color:#b31e2c;font-weight:800}
.transfer-override{padding:13px 15px;border:1px solid #f0d49b;background:#fffaf0;border-radius:11px}
.transfer-override label{display:flex;align-items:center;gap:9px;text-transform:none;letter-spacing:0;font-size:13px;color:#20242b;margin:0}
.transfer-override input[type="checkbox"]{width:auto}
@media(max-width:680px){
.transfer-current-grid,.transfer-fields{grid-template-columns:1fr}
.transfer-field.wide{grid-column:auto}
.transfer-title{display:block}
.transfer-actions{flex-wrap:wrap}
}
</style>

<div class="transfer-wrap">
    <div class="page-header">
        <div>
            <h1>Change Batch</h1>
            <p>Change the student's current batch and time slot without changing admission or payment details.</p>
        </div>
    </div>

    <?php if ($success): ?>
        <div class="transfer-success">
            ✓ Student batch and time slot changed successfully.
            <?php if (!empty($_GET['override']) || isset($_GET['transfer'])): ?>
                The transfer has been recorded in the history and audit log.
            <?php endif; ?>
        </div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="transfer-error"><?= e($error) ?></div>
    <?php endif; ?>

    <div class="card transfer-card">

        <div class="transfer-title">
            <div>
                <h2 style="margin:0 0 5px"><?= e($student['full_name']) ?></h2>
                <div style="color:#737982;font-size:13px">
                    Student ID: <?= e($student['student_id']) ?>
                </div>
            </div>

            <a class="btn btn-secondary"
               href="student-profile.php?id=<?= urlencode($student['student_id']) ?>">
                Back to Profile
            </a>
        </div>

        <div class="transfer-current">
            <strong>Current Enrollment</strong>

            <div class="transfer-current-grid">
                <div>
                    <small>Course</small>
                    <strong><?= e($current['course_name'] ?? '-') ?></strong>
                </div>

                <div>
                    <small>Current Batch</small>
                    <strong><?= e($current['batch_name'] ?? '-') ?></strong>
                </div>

                <div>
                    <small>Current Time Slot</small>
                    <strong><?= e($current['time_slot'] ?? 'Not set') ?></strong>
                </div>
            </div>
        </div>

        <form method="post" class="transfer-form">
            <?= csrf_input(); ?>

            <input type="hidden"
                   name="student_id"
                   value="<?= e($student['student_id']) ?>">

            <div class="transfer-fields">

                <div class="transfer-field">
                    <label>New Batch</label>

                    <select name="to_batch_id" id="toBatch" required>
                        <option value="">— Select New Batch —</option>

                        <?php foreach ($batches as $b): ?>
                            <?php
                            $slotInfoJson = json_encode(
                                $b['slot_info'] ?? [],
                                JSON_UNESCAPED_UNICODE |
                                JSON_HEX_TAG |
                                JSON_HEX_APOS |
                                JSON_HEX_AMP |
                                JSON_HEX_QUOT
                            );

                            $slotJson = json_encode(
                                transfer_slots((string)($b['time_slots'] ?? '')),
                                JSON_UNESCAPED_UNICODE |
                                JSON_HEX_TAG |
                                JSON_HEX_APOS |
                                JSON_HEX_AMP |
                                JSON_HEX_QUOT
                            );
                            ?>

                            <option
                                value="<?= (int)$b['id'] ?>"
                                data-slots="<?= e($slotJson) ?>"
                                data-slot-info="<?= e($slotInfoJson) ?>"
                            >
                                <?= e($b['name']) ?>
                                <?= !empty($b['start_date']) ? ' · '.e($b['start_date']) : '' ?>
                                <?= ((int)$b['id'] === (int)$current['batch_id']) ? ' (Current)' : '' ?>
                            </option>
                        <?php endforeach; ?>
                    </select>

                    <?php if (!$batches): ?>
                        <div class="transfer-empty">
                            No Active/Upcoming batch found for this course.
                        </div>
                    <?php endif; ?>
                </div>

                <div class="transfer-field">
                    <label>New Time Slot</label>

                    <select name="to_time_slot" id="toTimeSlot" required>
                        <option value="">— Select Time Slot —</option>
                    </select>

                    <div id="slotCapacityNote"
                         class="slot-capacity-note"></div>
                </div>

                <div class="transfer-field wide">
                    <label>Reason / Override Reason</label>

                    <input type="text"
                           name="reason"
                           id="transferReason"
                           maxlength="255"
                           placeholder="Optional normally; required when overriding capacity">
                </div>

                <div class="transfer-field wide"
                     id="overrideBox"
                     style="display:none">

                    <div class="transfer-override">
                        <label>
                            <input type="checkbox"
                                   name="capacity_override"
                                   id="capacityOverride"
                                   value="1">

                            Override Base Capacity &amp; Continue
                        </label>

                        <div class="transfer-help"
                             style="margin-top:10px">
                            This slot is already at or above its base capacity.
                            Any authorized admin can override the base capacity
                            when necessary. An override reason is required.
                            The action will be recorded in the admission and
                            audit log.
                        </div>
                    </div>
                </div>

            </div>

            <div class="transfer-help">
                <strong>Note:</strong>
                Only Batch and Time Slot will change.
                Admission fee, discount, final dealing price, payments,
                receipts and materials will remain unchanged.
                The configured capacity is the <strong>base capacity</strong>.
                If the selected slot is full, an authorized admin may override
                it with a reason.
            </div>

            <div class="transfer-actions">
                <button class="btn btn-primary"
                        type="submit"
                        id="transferSubmit">
                    Confirm Batch Change
                </button>

                <a class="btn btn-secondary"
                   href="student-profile.php?id=<?= urlencode($student['student_id']) ?>">
                    Cancel
                </a>
            </div>

        </form>
    </div>
</div>

<script>
(function(){

    const batch = document.getElementById('toBatch');
    const slot = document.getElementById('toTimeSlot');
    const note = document.getElementById('slotCapacityNote');

    const overrideBox = document.getElementById('overrideBox');
    const overrideCheck = document.getElementById('capacityOverride');
    const reasonInput = document.getElementById('transferReason');

    if (!batch || !slot) return;

    function readJson(value, fallback){
        try {
            const parsed = JSON.parse(value || '');
            return parsed ?? fallback;
        } catch (e) {
            return fallback;
        }
    }

    function getInfoMap(){
        const option = batch.options[batch.selectedIndex];
        const info = readJson(
            option ? option.getAttribute('data-slot-info') : '',
            []
        );

        const map = {};

        if (Array.isArray(info)) {
            info.forEach(function(row){
                if (row && row.slot !== undefined) {
                    map[String(row.slot)] = row;
                }
            });
        }

        return map;
    }

    function refreshSlots(){

        slot.innerHTML =
            '<option value="">— Select Time Slot —</option>';

        note.textContent = '';
        note.className = 'slot-capacity-note';

        overrideBox.style.display = 'none';

        if (overrideCheck) {
            overrideCheck.checked = false;
        }

        const option = batch.options[batch.selectedIndex];

        if (!option || !option.value) {
            return;
        }

        const slots = readJson(
            option.getAttribute('data-slots'),
            []
        );

        const infoMap = getInfoMap();

        if (!Array.isArray(slots) || slots.length === 0) {
            const empty = document.createElement('option');
            empty.value = '';
            empty.textContent = 'No time slot configured';
            empty.disabled = true;
            slot.appendChild(empty);
            return;
        }

        slots.forEach(function(slotName){

            slotName = String(slotName).trim();

            if (!slotName) return;

            const row = infoMap[slotName];
            const opt = document.createElement('option');

            opt.value = slotName;

            if (row) {
                opt.textContent =
                    slotName + ' — ' +
                    row.enrolled + '/' +
                    row.capacity +
                    (row.full
                        ? ' FULL — OVERRIDE AVAILABLE'
                        : '');

                /*
                 * IMPORTANT:
                 * FULL slots are NOT disabled.
                 */
            } else {
                opt.textContent = slotName;
            }

            slot.appendChild(opt);
        });

        updateNote();
    }

    function updateNote(){

        note.textContent = '';
        note.className = 'slot-capacity-note';

        const batchOption = batch.options[batch.selectedIndex];

        if (!batchOption || !batchOption.value || !slot.value) {
            overrideBox.style.display = 'none';
            if (overrideCheck) overrideCheck.checked = false;
            return;
        }

        const infoMap = getInfoMap();
        const row = infoMap[String(slot.value)];

        if (!row) {
            overrideBox.style.display = 'none';
            if (overrideCheck) overrideCheck.checked = false;
            return;
        }

        if (Number(row.enrolled) >= Number(row.capacity)) {

            note.textContent =
                'FULL: ' +
                row.enrolled +
                '/' +
                row.capacity +
                ' — Capacity Override Available';

            note.className =
                'slot-capacity-note full';

            overrideBox.style.display = 'block';

        } else {

            note.textContent =
                'Available: ' +
                row.enrolled +
                '/' +
                row.capacity;

            overrideBox.style.display = 'none';

            if (overrideCheck) {
                overrideCheck.checked = false;
            }
        }
    }

    if (overrideCheck) {
        overrideCheck.addEventListener('change', function(){

            if (this.checked) {
                reasonInput.focus();
            }
        });
    }

    batch.addEventListener('change', refreshSlots);
    slot.addEventListener('change', updateNote);

    refreshSlots();

})();
</script>

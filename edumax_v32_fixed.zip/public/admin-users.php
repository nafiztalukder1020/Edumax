<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
require_valid_csrf();
require_access('admin_users');

// Security hardening: Admin Users management is Super Admin only.
// This prevents privilege escalation even if the admin_users permission
// is accidentally granted to another role.
if (($_SESSION['role'] ?? '') !== 'Super Admin') {
    http_response_code(403);
    exit('Only Super Admin can manage admin users.');
}
ensure_user_permissions_table();

// Self-heal the optional staff activity field used by this page.
foreach ([
    "mobile" => "VARCHAR(30) NULL",
    "email" => "VARCHAR(150) NULL",
    "department" => "VARCHAR(50) NULL",
    "staff_id" => "VARCHAR(30) NULL",
    "joining_date" => "DATE NULL",
    "login_count" => "INT NOT NULL DEFAULT 0"
] as $column => $definition) {
    try { $pdo->exec("ALTER TABLE users ADD COLUMN {$column} {$definition}"); } catch (Throwable $e) {}
}

try {
    $pdo->exec("ALTER TABLE users ADD COLUMN last_login DATETIME NULL");
} catch (Throwable $e) {
    // Column already exists or DB user cannot ALTER; the rest of the page still works.
}

$roles=['Super Admin','Admission Admin','Accounts','Reception','Teacher'];
$departments=['Admission','Accounts','Reception','Academic','Management'];
$permissions=permission_catalog();
$success=''; $error='';

function default_permissions_for_role(string $role): array {
    return match ($role) {
        'Super Admin' => array_keys(permission_catalog()),
        'Admission Admin' => ['dashboard','new_admission','admissions','students','attendance','batch','classes','teachers'],
        'Accounts' => ['dashboard','payments','receipts','reports','students'],
        'Reception' => ['dashboard','new_admission','students','admissions'],
        'Teacher' => ['dashboard','students','attendance','student_performance'],
        default => ['dashboard'],
    };
}

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $action=$_POST['action'] ?? '';
    try {
        if ($action==='edit') {
            $id=(int)($_POST['user_id']??0);
            $name=trim($_POST['name']??'');
            $username=trim($_POST['username']??'');
            $mobile=trim($_POST['mobile']??'');
            $email=trim($_POST['email']??'');
            $department=trim($_POST['department']??'');
            $joiningDate=trim($_POST['joining_date']??'');
            if ($id<=0 || $name==='' || $username==='') throw new Exception('Name and username are required.');
            if ($department!=='' && !in_array($department,$departments,true)) throw new Exception('Invalid department.');
            if ($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new Exception('Invalid email address.');
            if ($joiningDate!=='' && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$joiningDate)) throw new Exception('Invalid joining date.');

            $check=$pdo->prepare('SELECT id FROM users WHERE username=? AND id<>? LIMIT 1');
            $check->execute([$username,$id]);
            if ($check->fetch()) throw new Exception('Username already exists.');

            $stmt=$pdo->prepare('UPDATE users SET name=?, username=?, mobile=?, email=?, department=?, joining_date=? WHERE id=?');
            $stmt->execute([$name,$username,$mobile?:null,$email?:null,$department?:null,$joiningDate?:null,$id]);

            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,NULL,?)");
            $audit->execute([$_SESSION['user_id'],'User Profile Updated','User ID: '.$id.', name: '.$name.', username: '.$username]);
            $success='User profile updated successfully.';
        } elseif ($action==='create') {
            $name=trim($_POST['name']??''); $username=trim($_POST['username']??'');
            $password=$_POST['password']??''; $role=$_POST['role']??'Reception';
            $mobile=trim($_POST['mobile']??''); $email=trim($_POST['email']??'');
            $department=trim($_POST['department']??''); $joiningDate=trim($_POST['joining_date']??'');
            if ($name==='' || $username==='' || strlen($password)<6) throw new Exception('Name, username and a password of at least 6 characters are required.');
            if (!in_array($role,$roles,true)) throw new Exception('Invalid role.');
            if ($department!=='' && !in_array($department,$departments,true)) throw new Exception('Invalid department.');
            if ($email!=='' && !filter_var($email,FILTER_VALIDATE_EMAIL)) throw new Exception('Invalid email address.');
            if ($joiningDate!=='' && !preg_match('/^\d{4}-\d{2}-\d{2}$/',$joiningDate)) throw new Exception('Invalid joining date.');
            $check=$pdo->prepare('SELECT id FROM users WHERE username=? LIMIT 1'); $check->execute([$username]);
            if ($check->fetch()) throw new Exception('Username already exists.');
            $stmt=$pdo->prepare("INSERT INTO users (name,username,password_hash,role,status,mobile,email,department,joining_date) VALUES (?,?,?,?, 'Active',?,?,?,?)");
            $stmt->execute([$name,$username,password_hash($password,PASSWORD_DEFAULT),$role,$mobile?:null,$email?:null,$department?:null,$joiningDate?:null]);
            $uid=(int)$pdo->lastInsertId();
            $staffId='EMP-'.str_pad((string)$uid,4,'0',STR_PAD_LEFT);
            $pdo->prepare('UPDATE users SET staff_id=? WHERE id=?')->execute([$staffId,$uid]);
            $ins=$pdo->prepare('INSERT IGNORE INTO user_permissions (user_id,permission_key) VALUES (?,?)');
            foreach(default_permissions_for_role($role) as $perm) $ins->execute([$uid,$perm]);
            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,NULL,?)");
            $audit->execute([$_SESSION['user_id'],'User Created','User ID: '.$uid.', name: '.$name.', username: '.$username.', role: '.$role]);
            $success='User created successfully. Default access was assigned from the selected role; you can customize it below.';
        } elseif ($action==='permissions') {
            $id=(int)($_POST['user_id']??0);
            if ($id<=0) throw new Exception('Invalid user.');
            $target=$pdo->prepare('SELECT id,role FROM users WHERE id=? LIMIT 1'); $target->execute([$id]); $u=$target->fetch();
            if (!$u) throw new Exception('User not found.');
            $selected=array_values(array_intersect(array_keys($permissions), (array)($_POST['permissions']??[])));
            if ($u['role']==='Super Admin') $selected=array_keys($permissions);
            // Dashboard is the landing page; keep it for non-super users so login remains usable.
            if ($u['role']!=='Super Admin' && !in_array('dashboard',$selected,true)) array_unshift($selected,'dashboard');
            $pdo->beginTransaction();
            $del=$pdo->prepare('DELETE FROM user_permissions WHERE user_id=?'); $del->execute([$id]);
            $ins=$pdo->prepare('INSERT INTO user_permissions (user_id,permission_key) VALUES (?,?)');
            foreach(array_unique($selected) as $perm) $ins->execute([$id,$perm]);
            $pdo->commit();
            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,NULL,?)");
            $audit->execute([$_SESSION['user_id'],'User Permission Updated','User ID: '.$id.', permissions: '.implode(', ',array_unique($selected))]);
            $success='Access updated successfully.';
        } elseif ($action==='status') {
            $id=(int)($_POST['user_id']??0);
            if ($id===(int)$_SESSION['user_id']) throw new Exception('You cannot deactivate your own account.');
            $stmt=$pdo->prepare("UPDATE users SET status=CASE WHEN status='Active' THEN 'Inactive' ELSE 'Active' END WHERE id=?"); $stmt->execute([$id]);
            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,NULL,?)");
            $audit->execute([$_SESSION['user_id'],'User Status Updated','User ID: '.$id]);
            $success='User status updated successfully.';
        } elseif ($action==='password') {
            $id=(int)($_POST['user_id']??0); $password=$_POST['new_password']??'';
            if (strlen($password)<6) throw new Exception('New password must be at least 6 characters.');
            $stmt=$pdo->prepare('UPDATE users SET password_hash=? WHERE id=?'); $stmt->execute([password_hash($password,PASSWORD_DEFAULT),$id]);
            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,NULL,?)");
            $audit->execute([$_SESSION['user_id'],'User Password Changed','User ID: '.$id]);
            $success='Password changed successfully.';
        } elseif ($action==='role') {
            $id=(int)($_POST['user_id']??0); $role=$_POST['role']??'';
            if (!in_array($role,$roles,true)) throw new Exception('Invalid role.');
            if ($id===(int)$_SESSION['user_id'] && $role!=='Super Admin') throw new Exception('You cannot remove Super Admin access from your own account.');
            if ($role!=='Super Admin') {
                $q=$pdo->query("SELECT COUNT(*) FROM users WHERE role='Super Admin' AND status='Active'");
                if ((int)$q->fetchColumn()<=1) { $cur=$pdo->prepare('SELECT role FROM users WHERE id=?'); $cur->execute([$id]); if (($cur->fetchColumn()??'')==='Super Admin') throw new Exception('At least one active Super Admin account must remain.'); }
            }
            $stmt=$pdo->prepare('UPDATE users SET role=? WHERE id=?'); $stmt->execute([$role,$id]);
            // Role changes get sensible defaults only when this user still has exactly the old role defaults.
            $pdo->prepare('DELETE FROM user_permissions WHERE user_id=?')->execute([$id]);
            $ins=$pdo->prepare('INSERT INTO user_permissions (user_id,permission_key) VALUES (?,?)');
            foreach(default_permissions_for_role($role) as $perm) $ins->execute([$id,$perm]);
            $audit=$pdo->prepare("INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,NULL,?)");
            $audit->execute([$_SESSION['user_id'],'User Role Updated','User ID: '.$id.', role: '.$role]);
            $success='Role updated and access reset to the new role defaults.';
        }
    } catch(Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error=$e->getMessage();
    }
}

$search=trim($_GET['search']??''); $roleFilter=$_GET['role']??''; $statusFilter=$_GET['status']??'';
$where=[]; $params=[];
if($search!==''){ $where[]='(name LIKE ? OR username LIKE ?)'; $params[]='%'.$search.'%'; $params[]='%'.$search.'%'; }
if(in_array($roleFilter,$roles,true)){ $where[]='role=?'; $params[]=$roleFilter; }
if(in_array($statusFilter,['Active','Inactive'],true)){ $where[]='status=?'; $params[]=$statusFilter; }
$sql='SELECT id,name,username,role,status,created_at,mobile,email,department,staff_id,joining_date,last_login,login_count FROM users'; if($where)$sql.=' WHERE '.implode(' AND ',$where); $sql.=' ORDER BY id DESC';
$stmt=$pdo->prepare($sql); $stmt->execute($params); $users=$stmt->fetchAll();

$permStmt=$pdo->prepare('SELECT permission_key FROM user_permissions WHERE user_id=?');
$userPerms=[];
foreach($users as $u){ $permStmt->execute([(int)$u['id']]); $userPerms[(int)$u['id']]=array_column($permStmt->fetchAll(),'permission_key'); }
$total=(int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn();
$active=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE status='Active'")->fetchColumn();
$inactive=$total-$active; $superAdmins=(int)$pdo->query("SELECT COUNT(*) FROM users WHERE role='Super Admin' AND status='Active'")->fetchColumn();
require '_header.php';
?>
<style>
.admin-stats{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:0 0 20px}.admin-stat{background:#fff;border:1px solid var(--border);border-radius:16px;padding:18px 20px;box-shadow:var(--shadow)}.admin-stat .label{font-size:12px;text-transform:uppercase;letter-spacing:.06em;color:var(--muted);font-weight:700}.admin-stat .value{font-size:28px;font-weight:800;color:var(--ink);margin-top:7px}.admin-toolbar{display:flex;gap:10px;align-items:center;flex-wrap:wrap}.admin-toolbar input,.admin-toolbar select{min-height:42px}.admin-toolbar input{flex:1;min-width:220px}.user-badge{display:inline-flex;padding:6px 10px;border-radius:999px;font-size:12px;font-weight:700;background:var(--brand-soft);color:var(--brand)}.status-active{color:#15803d;font-weight:700}.status-inactive{color:#9a3412;font-weight:700}.actions{display:flex;gap:7px;justify-content:flex-end;align-items:center;flex-wrap:wrap}.actions form{margin:0}.actions input{width:145px}.admin-table th{white-space:nowrap}.admin-table td{vertical-align:middle}.access-panel{background:#fafbfc;border:1px solid var(--border);border-radius:14px;padding:14px;margin-top:10px}.permission-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:8px 14px}.permission-item{display:flex;align-items:center;gap:9px;padding:9px 10px;background:#fff;border:1px solid var(--border);border-radius:10px;font-size:13px;font-weight:600}.permission-item input{accent-color:var(--brand);width:16px;height:16px}.access-note{font-size:12px;color:var(--muted);margin:4px 0 12px}@media(max-width:900px){.admin-stats{grid-template-columns:repeat(2,minmax(0,1fr))}.permission-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.actions{justify-content:flex-start}}@media(max-width:560px){.admin-stats{grid-template-columns:1fr}.permission-grid{grid-template-columns:1fr}.admin-stat .value{font-size:24px}}
</style>
<div class="section-title"><div><h1>Admin Users</h1><p>Manage staff accounts and control exactly which sections each user can access.</p></div></div>
<?php if($success): ?><div class="success"><?=e($success)?></div><?php endif; ?><?php if($error): ?><div class="alert"><?=e($error)?></div><?php endif; ?>
<div class="admin-stats"><div class="admin-stat"><div class="label">Total Users</div><div class="value"><?=number_format($total)?></div></div><div class="admin-stat"><div class="label">Active Users</div><div class="value"><?=number_format($active)?></div></div><div class="admin-stat"><div class="label">Inactive Users</div><div class="value"><?=number_format($inactive)?></div></div><div class="admin-stat"><div class="label">Active Super Admins</div><div class="value"><?=number_format($superAdmins)?></div></div></div>
<div class="card" style="margin-bottom:20px"><h2>Create User</h2><p style="margin:4px 0 18px;color:var(--muted)">Create a staff account. The selected role gives a starting access set, which you can customize afterwards.</p><form method="post"><?=csrf_input()?><input type="hidden" name="action" value="create"><div class="form-grid"><div class="field"><label>Name</label><input name="name" maxlength="120" required></div><div class="field"><label>Username</label><input name="username" maxlength="80" autocomplete="off" required></div><div class="field"><label>Mobile</label><input name="mobile" maxlength="30"></div><div class="field"><label>Email</label><input type="email" name="email" maxlength="150"></div><div class="field"><label>Department</label><select name="department"><option value="">Select Department</option><?php foreach($departments as $d): ?><option value="<?=e($d)?>"><?=e($d)?></option><?php endforeach; ?></select></div><div class="field"><label>Joining Date</label><input type="date" name="joining_date"></div><div class="field"><label>Password</label><input type="password" name="password" minlength="6" autocomplete="new-password" required></div><div class="field"><label>Role</label><select name="role" required><?php foreach($roles as $r): ?><option value="<?=e($r)?>" <?= $r==='Reception'?'selected':'' ?>><?=e($r)?></option><?php endforeach; ?></select></div></div><div style="margin-top:16px"><button class="btn btn-primary" type="submit">Create User</button></div></form></div>
<div class="card"><div style="display:flex;justify-content:space-between;gap:15px;align-items:center;flex-wrap:wrap"><div><h2 style="margin:0">Users & Access</h2><p style="margin:4px 0 0;color:var(--muted)"><?=count($users)?> user(s) shown</p></div></div>
<form method="get" class="admin-toolbar" style="margin:16px 0 12px"><input name="search" value="<?=e($search)?>" placeholder="Search name or username..."><select name="role"><option value="">All Roles</option><?php foreach($roles as $r): ?><option value="<?=e($r)?>" <?=$roleFilter===$r?'selected':''?>><?=e($r)?></option><?php endforeach; ?></select><select name="status"><option value="">All Status</option><option value="Active" <?=$statusFilter==='Active'?'selected':''?>>Active</option><option value="Inactive" <?=$statusFilter==='Inactive'?'selected':''?>>Inactive</option></select><button class="btn btn-light" type="submit">Filter</button><?php if($search!==''||$roleFilter!==''||$statusFilter!==''): ?><a class="btn btn-light" href="admin-users.php">Clear</a><?php endif; ?></form>
<div style="overflow-x:auto"><table class="admin-table" style="width:100%;border-collapse:collapse;min-width:1100px"><thead><tr><th style="text-align:left;padding:12px">Name</th><th style="text-align:left;padding:12px">Username</th><th style="text-align:left;padding:12px">Staff ID</th><th style="text-align:left;padding:12px">Department</th><th style="text-align:left;padding:12px">Role</th><th style="text-align:left;padding:12px">Status</th><th style="text-align:left;padding:12px">Access</th><th style="text-align:left;padding:12px">Created</th><th style="text-align:left;padding:12px">Last Login</th><th style="text-align:left;padding:12px">Login Count</th><th style="text-align:right;padding:12px">Actions</th></tr></thead><tbody>
<?php if(!$users): ?><tr><td colspan="10" style="padding:30px;text-align:center;color:var(--muted)">No users found.</td></tr><?php endif; ?>
<?php foreach($users as $u): $uid=(int)$u['id']; $isSelf=$uid===(int)$_SESSION['user_id']; $fullAccess=$u['role']==='Super Admin'; ?>
<tr style="border-top:1px solid var(--border)"><td style="padding:12px"><strong><?=e($u['name'])?></strong><?=$isSelf?' <span class="user-badge">You</span>':''?></td><td style="padding:12px"><?=e($u['username'])?></td><td style="padding:12px"><?=e($u['staff_id']??('EMP-'.str_pad((string)$uid,4,'0',STR_PAD_LEFT)))?></td><td style="padding:12px"><?=e($u['department']??'—')?></td><td style="padding:12px"><form method="post"><?=csrf_input()?><input type="hidden" name="action" value="role"><input type="hidden" name="user_id" value="<?=$uid?>"><select name="role" onchange="this.form.submit()" <?=$isSelf?'disabled':''?>><?php foreach($roles as $r): ?><option value="<?=e($r)?>" <?=$u['role']===$r?'selected':''?>><?=e($r)?></option><?php endforeach; ?></select><?php if($isSelf): ?><input type="hidden" name="role" value="Super Admin"><?php endif; ?></form></td><td style="padding:12px"><span class="<?=$u['status']==='Active'?'status-active':'status-inactive'?>"><?=e($u['status'])?></span></td><td style="padding:12px"><strong><?=$fullAccess?'Full Access':count($userPerms[$uid]??[]).' sections'?></strong><details class="access-panel"><summary style="cursor:pointer;color:var(--brand);font-weight:800"><?=$fullAccess?'View access':'Manage access'?></summary><form method="post" style="margin-top:12px"><?=csrf_input()?><input type="hidden" name="action" value="permissions"><input type="hidden" name="user_id" value="<?=$uid?>"><p class="access-note"><?=$fullAccess?'Super Admin automatically has access to every section.':'Tick only the sections this user should see and use. Server-side access is enforced too.'?></p><div class="permission-grid"><?php foreach($permissions as $key=>$label): ?><label class="permission-item"><input type="checkbox" name="permissions[]" value="<?=e($key)?>" <?=($fullAccess||in_array($key,$userPerms[$uid]??[],true))?'checked':''?> <?=$fullAccess?'disabled':''?>><?=e($label)?></label><?php endforeach; ?></div><?php if(!$fullAccess): ?><div style="margin-top:12px"><button class="btn btn-primary" type="submit">Save Access</button></div><?php endif; ?></form></details></td><td style="padding:12px;color:var(--muted)"><?=e(date('d M Y',strtotime($u['created_at'])))?></td><td style="padding:12px;color:var(--muted)"><?=!empty($u['last_login'])?e(date('d M Y h:i A',strtotime($u['last_login']))):'Never'?></td><td style="padding:12px"><?=number_format((int)($u['login_count']??0))?></td><td style="padding:12px"><div class="actions"><details style="position:relative"><summary class="btn btn-light" style="cursor:pointer;list-style:none">Edit</summary><form method="post" style="position:absolute;right:0;top:46px;z-index:20;background:#fff;border:1px solid var(--border);border-radius:12px;padding:12px;min-width:260px;box-shadow:var(--shadow)"><?=csrf_input()?><input type="hidden" name="action" value="edit"><input type="hidden" name="user_id" value="<?=$uid?>"><input type="text" name="name" value="<?=e($u['name'])?>" maxlength="120" required style="width:100%;margin-bottom:8px"><input type="text" name="username" value="<?=e($u['username'])?>" maxlength="80" required style="width:100%;margin-bottom:8px"><input type="text" name="mobile" value="<?=e($u['mobile']??'')?>" maxlength="30" placeholder="Mobile" style="width:100%;margin-bottom:8px"><input type="email" name="email" value="<?=e($u['email']??'')?>" maxlength="150" placeholder="Email" style="width:100%;margin-bottom:8px"><select name="department" style="width:100%;margin-bottom:8px"><option value="">Department</option><?php foreach($departments as $d): ?><option value="<?=e($d)?>" <?=($u['department']??'')===$d?'selected':''?>><?=e($d)?></option><?php endforeach; ?></select><input type="date" name="joining_date" value="<?=e($u['joining_date']??'')?>" style="width:100%;margin-bottom:8px"><button class="btn btn-primary" type="submit">Save Profile</button></form></details><form method="post"><?=csrf_input()?><input type="hidden" name="action" value="status"><input type="hidden" name="user_id" value="<?=$uid?>"><button class="btn btn-light" type="submit"><?=$u['status']==='Active'?'Deactivate':'Activate'?></button></form><form method="post"><?=csrf_input()?><input type="hidden" name="action" value="password"><input type="hidden" name="user_id" value="<?=$uid?>"><input type="password" name="new_password" minlength="6" placeholder="New password" required autocomplete="new-password"><button class="btn btn-primary" type="submit">Change</button></form></div></td></tr>
<?php endforeach; ?></tbody></table></div></div>
<?php require '_footer.php'; ?>

<?php
require_once __DIR__ . '/../config/app.php';
require_access('receipts');
$q = trim($_GET['q'] ?? '');
$method = trim($_GET['method'] ?? '');
$from = trim($_GET['from'] ?? '');
$to = trim($_GET['to'] ?? '');

$sql = "SELECT p.*, s.student_id AS student_code, s.full_name, s.mobile,
               a.final_dealing_price, u.name AS received_by_name, c.name AS course_name, b.name AS batch_name
        FROM payments p
        JOIN students s ON s.id=p.student_id
        JOIN admissions a ON a.id=p.admission_id
        LEFT JOIN courses c ON c.id=a.course_id
        LEFT JOIN batches b ON b.id=a.batch_id
        LEFT JOIN users u ON u.id=p.received_by
        WHERE p.status='Valid' AND p.receipt_no IS NOT NULL AND p.receipt_no <> ''";
$params=[];

if ($q !== '') {
    $sql .= " AND (p.receipt_no LIKE ? OR s.student_id LIKE ? OR s.full_name LIKE ? OR s.mobile LIKE ?)";
    $like="%{$q}%"; array_push($params,$like,$like,$like,$like);
}
if ($method !== '') { $sql .= " AND p.method=?"; $params[]=$method; }
if ($from !== '') { $sql .= " AND DATE(p.created_at)>=?"; $params[]=$from; }
if ($to !== '') { $sql .= " AND DATE(p.created_at)<=?"; $params[]=$to; }
$sql .= " ORDER BY p.id DESC LIMIT 300";
$stmt=$pdo->prepare($sql); $stmt->execute($params); $rows=$stmt->fetchAll();

$totalAmount=0; foreach($rows as $r) $totalAmount += (float)$r['amount'];
require '_header.php';
?>
<style>
.receipts-search{padding:22px!important;margin-bottom:18px}
.receipts-search .form-grid{grid-template-columns:repeat(2,minmax(0,1fr));gap:18px 18px}
.receipts-search .search-actions{grid-column:1/-1;display:flex;align-items:center;gap:10px;padding-top:2px}
.receipts-stats{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:18px;margin-bottom:18px}
.receipts-stats .stat-card{min-height:112px;padding:22px 24px!important;display:flex;flex-direction:column;justify-content:center}
.receipts-stats .stat-value{margin-top:8px;font-size:28px;font-weight:900;color:var(--ink)}
.receipts-table{padding:14px!important}
.receipts-table .table{min-width:920px}
@media(max-width:760px){.receipts-search .form-grid{grid-template-columns:1fr}.receipts-search .search-actions{grid-column:auto}.receipts-stats{grid-template-columns:1fr}.receipts-stats .stat-card{min-height:96px}.receipts-table{padding:10px!important}}
</style>

<div class="section-title">
  <div><h1>Receipts</h1><p class="muted">Search, view and print all valid payment receipts.</p></div>
</div>

<div class="card receipts-search">
  <form method="get" class="form-grid">
    <div class="field"><label>Search</label><input name="q" value="<?=e($q)?>" placeholder="Receipt / Student ID / Name / Mobile"></div>
    <div class="field"><label>Payment Method</label><select name="method"><option value="">All Methods</option><?php foreach(['Cash','bKash','Nagad','Bank','Other'] as $m):?><option value="<?=e($m)?>" <?= $method===$m?'selected':'' ?>><?=e($m)?></option><?php endforeach;?></select></div>
    <div class="field"><label>From Date</label><input type="date" name="from" value="<?=e($from)?>"></div>
    <div class="field"><label>To Date</label><input type="date" name="to" value="<?=e($to)?>"></div>
    <div class="search-actions"><button class="btn btn-primary">Search</button><a class="btn" href="receipts.php">Reset</a></div>
  </form>
</div>

<div class="receipts-stats">
  <div class="stat-card"><div class="stat-label">Receipts Found</div><div class="stat-value"><?=number_format(count($rows))?></div></div>
  <div class="stat-card"><div class="stat-label">Total Amount</div><div class="stat-value">৳<?=number_format($totalAmount,2)?></div></div>
</div>

<div class="card table-wrap receipts-table">
<table class="table">
<thead><tr><th>Receipt No</th><th>Student</th><th>Course</th><th>Amount</th><th>Method</th><th>Received By</th><th>Date</th><th>Action</th></tr></thead>
<tbody>
<?php if(!$rows): ?><tr><td colspan="8" style="text-align:center;padding:30px">No receipts found.</td></tr>
<?php else: foreach($rows as $r): ?>
<tr>
  <td><strong><?=e($r['receipt_no'])?></strong></td>
  <td><?=e($r['full_name'])?><br><small class="muted"><?=e($r['student_code'])?> · <?=e($r['mobile'])?></small></td>
  <td><?=e($r['course_name'] ?: '-')?></td>
  <td><strong>৳<?=number_format((float)$r['amount'],2)?></strong></td>
  <td><?=e($r['method'])?></td>
  <td><?=e($r['received_by_name'] ?? '-')?></td>
  <td><?=e(date('d M Y, h:i A',strtotime($r['created_at'])))?></td>
  <td><a class="btn btn-primary" style="padding:7px 11px" target="_blank" href="receipt.php?receipt=<?=urlencode($r['receipt_no'])?>">View / Print</a></td>
</tr>
<?php endforeach; endif; ?>
</tbody></table>
</div>
<?php require '_footer.php'; ?>

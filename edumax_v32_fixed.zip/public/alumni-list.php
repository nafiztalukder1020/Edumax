<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

if (function_exists('require_access')) {
    require_access('alumni');
} elseif (function_exists('is_admin') && !is_admin()) {
    http_response_code(403); exit('Access denied.');
}
if (session_status() !== PHP_SESSION_ACTIVE) session_start();

$db = $GLOBALS['pdo'] ?? ($pdo ?? null);
if (!$db instanceof PDO) exit('Database connection is not available.');

function h($v): string { return htmlspecialchars((string)$v, ENT_QUOTES, 'UTF-8'); }

$q = trim((string)($_GET['q'] ?? ''));
$batch = trim((string)($_GET['batch'] ?? ''));
$status = trim((string)($_GET['status'] ?? ''));

$where=[]; $params=[];
if ($q !== '') {
    $where[]="(registration_no LIKE ? OR alumni_name LIKE ? OR mobile_no LIKE ? OR email LIKE ?)";
    $like="%$q%"; array_push($params,$like,$like,$like,$like);
}
if ($batch !== '') { $where[]="batch=?"; $params[]=$batch; }
if (in_array($status,['Active','Inactive'],true)) { $where[]="status=?"; $params[]=$status; }

$sql="SELECT id,registration_no,registration_date,photo,alumni_name,batch,mobile_no,email,present_status,profession,organization_name,status
      FROM alumni_registrations ".($where?'WHERE '.implode(' AND ',$where):'')."
      ORDER BY id DESC LIMIT 300";
$rows=[]; $batches=[];
try {
    $stmt=$db->prepare($sql); $stmt->execute($params); $rows=$stmt->fetchAll(PDO::FETCH_ASSOC);
    $batches=$db->query("SELECT DISTINCT batch FROM alumni_registrations WHERE batch IS NOT NULL AND batch<>'' ORDER BY batch DESC")->fetchAll(PDO::FETCH_COLUMN);
} catch (Throwable $e) {
    // alumni_registrations is created by database/v32_fix_migration.sql; show an empty list until then.
}

if (file_exists(__DIR__.'/_header.php')) require __DIR__.'/_header.php';
?>
<style>
.alumni-list-wrap{max-width:1250px;margin:auto;padding:20px}
.al-card{background:#fff;border:1px solid #e5e7eb;border-radius:14px;box-shadow:0 8px 25px rgba(15,23,42,.06);overflow:hidden}
.al-head{padding:20px 24px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;align-items:center;gap:15px}
.al-head h2{margin:0;font-size:22px}.al-head p{margin:5px 0 0;color:#6b7280;font-size:13px}
.al-btn{display:inline-block;text-decoration:none;border:0;border-radius:8px;padding:10px 14px;font-weight:700;cursor:pointer}
.al-primary{background:#c91f2e;color:#fff}.al-light{background:#f3f4f6;color:#374151}
.al-filter{padding:18px 24px;border-bottom:1px solid #eee;background:#fafafa}
.al-filter form{display:grid;grid-template-columns:2fr 1fr 1fr auto auto;gap:10px}
.al-filter input,.al-filter select{width:100%;box-sizing:border-box;padding:10px 11px;border:1px solid #d7dbe0;border-radius:8px;background:#fff}
.al-table{width:100%;border-collapse:collapse}.al-table th,.al-table td{padding:12px 14px;border-bottom:1px solid #edf0f2;text-align:left;font-size:13px;vertical-align:middle}.al-table th{background:#f8f9fa;color:#4b5563;font-size:12px;text-transform:uppercase}
.al-person{display:flex;align-items:center;gap:10px}.al-avatar{width:38px;height:38px;border-radius:50%;object-fit:cover;background:#f1f1f1;border:1px solid #ddd}.al-name{font-weight:800}.al-sub{font-size:11px;color:#7b8188;margin-top:2px}
.al-badge{display:inline-block;padding:4px 8px;border-radius:20px;font-size:11px;font-weight:800}.active{background:#e9f7ef;color:#247b49}.inactive{background:#f1f3f5;color:#68717a}
.al-empty{padding:45px;text-align:center;color:#6b7280}.al-count{font-size:13px;color:#6b7280}
@media(max-width:850px){.al-filter form{grid-template-columns:1fr 1fr}.al-filter .search{grid-column:1/-1}.al-table{min-width:950px}.al-table-wrap{overflow:auto}}
@media(max-width:600px){.al-head{align-items:flex-start;flex-direction:column}.al-filter form{grid-template-columns:1fr}.al-filter .search{grid-column:auto}}
</style>

<div class="alumni-list-wrap">
 <div class="al-card">
  <div class="al-head">
   <div><h2>🎓 Alumni List</h2><p>Search, filter and manage registered alumni.</p></div>
   <?php if (is_file(__DIR__ . '/alumni-registration.php')): ?><a class="al-btn al-primary" href="alumni-registration.php">+ New Alumni</a><?php endif; ?>
  </div>

  <div class="al-filter">
   <form method="get">
    <div class="search"><input name="q" value="<?=h($q)?>" placeholder="Search Name / Mobile / Registration No. / Email"></div>
    <select name="batch"><option value="">All Batches</option><?php foreach($batches as $b):?><option value="<?=h($b)?>" <?=$batch===$b?'selected':''?>><?=h($b)?></option><?php endforeach;?></select>
    <select name="status"><option value="">All Status</option><option value="Active" <?=$status==='Active'?'selected':''?>>Active</option><option value="Inactive" <?=$status==='Inactive'?'selected':''?>>Inactive</option></select>
    <button class="al-btn al-primary">Search</button>
    <a class="al-btn al-light" href="alumni-list.php">Reset</a>
   </form>
  </div>

  <div class="al-table-wrap">
   <?php if(!$rows): ?>
    <div class="al-empty">No alumni records found.</div>
   <?php else: ?>
   <table class="al-table">
    <thead><tr><th>Alumni</th><th>Registration No.</th><th>Batch</th><th>Mobile</th><th>Current Status</th><th>Status</th><th>Action</th></tr></thead>
    <tbody>
    <?php foreach($rows as $r): ?>
     <tr>
      <td>
       <div class="al-person">
        <?php if(!empty($r['photo'])): ?><img class="al-avatar" src="<?=h('../'.$r['photo'])?>" alt=""><?php else: ?><div class="al-avatar"></div><?php endif;?>
        <div><div class="al-name"><?=h($r['alumni_name'])?></div><div class="al-sub"><?=h($r['email'] ?: 'No email')?></div></div>
       </div>
      </td>
      <td><strong><?=h($r['registration_no'])?></strong><div class="al-sub"><?=h($r['registration_date'])?></div></td>
      <td><?=h($r['batch'] ?: '—')?></td>
      <td><?=h($r['mobile_no'] ?: '—')?></td>
      <td><?=h($r['present_status'] ?: '—')?><?php if($r['profession']):?><div class="al-sub"><?=h($r['profession'])?><?= $r['organization_name'] ? ' · '.h($r['organization_name']) : '' ?></div><?php endif;?></td>
      <td><span class="al-badge <?=strtolower($r['status'])?>"><?=h($r['status'])?></span></td>
      <td><a class="al-btn al-light" href="alumni-profile.php?id=<?= (int)$r['id'] ?>">View</a></td>
     </tr>
    <?php endforeach;?>
    </tbody>
   </table>
   <?php endif;?>
  </div>
  <div style="padding:13px 24px;border-top:1px solid #eee" class="al-count">Showing <?=count($rows)?> record(s)<?=count($rows)>=300?' — maximum 300 shown':''?>.</div>
 </div>
</div>
<?php if(file_exists(__DIR__.'/_footer.php')) require __DIR__.'/_footer.php'; ?>

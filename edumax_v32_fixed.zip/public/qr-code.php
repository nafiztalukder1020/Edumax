<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_access('new_admission');

$publicUrl = 'https://admission.dawaghor.com/new-admission.php?mode=public';
$qrUrl = 'https://api.qrserver.com/v1/create-qr-code/?size=800x800&margin=20&data=' . rawurlencode($publicUrl);

/*
 * Same-origin QR download endpoint.
 * This avoids the browser's cross-origin canvas/download restriction.
 */
if (isset($_GET['download']) && $_GET['download'] === '1') {
    $qrBinary = false;

    if (function_exists('curl_init')) {
        $ch = curl_init($qrUrl);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_FOLLOWLOCATION => true,
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_TIMEOUT => 20,
            CURLOPT_SSL_VERIFYPEER => true,
            CURLOPT_SSL_VERIFYHOST => 2,
            CURLOPT_USERAGENT => 'Edumax Admission QR',
        ]);
        $qrBinary = curl_exec($ch);
        $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);

        if ($qrBinary === false || $httpCode !== 200) {
            $qrBinary = false;
        }
    }

    if ($qrBinary === false) {
        $qrBinary = @file_get_contents($qrUrl);
    }

    if ($qrBinary === false || $qrBinary === '') {
        http_response_code(502);
        header('Content-Type: text/plain; charset=utf-8');
        echo 'Unable to download the QR image right now. Please try again.';
        exit;
    }

    header('Content-Type: image/png');
    header('Content-Disposition: attachment; filename="edumax-public-admission-qr.png"');
    header('Content-Length: ' . strlen($qrBinary));
    header('Cache-Control: no-store, no-cache, must-revalidate');
    echo $qrBinary;
    exit;
}
?>
<?php require __DIR__ . '/_header.php'; ?>

<style>
.qr-page{max-width:980px;margin:0 auto}
.qr-hero{display:flex;justify-content:space-between;align-items:flex-start;gap:20px;margin-bottom:20px}
.qr-hero h1{margin:0 0 6px}
.qr-hero p{margin:0;color:#737982}
.qr-grid{display:grid;grid-template-columns:minmax(300px,420px) 1fr;gap:22px;align-items:start}
.qr-card{background:#fff;border:1px solid #e7e9ee;border-radius:18px;box-shadow:0 10px 30px rgba(20,30,50,.06);padding:24px}
.qr-preview{display:flex;justify-content:center;align-items:center;background:#fafbfc;border:1px dashed #d9dde5;border-radius:16px;padding:24px;min-height:380px}
.qr-preview img{width:min(100%,340px);height:auto;display:block;background:#fff}
.qr-label{font-size:12px;font-weight:800;text-transform:uppercase;letter-spacing:.06em;color:#7b818a;margin-bottom:7px}
.qr-url{background:#f7f8fa;border:1px solid #e5e7eb;border-radius:10px;padding:12px 13px;word-break:break-all;font-size:13px;color:#3d4249}
.qr-actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:16px}
.qr-actions .btn{cursor:pointer}
.qr-info{display:grid;gap:14px}
.qr-info-item{padding:16px;border:1px solid #eceef2;border-radius:13px;background:#fff}
.qr-info-item strong{display:block;margin-bottom:5px;color:#252a31}
.qr-info-item span{font-size:13px;color:#6f7680;line-height:1.55}
.qr-brand{display:flex;align-items:center;gap:12px;margin-bottom:18px}
.qr-brand img{width:56px;height:56px;object-fit:contain}
.qr-brand strong{font-size:17px}
@media(max-width:760px){
 .qr-hero{display:block}
 .qr-grid{grid-template-columns:1fr}
 .qr-card{padding:17px}
 .qr-preview{min-height:300px;padding:18px}
 .qr-actions .btn{flex:1 1 150px}
}
@media print{
 body *{visibility:hidden!important}
 #qr-print-area,#qr-print-area *{visibility:visible!important}
 #qr-print-area{position:absolute;left:0;top:0;width:100%;display:flex!important;flex-direction:column;align-items:center;padding-top:30px}
 #qr-print-area .print-title{display:block!important}
 #qr-print-area img{width:420px!important;max-width:90vw!important}
 .no-print{display:none!important}
}
.print-title{display:none;text-align:center;margin-bottom:20px}
</style>

<div class="qr-page">
    <div class="qr-hero">
        <div>
            <h1>Public Admission QR</h1>
            <p>Generate and print the QR code for the public admission registration form.</p>
        </div>
    </div>

    <div class="qr-grid">
        <div class="qr-card" id="qr-print-area">
            <div class="print-title">
                <h2 style="margin:0 0 5px">Edumax Admission Registration</h2>
                <p style="margin:0;color:#666">Scan to submit your admission information</p>
            </div>

            <div class="qr-brand no-print">
                <img src="assets/edumax-logo.png" alt="Edumax">
                <div>
                    <strong>Edumax Admission</strong>
                    <div style="font-size:13px;color:#737982">Public Registration QR</div>
                </div>
            </div>

            <div class="qr-preview">
                <img id="admissionQr" src="<?=e($qrUrl)?>" alt="Public Admission QR Code">
            </div>

            <div class="qr-actions no-print">
                <button class="btn btn-primary" type="button" onclick="downloadQR()">Download PNG</button>
                <button class="btn btn-light" type="button" onclick="window.print()">Print QR</button>
            </div>
        </div>

        <div class="qr-info">
            <div class="qr-card">
                <div class="qr-label">Public Admission URL</div>
                <div class="qr-url"><?=e($publicUrl)?></div>
                <div class="qr-actions">
                    <button class="btn btn-light" type="button" onclick="copyPublicUrl()">Copy Link</button>
                    <a class="btn btn-light" href="<?=e($publicUrl)?>" target="_blank" rel="noopener">Open Form</a>
                </div>
            </div>

            <div class="qr-card">
                <div class="qr-info-item">
                    <strong>✓ No Login Required</strong>
                    <span>Students can scan this QR and directly open the public admission form.</span>
                </div>
                <div class="qr-info-item">
                    <strong>✓ Same Admission Form</strong>
                    <span>This QR opens the existing <b>new-admission.php?mode=public</b> form. No separate admission form is used.</span>
                </div>
                <div class="qr-info-item">
                    <strong>✓ Admin Processing</strong>
                    <span>Submitted registrations appear in the system as Pending applications for admin processing.</span>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
function copyPublicUrl(){
    const url = <?=json_encode($publicUrl, JSON_UNESCAPED_SLASHES)?>;
    navigator.clipboard.writeText(url).then(function(){
        alert('Public Admission link copied.');
    }).catch(function(){
        prompt('Copy this link:', url);
    });
}

function downloadQR(){
    // Download through this same PHP page to avoid cross-origin restrictions.
    window.location.href = '?download=1';
}
</script>

</main>
</div>
</body>
</html>

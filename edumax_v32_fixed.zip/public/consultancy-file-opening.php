<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
require_access('consultancy_dashboard');
$_SESSION['workspace'] = 'consultancy';

$error = '';
$success = '';
$viewFileId = (int)($_GET['view'] ?? 0);
$userId = (int)($_SESSION['user_id'] ?? 0);

$serviceTypes = ['Study Abroad','University Application','Visa Processing','Other'];
$fileStatuses = ['Open','Processing','Completed','Cancelled'];
$docStatuses = ['Pending','Received','Verified','Not Required'];

try { $pdo->query('SELECT 1 FROM consultancy_files LIMIT 1'); }
catch (Throwable $e) { $error = 'File Opening database table is not installed yet. Please import consultancy-file-opening.sql first.'; }

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    require_valid_csrf();
    $action = trim((string)($_POST['action'] ?? ''));

    try {
        if ($action === 'create_file') {
            $enquiryId = (int)($_POST['enquiry_id'] ?? 0);
            $openingDate = trim((string)($_POST['opening_date'] ?? date('Y-m-d')));
            $passport = trim((string)($_POST['passport_number'] ?? ''));
            $service = trim((string)($_POST['service_type'] ?? 'Study Abroad'));
            $status = trim((string)($_POST['file_status'] ?? 'Open'));
            $serviceFee = (float)($_POST['service_fee'] ?? 0);
            $notes = trim((string)($_POST['notes'] ?? ''));

            if ($enquiryId <= 0) throw new RuntimeException('Please select an enquiry.');
            if (!in_array($service, $serviceTypes, true)) throw new RuntimeException('Invalid service type.');
            if (!in_array($status, $fileStatuses, true)) throw new RuntimeException('Invalid file status.');
            if ($serviceFee < 0) throw new RuntimeException('Service fee cannot be negative.');
            $d = DateTime::createFromFormat('Y-m-d', $openingDate);
            if (!$d || $d->format('Y-m-d') !== $openingDate) throw new RuntimeException('Please enter a valid file opening date.');

            $pdo->beginTransaction();

            $q = $pdo->prepare("SELECT e.id,e.enquiry_no,e.full_name,e.country_id,e.counselor_id,e.status
                FROM consultancy_enquiries e WHERE e.id=? LIMIT 1 FOR UPDATE");
            $q->execute([$enquiryId]);
            $enq = $q->fetch();
            if (!$enq) throw new RuntimeException('Selected enquiry was not found.');
            if (in_array((string)$enq['status'], ['Closed','Cancelled'], true)) {
                throw new RuntimeException('A file cannot be opened for a closed or cancelled enquiry.');
            }

            $q = $pdo->prepare("SELECT file_no FROM consultancy_files WHERE enquiry_id=? LIMIT 1 FOR UPDATE");
            $q->execute([$enquiryId]);
            if ($q->fetch()) throw new RuntimeException('This enquiry already has a consultancy file.');

            $year = (int)date('Y');
            $q = $pdo->prepare("INSERT IGNORE INTO consultancy_file_sequences(file_year,next_number) VALUES(?,1)");
            $q->execute([$year]);
            $q = $pdo->prepare("SELECT next_number FROM consultancy_file_sequences WHERE file_year=? FOR UPDATE");
            $q->execute([$year]);
            $n = (int)$q->fetchColumn();
            if ($n < 1) throw new RuntimeException('Unable to reserve a file number.');
            $q = $pdo->prepare("UPDATE consultancy_file_sequences SET next_number=? WHERE file_year=?");
            $q->execute([$n + 1,$year]);
            $fileNo = 'EDU-FL-'.$year.'-'.str_pad((string)$n,5,'0',STR_PAD_LEFT);

            $q = $pdo->prepare("INSERT INTO consultancy_files
                (file_no,enquiry_id,counselor_id,country_id,opening_date,passport_number,service_type,file_status,service_fee,notes,created_by,updated_by)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?)");
            $q->execute([
                $fileNo,$enquiryId,$enq['counselor_id'] !== null ? (int)$enq['counselor_id'] : null,
                $enq['country_id'] !== null ? (int)$enq['country_id'] : null,$openingDate,
                $passport !== '' ? $passport : null,$service,$status,$serviceFee,$notes !== '' ? $notes : null,
                $userId ?: null,$userId ?: null
            ]);
            $fileId = (int)$pdo->lastInsertId();

            $docInsert = $pdo->prepare("INSERT INTO consultancy_file_documents
                (file_id,document_type,document_status,created_by,updated_by) VALUES(?,?,?,?,?)");
            foreach (['Passport Copy','Student Photo','Academic Certificates','IELTS / English Result',
                      'Financial Documents','SOP','Recommendation Letter','Other Documents'] as $doc) {
                $docInsert->execute([$fileId,$doc,'Pending',$userId ?: null,$userId ?: null]);
            }

            $pdo->commit();
            $success = 'File opened successfully: '.$fileNo;
            $viewFileId = $fileId;
        }

        elseif ($action === 'update_file') {
            $id = (int)($_POST['file_id'] ?? 0);
            $passport = trim((string)($_POST['passport_number'] ?? ''));
            $service = trim((string)($_POST['service_type'] ?? ''));
            $status = trim((string)($_POST['file_status'] ?? ''));
            $serviceFee = (float)($_POST['service_fee'] ?? 0);
            $notes = trim((string)($_POST['notes'] ?? ''));
            if ($id <= 0) throw new RuntimeException('Invalid file selected.');
            if ($serviceFee < 0) throw new RuntimeException('Service fee cannot be negative.');
            if (!in_array($service,$serviceTypes,true) || !in_array($status,$fileStatuses,true)) {
                throw new RuntimeException('Invalid file information.');
            }
            $paid = 0.0;
            try {
                $q = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM consultancy_payments WHERE file_id=? AND status='Valid'");
                $q->execute([$id]);
                $paid = (float)$q->fetchColumn();
            } catch (Throwable $ignored) {
                // Consultancy Payments may not be installed yet.
            }
            if ($serviceFee + 0.0001 < $paid) {
                throw new RuntimeException('Service fee cannot be lower than the valid amount already collected.');
            }

            $q = $pdo->prepare("UPDATE consultancy_files SET passport_number=?,service_type=?,file_status=?,service_fee=?,notes=?,updated_by=? WHERE id=?");
            $q->execute([$passport !== '' ? $passport : null,$service,$status,$serviceFee,$notes !== '' ? $notes : null,$userId ?: null,$id]);
            $check = $pdo->prepare("SELECT id FROM consultancy_files WHERE id=?");
            $check->execute([$id]);
            if (!$check->fetch()) throw new RuntimeException('File was not found.');
            $success = 'File information updated successfully.';
            $viewFileId = $id;
        }

        elseif ($action === 'update_document') {
            $id = (int)($_POST['document_id'] ?? 0);
            $status = trim((string)($_POST['document_status'] ?? ''));
            $note = trim((string)($_POST['document_note'] ?? ''));
            if ($id <= 0 || !in_array($status,$docStatuses,true)) throw new RuntimeException('Invalid document update.');
            $q = $pdo->prepare("UPDATE consultancy_file_documents SET document_status=?,document_note=?,updated_by=? WHERE id=?");
            $q->execute([$status,$note !== '' ? $note : null,$userId ?: null,$id]);
            $q = $pdo->prepare("SELECT file_id FROM consultancy_file_documents WHERE id=?");
            $q->execute([$id]);
            $viewFileId = (int)$q->fetchColumn();
            if ($viewFileId <= 0) throw new RuntimeException('Document item was not found.');
            $success = 'Document status updated successfully.';
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $e instanceof RuntimeException ? $e->getMessage() : 'Unable to complete the requested file action.';
    }
}

$enquiries = $files = $documents = [];
$viewFile = null;
$stats = ['total'=>0,'open'=>0,'processing'=>0,'completed'=>0];

if ($error === '') {
    // Only enquiries without an existing consultancy file are eligible.
    $enquiryStmt = $pdo->query("SELECT
            e.id,e.enquiry_no,e.full_name,e.mobile,e.status,
            co.country_name,c.counselor_name
        FROM consultancy_enquiries e
        LEFT JOIN consultancy_countries co ON co.id=e.country_id
        LEFT JOIN consultancy_counselors c ON c.id=e.counselor_id
        WHERE LOWER(TRIM(COALESCE(e.status,''))) NOT IN ('closed','cancelled')
          AND NOT EXISTS (
              SELECT 1 FROM consultancy_files f WHERE f.enquiry_id=e.id
          )
        ORDER BY e.created_at DESC");
    $enquiries = $enquiryStmt->fetchAll();

    $s = $pdo->query("SELECT COUNT(*) total,
        COALESCE(SUM(file_status='Open'),0) open_count,
        COALESCE(SUM(file_status='Processing'),0) processing_count,
        COALESCE(SUM(file_status='Completed'),0) completed_count
        FROM consultancy_files")->fetch() ?: [];
    $stats = ['total'=>(int)($s['total']??0),'open'=>(int)($s['open_count']??0),
        'processing'=>(int)($s['processing_count']??0),'completed'=>(int)($s['completed_count']??0)];

    $files = $pdo->query("SELECT f.*,e.enquiry_no,e.full_name,e.mobile,co.country_name,c.counselor_name
        FROM consultancy_files f
        INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
        LEFT JOIN consultancy_countries co ON co.id=f.country_id
        LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id
        ORDER BY f.opening_date DESC,f.id DESC LIMIT 300")->fetchAll();

    if ($viewFileId > 0) {
        $q = $pdo->prepare("SELECT f.*,e.enquiry_no,e.full_name,e.mobile,e.whatsapp,e.email,e.education_level,
            e.intake,e.program,e.ielts_status,e.ielts_score,co.country_name,c.counselor_name
            FROM consultancy_files f INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
            LEFT JOIN consultancy_countries co ON co.id=f.country_id
            LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id WHERE f.id=? LIMIT 1");
        $q->execute([$viewFileId]);
        $viewFile = $q->fetch();
        if (!$viewFile) { $error = 'Selected consultancy file was not found.'; $viewFileId = 0; }
        else {
            $q = $pdo->prepare("SELECT * FROM consultancy_file_documents WHERE file_id=? ORDER BY id");
            $q->execute([$viewFileId]); $documents = $q->fetchAll();
        }
    }
}

require_once __DIR__ . '/_header.php';
?>
<style>
.fo-wrap{max-width:1220px;margin:28px auto;padding:0 18px}.fo-head{margin-bottom:20px}.fo-head h1{margin:0 0 5px;font-size:28px}.fo-head p{margin:0;color:#747a83}
.fo-alert{margin-bottom:18px;padding:12px 14px;border-radius:10px;font-size:13px}.fo-error{background:#fff1f2;color:#a71928;border:1px solid #f3c6cb}.fo-success{background:#eefaf2;color:#176b39;border:1px solid #c8e8d3}
.fo-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}.fo-stat{background:#fff;border:1px solid #e5e8ec;border-radius:14px;padding:16px}.fo-stat strong{display:block;font-size:24px}.fo-stat span{font-size:11px;color:#777f88}
.fo-grid{display:grid;grid-template-columns:390px 1fr;gap:18px}.fo-card{background:#fff;border:1px solid #e5e8ec;border-radius:16px;box-shadow:0 7px 24px rgba(25,30,38,.05);overflow:hidden}.fo-card-head{padding:18px 20px;border-bottom:1px solid #eceef1}.fo-card-head h2{margin:0;font-size:17px}.fo-body{padding:20px}
.fo-field{margin-bottom:14px}.fo-field label{display:block;margin-bottom:6px;font-size:12px;font-weight:750;color:#444a52}.fo-field input,.fo-field select,.fo-field textarea{width:100%;box-sizing:border-box;border:1px solid #dfe2e6;border-radius:10px;padding:11px 12px;font:inherit;background:#fff}.fo-field textarea{min-height:90px;resize:vertical}
.fo-btn{border:0;border-radius:10px;background:#c91f2e;color:#fff;padding:11px 16px;font-weight:800;cursor:pointer}.fo-link{display:inline-block;padding:7px 9px;border:1px solid #dfe2e6;border-radius:8px;color:#333;text-decoration:none;font-size:10px;font-weight:750;background:#fff}
.fo-actions{display:flex;justify-content:flex-end;gap:8px}.fo-table-wrap{overflow:auto}.fo-table{width:100%;border-collapse:collapse;min-width:850px}.fo-table th,.fo-table td{padding:12px 10px;border-bottom:1px solid #eef0f2;text-align:left;vertical-align:top;font-size:12px}.fo-table th{font-size:10px;color:#747b84;text-transform:uppercase}.fo-name{font-weight:800}.fo-sub{font-size:10px;color:#818892;margin-top:3px}.fo-badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:800}.fo-open{background:#eef4ff;color:#315b9b}.fo-processing{background:#fff5dd;color:#8b6100}.fo-completed{background:#eaf8ef;color:#176b39}.fo-cancelled{background:#f2f3f5;color:#69707a}.fo-empty{text-align:center;padding:35px;color:#858b93}
.fo-detail{margin-top:18px}.fo-detail-grid{display:grid;grid-template-columns:1.1fr .9fr;gap:18px}.fo-info-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:12px}.fo-info{padding:12px;background:#f8f9fa;border-radius:10px}.fo-info span{display:block;font-size:10px;color:#7b828b;margin-bottom:4px}.fo-info strong{font-size:13px}.fo-doc-table{width:100%;border-collapse:collapse}.fo-doc-table th,.fo-doc-table td{padding:10px;border-bottom:1px solid #eef0f2;text-align:left;font-size:12px;vertical-align:top}.fo-doc-table th{font-size:10px;color:#777;text-transform:uppercase}.fo-doc-table select,.fo-doc-table textarea{border:1px solid #dfe2e6;border-radius:8px;padding:8px;font:inherit;width:100%;box-sizing:border-box}.fo-doc-table textarea{min-height:52px}
@media(max-width:1050px){.fo-grid,.fo-detail-grid{grid-template-columns:1fr}}@media(max-width:700px){.fo-wrap{padding:0 12px}.fo-stats{grid-template-columns:1fr 1fr}.fo-info-grid{grid-template-columns:1fr}}
</style>

<div class="fo-wrap">
<div class="fo-head"><h1>Consultancy File Opening</h1><p>Open and manage consultancy files linked directly to student enquiries.</p></div>
<?php if($error!==''): ?><div class="fo-alert fo-error"><?=e($error)?></div><?php endif; ?>
<?php if($success!==''): ?><div class="fo-alert fo-success"><?=e($success)?></div><?php endif; ?>

<?php if($error==='' || $viewFile): ?>
<div class="fo-stats">
<div class="fo-stat"><strong><?=number_format($stats['total'])?></strong><span>Total Files</span></div>
<div class="fo-stat"><strong><?=number_format($stats['open'])?></strong><span>Open</span></div>
<div class="fo-stat"><strong><?=number_format($stats['processing'])?></strong><span>Processing</span></div>
<div class="fo-stat"><strong><?=number_format($stats['completed'])?></strong><span>Completed</span></div>
</div>

<div class="fo-grid">
<section class="fo-card"><div class="fo-card-head"><h2>Open New File</h2></div><div class="fo-body">
<?php if(!$enquiries): ?><div class="fo-empty">No eligible enquiry is available for a new file.</div>
<?php else: ?><form method="post"><?=csrf_input()?><input type="hidden" name="action" value="create_file">
<div class="fo-field"><label>Enquiry *</label><select name="enquiry_id" required><option value="">Select enquiry</option>
<?php foreach($enquiries as $enq): ?><option value="<?=e((string)$enq['id'])?>"><?=e($enq['enquiry_no'].' — '.$enq['full_name'].' — '.($enq['country_name']??''))?></option><?php endforeach; ?></select></div>
<div class="fo-field"><label>File Opening Date *</label><input type="date" name="opening_date" value="<?=e(date('Y-m-d'))?>" required></div>
<div class="fo-field"><label>Passport Number</label><input type="text" name="passport_number" maxlength="80"></div>
<div class="fo-field"><label>Service Fee (৳)</label><input type="number" name="service_fee" min="0" step="0.01" value="0"></div>
<div class="fo-field"><label>Service Type *</label><select name="service_type"><?php foreach($serviceTypes as $v): ?><option><?=e($v)?></option><?php endforeach; ?></select></div>
<div class="fo-field"><label>File Status *</label><select name="file_status"><?php foreach($fileStatuses as $v): ?><option value="<?=e($v)?>" <?=$v==='Open'?'selected':''?>><?=e($v)?></option><?php endforeach; ?></select></div>
<div class="fo-field"><label>Notes</label><textarea name="notes"></textarea></div>
<div class="fo-actions"><button class="fo-btn">Open Consultancy File</button></div></form><?php endif; ?>
</div></section>

<section class="fo-card"><div class="fo-card-head"><h2>Consultancy Files</h2></div><div class="fo-table-wrap">
<?php if(!$files): ?><div class="fo-empty">No consultancy files opened yet.</div><?php else: ?><table class="fo-table"><thead><tr><th>File</th><th>Student</th><th>Country</th><th>Counselor</th><th>Service Fee</th><th>Date</th><th>Status</th><th>Action</th></tr></thead><tbody>
<?php foreach($files as $f): $cls=match((string)$f['file_status']){'Processing'=>'fo-processing','Completed'=>'fo-completed','Cancelled'=>'fo-cancelled',default=>'fo-open'}; ?>
<tr><td><div class="fo-name"><?=e($f['file_no'])?></div><div class="fo-sub"><?=e($f['enquiry_no'])?></div></td>
<td><div class="fo-name"><?=e($f['full_name'])?></div><div class="fo-sub"><?=e($f['mobile'])?></div></td>
<td><?=e($f['country_name']??'-')?></td><td><?=e($f['counselor_name']??'Unassigned')?></td>
<td>৳<?=number_format((float)($f['service_fee'] ?? 0),2)?></td>
<td><?=e(date('d M Y',strtotime($f['opening_date'])))?></td><td><span class="fo-badge <?=$cls?>"><?=e($f['file_status'])?></span></td>
<td><a class="fo-link" href="consultancy-file-opening.php?view=<?=e((string)$f['id'])?>">Open File</a></td></tr>
<?php endforeach; ?></tbody></table><?php endif; ?>
</div></section></div>

<?php if($viewFile): ?>
<section class="fo-card fo-detail"><div class="fo-card-head"><h2><?=e($viewFile['file_no'])?> — File Details</h2></div><div class="fo-body">
<div class="fo-detail-grid"><div><h3>Student & Enquiry</h3><div class="fo-info-grid">
<div class="fo-info"><span>Student</span><strong><?=e($viewFile['full_name'])?></strong></div>
<div class="fo-info"><span>Mobile</span><strong><?=e($viewFile['mobile'])?></strong></div>
<div class="fo-info"><span>Country</span><strong><?=e($viewFile['country_name']??'-')?></strong></div>
<div class="fo-info"><span>Counselor</span><strong><?=e($viewFile['counselor_name']??'Unassigned')?></strong></div>
<div class="fo-info"><span>Intake</span><strong><?=e($viewFile['intake']??'-')?></strong></div>
<div class="fo-info"><span>Program</span><strong><?=e($viewFile['program']??'-')?></strong></div>
<div class="fo-info"><span>Education</span><strong><?=e($viewFile['education_level']??'-')?></strong></div>
<div class="fo-info"><span>IELTS</span><strong><?=e($viewFile['ielts_status']??'-')?><?=!empty($viewFile['ielts_score'])?' — '.e($viewFile['ielts_score']):''?></strong></div>
<div class="fo-info"><span>Passport</span><strong><?=e($viewFile['passport_number']??'-')?></strong></div>
</div></div>
<div><h3>Update File</h3><form method="post"><?=csrf_input()?><input type="hidden" name="action" value="update_file"><input type="hidden" name="file_id" value="<?=e($viewFile['id'])?>">
<div class="fo-field"><label>Passport Number</label><input name="passport_number" value="<?=e($viewFile['passport_number']??'')?>"></div>
<div class="fo-field"><label>Service Fee (৳)</label><input type="number" name="service_fee" min="0" step="0.01" value="<?=e(number_format((float)($viewFile['service_fee'] ?? 0),2,'.',''))?>"></div>
<div class="fo-field"><label>Service Type</label><select name="service_type"><?php foreach($serviceTypes as $v): ?><option value="<?=e($v)?>" <?=$viewFile['service_type']===$v?'selected':''?>><?=e($v)?></option><?php endforeach; ?></select></div>
<div class="fo-field"><label>File Status</label><select name="file_status"><?php foreach($fileStatuses as $v): ?><option value="<?=e($v)?>" <?=$viewFile['file_status']===$v?'selected':''?>><?=e($v)?></option><?php endforeach; ?></select></div>
<div class="fo-field"><label>Notes</label><textarea name="notes"><?=e($viewFile['notes']??'')?></textarea></div>
<div class="fo-actions"><button class="fo-btn">Update File</button></div></form></div></div>

<h3>Document Tracking</h3><div class="fo-table-wrap"><table class="fo-doc-table"><thead><tr><th>Document</th><th>Status</th><th>Note</th><th></th></tr></thead><tbody>
<?php foreach($documents as $doc): ?><tr><form method="post"><?=csrf_input()?><input type="hidden" name="action" value="update_document"><input type="hidden" name="document_id" value="<?=e($doc['id'])?>">
<td><strong><?=e($doc['document_type'])?></strong></td><td><select name="document_status"><?php foreach($docStatuses as $v): ?><option value="<?=e($v)?>" <?=$doc['document_status']===$v?'selected':''?>><?=e($v)?></option><?php endforeach; ?></select></td>
<td><textarea name="document_note"><?=e($doc['document_note']??'')?></textarea></td><td><button class="fo-link">Save</button></td></form></tr><?php endforeach; ?>
</tbody></table></div>
<p style="font-size:10px;color:#858b93">V1 tracks document status and notes. Actual document upload/preview can be added later without changing the IELTS workflow.</p>
</div></section>
<?php endif; ?>
<?php endif; ?>
</div>

</main></div></body></html>

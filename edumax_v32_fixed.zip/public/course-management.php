<?php
require_once __DIR__ . '/../config/app.php';
require_access('admissions');
require_valid_csrf();

$pdo = $pdo ?? db();
$error = '';
$success = '';

/*
 * Course & Fee Management
 * - Regular courses and Mock Test packages can both be created.
 * - Multiple Mock Test packages are allowed.
 * - Package fee/count are stored in courses.
 * - Existing course records are preserved.
 */
try {
    /* Self-heal package fields for databases created before package support. */
    $columns = [];
    $colStmt = $pdo->query("SHOW COLUMNS FROM courses");
    foreach ($colStmt->fetchAll(PDO::FETCH_ASSOC) as $col) {
        $columns[(string)$col['Field']] = true;
    }

    if (!isset($columns['regular_fee'])) {
        $pdo->exec("ALTER TABLE courses ADD COLUMN regular_fee DECIMAL(12,2) NOT NULL DEFAULT 0 AFTER status");
    }
    if (!isset($columns['default_discount_percent'])) {
        $pdo->exec("ALTER TABLE courses ADD COLUMN default_discount_percent DECIMAL(5,2) NOT NULL DEFAULT 0 AFTER regular_fee");
    }
    if (!isset($columns['course_type'])) {
        $pdo->exec("ALTER TABLE courses ADD COLUMN course_type VARCHAR(30) NOT NULL DEFAULT 'Regular' AFTER name");
    }
    if (!isset($columns['mock_test_count'])) {
        $pdo->exec("ALTER TABLE courses ADD COLUMN mock_test_count INT NOT NULL DEFAULT 0 AFTER default_discount_percent");
    }
    if (!isset($columns['mock_test_modules'])) {
        $pdo->exec("ALTER TABLE courses ADD COLUMN mock_test_modules VARCHAR(255) NULL AFTER mock_test_count");
    }
    if (!isset($columns['validity_days'])) {
        $pdo->exec("ALTER TABLE courses ADD COLUMN validity_days INT NULL AFTER mock_test_modules");
    }
} catch (Throwable $e) {
    $error = 'Course database setup failed: ' . $e->getMessage();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    try {
        $action = $_POST['action'] ?? '';

        if ($action === 'save') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['name'] ?? ''));
            $status = (string)($_POST['status'] ?? 'Active');
            $courseType = (string)($_POST['course_type'] ?? 'Regular');
            $fee = max(0, (float)($_POST['regular_fee'] ?? 0));
            $discount = max(0, min(100, (float)($_POST['default_discount_percent'] ?? 0)));
            $mockCount = max(0, (int)($_POST['mock_test_count'] ?? 0));
            $modules = trim((string)($_POST['mock_test_modules'] ?? ''));
            $validity = max(0, (int)($_POST['validity_days'] ?? 0));

            if ($name === '') {
                throw new RuntimeException('Course / Package name is required.');
            }
            if (!in_array($status, ['Active', 'Inactive'], true)) {
                $status = 'Active';
            }
            if (!in_array($courseType, ['Regular', 'Mock Test'], true)) {
                $courseType = 'Regular';
            }

            if ($courseType === 'Mock Test' && $mockCount <= 0) {
                throw new RuntimeException('Mock Test package-এ Mock Test Count দিতে হবে।');
            }

            if ($courseType !== 'Mock Test') {
                $mockCount = 0;
                $modules = '';
                $validity = 0;
            }

            /*
             * IMPORTANT:
             * Different package names are allowed.
             * Example:
             *   Mock Test - 1 Mock
             *   Mock Test - 2 Mocks
             *   Mock Test - 3 Mocks
             *
             * Only the exact same name is rejected by the DB's unique constraint.
             */
            if ($id > 0) {
                $q = $pdo->prepare("
                    UPDATE courses
                    SET name=?,
                        course_type=?,
                        status=?,
                        regular_fee=?,
                        default_discount_percent=?,
                        mock_test_count=?,
                        mock_test_modules=?,
                        validity_days=?
                    WHERE id=?
                ");
                $q->execute([
                    $name,
                    $courseType,
                    $status,
                    $fee,
                    $discount,
                    $mockCount,
                    $modules !== '' ? $modules : null,
                    $validity > 0 ? $validity : null,
                    $id
                ]);
                $success = 'Course / Package updated successfully.';
            } else {
                $q = $pdo->prepare("
                    INSERT INTO courses
                    (name, course_type, status, regular_fee, default_discount_percent,
                     mock_test_count, mock_test_modules, validity_days)
                    VALUES (?,?,?,?,?,?,?,?)
                ");
                $q->execute([
                    $name,
                    $courseType,
                    $status,
                    $fee,
                    $discount,
                    $mockCount,
                    $modules !== '' ? $modules : null,
                    $validity > 0 ? $validity : null
                ]);
                $success = 'Course / Package created successfully.';
            }
        } elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);

            if ($id <= 0) {
                throw new RuntimeException('Invalid course / package.');
            }

            /* Never delete a course/package already used by an admission. */
            $check = $pdo->prepare("SELECT COUNT(*) FROM admissions WHERE course_id=?");
            $check->execute([$id]);

            if ((int)$check->fetchColumn() > 0) {
                throw new RuntimeException(
                    'This course / package is already used in admission records. ' .
                    'Please set it Inactive instead of deleting it.'
                );
            }

            $q = $pdo->prepare("DELETE FROM courses WHERE id=?");
            $q->execute([$id]);

            $success = 'Course / Package deleted successfully.';
        }
    } catch (PDOException $e) {
        if ($e->getCode() === '23000') {
            $error = 'এই একই নামের Course / Package আগে থেকেই আছে। অন্য নাম দিন।';
        } else {
            $error = 'Database error while saving course / package.';
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

/* Edit record */
$edit = null;
if (isset($_GET['edit'])) {
    $q = $pdo->prepare("SELECT * FROM courses WHERE id=? LIMIT 1");
    $q->execute([(int)$_GET['edit']]);
    $edit = $q->fetch(PDO::FETCH_ASSOC);
}

/* All courses / packages */
$courses = $pdo->query("
    SELECT
        id,
        name,
        course_type,
        status,
        regular_fee,
        default_discount_percent,
        mock_test_count,
        mock_test_modules,
        validity_days,
        created_at
    FROM courses
    ORDER BY
        CASE WHEN course_type='Mock Test' THEN 0 ELSE 1 END,
        status DESC,
        name
")->fetchAll(PDO::FETCH_ASSOC);

require __DIR__ . '/_header.php';
?>

<div class="page-header">
    <div>
        <h1>Course & Fee Management</h1>
        <p>Create regular courses and multiple Mock Test packages with separate fees.</p>
    </div>
</div>

<?php if ($error): ?>
    <div class="alert alert-danger"><?= e($error) ?></div>
<?php endif; ?>

<?php if ($success): ?>
    <div class="alert alert-success"><?= e($success) ?></div>
<?php endif; ?>

<div class="card" style="margin-bottom:20px">
    <h2><?= $edit ? 'Edit Course / Package' : 'Add Course / Package' ?></h2>

    <form method="post" class="form-grid">
        <?= csrf_input() ?>

        <input type="hidden" name="action" value="save">
        <input type="hidden" name="id" value="<?= e($edit['id'] ?? 0) ?>">

        <div>
            <label>Course / Package Name</label>
            <input
                type="text"
                name="name"
                value="<?= e($edit['name'] ?? '') ?>"
                placeholder="Example: Mock Test - 1 Mock"
                required
            >
        </div>

        <div>
            <label>Type</label>
            <select name="course_type" id="course_type">
                <option
                    value="Regular"
                    <?= (($edit['course_type'] ?? 'Regular') === 'Regular') ? 'selected' : '' ?>
                >Regular Course</option>

                <option
                    value="Mock Test"
                    <?= (($edit['course_type'] ?? '') === 'Mock Test') ? 'selected' : '' ?>
                >Mock Test Package</option>
            </select>
        </div>

        <div>
            <label>Status</label>
            <select name="status">
                <option
                    value="Active"
                    <?= (($edit['status'] ?? 'Active') === 'Active') ? 'selected' : '' ?>
                >Active</option>

                <option
                    value="Inactive"
                    <?= (($edit['status'] ?? '') === 'Inactive') ? 'selected' : '' ?>
                >Inactive</option>
            </select>
        </div>

        <div>
            <label>Regular Fee (৳)</label>
            <input
                type="number"
                name="regular_fee"
                min="0"
                step="0.01"
                value="<?= e($edit['regular_fee'] ?? 0) ?>"
                required
            >
        </div>

        <div>
            <label>Default Discount (%)</label>
            <input
                type="number"
                name="default_discount_percent"
                min="0"
                max="100"
                step="0.01"
                value="<?= e($edit['default_discount_percent'] ?? 0) ?>"
                required
            >
        </div>

        <div id="mockPackageFields" style="display:none;grid-column:1/-1">
            <div style="
                padding:15px;
                border:1px solid #f0d5d8;
                border-radius:12px;
                background:#fff8f9;
            ">
                <strong style="color:#c91f2e">Mock Test Package Settings</strong>

                <div
                    class="form-grid"
                    style="margin-top:12px"
                >
                    <div>
                        <label>Mock Test Count</label>
                        <input
                            type="number"
                            name="mock_test_count"
                            id="mock_test_count"
                            min="1"
                            step="1"
                            value="<?= e($edit['mock_test_count'] ?? 0) ?>"
                            placeholder="1 / 2 / 3"
                        >
                    </div>

                    <div>
                        <label>Modules</label>
                        <input
                            type="text"
                            name="mock_test_modules"
                            value="<?= e($edit['mock_test_modules'] ?? '') ?>"
                            placeholder="Reading, Writing, Listening, Speaking"
                        >
                    </div>

                    <div>
                        <label>Validity (Days)</label>
                        <input
                            type="number"
                            name="validity_days"
                            min="0"
                            step="1"
                            value="<?= e($edit['validity_days'] ?? 0) ?>"
                            placeholder="Optional"
                        >
                    </div>
                </div>

                <small style="display:block;margin-top:8px;color:#737982">
                    Example: 1 Mock = ৳500, 2 Mocks = ৳900, 3 Mocks = ৳1,200.
                </small>
            </div>
        </div>

        <div style="grid-column:1/-1">
            <button class="btn btn-primary" type="submit">
                <?= $edit ? 'Update Course / Package' : 'Save Course / Package' ?>
            </button>

            <?php if ($edit): ?>
                <a class="btn" href="course-management.php">Cancel</a>
            <?php endif; ?>
        </div>
    </form>
</div>

<div class="card">
    <h2>Courses & Packages</h2>

    <div class="table-wrap">
        <table>
            <thead>
                <tr>
                    <th>Course / Package</th>
                    <th>Type</th>
                    <th>Status</th>
                    <th>Fee</th>
                    <th>Discount</th>
                    <th>Mock Count</th>
                    <th>After Discount</th>
                    <th>Action</th>
                </tr>
            </thead>

            <tbody>
            <?php if (!$courses): ?>
                <tr>
                    <td colspan="8">No courses / packages found.</td>
                </tr>
            <?php endif; ?>

            <?php foreach ($courses as $c): ?>
                <?php
                    $fee = (float)$c['regular_fee'];
                    $discount = (float)$c['default_discount_percent'];
                    $after = $fee * ((100 - $discount) / 100);
                    $isMock = (($c['course_type'] ?? '') === 'Mock Test');
                ?>

                <tr>
                    <td>
                        <strong><?= e($c['name']) ?></strong>

                        <?php if ($isMock && !empty($c['mock_test_modules'])): ?>
                            <br>
                            <small style="color:#737982">
                                <?= e($c['mock_test_modules']) ?>
                            </small>
                        <?php endif; ?>
                    </td>

                    <td>
                        <?= $isMock ? 'Mock Test Package' : 'Regular Course' ?>
                    </td>

                    <td><?= e($c['status']) ?></td>

                    <td>
                        ৳ <?= number_format($fee, 2) ?>
                    </td>

                    <td>
                        <?= number_format($discount, 2) ?>%
                    </td>

                    <td>
                        <?= $isMock ? (int)$c['mock_test_count'] : '—' ?>
                    </td>

                    <td>
                        ৳ <?= number_format($after, 2) ?>
                    </td>

                    <td>
                        <div style="display:flex;gap:6px;flex-wrap:wrap">
                            <a
                                class="btn btn-sm"
                                href="course-management.php?edit=<?= (int)$c['id'] ?>"
                            >Edit</a>

                            <form
                                method="post"
                                onsubmit="return confirm('Delete this course / package? This is allowed only if it has never been used in an admission.');"
                                style="display:inline"
                            >
                                <?= csrf_input() ?>
                                <input type="hidden" name="action" value="delete">
                                <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">

                                <button
                                    type="submit"
                                    class="btn btn-sm"
                                    style="color:#c91f2e"
                                >Delete</button>
                            </form>
                        </div>
                    </td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
(function () {
    const typeEl = document.getElementById('course_type');
    const packageFields = document.getElementById('mockPackageFields');
    const countEl = document.getElementById('mock_test_count');

    function togglePackageFields() {
        const isMock = typeEl && typeEl.value === 'Mock Test';

        if (packageFields) {
            packageFields.style.display = isMock ? '' : 'none';
        }

        if (countEl) {
            countEl.required = isMock;
            if (!isMock) countEl.value = '0';
        }
    }

    if (typeEl) {
        typeEl.addEventListener('change', togglePackageFields);
        togglePackageFields();
    }
})();
</script>

<?php require __DIR__ . '/_footer.php'; ?>

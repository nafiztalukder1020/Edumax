<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_access('consultancy_countries');

$_SESSION['workspace'] = 'consultancy';

$success = '';
$error = '';
$editingCountry = null;

// Keep the page self-contained and safe for deployments where the migration
// has not been run yet: show a clear message instead of a generic SQL error.
try {
    $pdo->query('SELECT 1 FROM consultancy_countries LIMIT 1');
} catch (Throwable $e) {
    $error = 'Country Management database table is not installed yet. Please import database/consultancy_countries_v1.sql first.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    require_valid_csrf();
    $action = trim((string)($_POST['action'] ?? ''));

    try {
        if ($action === 'create') {
            $name = trim((string)($_POST['country_name'] ?? ''));
            $status = (($_POST['status'] ?? 'Active') === 'Inactive') ? 'Inactive' : 'Active';

            if ($name === '') {
                throw new RuntimeException('Country name is required.');
            }
            if (mb_strlen($name) > 120) {
                throw new RuntimeException('Country name cannot exceed 120 characters.');
            }

            $stmt = $pdo->prepare('INSERT INTO consultancy_countries (country_name, status, created_by, updated_by) VALUES (?,?,?,?)');
            $userId = (int)($_SESSION['user_id'] ?? 0);
            $stmt->execute([$name, $status, $userId ?: null, $userId ?: null]);
            $success = 'Country added successfully.';
        }

        elseif ($action === 'update') {
            $id = (int)($_POST['id'] ?? 0);
            $name = trim((string)($_POST['country_name'] ?? ''));
            $status = (($_POST['status'] ?? 'Active') === 'Inactive') ? 'Inactive' : 'Active';

            if ($id < 1) {
                throw new RuntimeException('Invalid country selected.');
            }
            if ($name === '') {
                throw new RuntimeException('Country name is required.');
            }
            if (mb_strlen($name) > 120) {
                throw new RuntimeException('Country name cannot exceed 120 characters.');
            }

            $stmt = $pdo->prepare('UPDATE consultancy_countries SET country_name=?, status=?, updated_by=? WHERE id=? LIMIT 1');
            $stmt->execute([$name, $status, (int)$_SESSION['user_id'], $id]);
            if ($stmt->rowCount() === 0) {
                $check = $pdo->prepare('SELECT id FROM consultancy_countries WHERE id=? LIMIT 1');
                $check->execute([$id]);
                if (!$check->fetch()) {
                    throw new RuntimeException('Country not found.');
                }
            }
            $success = 'Country updated successfully.';
        }

        elseif ($action === 'toggle') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id < 1) {
                throw new RuntimeException('Invalid country selected.');
            }

            $stmt = $pdo->prepare("UPDATE consultancy_countries SET status = CASE WHEN status='Active' THEN 'Inactive' ELSE 'Active' END, updated_by=? WHERE id=? LIMIT 1");
            $stmt->execute([(int)$_SESSION['user_id'], $id]);
            if ($stmt->rowCount() < 1) {
                throw new RuntimeException('Country not found.');
            }
            $success = 'Country status updated successfully.';
        }

        elseif ($action === 'delete') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id < 1) {
                throw new RuntimeException('Invalid country selected.');
            }

            $stmt = $pdo->prepare('DELETE FROM consultancy_countries WHERE id=? LIMIT 1');
            $stmt->execute([$id]);
            if ($stmt->rowCount() < 1) {
                throw new RuntimeException('Country not found.');
            }
            $success = 'Country deleted successfully.';
        }
    } catch (PDOException $e) {
        if ((int)$e->errorInfo[1] === 1062) {
            $error = 'This country already exists.';
        } elseif ((int)$e->errorInfo[1] === 1451) {
            $error = 'This country is already being used by another Consultancy record, so it cannot be deleted. Make it Inactive instead.';
        } else {
            $error = 'The requested country action could not be completed.';
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

if (isset($_GET['edit'])) {
    $id = (int)$_GET['edit'];
    if ($id > 0 && $error === '') {
        $stmt = $pdo->prepare('SELECT id, country_name, status FROM consultancy_countries WHERE id=? LIMIT 1');
        $stmt->execute([$id]);
        $editingCountry = $stmt->fetch() ?: null;
        if (!$editingCountry) {
            $error = 'Country not found.';
        }
    }
}

$countries = [];
if ($error === '' || str_contains($error, 'Country Management database table')) {
    try {
        $countries = $pdo->query("SELECT c.id, c.country_name, c.status, c.created_at, c.updated_at, COALESCE(cc.counselor_count, 0) AS counselor_count
            FROM consultancy_countries c
            LEFT JOIN (
                SELECT country_id, COUNT(*) AS counselor_count
                FROM consultancy_country_counselors
                WHERE status='Active'
                GROUP BY country_id
            ) cc ON cc.country_id = c.id
            ORDER BY c.status DESC, c.country_name ASC")->fetchAll();
    } catch (Throwable $e) {
        $countries = [];
    }
}

require '_header.php';
?>

<style>
.country-page .cm-head{
    display:flex;align-items:flex-end;justify-content:space-between;gap:18px;margin-bottom:22px;
}
.country-page .cm-head h1{margin:0 0 6px;}
.country-page .cm-head p{margin:0;color:#737982;}
.country-page .cm-grid{display:grid;grid-template-columns:minmax(280px,.72fr) minmax(0,1.5fr);gap:18px;align-items:start;}
.country-page .cm-card{background:#fff;border:1px solid #e7e8ec;border-radius:16px;box-shadow:0 5px 18px rgba(32,36,43,.045);overflow:hidden;}
.country-page .cm-card-head{padding:18px 20px;border-bottom:1px solid #eef0f2;}
.country-page .cm-card-head h2{margin:0;font-size:16px;color:#20242b;}
.country-page .cm-card-head p{margin:5px 0 0;color:#858b93;font-size:11px;}
.country-page .cm-card-body{padding:20px;}
.country-page .cm-field{margin-bottom:15px;}
.country-page .cm-field label{display:block;margin-bottom:7px;color:#4c525a;font-size:12px;font-weight:750;}
.country-page .cm-field input,.country-page .cm-field select{width:100%;min-height:44px;padding:10px 12px;border:1px solid #dfe2e7;border-radius:9px;background:#fff;color:#20242b;box-sizing:border-box;outline:none;}
.country-page .cm-field input:focus,.country-page .cm-field select:focus{border-color:#c91f2e;box-shadow:0 0 0 3px rgba(201,31,46,.08);}
.country-page .cm-actions{display:flex;gap:9px;flex-wrap:wrap;}
.country-page .cm-btn{display:inline-flex;align-items:center;justify-content:center;min-height:42px;padding:9px 15px;border:0;border-radius:9px;background:#c91f2e;color:#fff;text-decoration:none;font-size:12px;font-weight:800;cursor:pointer;}
.country-page .cm-btn.secondary{background:#f0f1f3;color:#4f555d;}
.country-page .cm-btn.danger{background:#fff0f1;color:#b21c2b;border:1px solid #f1cbd0;}
.country-page .cm-alert{margin-bottom:16px;padding:11px 13px;border-radius:10px;font-size:12px;line-height:1.45;}
.country-page .cm-alert.success{background:#edf8f0;color:#24683a;border:1px solid #ccebd4;}
.country-page .cm-alert.error{background:#fff0f1;color:#9f1d2a;border:1px solid #f0cbd0;}
.country-page .cm-table-wrap{overflow:auto;}
.country-page table{width:100%;border-collapse:collapse;min-width:620px;}
.country-page th{padding:12px 14px;text-align:left;background:#fafbfc;color:#717781;font-size:10px;text-transform:uppercase;letter-spacing:.06em;}
.country-page td{padding:13px 14px;border-top:1px solid #eef0f2;color:#30353c;font-size:12px;vertical-align:middle;}
.country-page .cm-status{display:inline-flex;align-items:center;gap:6px;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:800;}
.country-page .cm-status.active{background:#edf8f0;color:#28703e;}
.country-page .cm-status.inactive{background:#f1f2f4;color:#6e747c;}
.country-page .cm-status i{width:6px;height:6px;border-radius:50%;background:currentColor;}
.country-page .cm-row-actions{display:flex;gap:6px;flex-wrap:wrap;}
.country-page .cm-row-actions form{margin:0;}
.country-page .cm-empty{padding:42px 20px;text-align:center;color:#858b93;font-size:12px;}
.country-page .cm-count{font-size:11px;color:#858b93;font-weight:700;}
@media(max-width:900px){.country-page .cm-grid{grid-template-columns:1fr;}}
@media(max-width:640px){.country-page .cm-head{align-items:flex-start;flex-direction:column}.country-page .cm-card-body{padding:16px}.country-page .cm-card-head{padding:16px}}
</style>

<div class="country-page">
    <div class="cm-head">
        <div>
            <h1>Country Management</h1>
            <p>Manage Consultancy destination countries and their availability.</p>
        </div>
        <div class="cm-count"><?=count($countries)?> <?=count($countries) === 1 ? 'country' : 'countries'?></div>
    </div>

    <?php if ($success): ?>
        <div class="cm-alert success"><?=e($success)?></div>
    <?php endif; ?>
    <?php if ($error): ?>
        <div class="cm-alert error"><?=e($error)?></div>
    <?php endif; ?>

    <div class="cm-grid">
        <section class="cm-card">
            <div class="cm-card-head">
                <h2><?= $editingCountry ? 'Edit Country' : 'Add Country' ?></h2>
                <p><?= $editingCountry ? 'Update the selected country.' : 'Add a destination country for Consultancy.' ?></p>
            </div>
            <div class="cm-card-body">
                <form method="post">
                    <?=csrf_input()?>
                    <input type="hidden" name="action" value="<?= $editingCountry ? 'update' : 'create' ?>">
                    <?php if ($editingCountry): ?>
                        <input type="hidden" name="id" value="<?=e((string)$editingCountry['id'])?>">
                    <?php endif; ?>

                    <div class="cm-field">
                        <label for="country_name">Country Name</label>
                        <input id="country_name" name="country_name" type="text" maxlength="120" required value="<?=e((string)($editingCountry['country_name'] ?? ''))?>" placeholder="e.g. Canada">
                    </div>

                    <div class="cm-field">
                        <label for="status">Status</label>
                        <select id="status" name="status">
                            <option value="Active" <?= (($editingCountry['status'] ?? 'Active') === 'Active') ? 'selected' : '' ?>>Active</option>
                            <option value="Inactive" <?= (($editingCountry['status'] ?? '') === 'Inactive') ? 'selected' : '' ?>>Inactive</option>
                        </select>
                    </div>

                    <div class="cm-actions">
                        <button class="cm-btn" type="submit"><?= $editingCountry ? 'Update Country' : 'Add Country' ?></button>
                        <?php if ($editingCountry): ?>
                            <a class="cm-btn secondary" href="country-management.php">Cancel</a>
                        <?php endif; ?>
                    </div>
                </form>
            </div>
        </section>

        <section class="cm-card">
            <div class="cm-card-head">
                <h2>Countries</h2>
                <p>These countries will be used later for counselor assignment and enquiries.</p>
            </div>
            <div class="cm-table-wrap">
                <?php if (!$countries): ?>
                    <div class="cm-empty">No countries added yet. Add the first Consultancy destination country.</div>
                <?php else: ?>
                    <table>
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Country</th>
                                <th>Status</th>
                                <th>Counselors</th>
                                <th>Updated</th>
                                <th>Actions</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($countries as $index => $country): ?>
                                <tr>
                                    <td><?=e((string)($index + 1))?></td>
                                    <td><strong><?=e((string)$country['country_name'])?></strong></td>
                                    <td>
                                        <span class="cm-count">
                                            <?=e((string)$country['counselor_count'])?> assigned
                                        </span>
                                    </td>
                                    <td>
                                        <span class="cm-status <?= $country['status'] === 'Active' ? 'active' : 'inactive' ?>">
                                            <i></i><?=e((string)$country['status'])?>
                                        </span>
                                    </td>
                                    <td><?=e(date('d M Y, h:i A', strtotime((string)$country['updated_at'])))?></td>
                                    <td>
                                        <div class="cm-row-actions">
                                            <a class="cm-btn secondary" href="country-management.php?edit=<?=e((string)$country['id'])?>">Edit</a>
                                            <form method="post">
                                                <?=csrf_input()?>
                                                <input type="hidden" name="action" value="toggle">
                                                <input type="hidden" name="id" value="<?=e((string)$country['id'])?>">
                                                <button class="cm-btn secondary" type="submit"><?= $country['status'] === 'Active' ? 'Deactivate' : 'Activate' ?></button>
                                            </form>
                                            <form method="post" onsubmit="return confirm('Delete this country? This should only be used if it is not connected to any Consultancy record.');">
                                                <?=csrf_input()?>
                                                <input type="hidden" name="action" value="delete">
                                                <input type="hidden" name="id" value="<?=e((string)$country['id'])?>">
                                                <button class="cm-btn danger" type="submit">Delete</button>
                                            </form>
                                        </div>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php endif; ?>
            </div>
        </section>
    </div>
</div>

<?php require '_footer.php'; ?>

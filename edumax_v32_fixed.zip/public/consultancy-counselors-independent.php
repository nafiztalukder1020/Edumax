<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_access('consultancy');

$error = '';
$success = '';
$currentUserId = (int)($_SESSION['user_id'] ?? 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (function_exists('require_valid_csrf')) {
        require_valid_csrf();
    } elseif (function_exists('verify_csrf')) {
        verify_csrf();
    }

    $action = (string)($_POST['action'] ?? '');

    try {
        if ($action === 'add_counselor') {
            $name = trim((string)($_POST['counselor_name'] ?? ''));
            $username = trim((string)($_POST['username'] ?? ''));
            $mobile = trim((string)($_POST['mobile'] ?? ''));
            $email = trim((string)($_POST['email'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));

            if ($name === '') {
                throw new RuntimeException('Counselor name is required.');
            }

            if ($username !== '') {
                $check = $pdo->prepare("SELECT id FROM consultancy_counselors WHERE username = ? LIMIT 1");
                $check->execute([$username]);
                if ($check->fetchColumn()) {
                    throw new RuntimeException('This username is already in use.');
                }
            }

            $stmt = $pdo->prepare("
                INSERT INTO consultancy_counselors
                    (counselor_name, username, mobile, email, status, notes, created_by, updated_by)
                VALUES (?, ?, ?, ?, 'Active', ?, ?, ?)
            ");
            $stmt->execute([
                $name,
                $username !== '' ? $username : null,
                $mobile !== '' ? $mobile : null,
                $email !== '' ? $email : null,
                $notes !== '' ? $notes : null,
                $currentUserId ?: null,
                $currentUserId ?: null
            ]);

            $success = 'Counselor added successfully.';
        }

        elseif ($action === 'toggle_counselor') {
            $id = (int)($_POST['counselor_id'] ?? 0);

            $stmt = $pdo->prepare("
                UPDATE consultancy_counselors
                SET status = CASE WHEN status = 'Active' THEN 'Inactive' ELSE 'Active' END,
                    updated_by = ?
                WHERE id = ?
            ");
            $stmt->execute([$currentUserId ?: null, $id]);

            $success = 'Counselor status updated.';
        }

        elseif ($action === 'assign_country') {
            $countryId = (int)($_POST['country_id'] ?? 0);
            $counselorId = (int)($_POST['counselor_id'] ?? 0);

            if ($countryId <= 0 || $counselorId <= 0) {
                throw new RuntimeException('Please select both country and counselor.');
            }

            $country = $pdo->prepare("SELECT id FROM consultancy_countries WHERE id = ? AND status = 'Active' LIMIT 1");
            $country->execute([$countryId]);

            $counselor = $pdo->prepare("SELECT id FROM consultancy_counselors WHERE id = ? AND status = 'Active' LIMIT 1");
            $counselor->execute([$counselorId]);

            if (!$country->fetchColumn()) {
                throw new RuntimeException('Selected country is not active.');
            }
            if (!$counselor->fetchColumn()) {
                throw new RuntimeException('Selected counselor is not active.');
            }

            $duplicate = $pdo->prepare("
                SELECT id FROM consultancy_counselor_country_assignments
                WHERE country_id = ? AND counselor_id = ? AND status = 'Active'
                LIMIT 1
            ");
            $duplicate->execute([$countryId, $counselorId]);

            if ($duplicate->fetchColumn()) {
                throw new RuntimeException('This counselor is already assigned to this country.');
            }

            $stmt = $pdo->prepare("
                INSERT INTO consultancy_counselor_country_assignments
                    (country_id, counselor_id, status, assigned_at, assigned_by)
                VALUES (?, ?, 'Active', NOW(), ?)
            ");
            $stmt->execute([$countryId, $counselorId, $currentUserId ?: null]);

            $success = 'Country assigned successfully.';
        }

        elseif ($action === 'end_assignment') {
            $assignmentId = (int)($_POST['assignment_id'] ?? 0);

            $stmt = $pdo->prepare("
                UPDATE consultancy_counselor_country_assignments
                SET status = 'Inactive',
                    ended_at = NOW(),
                    unassigned_by = ?
                WHERE id = ? AND status = 'Active'
            ");
            $stmt->execute([$currentUserId ?: null, $assignmentId]);

            $success = 'Assignment ended. History is preserved.';
        }
    } catch (Throwable $e) {
        $error = $e instanceof RuntimeException
            ? $e->getMessage()
            : 'Unable to complete the requested action.';
    }
}

$counselors = $pdo->query("
    SELECT
        c.id,
        c.counselor_name,
        c.username,
        c.mobile,
        c.email,
        c.status,
        c.notes,
        c.created_at,
        COUNT(DISTINCT CASE WHEN a.status = 'Active' THEN a.country_id END) AS active_country_count
    FROM consultancy_counselors c
    LEFT JOIN consultancy_counselor_country_assignments a
        ON a.counselor_id = c.id
    GROUP BY c.id, c.counselor_name, c.username, c.mobile, c.email, c.status, c.notes, c.created_at
    ORDER BY CASE WHEN c.status = 'Active' THEN 0 ELSE 1 END, c.counselor_name ASC
")->fetchAll();

$countries = $pdo->query("
    SELECT
        c.id,
        c.country_name,
        c.status,
        COUNT(DISTINCT CASE WHEN a.status = 'Active' THEN a.counselor_id END) AS active_counselor_count
    FROM consultancy_countries c
    LEFT JOIN consultancy_counselor_country_assignments a
        ON a.country_id = c.id
    GROUP BY c.id, c.country_name, c.status
    ORDER BY c.status DESC, c.country_name ASC
")->fetchAll();

$assignments = $pdo->query("
    SELECT
        a.id,
        a.status,
        a.assigned_at,
        a.ended_at,
        c.country_name,
        co.counselor_name
    FROM consultancy_counselor_country_assignments a
    INNER JOIN consultancy_countries c ON c.id = a.country_id
    INNER JOIN consultancy_counselors co ON co.id = a.counselor_id
    ORDER BY c.country_name ASC, a.status DESC, a.assigned_at DESC
")->fetchAll();

include __DIR__ . '/_header.php';
?>

<style>
.consultancy-page{padding:28px 30px 50px}
.page-head{display:flex;justify-content:space-between;align-items:flex-start;gap:16px;margin-bottom:22px}
.page-title{margin:0;font-size:26px;font-weight:700}
.page-subtitle{margin:6px 0 0;color:#6f747c;font-size:14px}
.grid{display:grid;grid-template-columns:360px minmax(0,1fr);gap:20px}
.card{background:#fff;border:1px solid #e6e8ec;border-radius:12px;padding:20px;box-shadow:0 2px 8px rgba(0,0,0,.03)}
.card h2{margin:0 0 6px;font-size:18px}
.card p{margin:0 0 18px;color:#7a7f87;font-size:13px}
.form-group{margin-bottom:14px}
.form-group label{display:block;margin-bottom:6px;font-size:13px;font-weight:600}
.form-control{width:100%;box-sizing:border-box;border:1px solid #d8dce2;border-radius:8px;padding:10px 11px;font-size:14px;background:#fff}
textarea.form-control{min-height:80px;resize:vertical}
.btn{border:0;border-radius:8px;padding:10px 14px;font-weight:700;cursor:pointer}
.btn-primary{background:#c91f2e;color:#fff}
.btn-secondary{background:#f1f3f5;color:#333}
.btn-danger{background:#fff0f1;color:#a31320}
.alert{padding:11px 13px;border-radius:8px;margin-bottom:16px;font-size:13px}
.alert-success{background:#ecfdf3;color:#17633c;border:1px solid #b7ebcc}
.alert-error{background:#fff1f2;color:#9f1239;border:1px solid #fecdd3}
.list{display:grid;gap:10px}
.row{display:flex;justify-content:space-between;align-items:center;gap:15px;border:1px solid #edf0f3;border-radius:10px;padding:13px}
.name{font-weight:700}.meta{color:#7b8088;font-size:12px;margin-top:3px}
.badge{display:inline-flex;padding:4px 9px;border-radius:999px;font-size:11px;font-weight:700}
.active{background:#dcfce7;color:#166534}.inactive{background:#f1f3f5;color:#6b7280}
.actions{display:flex;gap:7px;align-items:center}
.table-wrap{overflow:auto}
table{width:100%;border-collapse:collapse}
th,td{padding:11px 9px;border-bottom:1px solid #edf0f3;text-align:left;font-size:13px;white-space:nowrap}
th{font-size:12px;color:#737982}
.mt{margin-top:20px}
.empty{text-align:center;padding:30px;color:#777}
.empty strong{display:block;color:#20242b;margin-bottom:5px}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
@media(max-width:650px){.consultancy-page{padding:18px 12px 40px}.page-head{flex-direction:column}.table-wrap{overflow-x:auto}}
</style>

<div class="consultancy-page">
    <div class="page-head">
        <div>
            <h1 class="page-title">Counselor Management</h1>
            <p class="page-subtitle">Create and manage Consultancy counselors independently from the IELTS staff roles.</p>
        </div>
    </div>

    <?php if ($success): ?><div class="alert alert-success"><?=e($success)?></div><?php endif; ?>
    <?php if ($error): ?><div class="alert alert-error"><?=e($error)?></div><?php endif; ?>

    <div class="grid">
        <div>
            <div class="card">
                <h2>Add Counselor</h2>
                <p>Create a new Consultancy counselor account/profile.</p>
                <form method="post">
                    <?=csrf_input()?>
                    <input type="hidden" name="action" value="add_counselor">
                    <div class="form-group"><label>Counselor Name</label><input class="form-control" name="counselor_name" required></div>
                    <div class="form-group"><label>Username <span style="font-weight:400;color:#888">(optional for now)</span></label><input class="form-control" name="username"></div>
                    <div class="form-group"><label>Mobile</label><input class="form-control" name="mobile"></div>
                    <div class="form-group"><label>Email</label><input class="form-control" type="email" name="email"></div>
                    <div class="form-group"><label>Notes</label><textarea class="form-control" name="notes"></textarea></div>
                    <button class="btn btn-primary" type="submit">Add Counselor</button>
                </form>
            </div>

            <div class="card mt">
                <h2>Assign Country</h2>
                <p>One counselor can handle multiple countries.</p>
                <form method="post">
                    <?=csrf_input()?>
                    <input type="hidden" name="action" value="assign_country">
                    <div class="form-group"><label>Country</label>
                        <select class="form-control" name="country_id" required>
                            <option value="">Select Country</option>
                            <?php foreach($countries as $country): if($country['status']==='Active'): ?>
                                <option value="<?=e((string)$country['id'])?>"><?=e((string)$country['country_name'])?></option>
                            <?php endif; endforeach; ?>
                        </select>
                    </div>
                    <div class="form-group"><label>Counselor</label>
                        <select class="form-control" name="counselor_id" required>
                            <option value="">Select Counselor</option>
                            <?php foreach($counselors as $counselor): if($counselor['status']==='Active'): ?>
                                <option value="<?=e((string)$counselor['id'])?>"><?=e((string)$counselor['counselor_name'])?></option>
                            <?php endif; endforeach; ?>
                        </select>
                    </div>
                    <button class="btn btn-primary" type="submit">Assign Counselor</button>
                </form>
            </div>
        </div>

        <div class="card">
            <h2>Counselor List</h2>
            <p>Consultancy counselors are managed independently from the existing IELTS staff users.</p>
            <?php if (!$counselors): ?>
                <div class="empty"><strong>No Counselor Found</strong>Add the first Consultancy counselor.</div>
            <?php else: ?>
                <div class="list">
                    <?php foreach($counselors as $c): ?>
                        <div class="row">
                            <div>
                                <div class="name"><?=e($c['counselor_name'])?></div>
                                <div class="meta">
                                    <?=e($c['mobile'] ?: 'No mobile')?> ·
                                    <?=e($c['email'] ?: 'No email')?> ·
                                    <?=e((string)$c['active_country_count'])?> country(s)
                                </div>
                            </div>
                            <div class="actions">
                                <span class="badge <?=$c['status']==='Active'?'active':'inactive'?>"><?=e($c['status'])?></span>
                                <form method="post" style="margin:0">
                                    <?=csrf_input()?>
                                    <input type="hidden" name="action" value="toggle_counselor">
                                    <input type="hidden" name="counselor_id" value="<?=e((string)$c['id'])?>">
                                    <button class="btn btn-secondary" type="submit"><?=$c['status']==='Active'?'Deactivate':'Activate'?></button>
                                </form>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <div class="card mt">
        <h2>Assignment &amp; History</h2>
        <p>When an assignment ends, the historical record remains available.</p>
        <?php if (!$assignments): ?>
            <div class="empty"><strong>No Assignment Found</strong>Assign a counselor to a country to start the history.</div>
        <?php else: ?>
            <div class="table-wrap">
                <table>
                    <thead><tr><th>Country</th><th>Counselor</th><th>Status</th><th>Assigned At</th><th>Ended At</th><th>Action</th></tr></thead>
                    <tbody>
                    <?php foreach($assignments as $a): ?>
                        <tr>
                            <td><?=e($a['country_name'])?></td>
                            <td><?=e($a['counselor_name'])?></td>
                            <td><span class="badge <?=$a['status']==='Active'?'active':'inactive'?>"><?=e($a['status'])?></span></td>
                            <td><?=e($a['assigned_at'])?></td>
                            <td><?=e($a['ended_at'] ?: '—')?></td>
                            <td>
                                <?php if($a['status']==='Active'): ?>
                                <form method="post" style="margin:0" onsubmit="return confirm('End this assignment? History will be preserved.');">
                                    <?=csrf_input()?>
                                    <input type="hidden" name="action" value="end_assignment">
                                    <input type="hidden" name="assignment_id" value="<?=e((string)$a['id'])?>">
                                    <button class="btn btn-danger" type="submit">End Assignment</button>
                                </form>
                                <?php else: ?>History preserved<?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php include __DIR__ . '/_footer.php'; ?>

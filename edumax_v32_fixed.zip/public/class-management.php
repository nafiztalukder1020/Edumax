<?php
require_once __DIR__ . '/../config/app.php';
require_valid_csrf();
require_access('classes');
ensure_batch_schedule_columns();

/*
 * Scheduling extensions:
 * - class_type is widened to VARCHAR so new activity types (Speaking Club,
 *   Writing Club, ICU Batch, etc.) can be used without enum failures.
 * - batch_id becomes nullable for standalone activities that are not tied to
 *   an admission batch.
 */
try {
    $pdo->exec("ALTER TABLE class_schedules MODIFY COLUMN class_type VARCHAR(60) NOT NULL DEFAULT 'Regular Class'");
} catch (Throwable $ignore) {}
try {
    $pdo->exec("ALTER TABLE class_schedules MODIFY COLUMN batch_id INT UNSIGNED NULL");
} catch (Throwable $ignore) {}
if (isset($_GET['ajax']) && $_GET['ajax'] === 'calendar') {
    header('Content-Type: application/json; charset=utf-8');
    $fromA = $_GET['from'] ?? date('Y-m-01');
    $toA = $_GET['to'] ?? date('Y-m-t');
    $batchA = (int)($_GET['batch_id'] ?? 0);

    // Keep the calendar self-healing: when a batch has recurring day/time
    // settings but its placeholder rows were not generated (for example after
    // a hosting migration), generate the missing rows before reading the view.
    // Existing routine/teacher/topic data is never overwritten.
    try {
        if ($batchA > 0) {
            generate_batch_schedule($batchA);
        } else {
            $calendarBatches = $pdo->query("SELECT id FROM batches WHERE status <> 'Closed' AND is_archived=0")->fetchAll();
            foreach ($calendarBatches as $calendarBatch) {
                generate_batch_schedule((int)$calendarBatch['id']);
            }
        }
    } catch (Throwable $scheduleError) {
        // Calendar rendering should still work if an old deployment is missing
        // a schedule table or migration; the normal query below will return
        // whatever schedule data is already available.
    }

    $whereA = ["cs.class_date BETWEEN ? AND ?"];
    $paramsA = [$fromA, $toA];
    if ($batchA) { $whereA[] = "cs.batch_id=?"; $paramsA[] = $batchA; }
    $qA = "SELECT cs.*, 
                  COALESCE(b.name, 'Standalone Activity') AS batch_name,
                  COALESCE(c.name, 'General Activity') AS course_name
           FROM class_schedules cs
           LEFT JOIN batches b ON b.id=cs.batch_id
           LEFT JOIN courses c ON c.id=b.course_id
           WHERE (cs.batch_id IS NULL OR COALESCE(b.is_archived,0)=0)
             AND ".implode(' AND ', $whereA)."
           ORDER BY cs.class_date ASC, cs.time_slot ASC, cs.id ASC";
    $stA = $pdo->prepare($qA); $stA->execute($paramsA);
    echo json_encode(['classes'=>$stA->fetchAll()], JSON_UNESCAPED_UNICODE);
    exit;
}

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $action = $_POST['action'] ?? '';

        if ($action === 'save_class') {
            $id = (int)($_POST['id'] ?? 0);
            $date = trim($_POST['class_date'] ?? '');
            $batchId = (int)($_POST['batch_id'] ?? 0);
            $teacher = trim($_POST['teacher_name'] ?? '');
            $room = trim($_POST['room'] ?? '');
            $topic = trim($_POST['topic'] ?? '');
            $classType = trim($_POST['class_type'] ?? 'Regular Class');
            $status = $_POST['status'] ?? 'Scheduled';
            $notes = trim($_POST['notes'] ?? '');
            $requestedSlot = trim($_POST['time_slot'] ?? '');

            $allowedTypes = [
                'Regular Class','Mock Test','Special Class','Seminar','Other',
                'Spoken English','ICU Batch','Speaking Class','Speaking Club',
                'Writing Club','Free/Orientation Class'
            ];
            $allowedStatuses = ['Scheduled','Completed','Cancelled','Rescheduled'];

            if (!$date) {
                throw new RuntimeException('Class date is required.');
            }

            $dateObj = DateTime::createFromFormat('Y-m-d', $date);
            if (!$dateObj || $dateObj->format('Y-m-d') !== $date) {
                throw new RuntimeException('Please select a valid class date.');
            }
            if (!in_array($classType, $allowedTypes, true)) {
                $classType = 'Regular Class';
            }
            if (!in_array($status, $allowedStatuses, true)) {
                $status = 'Scheduled';
            }

            $isStandalone = in_array($classType, [
                'Speaking Class','Speaking Club','Writing Club',
                'Free/Orientation Class','Special Class','Seminar','Other'
            ], true);

            $batch = null;
            $slots = [];

            if (!$isStandalone) {
                if ($batchId <= 0) {
                    throw new RuntimeException('Batch is required for this class type.');
                }

                $stmt = $pdo->prepare(
                    "SELECT id,name,time_slots,status,is_archived
                     FROM batches
                     WHERE id=? AND status <> 'Closed'
                       AND COALESCE(is_archived,0)=0
                     LIMIT 1"
                );
                $stmt->execute([$batchId]);
                $batch = $stmt->fetch();

                if (!$batch) {
                    throw new RuntimeException('Selected batch was not found.');
                }

                $configuredSlots = json_decode((string)$batch['time_slots'], true);
                if (!is_array($configuredSlots) || count($configuredSlots) === 0) {
                    $configuredSlots = ['10:00 AM','12:00 PM','3:00 PM','5:00 PM'];
                }
                $cleanConfiguredSlots = [];
                foreach ($configuredSlots as $slotValue) {
                    $slotValue = trim((string)$slotValue);
                    if ($slotValue !== '' && !in_array($slotValue, $cleanConfiguredSlots, true)) {
                        $cleanConfiguredSlots[] = $slotValue;
                    }
                }
                $configuredSlots = $cleanConfiguredSlots ?: ['10:00 AM','12:00 PM','3:00 PM','5:00 PM'];

                $selectedSlots = $_POST['time_slots'] ?? [];
                if (!is_array($selectedSlots)) $selectedSlots = [$selectedSlots];
                $selectedSlots = array_values(array_unique(array_filter(
                    array_map(static fn($v) => trim((string)$v), $selectedSlots),
                    static fn($v) => $v !== ''
                )));
                foreach ($selectedSlots as $selectedSlot) {
                    if (!in_array($selectedSlot, $configuredSlots, true)) {
                        throw new RuntimeException('One or more selected time slots are not configured for this batch.');
                    }
                }
                if (!$selectedSlots) {
                    throw new RuntimeException('Select at least one time slot for this teacher.');
                }
                $slots = array_values(array_filter(
                    $configuredSlots,
                    static fn($slot) => in_array($slot, $selectedSlots, true)
                ));
            } else {
                // Standalone activities use one manually selected time slot.
                if ($requestedSlot === '') {
                    throw new RuntimeException('Time slot is required for a standalone activity.');
                }
                if (mb_strlen($requestedSlot) > 100) {
                    throw new RuntimeException('Time slot must be 100 characters or fewer.');
                }
                $slots = [$requestedSlot];
                $batchId = 0;
            }

            // Room comes from the Room Management directory.
            if ($room === '') {
                $room = 'Classroom 1';
            }
            if (mb_strlen($room) > 100) {
                throw new RuntimeException('Room name must be 100 characters or fewer.');
            }

            $oldAssignment = null;
            if ($id > 0) {
                $oldStmt = $pdo->prepare(
                    "SELECT id,class_date,batch_id,teacher_name,room,status,class_type,time_slot
                     FROM class_schedules
                     WHERE id=? LIMIT 1"
                );
                $oldStmt->execute([$id]);
                $oldAssignment = $oldStmt->fetch() ?: null;

                if (!$oldAssignment) {
                    throw new RuntimeException('Class record not found.');
                }
            }

            /*
             * Conflict protection:
             * - Same room + same date + same time cannot overlap.
             * - Same teacher + same date + same time cannot overlap.
             * - Cancelled records do not block a slot.
             *
             * For regular batch assignments, the existing full-day rule remains:
             * one selected teacher is assigned to every configured batch slot.
             */
            $excludeIds = [];
            if ($id > 0) {
                $oldIdsStmt = $pdo->prepare(
                    "SELECT id FROM class_schedules
                     WHERE class_date=? AND
                           ((batch_id <=> ?) AND (teacher_name <=> ?))
                       AND status <> 'Cancelled'"
                );
                $oldIdsStmt->execute([
                    $oldAssignment['class_date'],
                    $oldAssignment['batch_id'],
                    $oldAssignment['teacher_name']
                ]);
                $excludeIds = array_map('intval', $oldIdsStmt->fetchAll(PDO::FETCH_COLUMN));
            }

            foreach ($slots as $slot) {
                $conflictSql = "
                    SELECT cs.id, cs.time_slot, cs.teacher_name, cs.room,
                           COALESCE(b.name,'Standalone Activity') AS batch_name,
                           cs.class_type
                    FROM class_schedules cs
                    LEFT JOIN batches b ON b.id=cs.batch_id
                    WHERE cs.class_date=?
                      AND cs.time_slot=?
                      AND cs.status <> 'Cancelled'
                ";
                $conflictParams = [$date, $slot];

                if ($excludeIds) {
                    $marks = implode(',', array_fill(0, count($excludeIds), '?'));
                    $conflictSql .= " AND cs.id NOT IN ($marks)";
                    $conflictParams = array_merge($conflictParams, $excludeIds);
                }

                $conflictStmt = $pdo->prepare($conflictSql);
                $conflictStmt->execute($conflictParams);
                $conflicts = $conflictStmt->fetchAll();

                foreach ($conflicts as $conflict) {
                    if ($room !== '' && strcasecmp((string)$conflict['room'], $room) === 0) {
                        throw new RuntimeException(
                            'Room "' . $room . '" is already booked on ' .
                            date('d M Y', strtotime($date)) . ' at ' . $slot .
                            ' for ' . ($conflict['batch_name'] ?: 'another activity') . '.'
                        );
                    }

                    if ($teacher !== '' && strcasecmp((string)$conflict['teacher_name'], $teacher) === 0) {
                        throw new RuntimeException(
                            'Teacher "' . $teacher . '" is already assigned on ' .
                            date('d M Y', strtotime($date)) . ' at ' . $slot .
                            ' for ' . ($conflict['batch_name'] ?: 'another activity') . '.'
                        );
                    }
                }
            }

            $pdo->beginTransaction();

            if ($id > 0) {
                if ($oldAssignment['batch_id'] !== null && $oldAssignment['teacher_name'] !== null) {
                    $del = $pdo->prepare(
                        "DELETE FROM class_schedules
                         WHERE class_date=? AND batch_id=? AND teacher_name=?
                           AND status <> 'Cancelled'"
                    );
                    $del->execute([
                        $oldAssignment['class_date'],
                        (int)$oldAssignment['batch_id'],
                        (string)$oldAssignment['teacher_name']
                    ]);
                } else {
                    $del = $pdo->prepare("DELETE FROM class_schedules WHERE id=?");
                    $del->execute([$id]);
                }
            } elseif (!$isStandalone && $teacher !== '') {
                $del = $pdo->prepare(
                    "DELETE FROM class_schedules
                     WHERE class_date=? AND batch_id=? AND teacher_name=?
                       AND status <> 'Cancelled'"
                );
                $del->execute([$date, $batchId, $teacher]);
            }

            $insert = $pdo->prepare(
                "INSERT INTO class_schedules
                    (batch_id,class_date,time_slot,teacher_name,room,topic,class_type,status,notes,created_by)
                 VALUES (?,?,?,?,?,?,?,?,?,?)"
            );

            $createdBy = (int)($_SESSION['user_id'] ?? 0);
            foreach ($slots as $slot) {
                $insert->execute([
                    $batchId > 0 ? $batchId : null,
                    $date,
                    $slot,
                    $teacher !== '' ? $teacher : null,
                    $room !== '' ? $room : null,
                    $topic ?: null,
                    $classType,
                    $status,
                    $notes ?: null,
                    $createdBy ?: null
                ]);
            }

            $pdo->commit();
            $message = $isStandalone
                ? 'Activity scheduled successfully for ' . date('d M Y', strtotime($date)) . ' at ' . $slots[0] . '.'
                : 'Teacher assigned successfully. ' . count($slots) . ' time-slot classes were created for ' . date('d M Y', strtotime($date)) . '.';
        } elseif ($action === 'delete_class') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id > 0) {
                $stmt = $pdo->prepare("SELECT id,status FROM class_schedules WHERE id=? LIMIT 1");
                $stmt->execute([$id]);
                $row = $stmt->fetch();

                if (!$row) {
                    throw new RuntimeException('Class record not found.');
                }

                if ($row['status'] !== 'Cancelled') {
                    throw new RuntimeException('Scheduled classes cannot be deleted. Cancel the class instead so the history is preserved.');
                }

                $del = $pdo->prepare("DELETE FROM class_schedules WHERE id=?");
                $del->execute([$id]);
                $message = 'Cancelled class record removed.';
            }
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        $error = $e->getMessage();
    }
}

$teachers = [];
try {
    $teachers = $pdo->query(
        "SELECT id,name,subject,status
         FROM teachers
         WHERE status='Active'
         ORDER BY name ASC"
    )->fetchAll();
} catch (Throwable $ignore) {}

/*
 * Load batches for the Add Class modal and calendar filter.
 * V6 was missing this query, so the Batch dropdown had only
 * "Select Batch" and could not be used.
 */
$batches = [];
try {
    $batches = $pdo->query(
        "SELECT b.id, b.name, b.time_slots, b.class_days, b.start_date, b.status, c.name AS course_name
         FROM batches b
         LEFT JOIN courses c ON c.id=b.course_id
         WHERE b.status <> 'Closed' AND COALESCE(b.is_archived,0)=0
         ORDER BY b.name ASC, b.id ASC"
    )->fetchAll();
} catch (Throwable $ignore) {}

// Backfill recurring placeholders for configured batches without touching existing routines.
try {
    foreach ($batches as $batchRow) {
        if (!empty($batchRow['class_days']) && !empty($batchRow['start_date'])) {
            generate_batch_schedule((int)$batchRow['id']);
        }
    }
} catch (Throwable $ignore) {}

$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-t');
$batchFilter = (int)($_GET['batch_id'] ?? 0);
$statusFilter = trim($_GET['status'] ?? '');

$where = ["cs.class_date BETWEEN ? AND ?"];
$params = [$from,$to];

if ($batchFilter) {
    $where[] = "cs.batch_id=?";
    $params[] = $batchFilter;
}
if ($statusFilter !== '') {
    $where[] = "cs.status=?";
    $params[] = $statusFilter;
}

$sql = "SELECT cs.*, COALESCE(b.name,'Standalone Activity') AS batch_name,
               COALESCE(c.name,'General Activity') AS course_name
        FROM class_schedules cs
        LEFT JOIN batches b ON b.id=cs.batch_id
        LEFT JOIN courses c ON c.id=b.course_id
        WHERE ".implode(" AND ",$where)."
        ORDER BY cs.class_date ASC, cs.time_slot ASC, cs.id ASC";
$stmt = $pdo->prepare($sql);
$stmt->execute($params);
$classes = $stmt->fetchAll();

require '_header.php';
?>
<div class="section-title">
    <div>
        <h1>Class Management</h1>
        <p>Batch days and time slots are automatic. Set the daily module/routine from the calendar.</p>
    </div>
    <div class="header-actions">
        <button class="btn btn-primary" type="button" onclick="openClassModal()">+ Add Class</button>
        <button class="btn btn-secondary top-edit-btn" type="button" onclick="openClassEditList()">
            <span aria-hidden="true">✎</span> Edit
        </button>
    </div>
</div>

<?php if ($message): ?><div class="alert success"><?=e($message)?></div><?php endif; ?>
<?php if ($error): ?><div class="alert danger"><?=e($error)?></div><?php endif; ?>

<div class="card calendar-card">
    <div class="calendar-toolbar">
        <div class="calendar-nav">
            <button class="btn btn-secondary" type="button" onclick="goToday()">Today</button>
            <button class="icon-btn" type="button" onclick="movePeriod(-1)" aria-label="Previous">‹</button>
            <button class="icon-btn" type="button" onclick="movePeriod(1)" aria-label="Next">›</button>
            <h2 id="calendarTitle">Calendar</h2>
        </div>
        <div class="calendar-actions">
            <select id="calendarBatch" onchange="reloadCalendar()">
                <option value="0">All Batches</option>
                <?php foreach($batches as $b): ?><option value="<?=$b['id']?>"><?=e($b['name'])?></option><?php endforeach; ?>
            </select>
            <div class="view-switch">
                <button type="button" data-view="month" class="active" onclick="setView('month')">Month</button>
                <button type="button" data-view="week" onclick="setView('week')">Week</button>
                <button type="button" data-view="day" onclick="setView('day')">Day</button>
            </div>
        </div>
    </div>
    <div id="calendarLoading" class="calendar-loading">Loading calendar…</div>
    <div id="calendarRoot"></div>
</div>

<div class="card" id="class-edit-list" style="margin-top:18px;">
    <details id="advanced-class-list">
        <summary style="cursor:pointer;font-weight:700;padding:2px 0;">Advanced filters & class list</summary>
        <form method="get" class="form-grid" style="padding:18px 0 8px;grid-template-columns:repeat(4,1fr);align-items:end;">
            <div><label>From</label><input type="date" name="from" value="<?=e($from)?>"></div>
            <div><label>To</label><input type="date" name="to" value="<?=e($to)?>"></div>
            <div><label>Batch</label><select name="batch_id"><option value="0">All Batches</option><?php foreach($batches as $b): ?><option value="<?=$b['id']?>" <?=$batchFilter===$b['id']?'selected':''?>><?=e($b['name'])?></option><?php endforeach; ?></select></div>
            <div><label>Status</label><select name="status"><option value="">All Status</option><?php foreach(['Scheduled','Completed','Cancelled','Rescheduled'] as $s): ?><option value="<?=e($s)?>" <?=$statusFilter===$s?'selected':''?>><?=e($s)?></option><?php endforeach; ?></select></div>
            <div><button class="btn btn-primary" type="submit">Filter List</button></div>
        </form>
        <div class="table-wrap">
            <table class="table">
                <thead><tr><th>Date</th><th>Time</th><th>Batch</th><th>Topic</th><th>Teacher</th><th>Room</th><th>Type</th><th>Status</th><th>Action</th></tr></thead>
                <tbody>
                <?php if (!$classes): ?><tr><td colspan="9" style="text-align:center;padding:30px;">No classes found for the selected period.</td></tr><?php endif; ?>
                <?php foreach($classes as $c): ?>
                    <tr>
                        <td><?=e(date('d M Y',strtotime($c['class_date'])))?></td><td><?=e($c['time_slot'])?></td>
                        <td><strong><?=e($c['batch_name'])?></strong><br><small><?=e($c['course_name'])?></small></td>
                        <td><?=e($c['topic'] ?: '-')?></td><td><?=e($c['teacher_name'] ?: '-')?></td><td><?=e($c['room'] ?: '-')?></td>
                        <td><?=e($c['class_type'])?></td><td><?=e($c['status'])?></td>
                        <td><button class="btn btn-secondary" type="button" onclick='editClass(<?=json_encode($c, JSON_HEX_TAG|JSON_HEX_APOS|JSON_HEX_QUOT|JSON_HEX_AMP)?>)'>Edit</button>
                            <form method="post" style="display:inline" onsubmit="return confirm('Remove this teacher\'s full-day schedule?')"><?=csrf_input()?><input type="hidden" name="action" value="delete_class"><input type="hidden" name="id" value="<?=$c['id']?>"><button class="btn btn-secondary" type="submit">Delete</button></form>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </details>
</div>

<style>
 .time-slots-box{display:flex;flex-wrap:wrap;gap:8px;padding:10px;border:1px solid var(--border);border-radius:10px;background:#fafafa;min-height:44px}.slot-check{display:inline-flex;align-items:center;gap:7px;border:1px solid var(--border);background:#fff;border-radius:9px;padding:8px 11px;cursor:pointer;font-weight:700;font-size:12px}.slot-check input{margin:0}.slot-empty{color:var(--muted);font-size:12px;padding:5px}.slot-select{width:100%;height:40px;border:1px solid var(--border);border-radius:8px;padding:0 10px;background:#fff}.field-help{display:block;margin-top:5px;font-size:11px;color:var(--muted)}.field-help a{color:var(--brand);text-decoration:none;font-weight:700}.calendar-card{overflow:hidden}.calendar-toolbar{display:flex;justify-content:space-between;gap:16px;align-items:center;padding:18px 20px;border-bottom:1px solid var(--border);flex-wrap:wrap}.calendar-nav,.calendar-actions{display:flex;align-items:center;gap:8px}.calendar-nav h2{margin:0 8px;font-size:20px}.icon-btn{border:1px solid var(--border);background:#fff;border-radius:10px;width:38px;height:38px;font-size:26px;line-height:1;cursor:pointer}.calendar-actions select{height:40px;min-width:180px}.view-switch{display:flex;border:1px solid var(--border);border-radius:10px;overflow:hidden}.view-switch button{border:0;background:#fff;padding:10px 13px;cursor:pointer;font-weight:700;color:var(--muted)}.view-switch button.active{background:var(--brand);color:#fff}.calendar-loading{display:none;padding:10px 20px;color:var(--muted);font-size:13px}.calendar-grid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));border-left:1px solid var(--border);border-top:1px solid var(--border)}.cal-head{padding:10px;text-align:center;font-size:12px;font-weight:800;color:var(--muted);background:#fafafa;border-right:1px solid var(--border);border-bottom:1px solid var(--border)}.cal-day{min-height:135px;padding:8px;border-right:1px solid var(--border);border-bottom:1px solid var(--border);background:#fff;cursor:pointer}.cal-day.other{background:#fafafa}.cal-day.today{box-shadow:inset 0 0 0 2px var(--brand)}.day-number{font-weight:800;font-size:13px;margin-bottom:7px}.event{display:block;width:100%;text-align:left;border:0;border-left:3px solid var(--brand);background:var(--brand-soft);padding:6px 7px;margin:4px 0;border-radius:7px;cursor:pointer;color:var(--ink);font-size:11px}.event strong{display:block;font-size:11px}.event small{display:block;color:var(--muted);margin-top:2px}.status-Cancelled{opacity:.55;text-decoration:line-through}.status-Completed{border-left-color:#444}.status-Rescheduled{border-left-color:#777}.week-wrap,.day-wrap{overflow:auto}.time-grid{display:grid;grid-template-columns:74px repeat(7,minmax(150px,1fr));min-width:1050px}.day-grid{display:grid;grid-template-columns:74px minmax(400px,1fr);min-width:600px}.time-label{height:72px;border-right:1px solid var(--border);border-bottom:1px solid var(--border);padding:8px;font-size:11px;color:var(--muted);background:#fafafa}.slot-cell{min-height:72px;border-right:1px solid var(--border);border-bottom:1px solid var(--border);padding:5px}.slot-head{min-height:48px;padding:10px;border-right:1px solid var(--border);border-bottom:1px solid var(--border);background:#fafafa;font-weight:800;text-align:center}.slot-event{background:var(--brand-soft);border-left:3px solid var(--brand);border-radius:7px;padding:7px;margin:2px;font-size:11px;cursor:pointer}.slot-event strong{display:block}.empty-day{padding:40px;text-align:center;color:var(--muted)}@media(max-width:800px){.calendar-toolbar{align-items:stretch}.calendar-nav,.calendar-actions{width:100%;flex-wrap:wrap}.calendar-actions select{flex:1}.cal-day{min-height:105px}.calendar-grid{font-size:11px}.event{padding:5px}.event small{display:none}}
.event-status{font-weight:900;letter-spacing:.4px;margin-top:3px}.status-Cancelled .event-status{color:#b00020}.status-Rescheduled .event-status{color:#555}.status-Completed .event-status{color:#333}.header-actions{display:flex;align-items:center;gap:10px;flex-wrap:wrap}.top-edit-btn{display:inline-flex;align-items:center;justify-content:center;gap:7px}.top-edit-btn span{font-size:18px;line-height:1}</style>

<script>
const calendarState={date:new Date(),view:'month',classes:[],batch:0};
const monthNames=['January','February','March','April','May','June','July','August','September','October','November','December'];
const weekNames=['Sun','Mon','Tue','Wed','Thu','Fri','Sat'];
function pad(n){return String(n).padStart(2,'0')}
function iso(d){return d.getFullYear()+'-'+pad(d.getMonth()+1)+'-'+pad(d.getDate())}
function startOfWeek(d){const x=new Date(d);x.setDate(x.getDate()-x.getDay());x.setHours(0,0,0,0);return x}
function endOfWeek(d){const x=startOfWeek(d);x.setDate(x.getDate()+6);return x}
function rangeForView(){let d=calendarState.date;if(calendarState.view==='month'){let s=new Date(d.getFullYear(),d.getMonth(),1);s.setDate(s.getDate()-s.getDay());let e=new Date(d.getFullYear(),d.getMonth()+1,0);e.setDate(e.getDate()+(6-e.getDay()));return [s,e]}if(calendarState.view==='week')return [startOfWeek(d),endOfWeek(d)];return [d,d]}
function esc(s){return String(s??'').replace(/[&<>'"]/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[m]))}
function setView(v){calendarState.view=v;document.querySelectorAll('.view-switch button').forEach(b=>b.classList.toggle('active',b.dataset.view===v));reloadCalendar()}
function movePeriod(n){if(calendarState.view==='month')calendarState.date.setMonth(calendarState.date.getMonth()+n);else if(calendarState.view==='week')calendarState.date.setDate(calendarState.date.getDate()+7*n);else calendarState.date.setDate(calendarState.date.getDate()+n);reloadCalendar()}
function goToday(){calendarState.date=new Date();reloadCalendar()}
function reloadCalendar(){calendarState.batch=Number(document.getElementById('calendarBatch').value||0);const [s,e]=rangeForView();const loading=document.getElementById('calendarLoading');loading.style.display='block';fetch('class-management.php?ajax=calendar&from='+iso(s)+'&to='+iso(e)+'&batch_id='+calendarState.batch)
.then(r=>r.ok?r.json():Promise.reject())
.then(data=>{calendarState.classes=Array.isArray(data.classes)?data.classes:[];renderCalendar()})
.catch(()=>{document.getElementById('calendarRoot').innerHTML='<div class="empty-day">Unable to load calendar.</div>'})
.finally(()=>loading.style.display='none')}
function eventForDate(ds){return calendarState.classes.filter(c=>c.class_date===ds)}
function openDate(ds){calendarState.date=new Date(ds+'T12:00:00');document.getElementById('classModal').style.display='block';document.getElementById('modalTitle').textContent='Set Daily Class Routine';document.getElementById('class_id').value='0';document.getElementById('class_date').value=ds;document.getElementById('teacher_name').value='';if(document.getElementById('room').options.length) document.getElementById('room').selectedIndex=0;document.getElementById('topic').value='';document.getElementById('notes').value='';document.getElementById('class_type').value='Regular Class';document.getElementById('status').value='Scheduled';if(calendarState.batch){document.getElementById('batch_id').value=calendarState.batch;loadSlots()}else{
        document.getElementById('batch_id').value='';
        document.getElementById('time_slot').innerHTML='<option value="">Select batch first</option>';
    }
}
function eventHtml(c){
    const status=String(c.status||'Scheduled');
    const statusLabel=(status!=='Scheduled')?'<small class="event-status">'+esc(status.toUpperCase())+'</small>':'';
    return '<button type="button" class="event status-'+esc(status)+'" onclick=\'event.stopPropagation();editClass('+JSON.stringify(c).replace(/'/g,"&#39;")+')\'><strong>'+esc(c.time_slot)+' · '+esc(c.batch_name)+'</strong><small>'+esc(c.topic||c.class_type||'Class')+(c.teacher_name?' · '+esc(c.teacher_name):'')+(c.room?' · '+esc(c.room):'')+'</small>'+statusLabel+'</button>'
}
function renderCalendar(){const root=document.getElementById('calendarRoot');const d=calendarState.date;let title='';if(calendarState.view==='month')title=monthNames[d.getMonth()]+' '+d.getFullYear();else if(calendarState.view==='week'){const s=startOfWeek(d),e=endOfWeek(d);title=iso(s)+' — '+iso(e)}else title=iso(d);document.getElementById('calendarTitle').textContent=title;if(calendarState.view==='month')renderMonth(root);else if(calendarState.view==='week')renderWeek(root,false);else renderWeek(root,true)}
function renderMonth(root){let s=new Date(calendarState.date.getFullYear(),calendarState.date.getMonth(),1);s.setDate(s.getDate()-s.getDay());let html='<div class="calendar-grid">';weekNames.forEach(x=>html+='<div class="cal-head">'+x+'</div>');for(let i=0;i<42;i++){let d=new Date(s);d.setDate(s.getDate()+i);let ds=iso(d),other=d.getMonth()!==calendarState.date.getMonth(),today=ds===iso(new Date());html+='<div class="cal-day '+(other?'other ':'')+(today?'today':'')+'" onclick="openDate(\''+ds+'\')"><div class="day-number">'+d.getDate()+'</div>';eventForDate(ds).slice(0,5).forEach(c=>html+=eventHtml(c));if(eventForDate(ds).length>5)html+='<small>+'+(eventForDate(ds).length-5)+' more</small>';html+='</div>'}root.innerHTML=html+'</div>'}
function renderWeek(root,dayOnly){
  const s=dayOnly?new Date(calendarState.date):startOfWeek(calendarState.date);
  const days=dayOnly?[s]:Array.from({length:7},(_,i)=>{const d=new Date(s);d.setDate(s.getDate()+i);return d});
  const times=['8:00 AM','9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM','6:00 PM','7:00 PM'];
  const normTime=v=>String(v||'').toLowerCase().replace(/\s+/g,'').replace(/:00(?=[ap]m)/,'');
  let html='<div class="'+(dayOnly?'day-wrap':'week-wrap')+'"><div class="'+(dayOnly?'day-grid':'time-grid')+'"><div class="slot-head">Time</div>';
  days.forEach(d=>html+='<div class="slot-head">'+weekNames[d.getDay()]+'<br>'+d.getDate()+' '+monthNames[d.getMonth()].slice(0,3)+'</div>');
  times.forEach(t=>{
    html+='<div class="time-label">'+t+'</div>';
    days.forEach(d=>{
      const ds=iso(d);
      const ev=eventForDate(ds).filter(c=>normTime(c.time_slot)===normTime(t));
      html+='<div class="slot-cell" onclick="openDate(\''+ds+'\')">';
      ev.forEach(c=>{
        html+='<div class="slot-event" onclick=\'event.stopPropagation();editClass('+JSON.stringify(c).replace(/'/g,"&#39;")+')\'><strong>'+esc(c.time_slot)+' · '+esc(c.batch_name)+'</strong>'+esc(c.topic||'Routine not set')+'</div>';
      });
      html+='</div>';
    });
  });
  // Any non-standard configured slot is shown in an extra row so custom batch times are never lost in Week/Day view.
  const extra=[...new Set(calendarState.classes.map(c=>String(c.time_slot||'')).filter(Boolean))].filter(t=>!times.some(x=>normTime(x)===normTime(t)));
  extra.forEach(t=>{
    html+='<div class="time-label">'+esc(t)+'</div>';
    days.forEach(d=>{const ds=iso(d);const ev=eventForDate(ds).filter(c=>normTime(c.time_slot)===normTime(t));html+='<div class="slot-cell" onclick="openDate(\''+ds+'\')">';ev.forEach(c=>html+='<div class="slot-event" onclick=\'event.stopPropagation();editClass('+JSON.stringify(c).replace(/'/g,"&#39;")+')\'><strong>'+esc(c.time_slot)+' · '+esc(c.batch_name)+'</strong>'+esc(c.topic||'Routine not set')+'</div>');html+='</div>';});
  });
  html+='</div></div>';
  root.innerHTML=html;
}
</script>
<div id="classModal" style="display:none;position:fixed;inset:0;background:rgba(20,24,30,.55);z-index:2000;padding:30px;overflow:auto;">
  <div class="card" style="max-width:760px;margin:30px auto;">
    <div style="padding:18px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;">
      <strong id="modalTitle">Set Daily Class Routine</strong><button type="button" class="btn btn-secondary" onclick="closeClassModal()">×</button>
    </div>
    <form method="post" style="padding:20px;"><?=csrf_input()?>
      <input type="hidden" name="action" value="save_class"><input type="hidden" name="id" id="class_id" value="0">
      <div class="form-grid">
        <div><label>Batch *</label><select name="batch_id" id="batch_id" required onchange="loadSlots()">
            <option value="">Select Batch</option>
            <?php foreach($batches as $b): ?>
                <option value="<?=$b['id']?>" data-slots="<?=e($b['time_slots'] ?: '[]')?>">
                    <?=e($b['name'])?>
                </option>
            <?php endforeach; ?>
        </select>
        <?php if (!$batches): ?><small class="field-help" style="color:#c91f2e;">No active/upcoming batches found. Add a batch first.</small><?php endif; ?></div>
        <div><label>Date *</label><input type="date" name="class_date" id="class_date" required></div>
        <div style="grid-column:1/-1"><label>Teacher Time Slots</label><div id="timeSlotsBox" class="time-slots-box"><span class="slot-empty">Select a batch first.</span></div><input type="hidden" id="time_slot" name="time_slot" value=""><small class="field-help" id="slotHelp">Select one or more configured slots for this teacher.</small></div>
        <div><label>Teacher</label><select name="teacher_name" id="teacher_name"><option value="">Select Teacher</option><?php foreach($teachers as $t): ?><?php if($t['status']==='Active'): ?><option value="<?=e($t['name'])?>"><?=e($t['name'])?><?= $t['subject'] ? ' — '.e($t['subject']) : '' ?></option><?php endif; ?><?php endforeach; ?></select><small class="field-help"><a href="teacher-room-management.php?tab=teachers">Manage teachers</a></small></div>
        <div><label>Classroom / Room</label><select name="room" id="room"><?php
$rooms = [];
try { $rooms = $pdo->query("SELECT id,name,status FROM rooms WHERE status='Active' ORDER BY name ASC")->fetchAll(); } catch(Throwable $ignore) {}
?>
<?php if ($rooms): foreach($rooms as $r): ?><option value="<?=e($r['name'])?>"><?=e($r['name'])?></option><?php endforeach; else: ?><option value="Classroom 1">Classroom 1</option><?php endif; ?></select><small class="field-help"><a href="teacher-room-management.php?tab=rooms">Manage rooms</a></small></div>
        <div><label>Class Type</label><select name="class_type" id="class_type"><?php foreach(['Regular Class','Spoken English','ICU Batch','Speaking Class','Speaking Club','Writing Club','Mock Test','Special Class','Seminar','Free/Orientation Class','Other'] as $x): ?><option><?=e($x)?></option><?php endforeach; ?></select></div>
        <div style="grid-column:1/-1"><label>Daily Routine / Module</label><input type="text" name="topic" id="topic" placeholder="e.g. Writing Task 2 - Opinion Essay"></div>
        <div><label>Status</label><select name="status" id="status"><?php foreach(['Scheduled','Completed','Cancelled','Rescheduled'] as $x): ?><option><?=e($x)?></option><?php endforeach; ?></select></div>
        <div style="grid-column:1/-1"><label>Notes</label><textarea name="notes" id="notes" rows="3"></textarea></div>
      </div>
      <div style="display:flex;justify-content:flex-end;gap:10px;margin-top:18px;"><button type="button" class="btn btn-secondary" onclick="closeClassModal()">Cancel</button><button class="btn btn-primary">Save Daily Schedule</button></div>
    </form>
  </div>
</div>

<script>
function openClassModal(){document.getElementById('classModal').style.display='block';document.getElementById('modalTitle').textContent='Set Daily Class Routine';document.getElementById('class_id').value='0';document.getElementById('class_date').value=iso(calendarState.date);document.getElementById('teacher_name').value='';if(document.getElementById('room').options.length) document.getElementById('room').selectedIndex=0;document.getElementById('topic').value='';document.getElementById('notes').value='';document.getElementById('class_type').value='Regular Class';document.getElementById('status').value='Scheduled';document.getElementById('batch_id').value=calendarState.batch||'';loadSlots();}
function closeClassModal(){document.getElementById('classModal').style.display='none'}
document.getElementById('class_type').addEventListener('change',function(){
    const standalone=['Speaking Class','Speaking Club','Writing Club','Free/Orientation Class','Special Class','Seminar','Other'].includes(this.value);
    document.getElementById('batch_id').disabled=standalone;
    document.getElementById('batch_id').required=!standalone;
    loadSlots();
});
function isStandaloneType(){
    return ['Speaking Class','Speaking Club','Writing Club','Free/Orientation Class','Special Class','Seminar','Other'].includes(document.getElementById('class_type').value);
}
function batchConfiguredSlots(){
    const batch=document.getElementById('batch_id');
    const opt=batch ? batch.options[batch.selectedIndex] : null;
    let slots=[];
    try{slots=JSON.parse(opt?.dataset?.slots||'[]')}catch(e){}
    if(!Array.isArray(slots)||!slots.length) slots=['10:00 AM','12:00 PM','3:00 PM','5:00 PM'];
    return [...new Set(slots.map(x=>String(x).trim()).filter(Boolean))];
}
function selectedBatchSlots(){
    return [...document.querySelectorAll('input[name="time_slots[]"]:checked')].map(x=>x.value);
}
function loadSlots(selected=[]){
    const box=document.getElementById('timeSlotsBox');
    const hidden=document.getElementById('time_slot');
    if(!box) return;
    if(!Array.isArray(selected)) selected=selected?[selected]:[];
    if(isStandaloneType()){
        const common=['8:00 AM','9:00 AM','10:00 AM','11:00 AM','12:00 PM','1:00 PM','2:00 PM','3:00 PM','4:00 PM','5:00 PM','6:00 PM','7:00 PM'];
        box.innerHTML='<select id="standalone_time_select" class="slot-select"><option value="">Select time slot</option>'+
            common.map(x=>'<option value="'+esc(x)+'">'+esc(x)+'</option>').join('')+'</select>';
        const st=document.getElementById('standalone_time_select');
        if(selected.length) st.value=selected[0];
        hidden.value=st.value||'';
        st.addEventListener('change',()=>hidden.value=st.value);
        document.getElementById('slotHelp').textContent='Standalone activity: select one time slot.';
        return;
    }
    const slots=batchConfiguredSlots();
    box.innerHTML=slots.map(slot=>{
        const checked=selected.includes(slot)?' checked':'';
        return '<label class="slot-check"><input type="checkbox" name="time_slots[]" value="'+esc(slot)+'"'+checked+'><span>'+esc(slot)+'</span></label>';
    }).join('');
    hidden.value=selected.join(',');
    box.querySelectorAll('input[name="time_slots[]"]').forEach(cb=>{
        cb.addEventListener('change',()=>hidden.value=selectedBatchSlots().join(','));
    });
    document.getElementById('slotHelp').textContent='Select one or more slots for this teacher. Different teachers can use different slots.';
}

function setSelectSmart(id, wanted){
    const el=document.getElementById(id);
    if(!el) return false;
    wanted=String(wanted??'').trim();
    if(!wanted){el.value='';return false;}
    const norm=s=>String(s??'').trim().replace(/\s+/g,' ').toLowerCase();
    let opt=[...el.options].find(o=>String(o.value).trim()===wanted);
    if(!opt) opt=[...el.options].find(o=>norm(o.value)===norm(wanted));
    if(!opt) opt=[...el.options].find(o=>norm(o.textContent).split(' — ')[0]===norm(wanted));
    if(opt){el.value=opt.value;return true;}
    const newOpt=document.createElement('option');
    newOpt.value=wanted;
    newOpt.textContent=wanted+' (Current)';
    el.appendChild(newOpt);
    el.value=wanted;
    return true;
}

function editClass(c){
    document.getElementById('classModal').style.display='block';
    document.getElementById('modalTitle').textContent='Edit Class Schedule';
    document.getElementById('class_id').value=c.id;
    setSelectSmart('batch_id',c.batch_id||'');
    document.getElementById('batch_id').disabled=!c.batch_id;
    document.getElementById('batch_id').required=!!c.batch_id;
    document.getElementById('class_date').value=c.class_date||'';

    loadSlots(c.time_slot?[c.time_slot]:[]);
    setSelectSmart('teacher_name',c.teacher_name||'');
    setSelectSmart('room',c.room||'');
    setSelectSmart('class_type',c.class_type||'Regular Class');
    setSelectSmart('status',c.status||'Scheduled');
    document.getElementById('topic').value=c.topic||'';
    document.getElementById('notes').value=c.notes||'';

    const btn=document.querySelector('#classModal form button.btn-primary');
    if(btn) btn.textContent='Update Schedule';
}
window.addEventListener('click',e=>{if(e.target===document.getElementById('classModal'))closeClassModal()});

function openClassEditList(){
    const details=document.getElementById('advanced-class-list');
    const target=document.getElementById('class-edit-list');
    if(details) details.open=true;
    if(target) target.scrollIntoView({behavior:'smooth',block:'start'});
}

reloadCalendar();
</script>
<?php require '_footer.php'; ?>

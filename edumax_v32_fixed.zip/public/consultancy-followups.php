<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_access('consultancy_dashboard');
$_SESSION['workspace'] = 'consultancy';

$error = '';
$success = '';
$today = date('Y-m-d');

try {
    $pdo->query('SELECT 1 FROM consultancy_followups LIMIT 1');
} catch (Throwable $e) {
    $error = 'Follow-ups database table is not installed yet. Please import consultancy-followups.sql first.';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    require_valid_csrf();
    $action = trim((string)($_POST['action'] ?? ''));
    $currentUserId = (int)($_SESSION['user_id'] ?? 0);

    try {
        if ($action === 'create') {
            $enquiryId = (int)($_POST['enquiry_id'] ?? 0);
            $type = trim((string)($_POST['followup_type'] ?? 'Call'));
            $scheduledAt = trim((string)($_POST['scheduled_at'] ?? ''));
            $notes = trim((string)($_POST['notes'] ?? ''));

            $allowedTypes = ['Call','WhatsApp','In Person','Email','Other'];
            if ($enquiryId <= 0) throw new RuntimeException('Please select an enquiry.');
            if (!in_array($type, $allowedTypes, true)) throw new RuntimeException('Invalid follow-up type.');
            if ($scheduledAt === '') throw new RuntimeException('Follow-up date and time are required.');

            $dt = DateTime::createFromFormat('Y-m-d\\TH:i', $scheduledAt);
            if (!$dt || $dt->format('Y-m-d\\TH:i') !== $scheduledAt) {
                throw new RuntimeException('Please enter a valid follow-up date and time.');
            }

            $stmt = $pdo->prepare("SELECT e.id, e.counselor_id, e.status
                FROM consultancy_enquiries e
                WHERE e.id = ? LIMIT 1");
            $stmt->execute([$enquiryId]);
            $enquiry = $stmt->fetch();
            if (!$enquiry) throw new RuntimeException('Selected enquiry was not found.');

            if (in_array((string)$enquiry['status'], ['Closed','Converted','Cancelled'], true)) {
                throw new RuntimeException('A follow-up cannot be created for a closed, converted or cancelled enquiry.');
            }

            $insert = $pdo->prepare("INSERT INTO consultancy_followups
                (enquiry_id, counselor_id, followup_type, scheduled_at, notes, created_by)
                VALUES (?, ?, ?, ?, ?, ?)");
            $insert->execute([
                $enquiryId,
                $enquiry['counselor_id'] !== null ? (int)$enquiry['counselor_id'] : null,
                $type,
                $dt->format('Y-m-d H:i:s'),
                $notes !== '' ? $notes : null,
                $currentUserId ?: null
            ]);

            $success = 'Follow-up scheduled successfully.';
        }

        elseif ($action === 'complete') {
            $id = (int)($_POST['id'] ?? 0);
            $outcome = trim((string)($_POST['outcome'] ?? ''));
            $nextAt = trim((string)($_POST['next_followup_at'] ?? ''));

            if ($id <= 0) throw new RuntimeException('Invalid follow-up selected.');
            if ($outcome === '') throw new RuntimeException('Please enter the follow-up outcome.');

            $nextDateTime = null;
            if ($nextAt !== '') {
                $nextDt = DateTime::createFromFormat('Y-m-d\\TH:i', $nextAt);
                if (!$nextDt || $nextDt->format('Y-m-d\\TH:i') !== $nextAt) {
                    throw new RuntimeException('Please enter a valid next follow-up date and time.');
                }
                $nextDateTime = $nextDt->format('Y-m-d H:i:s');
            }

            $stmt = $pdo->prepare("UPDATE consultancy_followups
                SET status='Completed', outcome=?, next_followup_at=?, completed_by=?, completed_at=NOW()
                WHERE id=? AND status='Pending'");
            $stmt->execute([$outcome, $nextDateTime, $currentUserId ?: null, $id]);

            if ($stmt->rowCount() < 1) {
                throw new RuntimeException('Follow-up was not found or is already closed.');
            }

            if ($nextDateTime !== null) {
                $source = $pdo->prepare("SELECT enquiry_id, counselor_id, followup_type, notes
                    FROM consultancy_followups WHERE id=? LIMIT 1");
                $source->execute([$id]);
                $old = $source->fetch();
                if ($old) {
                    $new = $pdo->prepare("INSERT INTO consultancy_followups
                        (enquiry_id, counselor_id, followup_type, scheduled_at, notes, created_by)
                        VALUES (?, ?, ?, ?, ?, ?)");
                    $new->execute([
                        (int)$old['enquiry_id'],
                        $old['counselor_id'] !== null ? (int)$old['counselor_id'] : null,
                        (string)$old['followup_type'],
                        $nextDateTime,
                        $old['notes'] !== null ? (string)$old['notes'] : null,
                        $currentUserId ?: null
                    ]);
                }
            }

            $success = $nextDateTime !== null
                ? 'Follow-up completed and the next follow-up was scheduled.'
                : 'Follow-up marked as completed.';
        }

        elseif ($action === 'cancel') {
            $id = (int)($_POST['id'] ?? 0);
            if ($id <= 0) throw new RuntimeException('Invalid follow-up selected.');

            $stmt = $pdo->prepare("UPDATE consultancy_followups
                SET status='Cancelled'
                WHERE id=? AND status='Pending'");
            $stmt->execute([$id]);

            if ($stmt->rowCount() < 1) {
                throw new RuntimeException('Follow-up was not found or is already closed.');
            }
            $success = 'Follow-up cancelled.';
        }
    } catch (Throwable $e) {
        $error = $e instanceof RuntimeException
            ? $e->getMessage()
            : 'Unable to complete the requested follow-up action.';
    }
}

$enquiries = [];
$followups = [];
$stats = ['overdue'=>0,'today'=>0,'upcoming'=>0,'completed'=>0];

if ($error === '') {
    $enquiriesStmt = $pdo->query("SELECT e.id, e.enquiry_no, e.full_name, e.mobile,
            e.status, e.counselor_id, c.counselor_name, co.country_name
        FROM consultancy_enquiries e
        LEFT JOIN consultancy_counselors c ON c.id=e.counselor_id
        LEFT JOIN consultancy_countries co ON co.id=e.country_id
        WHERE e.status NOT IN ('Closed','Converted','Cancelled')
        ORDER BY e.created_at DESC");
    $enquiries = $enquiriesStmt->fetchAll();

    $statsStmt = $pdo->query("SELECT
        SUM(CASE WHEN status='Pending' AND scheduled_at < NOW() THEN 1 ELSE 0 END) AS overdue,
        SUM(CASE WHEN status='Pending' AND DATE(scheduled_at)=CURDATE() THEN 1 ELSE 0 END) AS today_count,
        SUM(CASE WHEN status='Pending' AND scheduled_at > NOW() AND DATE(scheduled_at)<>CURDATE() THEN 1 ELSE 0 END) AS upcoming,
        SUM(CASE WHEN status='Completed' THEN 1 ELSE 0 END) AS completed_count
        FROM consultancy_followups");
    $s = $statsStmt->fetch() ?: [];
    $stats = [
        'overdue'=>(int)($s['overdue'] ?? 0),
        'today'=>(int)($s['today_count'] ?? 0),
        'upcoming'=>(int)($s['upcoming'] ?? 0),
        'completed'=>(int)($s['completed_count'] ?? 0),
    ];

    $statusFilter = trim((string)($_GET['status'] ?? 'Pending'));
    $allowedStatusFilters = ['Pending','Completed','Cancelled','All'];
    if (!in_array($statusFilter, $allowedStatusFilters, true)) $statusFilter = 'Pending';

    $where = '';
    $params = [];
    if ($statusFilter !== 'All') {
        $where = 'WHERE f.status = ?';
        $params[] = $statusFilter;
    }

    $list = $pdo->prepare("SELECT f.*, e.enquiry_no, e.full_name, e.mobile,
            co.country_name, c.counselor_name
        FROM consultancy_followups f
        INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
        LEFT JOIN consultancy_countries co ON co.id=e.country_id
        LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id
        {$where}
        ORDER BY CASE WHEN f.status='Pending' THEN 0 ELSE 1 END,
                 CASE WHEN f.status='Pending' THEN f.scheduled_at ELSE f.updated_at END ASC,
                 f.id DESC
        LIMIT 200");
    $list->execute($params);
    $followups = $list->fetchAll();
}

require_once __DIR__ . '/_header.php';
?>

<style>
.fu-wrap{max-width:1180px;margin:28px auto;padding:0 18px}
.fu-head{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin-bottom:20px}
.fu-head h1{margin:0 0 5px;font-size:28px}.fu-head p{margin:0;color:#747a83}
.fu-grid{display:grid!important;visibility:visible!important;opacity:1!important;grid-template-columns:1.05fr 1.95fr;gap:18px;align-items:start}
.fu-card{display:block!important;visibility:visible!important;opacity:1!important;background:#fff;border:1px solid #e5e8ec;border-radius:16px;box-shadow:0 7px 24px rgba(25,30,38,.05);overflow:hidden}
.fu-card-head{padding:18px 20px;border-bottom:1px solid #eceef1}.fu-card-head h2{margin:0;font-size:17px}
.fu-body{display:block!important;visibility:visible!important;opacity:1!important;padding:20px!important;height:auto!important;min-height:40px!important}
.consult-fu-form-body,.consult-fu-form-body form{display:block!important;visibility:visible!important;opacity:1!important;}
.consult-fu-form-body .fu-field{display:block!important;visibility:visible!important;opacity:1!important;margin-bottom:14px!important;}
.consult-fu-form-body input,.consult-fu-form-body select,.consult-fu-form-body textarea{display:block!important;visibility:visible!important;opacity:1!important;}.fu-field{display:block!important;visibility:visible!important;opacity:1!important;margin-bottom:14px}.fu-field label{display:block;margin-bottom:6px;font-size:12px;font-weight:750;color:#444a52}
.fu-field input,.fu-field select,.fu-field textarea{width:100%;box-sizing:border-box;border:1px solid #dfe2e6;border-radius:10px;padding:11px 12px;font:inherit;background:#fff}
.fu-field textarea{min-height:90px;resize:vertical}.fu-actions{display:flex;justify-content:flex-end}.fu-btn{border:0;border-radius:10px;background:#c91f2e;color:#fff;padding:11px 16px;font-weight:800;cursor:pointer}
.fu-alert{margin-bottom:18px;padding:12px 14px;border-radius:10px;font-size:13px}.fu-error{background:#fff1f2;color:#a71928;border:1px solid #f3c6cb}.fu-success{background:#eefaf2;color:#176b39;border:1px solid #c8e8d3}
.fu-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}.fu-stat{background:#fff;border:1px solid #e5e8ec;border-radius:14px;padding:16px}.fu-stat strong{display:block;font-size:24px}.fu-stat span{font-size:11px;color:#777f88}.fu-list-tools{display:flex;justify-content:flex-end;margin-bottom:12px}.fu-list-tools select{border:1px solid #dfe2e6;border-radius:9px;padding:9px 11px;background:#fff}
.fu-table{width:100%;border-collapse:collapse}.fu-table th,.fu-table td{padding:12px 10px;border-bottom:1px solid #eef0f2;text-align:left;vertical-align:top;font-size:12px}.fu-table th{font-size:10px;text-transform:uppercase;letter-spacing:.04em;color:#747b84}.fu-name{font-weight:800;color:#222}.fu-sub{font-size:10px;color:#818892;margin-top:3px}.fu-badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:800}.fu-pending{background:#fff5dd;color:#8b6100}.fu-completed{background:#eaf8ef;color:#176b39}.fu-cancelled{background:#f2f3f5;color:#69707a}.fu-overdue{color:#b3192b;font-weight:800}.fu-today{color:#a35d00;font-weight:800}.fu-row-actions{display:flex;gap:6px;flex-wrap:wrap}.fu-small-btn{border:1px solid #dfe2e6;background:#fff;border-radius:8px;padding:7px 9px;font-size:10px;font-weight:750;cursor:pointer}.fu-small-btn.primary{background:#c91f2e;color:#fff;border-color:#c91f2e}.fu-empty{text-align:center;padding:35px 15px;color:#858b93;font-size:13px}
@media(max-width:1000px){.fu-grid{grid-template-columns:1fr}.fu-stats{grid-template-columns:repeat(2,1fr)}}
@media(max-width:700px){.fu-wrap{padding:0 12px}.fu-head{display:block}.fu-stats{grid-template-columns:1fr 1fr}.fu-table{min-width:900px}.fu-card:has(.fu-table){overflow:auto}}
</style>

<div class="fu-wrap">
    <div class="fu-head">
        <div>
            <h1>Consultancy Follow-ups</h1>
            <p>Schedule, track and complete student follow-ups from consultancy enquiries.</p>
        </div>
    </div>

    <?php if ($error !== ''): ?><div class="fu-alert fu-error"><?=e($error)?></div><?php endif; ?>
    <?php if ($success !== ''): ?><div class="fu-alert fu-success"><?=e($success)?></div><?php endif; ?>

    <?php if ($error === ''): ?>
        <div class="fu-stats">
            <div class="fu-stat"><strong><?=number_format($stats['overdue'])?></strong><span>Overdue</span></div>
            <div class="fu-stat"><strong><?=number_format($stats['today'])?></strong><span>Today</span></div>
            <div class="fu-stat"><strong><?=number_format($stats['upcoming'])?></strong><span>Upcoming</span></div>
            <div class="fu-stat"><strong><?=number_format($stats['completed'])?></strong><span>Completed</span></div>
        </div>

        <div class="fu-grid">
            <section class="fu-card" style="display:block !important; visibility:visible !important; opacity:1 !important; overflow:visible !important;">
                <div class="fu-card-head"><h2>Schedule New Follow-up</h2></div>
                <div class="consult-fu-form-body" style="display:block !important; visibility:visible !important; opacity:1 !important; padding:20px !important; height:auto !important; min-height:300px !important; overflow:visible !important; background:#fff !important;">
                    <form method="post" style="display:block !important; visibility:visible !important; opacity:1 !important;">
                        <?=csrf_input()?>
                        <input type="hidden" name="action" value="create">

                        <div class="fu-field">
                            <label>Enquiry *</label>
                            <select name="enquiry_id" required>
                                <option value="">Select enquiry</option>
                                <?php foreach ($enquiries as $enq): ?>
                                    <option value="<?=e((string)$enq['id'])?>">
                                        <?=e($enq['enquiry_no'].' — '.$enq['full_name'].' — '.($enq['country_name'] ?? ''))?>
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>

                        <div class="fu-field">
                            <label>Follow-up Type *</label>
                            <select name="followup_type" required>
                                <option>Call</option><option>WhatsApp</option><option>In Person</option><option>Email</option><option>Other</option>
                            </select>
                        </div>

                        <div class="fu-field">
                            <label>Follow-up Date & Time *</label>
                            <input type="datetime-local" name="scheduled_at" required>
                        </div>

                        <div class="fu-field">
                            <label>Notes</label>
                            <textarea name="notes" placeholder="What needs to be discussed or checked?"></textarea>
                        </div>

                        <div class="fu-actions"><button class="fu-btn" type="submit">Schedule Follow-up</button></div>
                    </form>
                </div>
            </section>

            <section class="fu-card">
                <div class="fu-card-head"><h2>Follow-up List</h2></div>
                <div class="fu-body">
                    <div class="fu-list-tools">
                        <form method="get">
                            <select name="status" onchange="this.form.submit()">
                                <?php foreach (['Pending','Completed','Cancelled','All'] as $opt): ?>
                                    <option value="<?=e($opt)?>" <?=$statusFilter===$opt?'selected':''?>><?=e($opt)?></option>
                                <?php endforeach; ?>
                            </select>
                        </form>
                    </div>

                    <?php if (!$followups): ?>
                        <div class="fu-empty">No follow-ups found for this filter.</div>
                    <?php else: ?>
                        <table class="fu-table">
                            <thead><tr><th>Student</th><th>Schedule</th><th>Counselor</th><th>Status</th><th>Action</th></tr></thead>
                            <tbody>
                            <?php foreach ($followups as $f): ?>
                                <?php
                                    $scheduledTs = strtotime((string)$f['scheduled_at']);
                                    $isOverdue = $f['status']==='Pending' && $scheduledTs < time();
                                    $isToday = $f['status']==='Pending' && date('Y-m-d',$scheduledTs)===$today;
                                    $badgeClass = $f['status']==='Completed' ? 'fu-completed' : ($f['status']==='Cancelled' ? 'fu-cancelled' : 'fu-pending');
                                ?>
                                <tr>
                                    <td>
                                        <div class="fu-name"><?=e((string)$f['full_name'])?></div>
                                        <div class="fu-sub"><?=e((string)$f['enquiry_no'])?> · <?=e((string)($f['country_name'] ?? ''))?></div>
                                        <div class="fu-sub"><?=e((string)$f['mobile'])?></div>
                                    </td>
                                    <td>
                                        <div class="<?= $isOverdue ? 'fu-overdue' : ($isToday ? 'fu-today' : '') ?>">
                                            <?=e(date('d M Y, h:i A',$scheduledTs))?>
                                        </div>
                                        <div class="fu-sub"><?=e((string)$f['followup_type'])?></div>
                                    </td>
                                    <td><?=e((string)($f['counselor_name'] ?? 'Unassigned'))?></td>
                                    <td><span class="fu-badge <?=$badgeClass?>"><?=e((string)$f['status'])?></span></td>
                                    <td>
                                        <?php if ($f['status']==='Pending'): ?>
                                            <div class="fu-row-actions">
                                                <button type="button" class="fu-small-btn primary" onclick="document.getElementById('complete-<?=e((string)$f['id'])?>').showModal()">Complete</button>
                                                <form method="post" onsubmit="return confirm('Cancel this follow-up?');" style="display:inline">
                                                    <?=csrf_input()?>
                                                    <input type="hidden" name="action" value="cancel">
                                                    <input type="hidden" name="id" value="<?=e((string)$f['id'])?>">
                                                    <button class="fu-small-btn" type="submit">Cancel</button>
                                                </form>
                                            </div>
                                            <dialog id="complete-<?=e((string)$f['id'])?>" style="border:0;border-radius:14px;padding:0;max-width:460px;width:calc(100% - 30px)">
                                                <form method="post" style="padding:22px">
                                                    <?=csrf_input()?>
                                                    <input type="hidden" name="action" value="complete">
                                                    <input type="hidden" name="id" value="<?=e((string)$f['id'])?>">
                                                    <h3 style="margin-top:0">Complete Follow-up</h3>
                                                    <p style="font-size:12px;color:#777">Record what happened and optionally schedule the next follow-up.</p>
                                                    <div class="fu-field"><label>Outcome *</label><textarea name="outcome" required></textarea></div>
                                                    <div class="fu-field"><label>Next Follow-up (optional)</label><input type="datetime-local" name="next_followup_at"></div>
                                                    <div style="display:flex;justify-content:flex-end;gap:8px"><button type="button" class="fu-small-btn" onclick="this.closest('dialog').close()">Close</button><button class="fu-btn" type="submit">Save Outcome</button></div>
                                                </form>
                                            </dialog>
                                        <?php else: ?>
                                            <?php if (!empty($f['outcome'])): ?><div class="fu-sub" style="max-width:230px"><?=e((string)$f['outcome'])?></div><?php endif; ?>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                            </tbody>
                        </table>
                    <?php endif; ?>
                </div>
            </section>
        </div>
    <?php endif; ?>
</div>

</main>
</div>
</body>
</html>

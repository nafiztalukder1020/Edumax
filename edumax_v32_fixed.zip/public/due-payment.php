<?php
require_once __DIR__ . '/../config/app.php';
require_access('payments');

$studentCode = trim($_GET['id'] ?? '');
if ($studentCode === '') {
    exit('Student ID is required.');
}

/*
 * Always use the latest non-cancelled admission for this student.
 * This prevents an older admission from being selected when a student
 * has multiple admissions.
 */
$stmt = $pdo->prepare("
    SELECT
        s.*,
        ad.id AS admission_id,
        ad.final_dealing_price,
        ad.status AS admission_status,
        c.name AS course_name,
        b.name AS batch_name
    FROM students s
    JOIN admissions ad ON ad.student_id = s.id
    JOIN courses c ON c.id = ad.course_id
    JOIN batches b ON b.id = ad.batch_id
    WHERE s.student_id = ?
      AND ad.status <> 'Cancelled'
    ORDER BY ad.id DESC
    LIMIT 1
");
$stmt->execute([$studentCode]);
$row = $stmt->fetch();

if (!$row) {
    exit('Admission not found.');
}

$sum = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM payments WHERE admission_id=? AND status='Valid'");
$sum->execute([$row['admission_id']]);
$grossPaid = (float)$sum->fetchColumn();
$refundSum = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE admission_id=? AND status='Valid'");
$refundSum->execute([$row['admission_id']]);
$refunded = (float)$refundSum->fetchColumn();
$paid = max(0, $grossPaid - $refunded);
$due = max(0, (float)$row['final_dealing_price'] - $paid);

$error = '';
$success = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    if ($due <= 0) {
        $error = 'This admission is already fully paid.';
    } elseif ($row['admission_status'] !== 'Approved') {
        $error = 'This admission is not available for due payment.';
    } else {

        $amount = (float)($_POST['amount'] ?? 0);
        $method = $_POST['method'] ?? 'Cash';
        $ref = trim($_POST['reference'] ?? '');

        if ($amount <= 0) {
            $error = 'Enter a valid payment amount.';
        } elseif ($amount > $due + 0.0001) {
            $error = 'Payment cannot be greater than current due.';
        } elseif (!in_array($method, ['Cash', 'bKash', 'Nagad', 'Bank', 'Other'], true)) {
            $error = 'Invalid payment method.';
        }

        if ($error === '') {
            try {
                /*
                 * Lock the admission row first. This serializes two simultaneous
                 * due-payment submissions for the same admission.
                 */
                $pdo->beginTransaction();

                $lock = $pdo->prepare("
                    SELECT
                        ad.id,
                        ad.student_id,
                        ad.final_dealing_price,
                        ad.status
                    FROM admissions ad
                    WHERE ad.id = ?
                    FOR UPDATE
                ");
                $lock->execute([(int)$row['admission_id']]);
                $lockedAdmission = $lock->fetch();

                if (!$lockedAdmission) {
                    throw new RuntimeException('Admission not found. Please refresh and try again.');
                }

                if ($lockedAdmission['status'] !== 'Approved') {
                    throw new RuntimeException('This admission is no longer available for due payment.');
                }

                $check = $pdo->prepare("
                    SELECT COALESCE(SUM(amount), 0)
                    FROM payments
                    WHERE admission_id = ?
                      AND status = 'Valid'
                ");
                $check->execute([(int)$row['admission_id']]);

                $livePaid = (float)$check->fetchColumn();
                $liveRefundStmt = $pdo->prepare("SELECT COALESCE(SUM(amount),0) FROM refunds WHERE admission_id=? AND status='Valid'");
                $liveRefundStmt->execute([(int)$row['admission_id']]);
                $liveRefunded = (float)$liveRefundStmt->fetchColumn();
                $liveNetPaid = max(0, $livePaid - $liveRefunded);
                $liveDue = max(0, (float)$lockedAdmission['final_dealing_price'] - $liveNetPaid);

                if ($liveDue <= 0) {
                    throw new RuntimeException('This admission is already fully paid.');
                }

                if ($amount > $liveDue + 0.0001) {
                    throw new RuntimeException(
                        'Current due has changed. Maximum payable amount is ' .
                        number_format($liveDue, 2) . '.'
                    );
                }

                /*
                 * next_receipt_number() now only uses transactional DML.
                 * The receipt_sequences table is created at app bootstrap,
                 * never inside this transaction.
                 */
                $receipt = next_receipt_number();

                $p = $pdo->prepare("
                    INSERT INTO payments
                    (student_id, admission_id, receipt_no, amount, method, note, received_by, status)
                    VALUES (?, ?, ?, ?, ?, ?, ?, 'Valid')
                ");

                $p->execute([
                    (int)$lockedAdmission['student_id'],
                    (int)$lockedAdmission['id'],
                    $receipt,
                    $amount,
                    $method,
                    $ref !== '' ? $ref : null,
                    $_SESSION['user_id']
                ]);

                // Refund-aware calculation: Total Paid = Valid Payments - Valid Refunds.
                // The new payment increases net paid; existing valid refunds must remain deducted.
                $newNetPaid = $liveNetPaid + $amount;
                $newDue = max(
                    0,
                    (float)$lockedAdmission['final_dealing_price'] - $newNetPaid
                );

                $newStatus = $newDue <= 0.0001 ? 'Active' : 'Approved';

                $u = $pdo->prepare("
                    UPDATE admissions
                    SET status = ?
                    WHERE id = ?
                ");
                $u->execute([
                    $newStatus,
                    (int)$lockedAdmission['id']
                ]);

                $ua = $pdo->prepare("
                    UPDATE applications
                    SET status = ?
                    WHERE student_id = ?
                ");
                $ua->execute([
                    $newStatus,
                    (int)$lockedAdmission['student_id']
                ]);

                $audit = $pdo->prepare("
                    INSERT INTO audit_logs
                    (user_id, action, student_id, details)
                    VALUES (?, ?, ?, ?)
                ");

                $audit->execute([
                    $_SESSION['user_id'],
                    'Due Payment Received',
                    (int)$lockedAdmission['student_id'],
                    'Payment: ' . $amount .
                    ', method: ' . $method .
                    ', receipt: ' . $receipt .
                    ', net paid: ' . $newNetPaid .
                    ', new due: ' . $newDue .
                    ', status: ' . $newStatus
                ]);

                $pdo->commit();

                header(
                    'Location: due-payment.php?id=' .
                    urlencode($studentCode) .
                    '&saved=' .
                    urlencode($receipt)
                );
                exit;

            } catch (Throwable $e) {

                if ($pdo->inTransaction()) {
                    $pdo->rollBack();
                }

                $error = $e->getMessage();
            }
        }
    }
}

if (isset($_GET['saved'])) {
    $success = 'Payment received successfully. Receipt: ' . $_GET['saved'];
}

require '_header.php';
?>

<div class="section-title">
    <div>
        <h1>Due Payment</h1>
        <p><?= e($row['full_name']) ?> · <?= e($row['student_id']) ?></p>
    </div>

    <a
        class="btn btn-light"
        href="admission-review.php?id=<?= urlencode($studentCode) ?>"
    >
        ← Back to Admission
    </a>
</div>

<?php if ($success): ?>
    <div class="success"><?= e($success) ?></div>
<?php endif; ?>

<?php if ($error): ?>
    <div class="alert"><?= e($error) ?></div>
<?php endif; ?>

<div class="card edmx-card">
    <h2>Payment Summary</h2>

    <div class="form-grid">

        <div>
            <small>Course</small>
            <strong><?= e($row['course_name']) ?></strong>
        </div>

        <div>
            <small>Batch</small>
            <strong><?= e($row['batch_name']) ?></strong>
        </div>

        <div>
            <small>Final Dealing Price</small>
            <strong>
                ৳ <?= number_format((float)$row['final_dealing_price'], 2) ?>
            </strong>
        </div>

        <div>
            <small>Total Paid</small>
            <strong>৳ <?= number_format($paid, 2) ?></strong>
        </div>

        <div>
            <small>Current Due</small>
            <strong style="color:#c91f2e">
                ৳ <?= number_format($due, 2) ?>
            </strong>
        </div>

        <div>
            <small>Status</small>
            <strong><?= e($row['admission_status']) ?></strong>
        </div>

    </div>
</div>

<br>

<?php if ($due > 0 && $row['admission_status'] === 'Approved'): ?>

    <div class="card edmx-card">

        <h2>Receive Due Payment</h2>

        <p style="color:#737982;margin-top:4px">
            Only this payment transaction can be added.
            The original deal is locked.
        </p>

        <form method="post">

            <?= csrf_input() ?>

            <div class="form-grid">

                <div>
                    <label>Payment Amount</label>

                    <input
                        type="number"
                        name="amount"
                        step="0.01"
                        min="0.01"
                        max="<?= e((string)$due) ?>"
                        required
                    >
                </div>

                <div>
                    <label>Payment Method</label>

                    <select name="method">
                        <option>Cash</option>
                        <option>bKash</option>
                        <option>Nagad</option>
                        <option>Bank</option>
                        <option>Other</option>
                    </select>
                </div>

                <div>
                    <label>Reference</label>

                    <input
                        type="text"
                        name="reference"
                        placeholder="Optional reference"
                        maxlength="180"
                    >
                </div>

            </div>

            <div class="actions" style="margin-top:18px">

                <button
                    class="btn btn-primary"
                    type="submit"
                >
                    Save Due Payment
                </button>

            </div>

        </form>

    </div>

<?php elseif ($due <= 0): ?>

    <div class="card edmx-card">
        <h2>Payment Complete</h2>
        <p>
            No due payment is available.
            This admission is fully paid and the student is Active.
        </p>
    </div>

<?php else: ?>

    <div class="card edmx-card">
        <h2>Due Payment Unavailable</h2>
        <p>
            This admission is not currently available for a due payment.
        </p>
    </div>

<?php endif; ?>

<?php require '_footer.php'; ?>

<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';

/* Management users must remain in the main Management System. */
if (!empty($_SESSION['user_id'])) {
    require_admin();
    if (user_has_permission('consultancy_dashboard')) {
        $_SESSION['workspace'] = 'consultancy';
        header('Location: consultancy-dashboard.php');
        exit;
    }
}

if (!empty($_SESSION['counselor_id'])) {
    header('Location: consultancy-counselor-dashboard.php');
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();
    $username = trim((string)($_POST['username'] ?? ''));
    $password = (string)($_POST['password'] ?? '');

    if (login_is_locked('counselor', $username)) {
        $error = 'Too many failed login attempts. Please wait ' . LOGIN_LOCK_MINUTES . ' minutes and try again.';
    } else try {
        $stmt = $pdo->prepare("SELECT id,counselor_name,username,password_hash,status FROM consultancy_counselors WHERE username=? LIMIT 1");
        $stmt->execute([$username]);
        $c = $stmt->fetch();

        if ($c && $c['status'] === 'Active' && !empty($c['password_hash']) && password_verify($password, $c['password_hash'])) {
            login_record_attempt('counselor', $username, true);
            session_regenerate_id(true);
            $_SESSION['counselor_id'] = (int)$c['id'];
            $_SESSION['counselor_name'] = $c['counselor_name'];
            $_SESSION['counselor_username'] = $c['username'];
            header('Location: consultancy-counselor-dashboard.php');
            exit;
        }
        login_record_attempt('counselor', $username, false);
        $error = 'Invalid username or password.';
    } catch (Throwable $e) {
        $error = 'Counselor login is temporarily unavailable.';
    }
}
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>Edumax Counselor Login</title>
<style>
*{box-sizing:border-box}body{margin:0;min-height:100vh;font-family:Arial,sans-serif;background:#f5f6f8;display:flex;align-items:center;justify-content:center;padding:20px;color:#20242b}
.box{width:100%;max-width:420px;background:#fff;border:1px solid #e5e7eb;border-radius:18px;padding:30px;box-shadow:0 18px 50px rgba(0,0,0,.08)}
.logo{text-align:center;font-size:25px;font-weight:900;color:#c91f2e;margin-bottom:8px}.sub{text-align:center;color:#737982;font-size:13px;margin-bottom:25px}
label{display:block;font-size:12px;font-weight:800;margin:0 0 7px}input{width:100%;padding:13px;border:1px solid #dfe2e7;border-radius:10px;margin-bottom:15px;font-size:14px}
button{width:100%;padding:13px;border:0;border-radius:10px;background:#c91f2e;color:#fff;font-weight:800;cursor:pointer}
.err{padding:11px;border-radius:9px;background:#fff1f2;color:#a71928;border:1px solid #f3c6cb;font-size:12px;margin-bottom:15px}
.note{margin-top:18px;text-align:center;color:#8a9097;font-size:11px;line-height:1.5}
</style></head>
<body><div class="box">
<div class="logo">EDUMAX</div><div class="sub">Consultancy Counselor Workspace</div>
<?php if($error): ?><div class="err"><?=e($error)?></div><?php endif; ?>
<form method="post">
<?=csrf_input()?>
<label>Username</label><input name="username" autocomplete="username" required>
<label>Password</label><input type="password" name="password" autocomplete="current-password" required>
<button type="submit">Login to Counselor Workspace</button>
</form>
<div class="note">This workspace is only for assigned consultancy counselors.</div>
</div></body></html>

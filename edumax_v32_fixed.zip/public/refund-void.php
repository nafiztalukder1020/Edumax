<?php
require_once __DIR__ . '/../config/app.php';
require_access('payments');

$id = (int)($_GET['id'] ?? 0);
if ($id <= 0) exit('Refund ID is required.');

$st = $pdo->prepare("SELECT * FROM refunds WHERE id=? AND status='Valid' LIMIT 1");
$st->execute([$id]);
$r = $st->fetch();
if (!$r) exit('Valid refund not found.');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require_valid_csrf();

    try {
        $pdo->beginTransaction();

        $lk = $pdo->prepare("SELECT * FROM refunds WHERE id=? FOR UPDATE");
        $lk->execute([$id]);
        $r = $lk->fetch();

        if (!$r || $r['status'] !== 'Valid') {
            throw new RuntimeException('Refund is already void or unavailable.');
        }

        $u = $pdo->prepare("UPDATE refunds SET status='Void' WHERE id=?");
        $u->execute([$id]);

        $audit = $pdo->prepare(
            "INSERT INTO audit_logs (user_id,action,student_id,details) VALUES (?,?,?,?)"
        );
        $audit->execute([
            $_SESSION['user_id'],
            'Refund Voided',
            (int)$r['student_id'],
            'Refund no: ' . $r['refund_no'] . ', amount: ' . $r['amount']
        ]);

        $pdo->commit();
        header('Location: refunds.php');
        exit;
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $e->getMessage();
    }
}

require '_header.php';
?>
<div class="section-title">
    <div>
        <h1>Void Refund</h1>
        <p>This keeps the refund history but removes it from net-paid calculations.</p>
    </div>
    <a class="btn btn-light" href="refunds.php">← Back</a>
</div>

<?php if (!empty($error)): ?>
    <div class="alert"><?= e($error) ?></div>
<?php endif; ?>

<div class="card">
    <p>
        Refund <strong><?= e($r['refund_no']) ?></strong> for
        <strong>৳<?= number_format((float)$r['amount'], 2) ?></strong> will be voided.
    </p>

    <form method="post">
        <?= csrf_input() ?>
        <button class="btn btn-primary">Confirm Void</button>
    </form>
</div>

<?php require '_footer.php'; ?>

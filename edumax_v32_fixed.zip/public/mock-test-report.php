<?php
require_once __DIR__ . '/../config/app.php';
require_access('reports');

$from=$_GET['from']??date('Y-m-01');
$to=$_GET['to']??date('Y-m-d');
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)) $from=date('Y-m-01');
if(!preg_match('/^\d{4}-\d{2}-\d{2}$/',$to)) $to=date('Y-m-d');
if($from>$to) [$from,$to]=[$to,$from];

$rows=[]; $summary=['scheduled'=>0,'completed'=>0,'cancelled'=>0];
try {
 $q=$pdo->prepare("SELECT mu.mock_date,mu.mock_day,mu.time_slot,mu.mock_no,mu.status,
     mu.test_type,mu.listening_band,mu.reading_band,mu.writing_band,mu.speaking_band,mu.overall_band,mu.result_note,
     s.student_id,s.full_name,s.mobile,a.mock_package
     FROM mock_test_usage mu
     INNER JOIN admissions a ON a.id=mu.admission_id
     INNER JOIN students s ON s.id=mu.student_id
     WHERE mu.mock_date BETWEEN ? AND ? AND a.status<>'Cancelled'
     ORDER BY mu.mock_date ASC, mu.mock_day ASC, mu.mock_no ASC, s.full_name ASC");
 $q->execute([$from,$to]); $rows=$q->fetchAll();
 foreach($rows as $r) $summary[strtolower($r['status'])]++;
} catch(Throwable $e) {}

$resultCount=0; $resultTotal=0;
foreach($rows as $r){
    if($r['overall_band'] !== null){
        $resultCount++;
        $resultTotal += (float)$r['overall_band'];
    }
}
$averageOverall = $resultCount ? round($resultTotal/$resultCount,1) : 0;

$admissions=0;$collection=0;
try {
 $q=$pdo->prepare("SELECT COUNT(*) FROM admissions a INNER JOIN courses c ON c.id=a.course_id WHERE LOWER(c.name)='mock test' AND a.admission_date BETWEEN ? AND ? AND a.status<>'Cancelled'");
 $q->execute([$from,$to]); $admissions=(int)$q->fetchColumn();
 $q=$pdo->prepare("SELECT COALESCE(SUM(p.amount),0) FROM payments p INNER JOIN admissions a ON a.id=p.admission_id INNER JOIN courses c ON c.id=a.course_id WHERE LOWER(c.name)='mock test' AND p.status='Valid' AND DATE(p.created_at) BETWEEN ? AND ?");
 $q->execute([$from,$to]); $collection=(float)$q->fetchColumn();
} catch(Throwable $e) {}

require '_header.php';
?>
<div class="page-header"><div><h1>Mock Test Report</h1><p>Schedule, usage and collection overview</p></div></div>

<form method="get" class="card" style="margin-bottom:18px">
 <div class="form-grid">
  <div><label>From</label><input type="date" name="from" value="<?=e($from)?>"></div>
  <div><label>To</label><input type="date" name="to" value="<?=e($to)?>"></div>
  <div style="align-self:end"><button class="btn btn-primary">Apply</button></div>
 </div>
</form>

<div class="form-grid" style="margin-bottom:18px">
 <div class="card"><small>Mock Admissions</small><h2><?=$admissions?></h2></div>
 <div class="card"><small>Collection</small><h2>৳<?=number_format($collection,2)?></h2></div>
 <div class="card"><small>Scheduled</small><h2><?=$summary['scheduled']?></h2></div>
 <div class="card"><small>Completed</small><h2><?=$summary['completed']?></h2></div>
 <div class="card"><small>Cancelled</small><h2><?=$summary['cancelled']?></h2></div>
 <div class="card"><small>Results Entered</small><h2><?=$resultCount?></h2></div>
 <div class="card"><small>Average Overall</small><h2><?=$resultCount?number_format($averageOverall,1):'—'?></h2></div>
</div>

<div class="card">
 <h2>Mock Schedule</h2>
 <div class="table-wrap"><table class="table">
 <tr><th>Date</th><th>Student</th><th>Package</th><th>Mock</th><th>Time</th><th>Status</th><th>Result</th></tr>
 <?php foreach($rows as $r): ?>
 <tr>
  <td><?=e(date('d M Y',strtotime($r['mock_date'])))?></td>
  <td><strong><?=e($r['full_name'])?></strong><br><small><?=e($r['student_id'])?> | <?=e($r['mobile'])?></small></td>
  <td><?=e($r['mock_package'])?></td>
  <td>#<?=e($r['mock_no'])?><br><small><?=e($r['mock_day'])?></small></td>
  <td><?=e($r['time_slot'])?></td><td><?=e($r['status'])?></td>
  <td>
   <?php if($r['overall_band']!==null): ?>
    <strong><?=number_format((float)$r['overall_band'],1)?></strong><br>
    <small>L <?=number_format((float)$r['listening_band'],1)?> · R <?=number_format((float)$r['reading_band'],1)?> · W <?=number_format((float)$r['writing_band'],1)?> · S <?=number_format((float)$r['speaking_band'],1)?></small>
   <?php else: ?>—<?php endif; ?>
  </td>
 </tr>
 <?php endforeach; ?>
 <?php if(!$rows): ?><tr><td colspan="7">No Mock Test schedule found for this period.</td></tr><?php endif; ?>
 </table></div>
</div>
<?php require '_footer.php'; ?>

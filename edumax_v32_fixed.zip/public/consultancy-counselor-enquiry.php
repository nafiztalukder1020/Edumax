<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
if (empty($_SESSION['counselor_id'])) { header('Location: consultancy-counselor-login.php'); exit; }
$counselorId=(int)$_SESSION['counselor_id']; $id=(int)($_GET['id']??0);
if($id<=0){http_response_code(400);exit('Invalid enquiry.');}
$error='';$success='';
try{
    $q=$pdo->prepare("SELECT e.*,c.country_name,cc.counselor_name FROM consultancy_enquiries e
        LEFT JOIN consultancy_countries c ON c.id=e.country_id
        LEFT JOIN consultancy_counselors cc ON cc.id=e.counselor_id
        WHERE e.id=? AND e.counselor_id=? LIMIT 1");
    $q->execute([$id,$counselorId]); $e=$q->fetch();
    if(!$e){http_response_code(404);exit('Enquiry not found or not assigned to you.');}

    if($_SERVER['REQUEST_METHOD']==='POST'){
        require_valid_csrf(); $action=(string)($_POST['action']??'');
        if($action==='accept'){
            $pdo->beginTransaction();
            $u=$pdo->prepare("UPDATE consultancy_enquiries SET status='Ready for Counselling' WHERE id=? AND counselor_id=? AND status IN ('New','Unassigned')");
            $u->execute([$id,$counselorId]);
            if($u->rowCount() < 1){ throw new RuntimeException('This enquiry is no longer waiting for counselor acceptance.'); }
            $n=$pdo->prepare("UPDATE consultancy_notifications SET is_read=1,read_at=NOW() WHERE counselor_id=? AND enquiry_id=? AND notification_type='New Enquiry'");
            $n->execute([$counselorId,$id]);
            $alert=$pdo->prepare("INSERT INTO consultancy_notifications (counselor_id,enquiry_id,notification_type,title,message) VALUES (?,?,?,?,?)");
            $alert->execute([$counselorId,$id,'Counselor Ready','Counselor Ready for Counselling','Counselor '.$e['counselor_name'].' is ready to counsel '.$e['full_name'].' ('.$e['enquiry_no'].'). Front desk can now send the student.']);
            $pdo->commit(); $success='Ready for Counselling confirmed. Front Desk has been notified.';
        } elseif($action==='start'){
            $pdo->beginTransaction();
            $u=$pdo->prepare("UPDATE consultancy_enquiries SET status='Counselling Started', counselling_date=COALESCE(counselling_date,NOW()) WHERE id=? AND counselor_id=? AND status='Ready for Counselling'");
            $u->execute([$id,$counselorId]);
            if($u->rowCount() < 1){ throw new RuntimeException('Counselling cannot be started from the current status.'); }
            $pdo->prepare("UPDATE consultancy_notifications SET is_read=1,read_at=NOW() WHERE enquiry_id=? AND notification_type='Counselor Ready'")->execute([$id]);
            $pdo->commit(); $success='Counselling started.';
        } elseif($action==='complete'){
            $outcome=trim((string)($_POST['outcome']??''));
            $notes=trim((string)($_POST['counselling_notes']??''));
            $allowed=['Interested','Need More Time','Not Interested'];
            if(!in_array($outcome,$allowed,true)) throw new RuntimeException('Please select a valid counselling outcome.');
            if($notes==='') throw new RuntimeException('Please enter counselling notes before completing the counselling.');
            $pdo->beginTransaction();
            $u=$pdo->prepare("UPDATE consultancy_enquiries SET status='Counselling Completed', counselling_outcome=?, counselling_notes=?, counselling_completed_at=NOW() WHERE id=? AND counselor_id=? AND status='Counselling Started'");
            $u->execute([$outcome,$notes,$id,$counselorId]);
            if($u->rowCount() < 1){ throw new RuntimeException('Counselling cannot be completed from the current status.'); }
            $title='Counselling Completed: '.$e['full_name'];
            $msg='Counselling completed by '.$e['counselor_name'].'. Outcome: '.$outcome.'.';
            $n=$pdo->prepare("INSERT INTO consultancy_notifications (counselor_id,enquiry_id,notification_type,title,message) VALUES (?,?,?,?,?)");
            $n->execute([$counselorId,$id,'Counselling Completed',$title,$msg]);
            $pdo->commit(); $success='Counselling completed and outcome recorded.';
        } elseif($action==='read'){
            $n=$pdo->prepare("UPDATE consultancy_notifications SET is_read=1,read_at=NOW() WHERE counselor_id=? AND enquiry_id=?");
            $n->execute([$counselorId,$id]); $success='Notification marked as read.';
        }
        $q->execute([$id,$counselorId]); $e=$q->fetch();
    }
}catch(Throwable $x){if($pdo->inTransaction())$pdo->rollBack();$error='Unable to load or update this enquiry.';}
function val($v){return ($v===null||$v==='')?'-':e((string)$v);}
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Student Brief</title>
<style>
*{box-sizing:border-box}body{margin:0;background:#f5f6f8;font-family:Arial,sans-serif;color:#20242b}.top{background:#fff;border-bottom:1px solid #e6e8ec;padding:14px 20px;display:flex;justify-content:space-between}.top a{color:#333;text-decoration:none;font-size:12px;font-weight:800}.wrap{max-width:1000px;margin:25px auto;padding:0 16px}.card{background:#fff;border:1px solid #e5e8ec;border-radius:14px;margin-bottom:16px}.head{padding:20px;display:flex;justify-content:space-between;gap:15px}.head h1{margin:0 0 5px;font-size:24px}.sub{color:#777;font-size:12px}.status{padding:7px 10px;border-radius:999px;background:#fbecef;color:#a71928;font-size:11px;font-weight:800;height:max-content}.body{padding:20px;border-top:1px solid #eee}.grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.item{background:#f8f9fa;padding:12px;border-radius:10px}.item span{display:block;color:#7c838b;font-size:10px;margin-bottom:5px}.item strong{font-size:13px}.section{font-size:14px;font-weight:900;margin:20px 0 10px}.actions{display:flex;gap:8px;flex-wrap:wrap}.btn{border:0;border-radius:9px;padding:10px 14px;background:#c91f2e;color:#fff;font-weight:800;text-decoration:none;font-size:12px;cursor:pointer}.btn.light{background:#fff;color:#333;border:1px solid #ddd}.note{padding:13px;background:#fff9e9;border:1px solid #f2df9b;border-radius:10px;color:#705b1d;font-size:11px;line-height:1.6}.alert{padding:11px 13px;border-radius:9px;margin-bottom:14px;font-size:12px}.ok{background:#eefaf2;color:#176b39}.err{background:#fff1f2;color:#a71928}@media(max-width:700px){.grid{grid-template-columns:1fr}.head{display:block}.status{display:inline-block;margin-top:10px}}
</style></head><body>
<div class="top"><strong style="color:#c91f2e">EDUMAX CONSULTANCY</strong><a href="consultancy-counselor-dashboard.php">← Dashboard</a></div>
<div class="wrap">
<?php if($error): ?><div class="alert err"><?=e($error)?></div><?php endif; ?><?php if($success): ?><div class="alert ok"><?=e($success)?></div><?php endif; ?>
<div class="card"><div class="head"><div><h1><?=val($e['full_name'])?></h1><div class="sub"><?=val($e['enquiry_no'])?> · <?=val($e['mobile'])?></div></div><div class="status"><?=val($e['status'])?></div></div>
<div class="body">
<div class="section">🎯 Quick Brief</div><div class="grid">
<div class="item"><span>Preferred Country</span><strong><?=val($e['country_name'])?></strong></div>
<div class="item"><span>Preferred Intake</span><strong><?=val($e['intake'])?></strong></div>
<div class="item"><span>Interested Program</span><strong><?=val($e['program'])?></strong></div>
<div class="item"><span>IELTS Status</span><strong><?=val($e['ielts_status'])?></strong></div>
<div class="item"><span>IELTS Score</span><strong><?=val($e['ielts_score'])?></strong></div>
<div class="item"><span>Lead Source</span><strong><?=val($e['lead_source'])?></strong></div>
</div>
<div class="section">👤 Personal & Academic Information</div><div class="grid">
<div class="item"><span>WhatsApp</span><strong><?=val($e['whatsapp'])?></strong></div><div class="item"><span>Email</span><strong><?=val($e['email'])?></strong></div><div class="item"><span>Date of Birth</span><strong><?=val($e['dob'])?></strong></div>
<div class="item"><span>Education</span><strong><?=val($e['education_level'])?></strong></div><div class="item"><span>Institution</span><strong><?=val($e['institution'])?></strong></div><div class="item"><span>Passing Year / Result</span><strong><?=val($e['passing_year'])?> / <?=val($e['result_value'])?></strong></div>
</div>
<div class="section">💬 Student Message</div><div class="note"><?=val($e['student_message'])?></div>
<div class="section">⚡ Counselling Workflow</div>
<div class="actions">
<?php if(in_array($e['status'],['New','Unassigned'],true)): ?>
<form method="post" style="margin:0"><?=csrf_input()?><input type="hidden" name="action" value="accept"><button class="btn" type="submit">✓ Accept &amp; Ready for Counselling</button></form>
<?php elseif($e['status']==='Ready for Counselling'): ?>
<span class="btn light">✓ Ready for Counselling</span>
<form method="post" style="margin:0"><?=csrf_input()?><input type="hidden" name="action" value="start"><button class="btn" type="submit">▶ Start Counselling</button></form>
<?php elseif($e['status']==='Counselling Started'): ?>
<span class="btn light">▶ Counselling in Progress</span>
<?php elseif($e['status']==='Counselling Completed'): ?>
<span class="btn light">✓ Counselling Completed</span>
<?php endif; ?>
<form method="post" style="margin:0"><?=csrf_input()?><input type="hidden" name="action" value="read"><button class="btn light" type="submit">Mark Notification Read</button></form>
</div>
<?php if($e['status']==='Counselling Started'): ?>
<div class="section">📝 Complete Counselling</div>
<form method="post">
<?=csrf_input()?><input type="hidden" name="action" value="complete">
<label style="display:block;font-size:11px;font-weight:800;margin-bottom:5px">Counselling Outcome</label>
<select name="outcome" required style="width:100%;box-sizing:border-box;border:1px solid #dfe2e6;border-radius:9px;padding:10px 11px;margin-bottom:10px">
<option value="">Select outcome</option><option value="Interested">Interested</option><option value="Need More Time">Need More Time</option><option value="Not Interested">Not Interested</option>
</select>
<label style="display:block;font-size:11px;font-weight:800;margin-bottom:5px">Counselling Notes</label>
<textarea name="counselling_notes" required maxlength="5000" rows="5" placeholder="Record key discussion points, student interest, concerns, preferred options, etc." style="width:100%;box-sizing:border-box;border:1px solid #dfe2e6;border-radius:9px;padding:10px 11px;resize:vertical"></textarea>
<div style="margin-top:10px"><button class="btn" type="submit">✓ Complete Counselling</button></div>
</form>
<?php elseif($e['status']==='Counselling Completed'): ?>
<div class="note" style="margin-top:12px"><strong>Outcome:</strong> <?=val($e['counselling_outcome'])?><br><strong>Notes:</strong><br><?=nl2br(val($e['counselling_notes']))?></div>
<?php endif; ?>
</div></div>
</div></body></html>

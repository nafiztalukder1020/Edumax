<?php
require_once __DIR__ . '/../config/app.php';
require_access('admissions');
$admissionId=(int)($_GET['id']??0);
if($admissionId<=0) exit('Admission ID is required.');
$st=$pdo->prepare("SELECT a.id,s.student_id,a.status FROM admissions a JOIN students s ON s.id=a.student_id WHERE a.id=? LIMIT 1");$st->execute([$admissionId]);$r=$st->fetch();
if(!$r) exit('Admission not found.');
header('Location: admission-review.php?id='.urlencode($r['student_id']));
exit;

<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';

// Logout requires the session's CSRF token so that another website cannot
// silently log users out with a hidden link/image.
$logoutToken = $_POST['_csrf'] ?? $_GET['_csrf'] ?? null;
if (isset($_SESSION['user_id']) && !csrf_validate(is_string($logoutToken) ? $logoutToken : null)) {
    header('Location: workspace-switch.php?to=auto');
    exit;
}

if (isset($_SESSION['user_id'])) {
    try {
        $stmt = $pdo->prepare("INSERT INTO audit_logs (user_id, action, details) VALUES (?, 'Logout', 'User logged out')");
        $stmt->execute([(int)$_SESSION['user_id']]);
    } catch (Throwable $e) {
        // Logout must still succeed even if audit logging is unavailable.
    }
}

$_SESSION = [];

if (ini_get('session.use_cookies')) {
    $params = session_get_cookie_params();
    setcookie(
        session_name(),
        '',
        time() - 42000,
        $params['path'],
        $params['domain'],
        (bool)$params['secure'],
        (bool)$params['httponly']
    );
}

if (session_status() === PHP_SESSION_ACTIVE) {
    session_destroy();
}

header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');
header('Pragma: no-cache');
header('Location: login.php');
exit;

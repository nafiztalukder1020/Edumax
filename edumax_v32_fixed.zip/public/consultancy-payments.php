<?php
declare(strict_types=1);

require_once __DIR__ . '/../config/app.php';
require_access('consultancy_dashboard');
$_SESSION['workspace'] = 'consultancy';

$error = '';
$success = '';
$userId = (int)($_SESSION['user_id'] ?? 0);
$viewFileId = (int)($_GET['file'] ?? 0);

$methods = ['Cash','bKash','Nagad','Bank','Other'];

try {
    $pdo->query('SELECT 1 FROM consultancy_payments LIMIT 1');
    $pdo->query('SELECT 1 FROM consultancy_payment_sequences LIMIT 1');
    $pdo->query('SELECT 1 FROM consultancy_files LIMIT 1');
} catch (Throwable $e) {
    $error = 'Consultancy Payments database tables are not installed. Please verify consultancy_payments, consultancy_payment_sequences and consultancy_files.';
}

function payment_money(float $amount): string {
    return number_format($amount, 2);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST' && $error === '') {
    require_valid_csrf();
    $action = trim((string)($_POST['action'] ?? ''));

    try {
        if ($action === 'add_payment') {
            $fileId = (int)($_POST['file_id'] ?? 0);
            $amount = (float)($_POST['amount'] ?? 0);
            $method = trim((string)($_POST['method'] ?? 'Cash'));
            $reference = trim((string)($_POST['reference_no'] ?? ''));
            $note = trim((string)($_POST['note'] ?? ''));

            if ($fileId <= 0) throw new RuntimeException('Please select a consultancy file.');
            if ($amount <= 0) throw new RuntimeException('Payment amount must be greater than 0.');
            if (!in_array($method, $methods, true)) throw new RuntimeException('Invalid payment method.');
            if (strlen($reference) > 120) throw new RuntimeException('Reference number is too long.');
            if (strlen($note) > 500) throw new RuntimeException('Payment note is too long.');

            $pdo->beginTransaction();

            $q = $pdo->prepare(
                "SELECT f.id,f.file_no,f.service_fee,f.file_status,e.enquiry_no,e.full_name,
                        co.country_name,c.counselor_name
                 FROM consultancy_files f
                 INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
                 LEFT JOIN consultancy_countries co ON co.id=f.country_id
                 LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id
                 WHERE f.id=? LIMIT 1 FOR UPDATE"
            );
            $q->execute([$fileId]);
            $file = $q->fetch();

            if (!$file) throw new RuntimeException('Selected consultancy file was not found.');
            if ((string)$file['file_status'] === 'Cancelled') {
                throw new RuntimeException('Payment cannot be collected for a cancelled consultancy file.');
            }

            $q = $pdo->prepare(
                "SELECT COALESCE(SUM(amount),0)
                 FROM consultancy_payments
                 WHERE file_id=? AND status='Valid'"
            );
            $q->execute([$fileId]);
            $paid = (float)$q->fetchColumn();
            $serviceFee = (float)$file['service_fee'];
            $due = max(0.0, $serviceFee - $paid);

            if ($due <= 0.0001) {
                throw new RuntimeException('This consultancy file has no outstanding due.');
            }
            if ($amount - $due > 0.0001) {
                throw new RuntimeException(
                    'Payment exceeds the current due. Current due is ৳'.payment_money($due).'.'
                );
            }

            $year = (int)date('Y');

            $q = $pdo->prepare(
                "INSERT IGNORE INTO consultancy_payment_sequences(payment_year,next_number)
                 VALUES(?,1)"
            );
            $q->execute([$year]);

            $q = $pdo->prepare(
                "SELECT next_number
                 FROM consultancy_payment_sequences
                 WHERE payment_year=? FOR UPDATE"
            );
            $q->execute([$year]);
            $next = (int)$q->fetchColumn();

            if ($next < 1) throw new RuntimeException('Unable to reserve a payment number.');

            $q = $pdo->prepare(
                "UPDATE consultancy_payment_sequences
                 SET next_number=?
                 WHERE payment_year=?"
            );
            $q->execute([$next + 1, $year]);

            $paymentNo = 'EDU-CP-'.$year.'-'.str_pad((string)$next, 5, '0', STR_PAD_LEFT);

            $q = $pdo->prepare(
                "INSERT INTO consultancy_payments
                 (payment_no,file_id,amount,method,reference_no,note,received_by,status)
                 VALUES(?,?,?,?,?,?,?,'Valid')"
            );
            $q->execute([
                $paymentNo,
                $fileId,
                number_format($amount, 2, '.', ''),
                $method,
                $reference !== '' ? $reference : null,
                $note !== '' ? $note : null,
                $userId ?: null
            ]);

            $pdo->commit();

            $success = 'Payment received successfully: '.$paymentNo;
            $viewFileId = $fileId;
        }

        elseif ($action === 'void_payment') {
            $paymentId = (int)($_POST['payment_id'] ?? 0);
            if ($paymentId <= 0) throw new RuntimeException('Invalid payment selected.');

            $pdo->beginTransaction();

            $q = $pdo->prepare(
                "SELECT id,payment_no,file_id,amount,status
                 FROM consultancy_payments
                 WHERE id=? LIMIT 1 FOR UPDATE"
            );
            $q->execute([$paymentId]);
            $payment = $q->fetch();

            if (!$payment) throw new RuntimeException('Payment was not found.');
            if ((string)$payment['status'] !== 'Valid') {
                throw new RuntimeException('This payment is already void.');
            }

            $q = $pdo->prepare(
                "SELECT id,file_status
                 FROM consultancy_files
                 WHERE id=? LIMIT 1 FOR UPDATE"
            );
            $q->execute([(int)$payment['file_id']]);
            $file = $q->fetch();

            if (!$file) throw new RuntimeException('Linked consultancy file was not found.');

            $q = $pdo->prepare(
                "UPDATE consultancy_payments SET status='Void' WHERE id=? AND status='Valid'"
            );
            $q->execute([$paymentId]);

            if ($q->rowCount() !== 1) {
                throw new RuntimeException('Payment could not be voided.');
            }

            $pdo->commit();

            $success = 'Payment '.$payment['payment_no'].' was voided.';
            $viewFileId = (int)$payment['file_id'];
        }
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $error = $e instanceof RuntimeException
            ? $e->getMessage()
            : 'Unable to complete the payment action.';
    }
}

$files = [];
$payments = [];
$selectedFile = null;
$stats = ['total'=>0,'valid'=>0,'void'=>0,'received'=>0.0];

if ($error === '') {
    $files = $pdo->query(
        "SELECT
            f.id,f.file_no,f.service_fee,f.file_status,f.opening_date,
            e.enquiry_no,e.full_name,e.mobile,
            co.country_name,c.counselor_name,
            COALESCE((
                SELECT SUM(cp.amount)
                FROM consultancy_payments cp
                WHERE cp.file_id=f.id AND cp.status='Valid'
            ),0) AS total_paid
         FROM consultancy_files f
         INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
         LEFT JOIN consultancy_countries co ON co.id=f.country_id
         LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id
         WHERE f.file_status <> 'Cancelled'
         ORDER BY f.opening_date DESC,f.id DESC
         LIMIT 300"
    )->fetchAll();

    $s = $pdo->query(
        "SELECT
            COUNT(*) total,
            COALESCE(SUM(status='Valid'),0) valid_count,
            COALESCE(SUM(status='Void'),0) void_count,
            COALESCE(SUM(CASE WHEN status='Valid' THEN amount ELSE 0 END),0) received
         FROM consultancy_payments"
    )->fetch() ?: [];

    $stats = [
        'total'=>(int)($s['total'] ?? 0),
        'valid'=>(int)($s['valid_count'] ?? 0),
        'void'=>(int)($s['void_count'] ?? 0),
        'received'=>(float)($s['received'] ?? 0)
    ];

    if ($viewFileId > 0) {
        $q = $pdo->prepare(
            "SELECT
                f.*,e.enquiry_no,e.full_name,e.mobile,e.whatsapp,e.email,
                e.intake,e.program,e.ielts_status,e.ielts_score,
                co.country_name,c.counselor_name,
                COALESCE((
                    SELECT SUM(cp.amount)
                    FROM consultancy_payments cp
                    WHERE cp.file_id=f.id AND cp.status='Valid'
                ),0) AS total_paid
             FROM consultancy_files f
             INNER JOIN consultancy_enquiries e ON e.id=f.enquiry_id
             LEFT JOIN consultancy_countries co ON co.id=f.country_id
             LEFT JOIN consultancy_counselors c ON c.id=f.counselor_id
             WHERE f.id=? LIMIT 1"
        );
        $q->execute([$viewFileId]);
        $selectedFile = $q->fetch();

        if (!$selectedFile) {
            $error = 'Selected consultancy file was not found.';
            $viewFileId = 0;
        } else {
            $q = $pdo->prepare(
                "SELECT p.*,u.name AS receiver_name
                 FROM consultancy_payments p
                 LEFT JOIN users u ON u.id=p.received_by
                 WHERE p.file_id=?
                 ORDER BY p.id DESC"
            );
            try {
                $q->execute([$viewFileId]);
            } catch (Throwable $e) {
                $q = $pdo->prepare(
                    "SELECT p.*
                     FROM consultancy_payments p
                     WHERE p.file_id=?
                     ORDER BY p.id DESC"
                );
                $q->execute([$viewFileId]);
            }
            $payments = $q->fetchAll();
        }
    }
}
?>
<?php require_once __DIR__ . '/_header.php'; ?>

<style>
.cp-wrap{max-width:1240px;margin:28px auto;padding:0 18px}
.cp-head{margin-bottom:20px}.cp-head h1{margin:0 0 5px;font-size:28px}.cp-head p{margin:0;color:#747a83}
.cp-alert{margin-bottom:18px;padding:12px 14px;border-radius:10px;font-size:13px}
.cp-error{background:#fff1f2;color:#a71928;border:1px solid #f3c6cb}
.cp-success{background:#eefaf2;color:#176b39;border:1px solid #c8e8d3}
.cp-stats{display:grid;grid-template-columns:repeat(4,1fr);gap:12px;margin-bottom:18px}
.cp-stat{background:#fff;border:1px solid #e5e8ec;border-radius:14px;padding:16px}
.cp-stat strong{display:block;font-size:24px}.cp-stat span{font-size:11px;color:#777f88}
.cp-grid{display:grid;grid-template-columns:390px 1fr;gap:18px}
.cp-card{background:#fff;border:1px solid #e5e8ec;border-radius:16px;box-shadow:0 7px 24px rgba(25,30,38,.05);overflow:hidden}
.cp-card-head{padding:18px 20px;border-bottom:1px solid #eceef1}.cp-card-head h2{margin:0;font-size:17px}
.cp-body{padding:20px}
.cp-field{margin-bottom:14px}.cp-field label{display:block;margin-bottom:6px;font-size:12px;font-weight:750;color:#444a52}
.cp-field input,.cp-field select,.cp-field textarea{width:100%;box-sizing:border-box;border:1px solid #dfe2e6;border-radius:10px;padding:11px 12px;font:inherit;background:#fff}
.cp-field textarea{min-height:80px;resize:vertical}
.cp-btn{border:0;border-radius:10px;background:#c91f2e;color:#fff;padding:11px 16px;font-weight:800;cursor:pointer}
.cp-link{display:inline-block;padding:7px 9px;border:1px solid #dfe2e6;border-radius:8px;color:#333;text-decoration:none;font-size:10px;font-weight:750;background:#fff}
.cp-actions{display:flex;justify-content:flex-end;gap:8px}
.cp-table-wrap{overflow:auto}.cp-table{width:100%;border-collapse:collapse;min-width:900px}
.cp-table th,.cp-table td{padding:12px 10px;border-bottom:1px solid #eef0f2;text-align:left;vertical-align:top;font-size:12px}
.cp-table th{font-size:10px;color:#747b84;text-transform:uppercase}
.cp-name{font-weight:800}.cp-sub{font-size:10px;color:#818892;margin-top:3px}
.cp-badge{display:inline-flex;padding:5px 8px;border-radius:999px;font-size:10px;font-weight:800}
.cp-valid{background:#eaf8ef;color:#176b39}.cp-void{background:#f2f3f5;color:#69707a}
.cp-open{background:#eef4ff;color:#315b9b}.cp-processing{background:#fff5dd;color:#8b6100}
.cp-due{font-weight:850}.cp-paid{color:#176b39}.cp-empty{text-align:center;padding:35px;color:#858b93}
.cp-detail{margin-top:18px}.cp-info-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}
.cp-info{padding:12px;background:#f8f9fa;border-radius:10px}.cp-info span{display:block;font-size:10px;color:#7b828b;margin-bottom:4px}.cp-info strong{font-size:13px}
.cp-summary{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:18px 0}
.cp-summary-box{padding:14px;border-radius:12px;background:#f8f9fa}.cp-summary-box span{display:block;font-size:10px;color:#777}.cp-summary-box strong{display:block;font-size:20px;margin-top:3px}
.cp-pay-form{max-width:650px}
@media(max-width:1050px){.cp-grid{grid-template-columns:1fr}.cp-info-grid,.cp-summary{grid-template-columns:1fr 1fr}}
@media(max-width:700px){.cp-wrap{padding:0 12px}.cp-stats{grid-template-columns:1fr 1fr}.cp-info-grid,.cp-summary{grid-template-columns:1fr}}
</style>

<div class="cp-wrap">
  <div class="cp-head">
    <h1>Consultancy Payments</h1>
    <p>Receive and track payments against consultancy files.</p><div style="margin-top:12px"><a class="cp-btn" style="display:inline-block;text-decoration:none" href="consultancy-receipts.php">🧾 Receipt List</a></div>
  </div>

  <?php if($error!==''): ?><div class="cp-alert cp-error"><?=e($error)?></div><?php endif; ?>
  <?php if($success!==''): ?><div class="cp-alert cp-success"><?=e($success)?></div><?php endif; ?>

  <?php if($error==='' || $selectedFile): ?>
    <div class="cp-stats">
      <div class="cp-stat"><strong><?=number_format($stats['total'])?></strong><span>Total Transactions</span></div>
      <div class="cp-stat"><strong><?=number_format($stats['valid'])?></strong><span>Valid Payments</span></div>
      <div class="cp-stat"><strong><?=number_format($stats['void'])?></strong><span>Void Payments</span></div>
      <div class="cp-stat"><strong>৳<?=payment_money($stats['received'])?></strong><span>Total Valid Received</span></div>
    </div>

    <div class="cp-grid">
      <section class="cp-card">
        <div class="cp-card-head"><h2>Consultancy Files</h2></div>
        <div class="cp-table-wrap">
          <?php if(!$files): ?>
            <div class="cp-empty">No consultancy files are available for payment.</div>
          <?php else: ?>
            <table class="cp-table">
              <thead><tr><th>File</th><th>Student</th><th>Fee</th><th>Paid</th><th>Due</th><th>Status</th><th></th></tr></thead>
              <tbody>
              <?php foreach($files as $f):
                $fee=(float)$f['service_fee']; $paid=(float)$f['total_paid']; $due=max(0,$fee-$paid);
                $cls=(string)$f['file_status']==='Processing'?'cp-processing':'cp-open';
              ?>
                <tr>
                  <td><div class="cp-name"><?=e($f['file_no'])?></div><div class="cp-sub"><?=e($f['enquiry_no'])?></div></td>
                  <td><div class="cp-name"><?=e($f['full_name'])?></div><div class="cp-sub"><?=e($f['mobile'])?></div></td>
                  <td>৳<?=payment_money($fee)?></td>
                  <td class="cp-paid">৳<?=payment_money($paid)?></td>
                  <td class="cp-due">৳<?=payment_money($due)?></td>
                  <td><span class="cp-badge <?=$cls?>"><?=e($f['file_status'])?></span></td>
                  <td><div style="display:flex;gap:6px;flex-wrap:wrap"><a class="cp-link" href="consultancy-payments.php?file=<?=e((string)$f['id'])?>">Payments</a><a class="cp-link" href="consultancy-receipts.php?file=<?=e((string)$f['id'])?>">Receipts</a></div></td>
                </tr>
              <?php endforeach; ?>
              </tbody>
            </table>
          <?php endif; ?>
        </div>
      </section>

      <?php if($selectedFile): ?>
      <section class="cp-card">
        <div class="cp-card-head"><h2><?=e($selectedFile['file_no'])?> — Receive Payment</h2></div>
        <div class="cp-body">
          <div class="cp-info-grid">
            <div class="cp-info"><span>Student</span><strong><?=e($selectedFile['full_name'])?></strong></div>
            <div class="cp-info"><span>Country</span><strong><?=e($selectedFile['country_name']??'-')?></strong></div>
            <div class="cp-info"><span>Counselor</span><strong><?=e($selectedFile['counselor_name']??'Unassigned')?></strong></div>
          </div>

          <?php
            $fee=(float)$selectedFile['service_fee'];
            $paid=(float)$selectedFile['total_paid'];
            $due=max(0,$fee-$paid);
          ?>
          <div class="cp-summary">
            <div class="cp-summary-box"><span>Service Fee</span><strong>৳<?=payment_money($fee)?></strong></div>
            <div class="cp-summary-box"><span>Total Paid</span><strong>৳<?=payment_money($paid)?></strong></div>
            <div class="cp-summary-box"><span>Current Due</span><strong>৳<?=payment_money($due)?></strong></div>
          </div>

          <?php if($due > 0.0001 && (string)$selectedFile['file_status'] !== 'Cancelled'): ?>
          <form method="post" class="cp-pay-form">
            <?=csrf_input()?>
            <input type="hidden" name="action" value="add_payment">
            <input type="hidden" name="file_id" value="<?=e((string)$selectedFile['id'])?>">

            <div class="cp-field">
              <label>Current Payment (৳) *</label>
              <input type="number" name="amount" min="0.01" max="<?=e(number_format($due,2,'.',''))?>" step="0.01" required>
            </div>

            <div class="cp-field">
              <label>Payment Method *</label>
              <select name="method">
                <?php foreach($methods as $m): ?><option value="<?=e($m)?>"><?=e($m)?></option><?php endforeach; ?>
              </select>
            </div>

            <div class="cp-field">
              <label>Reference No.</label>
              <input type="text" name="reference_no" maxlength="120" placeholder="bKash/Nagad/Bank reference (if applicable)">
            </div>

            <div class="cp-field">
              <label>Payment Note</label>
              <textarea name="note" maxlength="500"></textarea>
            </div>

            <div class="cp-actions"><button class="cp-btn">Receive Payment</button></div>
          </form>
          <?php elseif($due <= 0.0001): ?>
            <div class="cp-alert cp-success" style="margin-top:10px">This file is fully paid.</div>
          <?php else: ?>
            <div class="cp-alert cp-error" style="margin-top:10px">Payment is disabled because this file is cancelled.</div>
          <?php endif; ?>
        </div>
      </section>
      <?php else: ?>
      <section class="cp-card">
        <div class="cp-card-head"><h2>Payment Instructions</h2></div>
        <div class="cp-body">
          <p style="margin-top:0;color:#666;font-size:13px;line-height:1.7">
            Select a consultancy file from the list to view its service fee, paid amount,
            current due and payment history.
          </p>
        </div>
      </section>
      <?php endif; ?>
    </div>

    <?php if($selectedFile): ?>
    <section class="cp-card cp-detail">
      <div class="cp-card-head"><h2>Payment History — <?=e($selectedFile['file_no'])?></h2></div>
      <div class="cp-table-wrap">
        <?php if(!$payments): ?>
          <div class="cp-empty">No payments recorded for this file yet.</div>
        <?php else: ?>
          <table class="cp-table">
            <thead><tr><th>Payment No.</th><th>Amount</th><th>Method</th><th>Reference</th><th>Received By</th><th>Date</th><th>Status</th><th></th></tr></thead>
            <tbody>
            <?php foreach($payments as $p): ?>
              <tr>
                <td><div class="cp-name"><?=e($p['payment_no'])?></div></td>
                <td>৳<?=payment_money((float)$p['amount'])?></td>
                <td><?=e($p['method'])?></td>
                <td><?=e($p['reference_no']??'-')?></td>
                <td><?=e($p['receiver_name']??((string)($p['received_by']??'-')))?></td>
                <td><?=e(date('d M Y, h:i A',strtotime($p['created_at'])))?></td>
                <td>
                  <span class="cp-badge <?=$p['status']==='Valid'?'cp-valid':'cp-void'?>"><?=e($p['status'])?></span>
                </td>
                <td>
                  <?php if($p['status']==='Valid'): ?>
                    <form method="post" onsubmit="return confirm('Void this payment? This will remove it from the valid paid total.');">
                      <?=csrf_input()?>
                      <input type="hidden" name="action" value="void_payment">
                      <input type="hidden" name="payment_id" value="<?=e((string)$p['id'])?>">
                      <button class="cp-link" type="submit">Void</button>
                    </form>
                  <?php endif; ?>
                </td>
              </tr>
              <?php if(!empty($p['note'])): ?>
                <tr><td colspan="8"><div class="cp-sub">Note: <?=e($p['note'])?></div></td></tr>
              <?php endif; ?>
            <?php endforeach; ?>
            </tbody>
          </table>
        <?php endif; ?>
      </div>
    </section>
    <?php endif; ?>
  <?php endif; ?>
</div>

</main></div></body></html>

<?php
require_once __DIR__ . '/../config/app.php';

$token = trim($_GET['token'] ?? '');
if (!preg_match('/^[a-f0-9]{64}$/i', $token)) {
    http_response_code(404);
    exit('Guardian report not found.');
}

$stmt = $pdo->prepare("SELECT g.id link_id, g.expires_at, s.id student_id, s.student_id student_code, s.full_name, s.guardian_name,
        c.name course_name, b.name batch_name, a.time_slot,
        e.evaluation_month,e.participation,e.homework_assigned,e.homework_completed,e.speaking,e.listening,e.reading,e.writing,e.grammar,e.vocabulary,e.strengths,e.improvement_areas,e.teacher_comment,u.name evaluator_name
        FROM guardian_report_links g
        INNER JOIN performance_evaluations e ON e.id=g.evaluation_id
        INNER JOIN students s ON s.id=g.student_id
        LEFT JOIN users u ON u.id=e.evaluated_by
        LEFT JOIN (SELECT a1.* FROM admissions a1 INNER JOIN (SELECT student_id,MAX(id) max_id FROM admissions GROUP BY student_id) x ON x.student_id=a1.student_id AND x.max_id=a1.id) a ON a.student_id=s.id
        LEFT JOIN courses c ON c.id=a.course_id
        LEFT JOIN batches b ON b.id=a.batch_id
        WHERE g.token=? AND g.status='Active' AND (g.expires_at IS NULL OR g.expires_at>NOW()) LIMIT 1");
$stmt->execute([$token]);
$report = $stmt->fetch();
if (!$report) { http_response_code(404); exit('This guardian report is unavailable or has expired.'); }

$from = $report['evaluation_month'];
$to = date('Y-m-t', strtotime($from));
$att = $pdo->prepare("SELECT COUNT(*) total, SUM(status='Present') present, SUM(status='Absent') absent FROM attendance WHERE student_id=? AND attendance_date BETWEEN ? AND ?");
$att->execute([(int)$report['student_id'],$from,$to]);
$a=$att->fetch() ?: [];
$total=(int)($a['total']??0); $present=(int)($a['present']??0); $absent=(int)($a['absent']??0); $rate=$total?round($present/$total*100,1):0;
$hwAssigned=(int)$report['homework_assigned']; $hwCompleted=(int)$report['homework_completed']; $hwRate=$hwAssigned?round($hwCompleted/$hwAssigned*100):0;
$historyStmt = $pdo->prepare("SELECT evaluation_month, participation, homework_assigned, homework_completed,
    speaking, listening, reading, writing, grammar, vocabulary
    FROM performance_evaluations WHERE student_id=? AND evaluation_month<=?
    ORDER BY evaluation_month DESC LIMIT 6");
$historyStmt->execute([(int)$report['student_id'], $report['evaluation_month']]);
$history = $historyStmt->fetchAll();

// Attendance history for the latest six evaluated months.
$attHistoryStmt = $pdo->prepare("SELECT e.evaluation_month,
    COUNT(a.id) total, SUM(a.status='Present') present
    FROM performance_evaluations e
    LEFT JOIN attendance a ON a.student_id=e.student_id
        AND a.attendance_date BETWEEN e.evaluation_month AND LAST_DAY(e.evaluation_month)
    WHERE e.student_id=? AND e.evaluation_month<=?
    GROUP BY e.evaluation_month
    ORDER BY e.evaluation_month DESC LIMIT 6");
$attHistoryStmt->execute([(int)$report['student_id'], $report['evaluation_month']]);
$attHistory = $attHistoryStmt->fetchAll();
function perf_score(string $v): int {
    return ['Excellent'=>5,'Very Good'=>4,'Good'=>3,'Average'=>2,'Needs Improvement'=>1][$v] ?? 0;
}
$skillLabels = ['speaking'=>'Speaking','listening'=>'Listening','reading'=>'Reading','writing'=>'Writing','grammar'=>'Grammar','vocabulary'=>'Vocabulary'];
$skillScores=[]; $skillTotal=0; $skillCount=0;
foreach($skillLabels as $key=>$label){ $sc=perf_score((string)$report[$key]); $skillScores[$key]=$sc; if($sc){$skillTotal+=$sc;$skillCount++;} }
$overallScore=$skillCount?round($skillTotal/$skillCount,1):0;
$overallPercent=round($overallScore/5*100);
$historyRows = [];
foreach ($history as $h) {
    $sum=0; $count=0;
    foreach (array_keys($skillLabels) as $sk) { $sc=perf_score((string)$h[$sk]); if($sc){$sum+=$sc;$count++;} }
    $historyRows[]=['month'=>date('M Y',strtotime($h['evaluation_month'])),'score'=>$count?round($sum/$count,1):0,'participation'=>$h['participation'],'homework_rate'=>((int)$h['homework_assigned']>0?round(((int)$h['homework_completed']/(int)$h['homework_assigned'])*100):0)];
}

function rr_class(string $v): string { return $v==='Needs Improvement'?'needs':($v==='Excellent'?'excellent':($v==='Very Good'?'verygood':'')); }
?>
<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Guardian Student Report - Edumax</title><style>
*{box-sizing:border-box}body{margin:0;background:#f6f7f9;color:#20242b;font-family:Arial,Helvetica,sans-serif}.wrap{max-width:920px;margin:35px auto;padding:0 16px}.report{background:#fff;border:1px solid #e5e6ea;border-radius:18px;overflow:hidden;box-shadow:0 10px 35px rgba(25,31,40,.07)}.top{padding:26px 28px;border-bottom:1px solid #eee;display:flex;justify-content:space-between;gap:20px}.brand{font-size:21px;font-weight:900;color:#c91f2e}.sub{font-size:12px;color:#777;margin-top:5px}.month{font-weight:800;text-align:right}.body{padding:28px}.student{padding:18px;border:1px solid #ececf0;border-radius:14px}.student h1{margin:0 0 8px;font-size:25px}.meta{color:#666;font-size:13px;line-height:1.8}.stats{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin:18px 0}.stat{padding:17px;border:1px solid #ececf0;border-radius:13px}.stat small{color:#777}.stat strong{display:block;font-size:27px;margin-top:5px}.section{margin-top:24px}.section h2{font-size:16px;margin:0 0 12px}.rating-grid{display:grid;grid-template-columns:repeat(2,1fr);gap:10px}.rating{display:flex;justify-content:space-between;gap:12px;padding:12px 14px;border:1px solid #eee;border-radius:10px}.rating span:last-child{font-weight:800}.rating.excellent span:last-child{color:#18733b}.rating.verygood span:last-child{color:#24724c}.rating.needs span:last-child{color:#b21d2b}.two{display:grid;grid-template-columns:1fr 1fr;gap:14px}.box{padding:15px;border:1px solid #eee;border-radius:12px;white-space:pre-line;line-height:1.65;color:#444}.footer{padding:18px 28px;border-top:1px solid #eee;color:#777;font-size:11px;text-align:center}.history{display:grid;gap:10px}.history-row{display:grid;grid-template-columns:90px 1fr 85px 85px;gap:10px;align-items:center;padding:11px 12px;border:1px solid #eee;border-radius:10px;font-size:12px}.history-head{color:#777;font-weight:700}.bar{height:9px;background:#eef0f3;border-radius:20px;overflow:hidden}.bar>i{display:block;height:100%;background:#c91f2e;border-radius:20px}.security-note{margin-top:18px;padding:11px 13px;border-radius:10px;background:#fafafa;border:1px solid #eee;color:#777;font-size:11px;line-height:1.55}.score-panel{display:grid;grid-template-columns:180px 1fr;gap:22px;align-items:center;padding:18px;border:1px solid #eee;border-radius:14px}.score-ring{width:150px;height:150px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:auto;background:conic-gradient(#c91f2e <?=e((string)$overallPercent)?>%,#eceef1 0);position:relative}.score-ring:after{content:'';position:absolute;width:112px;height:112px;background:#fff;border-radius:50%}.score-value{position:relative;z-index:1;text-align:center;font-size:25px;font-weight:900}.score-value small{display:block;font-size:11px;color:#777;margin-top:2px}.skill-bars{display:grid;gap:10px}.skill-line{display:grid;grid-template-columns:95px 1fr 48px;gap:10px;align-items:center;font-size:12px}.skill-track{height:10px;background:#eef0f3;border-radius:20px;overflow:hidden}.skill-fill{height:100%;background:#c91f2e;border-radius:20px}.attendance-history{display:grid;grid-template-columns:repeat(6,1fr);gap:10px}.att-month{padding:12px 9px;border:1px solid #eee;border-radius:11px;text-align:center}.att-month strong{display:block;font-size:17px;margin-top:4px}.att-month small{color:#777;font-size:10px}.att-track{height:7px;background:#eef0f3;border-radius:20px;margin-top:9px;overflow:hidden}.att-fill{height:100%;background:#5f5f63;border-radius:20px}@media(max-width:650px){.history-row{grid-template-columns:1fr 1fr}.history-head{display:none}}.print{display:flex;justify-content:flex-end;margin-bottom:12px}.print{gap:8px;flex-wrap:wrap}.print button{border:0;background:#c91f2e;color:#fff;padding:10px 15px;border-radius:9px;font-weight:700;cursor:pointer}.print button:nth-child(1),.print button:nth-child(2){background:#5f5f63}@media(max-width:650px){.score-panel{grid-template-columns:1fr}.attendance-history{grid-template-columns:repeat(2,1fr)}.top{flex-direction:column}.month{text-align:left}.stats,.rating-grid,.two{grid-template-columns:1fr}.body{padding:18px}}@media print{@page{size:A4 portrait;margin:12mm}body{background:#fff}.wrap{margin:0;max-width:none}.print{display:none}.report{border:0;box-shadow:none}}
</style></head><body><div class="wrap"><div class="print">
<button type="button" onclick="copyReportLink()">Copy Link</button>
<button type="button" onclick="shareWhatsApp()">WhatsApp</button>
<button type="button" onclick="window.print()">Print / Save PDF</button>
</div>
<script>
const guardianReportUrl = <?=json_encode(
    (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' ? 'https' : 'http')
    . '://' . ($_SERVER['HTTP_HOST'] ?? 'localhost')
    . ($_SERVER['SCRIPT_NAME'] ?? '/guardian-report.php')
    . '?token=' . urlencode($token),
    JSON_UNESCAPED_SLASHES
)?>;
function copyReportLink(){
    navigator.clipboard.writeText(guardianReportUrl).then(function(){
        alert('Guardian report link copied.');
    }).catch(function(){ prompt('Copy this link:', guardianReportUrl); });
}
function shareWhatsApp(){
    window.open('https://wa.me/?text=' + encodeURIComponent('Edumax Student Performance & Guardian Report\n' + guardianReportUrl), '_blank', 'noopener');
}
</script><div class="report"><div class="top"><div><div class="brand">EDUMAX IELTS Center</div><div class="sub">Student Performance & Guardian Report</div></div><div class="month"><?=e(date('F Y',strtotime($report['evaluation_month'])))?><div class="sub">Prepared for Guardian</div></div></div><div class="body"><div class="student"><h1><?=e($report['full_name'])?></h1><div class="meta"><strong>Student ID:</strong> <?=e($report['student_code'])?> &nbsp; | &nbsp; <strong>Course:</strong> <?=e($report['course_name']?:'-')?><br><strong>Batch:</strong> <?=e($report['batch_name']?:'-')?><?=!empty($report['time_slot'])?' | '.e($report['time_slot']):''?><br><strong>Guardian:</strong> <?=e($report['guardian_name']?:'-')?></div></div><div class="stats"><div class="stat"><small>Attendance</small><strong><?=e((string)$rate)?>%</strong><span><?=number_format($present)?> present / <?=number_format($total)?> classes</span></div><div class="stat"><small>Homework / Assigned Work</small><strong><?=e((string)$hwRate)?>%</strong><span><?=number_format($hwCompleted)?> / <?=number_format($hwAssigned)?> completed</span></div><div class="stat"><small>Class Participation</small><strong style="font-size:18px"><?=e($report['participation'])?></strong></div></div><div class="section"><h2>Attendance Progress</h2><div class="attendance-history"><?php foreach(array_reverse($attHistory) as $ah): $at=(int)$ah['total']; $ap=(int)$ah['present']; $ar=$at?round($ap/$at*100):0; ?><div class="att-month"><small><?=e(date('M Y',strtotime($ah['evaluation_month'])))?></small><strong><?=e((string)$ar)?>%</strong><div class="att-track"><div class="att-fill" style="width:<?=e((string)$ar)?>%"></div></div><small><?=e((string)$ap)?> / <?=e((string)$at)?> present</small></div><?php endforeach; ?><?php if(!$attHistory): ?><div class="box">No attendance history is available.</div><?php endif; ?></div></div><div class="section"><h2>Overall Learning Performance</h2><div class="score-panel"><div class="score-ring"><div class="score-value"><?=e((string)$overallScore)?><small>/ 5.0</small></div></div><div class="skill-bars"><?php foreach($skillLabels as $key=>$label): $sc=$skillScores[$key]; ?><div class="skill-line"><span><?=e($label)?></span><div class="skill-track"><div class="skill-fill" style="width:<?=e((string)round($sc/5*100))?>%"></div></div><strong><?=e($report[$key])?></strong></div><?php endforeach; ?></div></div></div><div class="section two"><div><h2>Strengths</h2><div class="box"><?=e($report['strengths']?:'No specific strengths were recorded for this period.')?></div></div><div><h2>Areas to Improve</h2><div class="box"><?=e($report['improvement_areas']?:'No specific improvement area was recorded for this period.')?></div></div></div><div class="section"><h2>Progress History</h2><div class="history">
<div class="history-row history-head"><span>Month</span><span>Overall Skill</span><span>Participation</span><span>Homework</span></div>
<?php foreach($historyRows as $hr): ?><div class="history-row"><span><strong><?=e($hr['month'])?></strong></span><span><div class="bar" title="<?=e((string)$hr['score'])?> / 5"><i style="width:<?=e((string)round($hr['score']/5*100))?>%"></i></div></span><span><?=e($hr['participation'])?></span><span><?=e((string)$hr['homework_rate'])?>%</span></div><?php endforeach; ?>
<?php if(!$historyRows): ?><div class="box">No previous monthly evaluations are available.</div><?php endif; ?></div></div><div class="section"><h2>Teacher's Comment</h2><div class="box"><?=e($report['teacher_comment']?:'No teacher comment was added for this period.')?></div></div><div class="security-note"><strong>Privacy:</strong> This is a private, read-only guardian report link. Please do not post or forward the link publicly.</div><div class="section" style="font-size:12px;color:#777">This report is a learning progress summary prepared by Edumax. It is intended for the student's guardian and should not be treated as an official examination result.</div></div><div class="footer"><span>EDUMAX IELTS Center | Mobile: 01968-373223, 01968-373227</span><span>QR Tower (Lift-6), Badurtala, 1st Kandirpar, Cumilla</span></div></div></div></body></html>

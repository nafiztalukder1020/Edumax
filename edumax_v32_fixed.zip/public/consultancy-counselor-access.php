<?php
declare(strict_types=1);
require_once __DIR__ . '/../config/app.php';
require_access('consultancy_dashboard');
$_SESSION['workspace']='consultancy';
$error='';$success='';

if($_SERVER['REQUEST_METHOD']==='POST'){
    require_valid_csrf();
    try{
        $id=(int)($_POST['counselor_id']??0);
        $username=trim((string)($_POST['username']??''));
        $password=(string)($_POST['password']??'');

        if($id<=0) throw new RuntimeException('Select a counselor.');
        if($username==='') throw new RuntimeException('Username is required.');
        if(strlen($password)<6) throw new RuntimeException('Password must be at least 6 characters.');

        $q=$pdo->prepare("SELECT id FROM consultancy_counselors WHERE id=? AND status='Active' LIMIT 1");
        $q->execute([$id]);
        if(!$q->fetchColumn()) throw new RuntimeException('Active counselor not found.');

        $check=$pdo->prepare("SELECT id FROM consultancy_counselors WHERE username=? AND id<>? LIMIT 1");
        $check->execute([$username,$id]);
        if($check->fetchColumn()) throw new RuntimeException('This username is already used by another counselor.');

        $u=$pdo->prepare("UPDATE consultancy_counselors SET username=?,password_hash=?,updated_by=? WHERE id=?");
        $u->execute([$username,password_hash($password,PASSWORD_DEFAULT),(int)($_SESSION['user_id']??0),$id]);
        $success='Counselor username and password updated successfully.';
    }catch(Throwable $x){
        $error=$x instanceof RuntimeException?$x->getMessage():'Unable to update counselor access.';
    }
}

$c=$pdo->query("SELECT id,counselor_name,username,status,CASE WHEN password_hash IS NULL OR password_hash='' THEN 0 ELSE 1 END AS has_password FROM consultancy_counselors ORDER BY counselor_name")->fetchAll();
?>
<?php require_once __DIR__ . '/_header.php'; ?>
<style>.ca{max-width:1000px;margin:28px auto;padding:0 18px}.card{background:#fff;border:1px solid #e5e8ec;border-radius:14px;padding:20px;margin-bottom:16px}.row{display:grid;grid-template-columns:1.2fr .8fr .8fr 1fr auto;gap:10px;align-items:center;padding:12px 0;border-bottom:1px solid #eee}.row:last-child{border:0}.muted{font-size:11px;color:#777}.field{width:100%;padding:9px;border:1px solid #ddd;border-radius:8px}.btn{border:0;border-radius:8px;padding:9px 12px;background:#c91f2e;color:#fff;font-weight:800;cursor:pointer}.ok,.err{padding:11px;border-radius:9px;margin-bottom:12px;font-size:12px}.ok{background:#eefaf2;color:#176b39}.err{background:#fff1f2;color:#a71928}@media(max-width:850px){.row{grid-template-columns:1fr}.row form{display:grid;grid-template-columns:1fr auto;gap:8px}}</style>
<div class="ca"><h1>Counselor Access</h1><p class="muted">Admin only — create or reset the separate Counselor Workspace login.</p>
<?php if($success):?><div class="ok"><?=e($success)?></div><?php endif;?><?php if($error):?><div class="err"><?=e($error)?></div><?php endif;?>
<div class="card">
<?php if(!$c):?><div class="muted">No counselors found.</div><?php else: foreach($c as $x):?>
<div class="row">
<div><strong><?=e($x['counselor_name'])?></strong><div class="muted">Current username: <?=e($x['username']?:'Not set')?></div></div>
<div><span class="muted">Status</span><br><?=e($x['status'])?></div>
<div><span class="muted">Password</span><br><?=((int)$x['has_password']===1)?'Configured':'Not configured'?></div>
<form method="post">
<?=csrf_input()?>
<input type="hidden" name="counselor_id" value="<?=e((string)$x['id'])?>">
<input class="field" type="text" name="username" value="<?=e((string)($x['username']??''))?>" placeholder="Username" required>
<input class="field" type="password" name="password" minlength="6" placeholder="New password" required>
<button class="btn" type="submit">Save Login</button>
</form>
</div>
<?php endforeach; endif;?>
</div>
</div>
</body></html>

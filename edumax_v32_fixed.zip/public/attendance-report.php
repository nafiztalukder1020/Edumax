<?php
require_once __DIR__ . '/../config/app.php';
require_access('attendance');
$from = $_GET['from'] ?? date('Y-m-01');
$to   = $_GET['to'] ?? date('Y-m-d');
$batchId = (int)($_GET['batch_id'] ?? 0);
$status = $_GET['status'] ?? '';

$validStatuses = ['Present','Absent'];
if (!in_array($status, $validStatuses, true)) $status = '';

$batches = $pdo->query("
    SELECT id, name
    FROM batches
    ORDER BY name ASC, id ASC
")->fetchAll();

$where = ["a.attendance_date BETWEEN ? AND ?"];
$params = [$from, $to];

if ($batchId > 0) {
    $where[] = "a.batch_id = ?";
    $params[] = $batchId;
}
if ($status !== '') {
    $where[] = "a.status = ?";
    $params[] = $status;
}

$whereSql = implode(' AND ', $where);

$summaryStmt = $pdo->prepare("
    SELECT
        COUNT(*) AS total_marked,
        SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_count,
        SUM(CASE WHEN a.status='Absent' THEN 1 ELSE 0 END) AS absent_count
    FROM attendance a
    WHERE $whereSql
");
$summaryStmt->execute($params);
$summary = $summaryStmt->fetch() ?: [
    'total_marked'=>0,'present_count'=>0,'absent_count'=>0
];

$attendanceRate = ((int)$summary['total_marked'] > 0)
    ? round(((int)$summary['present_count'] / (int)$summary['total_marked']) * 100, 1)
    : 0;

$stmt = $pdo->prepare("
    SELECT
        a.id,
        a.attendance_date,
        a.status,
        s.student_id AS student_code,
        s.full_name,
        s.mobile,
        b.name AS batch_name
    FROM attendance a
    INNER JOIN students s ON s.id = a.student_id
    INNER JOIN batches b ON b.id = a.batch_id
    WHERE $whereSql
    ORDER BY a.attendance_date DESC, b.name ASC, s.full_name ASC
");
$stmt->execute($params);
$rows = $stmt->fetchAll();

$byDate = [];
foreach ($rows as $row) {
    $dateKey = $row['attendance_date'];
    $byDate[$dateKey][] = $row;
}

// Student-wise summary for the selected date range/batch.
$studentSummaryStmt = $pdo->prepare("
    SELECT
        s.student_id AS student_code,
        s.full_name,
        s.mobile,
        b.name AS batch_name,
        COUNT(*) AS total_classes,
        SUM(CASE WHEN a.status='Present' THEN 1 ELSE 0 END) AS present_classes,
        SUM(CASE WHEN a.status='Absent' THEN 1 ELSE 0 END) AS absent_classes
    FROM attendance a
    INNER JOIN students s ON s.id = a.student_id
    INNER JOIN batches b ON b.id = a.batch_id
    WHERE $whereSql
    GROUP BY a.student_id, a.batch_id, s.student_id, s.full_name, s.mobile, b.name
    ORDER BY s.full_name ASC
");
$studentSummaryStmt->execute($params);
$studentSummaries = $studentSummaryStmt->fetchAll();

require '_header.php';
?>
<style>
.report-head{display:flex;justify-content:space-between;align-items:flex-end;gap:18px;margin-bottom:20px}
.report-head h1{margin:0;font-size:25px}.report-head p{margin:6px 0 0;color:#737982}
.filters{display:flex;flex-wrap:wrap;gap:12px;align-items:end}
.filters label{display:block;font-size:12px;font-weight:700;margin-bottom:6px;color:#5f636b}
.filters input,.filters select{height:42px;border:1px solid #e2e4e8;border-radius:10px;padding:0 12px;background:#fff}
.filters .btn{height:42px}
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:14px;margin-bottom:20px}
.stat{background:#fff;border:1px solid #e8e9ed;border-radius:14px;padding:18px;box-shadow:0 8px 30px rgba(25,31,40,.05)}
.stat small{color:#737982}.stat strong{display:block;font-size:25px;margin-top:6px}
.day-card{background:#fff;border:1px solid #e8e9ed;border-radius:16px;margin-bottom:16px;overflow:hidden}
.day-title{padding:14px 18px;background:#f8f8fa;font-weight:800;border-bottom:1px solid #e8e9ed}
.table-wrap{overflow:auto}.data-table{width:100%;border-collapse:collapse}.data-table th,.data-table td{padding:12px 14px;border-bottom:1px solid #eee;text-align:left;font-size:13px}.data-table th{font-size:11px;text-transform:uppercase;color:#737982;letter-spacing:.04em}
.badge{display:inline-flex;padding:5px 9px;border-radius:999px;font-size:11px;font-weight:800}.present{background:#eaf8ef;color:#18733b}.absent{background:#fff0f1;color:#b21d2b}
.empty{padding:40px;text-align:center;color:#737982;background:#fff;border:1px dashed #d9dce1;border-radius:16px}
@media(max-width:900px){.stats{grid-template-columns:repeat(2,1fr)}.report-head{align-items:flex-start;flex-direction:column}}
@media(max-width:560px){.stats{grid-template-columns:1fr}.filters>*{width:100%}.filters input,.filters select,.filters .btn{width:100%}}
</style>

<div class="page">
    <div class="report-head">
        <div>
            <h1>Attendance Report</h1>
            <p>Review attendance by date, batch and student.</p>
        </div>
        <form class="filters" method="get">
            <div>
                <label>From</label>
                <input type="date" name="from" value="<?=e($from)?>">
            </div>
            <div>
                <label>To</label>
                <input type="date" name="to" value="<?=e($to)?>">
            </div>
            <div>
                <label>Batch</label>
                <select name="batch_id">
                    <option value="0">All Batches</option>
                    <?php foreach($batches as $b): ?>
                        <option value="<?=$b['id']?>" <?=$batchId===(int)$b['id']?'selected':''?>>
                            <?=e($b['name'])?>
                        </option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div>
                <label>Status</label>
                <select name="status">
                    <option value="">All</option>
                    <option value="Present" <?=$status==='Present'?'selected':''?>>Present</option>
                    <option value="Absent" <?=$status==='Absent'?'selected':''?>>Absent</option>
                </select>
            </div>
            <button class="btn btn-primary" type="submit">Apply Filter</button>
        </form>
    </div>

    <div class="stats">
        <div class="stat"><small>Total Marked</small><strong><?=number_format((int)$summary['total_marked'])?></strong></div>
        <div class="stat"><small>Present</small><strong><?=number_format((int)$summary['present_count'])?></strong></div>
        <div class="stat"><small>Absent</small><strong><?=number_format((int)$summary['absent_count'])?></strong></div>
        <div class="stat"><small>Attendance Rate</small><strong><?=e((string)$attendanceRate)?>%</strong></div>
    </div>

    <?php if (!$studentSummaries): ?>
        <div class="empty">No attendance records found for the selected filters.</div>
    <?php else: ?>
        <section class="day-card" style="margin-bottom:18px">
            <div class="day-title">Student-wise Attendance Summary</div>
            <div class="table-wrap">
                <table class="data-table">
                    <thead><tr>
                        <th>Student ID</th><th>Student</th><th>Mobile</th><th>Batch</th>
                        <th>Total Classes</th><th>Present</th><th>Absent</th><th>Attendance</th>
                    </tr></thead>
                    <tbody>
                    <?php foreach($studentSummaries as $r): ?>
                        <?php $rate = ((int)$r['total_classes'] > 0) ? round(((int)$r['present_classes'] / (int)$r['total_classes']) * 100, 1) : 0; ?>
                        <tr>
                            <td><?=e($r['student_code'])?></td>
                            <td><strong><?=e($r['full_name'])?></strong></td>
                            <td><?=e($r['mobile'])?></td>
                            <td><?=e($r['batch_name'])?></td>
                            <td><?=number_format((int)$r['total_classes'])?></td>
                            <td><?=number_format((int)$r['present_classes'])?></td>
                            <td><?=number_format((int)$r['absent_classes'])?></td>
                            <td><strong><?=e((string)$rate)?>%</strong></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>

        <?php foreach($byDate as $date => $items): ?>
            <section class="day-card">
                <div class="day-title"><?=e(date('l, d M Y', strtotime($date)))?> <span style="color:#737982;font-weight:600">(<?=count($items)?> records)</span></div>
                <div class="table-wrap">
                    <table class="data-table">
                        <thead><tr>
                            <th>Student ID</th><th>Student</th><th>Mobile</th><th>Batch</th><th>Status</th>
                        </tr></thead>
                        <tbody>
                        <?php foreach($items as $r): ?>
                            <tr>
                                <td><?=e($r['student_code'])?></td>
                                <td><?=e($r['full_name'])?></td>
                                <td><?=e($r['mobile'])?></td>
                                <td><?=e($r['batch_name'])?></td>
                                <td><span class="badge <?=$r['status']==='Present'?'present':'absent'?>"><?=e($r['status'])?></span></td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </section>
        <?php endforeach; ?>
    <?php endif; ?>
</div>

<?php
/**
 * Edumax Batch Capacity Helper
 * Source of truth: Batch Management.
 * No fixed 50-student ceiling.
 */
if (!function_exists('edumax_ensure_batch_capacity_column')) {
    function edumax_ensure_batch_capacity_column(PDO $pdo): void
    {
        try {
            $pdo->exec("ALTER TABLE batches ADD COLUMN max_students INT UNSIGNED NOT NULL DEFAULT 50 AFTER schedule_months");
        } catch (Throwable $e) {}
        try {
            $pdo->exec("ALTER TABLE batches ADD COLUMN slot_capacities TEXT NULL AFTER max_students");
        } catch (Throwable $e) {}
    }
}

if (!function_exists('edumax_ensure_capacity_override_columns')) {
    function edumax_ensure_capacity_override_columns(PDO $pdo): void
    {
        try {
            $pdo->exec("ALTER TABLE admissions ADD COLUMN capacity_override TINYINT UNSIGNED NOT NULL DEFAULT 0 AFTER time_slot");
        } catch (Throwable $e) {}
        try {
            $pdo->exec("ALTER TABLE admissions ADD COLUMN capacity_override_reason VARCHAR(255) NULL AFTER capacity_override");
        } catch (Throwable $e) {}
        try {
            $pdo->exec("ALTER TABLE admissions ADD COLUMN capacity_override_by INT UNSIGNED NULL AFTER capacity_override_reason");
        } catch (Throwable $e) {}
    }
}

if (!function_exists('edumax_batch_capacity_map')) {
    function edumax_batch_capacity_map(PDO $pdo, int $batchId): array
    {
        $q = $pdo->prepare("SELECT COALESCE(max_students,50) AS max_students, slot_capacities FROM batches WHERE id=? LIMIT 1");
        $q->execute([$batchId]);
        $row = $q->fetch();

        if (!$row) return ['default' => 50, 'slots' => []];

        $default = max(1, (int)($row['max_students'] ?? 50));
        $slots = json_decode((string)($row['slot_capacities'] ?? ''), true);
        $slots = is_array($slots) ? $slots : [];

        $clean = [];
        foreach ($slots as $slot => $capacity) {
            $slot = trim((string)$slot);
            if ($slot === '') continue;
            $clean[$slot] = max(1, (int)$capacity);
        }

        return ['default' => $default, 'slots' => $clean];
    }
}

if (!function_exists('edumax_batch_capacity')) {
    function edumax_batch_capacity(PDO $pdo, int $batchId, ?string $timeSlot = null): int
    {
        $map = edumax_batch_capacity_map($pdo, $batchId);
        if ($timeSlot !== null) {
            $timeSlot = trim($timeSlot);
            if ($timeSlot !== '' && array_key_exists($timeSlot, $map['slots'])) {
                return max(1, (int)$map['slots'][$timeSlot]);
            }
        }
        return max(1, (int)$map['default']);
    }
}

if (!function_exists('edumax_batch_slot_count')) {
    function edumax_batch_slot_count(PDO $pdo, int $batchId, string $timeSlot, ?int $excludeAdmissionId = null): int
    {
        $sql = "SELECT COUNT(*) FROM admissions WHERE batch_id=? AND time_slot=? AND status <> 'Cancelled'";
        $params = [$batchId, $timeSlot];
        if ($excludeAdmissionId !== null) {
            $sql .= " AND id<>?";
            $params[] = $excludeAdmissionId;
        }
        $q = $pdo->prepare($sql);
        $q->execute($params);
        return (int)$q->fetchColumn();
    }
}

if (!function_exists('edumax_lock_and_assert_batch_slot_available')) {
    function edumax_lock_and_assert_batch_slot_available(PDO $pdo, int $batchId, string $timeSlot, ?int $excludeAdmissionId = null, bool $allowCapacityOverride = false): void
    {
        $timeSlot = trim($timeSlot);
        if ($batchId <= 0 || $timeSlot === '') {
            throw new RuntimeException('Batch and time slot are required.');
        }

        $q = $pdo->prepare("
            SELECT id,status,time_slots,is_archived,max_students,slot_capacities
            FROM batches WHERE id=? FOR UPDATE
        ");
        $q->execute([$batchId]);
        $batch = $q->fetch();

        if (!$batch) throw new RuntimeException('Selected batch was not found.');
        if ((int)($batch['is_archived'] ?? 0) === 1) {
            throw new RuntimeException('Archived batches cannot receive students.');
        }
        if (($batch['status'] ?? '') === 'Closed') {
            throw new RuntimeException('Closed batches cannot receive students.');
        }

        $slots = json_decode((string)($batch['time_slots'] ?? ''), true);
        if (!is_array($slots) || !in_array($timeSlot, $slots, true)) {
            throw new RuntimeException('Selected time slot is not available in this batch.');
        }

        $capacity = max(1, (int)($batch['max_students'] ?? 50));
        $slotCaps = json_decode((string)($batch['slot_capacities'] ?? ''), true);
        if (is_array($slotCaps) && array_key_exists($timeSlot, $slotCaps)) {
            $capacity = max(1, (int)$slotCaps[$timeSlot]);
        }

        $current = edumax_batch_slot_count($pdo, $batchId, $timeSlot, $excludeAdmissionId);

        if ($current >= $capacity && !$allowCapacityOverride) {
            throw new RuntimeException(
                'This time slot is FULL (' . $current . '/' . $capacity . '). Please select another time slot or use the authorized capacity override.'
            );
        }
    }
}

if (!function_exists('edumax_assert_batch_slot_available')) {
    function edumax_assert_batch_slot_available(PDO $pdo, int $batchId, string $timeSlot, ?int $excludeAdmissionId = null): void
    {
        edumax_lock_and_assert_batch_slot_available($pdo, $batchId, $timeSlot, $excludeAdmissionId);
    }
}

</main>
</div>
<footer class="app-footer">EDUMAX Admission Management System</footer>
<script>
(function () {
    var body = document.body;
    var sidebar = document.getElementById('sidebar');

    document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') body.classList.remove('sidebar-open');
    });

    if (sidebar) {
        sidebar.addEventListener('click', function (event) {
            if (window.innerWidth <= 760 && event.target.closest('a')) {
                body.classList.remove('sidebar-open');
            }
        });
    }
})();
</script>
</body>
</html>
